# GameLingo — sınırlı Google girdi düzeltmesi (kaynak kod)

Temel: kullanıcının çalışan 10.12 kaynak paketi `altyazi-src.zip`.

**Değişenler**
- `OfflineFix.kt`: Google'a gitmeden önce `Slang.normalize` ve `SlangNormalizer.normalize` uygulanmıyor. OCR sonrası mevcut özgün İngilizce Google'a gönderiliyor; `NameShield` yalnız özel adları koruyor.
- Google başarısız olunca Firefox/ML Kit ve mevcut argo/küfür işleme zinciri korunuyor. API anahtarı/Gemini eklenmedi, çeviri motorları kaldırılmadı.
- `TranslationStore.HIZLI_SURUM` 2→3: önceki otomatik **hızlı çeviri** önbelleği ilk açılışta temizlenir ki eski, yanlış çeviriler görünmesin. Kullanıcının `Sözlüğüm` girdilerine ve yapay zekâ hafızasına dokunulmaz.
- `versionCode` 146→151, `versionName` 10.12→10.18; önceki 10.17 (kod 150) üzerine derlenip kurulabilsin.

**Değişmeyenler**
- OCR, ekran yakalama, hız ayarları, döndürme, overlay, Firefox, ML Kit, isim koruma ve argo/küfür fallback davranışı.

**Sınırlar**
- Bu kaynak ZIP'tir, **APK değildir**. Android'de derlenip/çalıştırılıp test edilmedi.
- Google'ın bağlamsız kısa cümleleri yanlış çevirmesi veya OCR'nin bölünmüş cümleleri tek başına çevirmesi bu yama ile bütünüyle çözülmez.
- Anahtarsız Google arayüzü resmî API değildir; kota/bağlantı garantisi yoktur.
