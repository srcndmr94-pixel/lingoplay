#!/usr/bin/env python3
"""10.18: Üretim kodundaki Google yolunu ve ad-kalkanını Kotlin ile gerçekten çalıştırır.
Android SDK gerektirmeyen dar test; tam APK/cihaz testi DEĞİLDİR.
"""
from pathlib import Path
import subprocess, tempfile, sys, re
root = Path(__file__).resolve().parents[1]
src = (root/'app/src/main/java/com/example/altyazi/OfflineFix.kt').read_text()
name_start = src.index('object NameShield {')
name_end = src.index('/** Uygulama genelinde tek örnek. */', name_start)
name = src[name_start:name_end]
method_start = src.index('    private suspend fun mlTranslate(text: String): String {')
method_end = src.index('    /**\n     * Virgülle ayrılmış TEK PARÇA hitaplar', method_start)
method = src[method_start:method_end]
assert 'val k = NameShield.shield(text)' in method
assert 'SlangNormalizer.normalize(Slang.normalize(text))' in method
assert not re.search(r'val k = NameShield.shield\(Slang', method)
kotlin = r'''
package com.example.altyazi
import kotlin.coroutines.*
object Sozluk { const val hazir = true; fun icinde(w: String) = w != "mark" }
object AdDefteri { fun adMi(w: String) = false }
''' + name + r'''
object Slang { fun normalize(s: String) = "SLANG:" + s }
object SlangNormalizer { fun normalize(s: String) = "NORM:" + s }
object ProfanityShield {
  class Shield(val text: String) { val slots = emptyList<String>(); val tails = emptyList<String>() }
  fun shield(s: String) = Shield(s)
  fun addTails(s: String, tails: List<String>) = s
  fun restore(s: String, slots: List<String>, tr: java.util.Locale): String? = s
  fun unshield(s: String, slots: List<String>) = s
}
class TestEngine {
    val tr = java.util.Locale("tr")
    var gucluFn: (suspend (String) -> String?)? = null
    var fallbackCount = 0
    private suspend fun base(s: String): String { fallbackCount++; return "YEDEK:" + s }
    private fun fix(s: String) = s
''' + method.replace('    private suspend fun mlTranslate(', '    suspend fun mlTranslate(') + r'''
}
fun <T> call(block: suspend () -> T): T {
  var result: Result<T>? = null
  block.startCoroutine(object : Continuation<T> {
    override val context = EmptyCoroutineContext
    override fun resumeWith(r: Result<T>) { result = r }
  })
  return checkNotNull(result).getOrThrow()
}
fun main() {
  val t = TestEngine()
  var seen = ""
  t.gucluFn = { source -> seen = source; "Doğru Türkçe" }
  check(call { t.mlTranslate("Where the fuck you at?") } == "Doğru Türkçe")
  check(seen == "Where the fuck you at?") { "Google'a küfür/argo değiştirilerek gidiyor: $seen" }
  check(t.fallbackCount == 0)

  t.gucluFn = { source -> seen = source; "Qx1 bir süper kahraman." }
  check(call { t.mlTranslate("Mark is a superhero.") } == "Mark bir süper kahraman.")
  check(seen == "Qx1 is a superhero.") { "Özel ad korunmadı: $seen" }

  t.gucluFn = { null }
  val backup = call { t.mlTranslate("This is fucked up!") }
  check(backup == "YEDEK:NORM:SLANG:This is fucked up!") { "Yedek yol bozuldu: $backup" }

  t.gucluFn = { "İsim kayboldu" }
  val missing = call { t.mlTranslate("Mark is a superhero.") }
  check(missing.startsWith("YEDEK:")) { "Google özel adı kaybettiğinde yedek kullanılmadı: $missing" }

  println("Kotlin testleri geçti: ham Google girişi, küfür korunumu, özel ad geri koyma, iki yedek senaryosu.")
}
'''
with tempfile.TemporaryDirectory() as td:
    p = Path(td)/'GoogleBranch.kt'; p.write_text(kotlin)
    jar = Path(td)/'google-test.jar'
    c = subprocess.run(['kotlinc',str(p),'-include-runtime','-d',str(jar)],capture_output=True,text=True,timeout=80)
    if c.returncode:
        print(c.stdout+c.stderr);sys.exit(c.returncode)
    r = subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,timeout=20)
    print(r.stdout+r.stderr)
    sys.exit(r.returncode)
