# GameLingo 10.20 — temkinli çeviri kalitesi düzeltmesi

Taban: GameLingo 10.19 kaynak kodu. Google/Firefox/ML Kit/yerel AI, OCR yakalama, overlay ve ayarlar aynı bırakıldı.

Doğrulanan kod değişiklikleri:
- `Phrases.kt`: yalnız tam cümle eşleşmesinde `I'm coming, too.` → `Ben de geliyorum`, `I love you, too.` → `Ben de seni seviyorum`. `too late`, `too much` etkilenmez.
- `SubtitlePreparation.kt` + `OfflineFix.kt`: Google'a giden, cümle sonunda virgülle ayrılmış `too` kelimesi `as well` olarak hazırlanır. Diğer İngilizce metinler ve Google başarısızsa kullanılan yedek çeviri yolu korunur.
- `AdDefteri` + `NameShield`: `Wait, Art.` gibi açık seslenmelerden üç harfli isimler öğrenilebilir; `Art` diğer cümlelerde otomatik isim sanılmaz.
- `DialogueContextRepair.kt` + `CaptureService.kt`: daha önce doğrulanmış `Paul` yakın geçmişte mevcutsa `Pout's` OCR okuması `Paul's` olur; aksi halde değişmez. Aynı OCR karesi tekrarlandığında isim geçmişi yanlış ilerlemez. Önceden doğrulanmış altyazıların gösterim ve çeviri sırası değiştirilmedi.
- Hızlı çeviri hafızası 4→5; eski hızlı çeviri yanlış kayıtları tek seferlik yenilenir. `Sözlüğüm` ve AI hafızası etkilenmez.
- Sürüm adı 10.20, versionCode 153.

Test sonuçları:
- Tarayıcı gerektirmeyen 59 Python test betiği geçti; ayrıca statik denetleyici geçti.
- `DialogueContextTest.kt`: 16 test/koruma kontrolü (60 kez yinelenen aynı altyazı denetimi ayrıca) geçti.
- Üretim `AdDefteri` ve `NameShield` kodunu çalıştıran 6 Kotlin kontrolü geçti.
- Google ham-yol / özel ad / küfür / yedek motor Kotlin testi geçti.
- Eski `SubtitlePreparationTest.kt` ve `SubtitleQualityTest.kt` Kotlin kontrolleri ayrıca doğrulanabilir.

Sınır: Chrome Playwright testleri bu ortamda Chromium yüklenmediğinden çalıştırılamadı. Android SDK/Gradle olmadığı için APK üretilmedi ve telefonda kalite testi yapılmadı. Ayrı ekran altyazılarının tam gramer bağlamı hâlâ çözümlenmedi; bunu düzelmiş gibi göstermiyoruz.
