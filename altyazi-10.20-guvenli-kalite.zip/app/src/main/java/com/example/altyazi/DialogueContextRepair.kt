package com.example.altyazi

/**
 * Güvenli oturum-içi isim onarımı. Yalnız kabul edilen altyazılar hatırlanır.
 * "Pout's" ancak yakın geçmişte "Paul" adı açık bağlamda geçerse "Paul's" olur.
 * Kanıt yoksa metin değiştirilmez. Yeni ağ isteği/çeviri gecikmesi yoktur.
 */
class DialogueContextRepair {
    private var acceptedCount = 0
    private var lastPaulAt = -1
    private val paulEvidence = Regex("\\b(?:with\\s+Paul|about\\s+this\\s+Paul\\s+guy|Paul\\s+is)\\b")
    private val likelyPoutName = Regex("\\bPout(?=['’]s\\b)")

    fun reset() {
        acceptedCount = 0
        lastPaulAt = -1
    }

    /** Saf işlem: aynı kare birden çok kez okunsa da geçmişi ilerletmez. */
    fun repair(text: String): String {
        if (lastPaulAt == -1 || acceptedCount - lastPaulAt > 40) return text
        return likelyPoutName.replace(text, "Paul")
    }

    /** Gerçekten çevirmeye alınan altyazıdan öğrenir. */
    fun remember(acceptedSubtitle: String) {
        acceptedCount++
        if (paulEvidence.containsMatchIn(acceptedSubtitle)) lastPaulAt = acceptedCount
    }
}
