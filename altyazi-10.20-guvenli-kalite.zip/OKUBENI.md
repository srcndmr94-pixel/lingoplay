# GameLingo 10.20 kaynak ZIP

Bu **APK değildir**. Google/Firefox çeviri motorlarını bozmadan sınırlı üç hata grubuna yönelik düzeltme içerir: cümle sonundaki “too”, üç harfli kişi adı ve bağlamda Paul varken Pout OCR okuması. Kararlı eski APK'yi silmeyin.

Derleme: Bu ZIP'i GitHub Actions kaynak seçimine uygun `altyazi` adıyla kullanın. Yeni APK'nın sürüm başlığı 10.20 olmalıdır. Android cihazda çalışması henüz doğrulanmamıştır.

Değişikliklerin ve test sınırlamalarının ayrıntısı: `GUNCELLEME-NOTU.md`.
