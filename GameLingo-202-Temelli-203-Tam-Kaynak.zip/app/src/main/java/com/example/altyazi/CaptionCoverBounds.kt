package com.example.altyazi

/** Pure coordinate mapping; source box, not a fixed percentage, owns placement. */
object CaptionCoverBounds {
    data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int)
    fun map(left: Int, top: Int, right: Int, bottom: Int,
            cropLeft: Int, cropTop: Int, ocrScale: Float, screenScale: Float): Box {
        require(ocrScale > 0 && screenScale > 0 && right > left && bottom > top)
        return Box(((cropLeft + left / ocrScale) * screenScale).toInt(),
            ((cropTop + top / ocrScale) * screenScale).toInt(),
            ((cropLeft + right / ocrScale) * screenScale).toInt(),
            ((cropTop + bottom / ocrScale) * screenScale).toInt())
    }
    fun place(box: Box, width: Int, height: Int, screenWidth: Int, screenHeight: Int, padding: Int): Box {
        val w = width.coerceIn(1, screenWidth)
        val h = height.coerceIn(1, screenHeight)
        val x = ((box.left + box.right - w) / 2).coerceIn(0, screenWidth - w)
        val y = (box.top - padding).coerceIn(0, screenHeight - h)
        return Box(x, y, x + w, y + h)
    }
}
