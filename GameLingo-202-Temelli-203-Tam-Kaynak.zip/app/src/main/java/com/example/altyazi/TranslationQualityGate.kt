package com.example.altyazi

/** Checks structural errors without assuming that a fluent sentence is a faithful translation. */
object TranslationQualityGate {
    enum class Problem {
        INVENTED_QUESTION, LOST_NEGATION, UNTRANSLATED,
        REVERSED_COMMAND, LOST_PROHIBITION, IMPERATIVE_AS_INFINITIVE,
        LOST_PROFANITY, LITERAL_IDIOM, MISSING_QUESTION, MISSING_DETAIL, ENGLISH_FRAGMENT
    }
    private val englishResidue = Regex("\\b(?:the|you|your|we|they|this|that|with|from|would|should|intro)\\b", RegexOption.IGNORE_CASE)
    private val negativeEnglish = Regex("\\b(?:not|never|nothing|nobody|nowhere|cannot|can't|don't|doesn't|didn't|won't|wouldn't|shouldn't|couldn't|isn't|aren't|wasn't|weren't)\\b", RegexOption.IGNORE_CASE)
    private val negativeTurkish = Regex("(?<![\\p{L}])(?:değil(?:iz|im|sin|siniz|ler)?|yok|hayır|asla|hiç|kimse|hiçbir|olmaz|olmadı|olmadık|olmayacak|istemiyorum|istemez|istemedim|yapmadı|yapmadık)(?![\\p{L}])|(?:m[ae](?:d[ıiuü]|y[ae]c[ae]k|m[ıiuü]ş|m[ae]|z(?:di|miş)?))|(?:m[ıiuü]yor)", RegexOption.IGNORE_CASE)

    // 10.37: warnings, NOT automatic corrections. A warning alone cannot
    // prove an alternative is better, so these do not hide a live subtitle.
    // They do stop a lossy translation being marked as verified in memory.
    private val explicitEnglishProfanity = Regex(
        """(?i)\b(?:fuck(?:ing|ed|er)?|shit(?:ty)?|motherfucker|asshole|bitch|bastard)\b"""
    )
    private val turkishProfanity = Regex(
        """(?iu)(?:sik|siktir|sikti|sikik|amına|bok|piç|orospu|yavşak|kaltak|göt|ibne|lanet)"""
    )
    private val onlineAgain = Regex("""(?i)\b(?:network|system|service|connection)\b.*\bback up\b""")
    private val backupMistranslated = Regex("""(?iu)\byedeklen(?:di|miş|iyor|ecek)\b""")
    private val fainted = Regex("""(?i)\bpass(?:ed)?\s+(?:right\s+)?out\b""")
    private val exited = Regex("""(?iu)\bdışarı\s+çık(?:tım|tı|tık|tılar|tın)\b""")
    private val injuredBack = Regex("""(?i)\bthrew\s+(?:his|her|my|their)\s+back\s+out\b""")
    private val thrownBackLiteral = Regex("""(?iu)(?<![\p{L}])(?:sırtını|belini)\s+(?:işten\s+)?attı(?![\p{L}])""")

    fun check(source: String, translated: String): Problem? {
        val s = source.trim()
        val t = translated.trim()
        if (s.isEmpty() || t.isEmpty() || s.equals(t, ignoreCase = true) ||
            EnglishEchoGuard.looksEnglish(s, t)) return Problem.UNTRANSLATED
        when (MeaningSafety.risk(s, t)) {
            MeaningSafety.Risk.REVERSED_NEGATIVE_COMMAND -> return Problem.REVERSED_COMMAND
            MeaningSafety.Risk.LOST_PROHIBITION -> return Problem.LOST_PROHIBITION
            MeaningSafety.Risk.IMPERATIVE_AS_INFINITIVE -> return Problem.IMPERATIVE_AS_INFINITIVE
            null -> Unit
        }
        if (!s.contains('?') && t.endsWith('?') && !s.endsWith("...") &&
            !s.contains('"') && !s.contains('“') && !s.contains(':')) return Problem.INVENTED_QUESTION
        // Only explicit English negation; avoid guessing from ambiguous contractions.
        // "Don't worry" can be faithfully rendered as "boş ver";
        // this is not a lost negation. The same applies to "never mind".
        val idiomaticNegative = Regex("\\b(?:don['’]?t worry|never mind)\\b", RegexOption.IGNORE_CASE)
        if (negativeEnglish.containsMatchIn(s) && s.length >= 18 &&
            !idiomaticNegative.containsMatchIn(s) &&
            !negativeTurkish.containsMatchIn(t) && !t.contains('?')) return Problem.LOST_NEGATION
        // A two-question subtitle must not silently lose its second question.
        // Warning, not hard rejection: one Turkish question can occasionally
        // paraphrase both. The live pipeline retries as separate clauses.
        if (s.count { it == '?' } >= 2 && t.count { it == '?' } < s.count { it == '?' })
            return Problem.MISSING_QUESTION
        if (englishResidue.findAll(t).count() >= 2) return Problem.UNTRANSLATED
        when (LiveSubtitleQuality10425.defect(s, t)) {
            LiveSubtitleQuality10425.Defect.ENGLISH_RESIDUE -> return Problem.ENGLISH_FRAGMENT
            LiveSubtitleQuality10425.Defect.MISSING_DETAIL -> return Problem.MISSING_DETAIL
            null -> Unit
        }
        if (onlineAgain.containsMatchIn(s) && backupMistranslated.containsMatchIn(t))
            return Problem.LITERAL_IDIOM
        if (fainted.containsMatchIn(s) && exited.containsMatchIn(t))
            return Problem.LITERAL_IDIOM
        if (injuredBack.containsMatchIn(s) && thrownBackLiteral.containsMatchIn(t))
            return Problem.LITERAL_IDIOM
        if (explicitEnglishProfanity.containsMatchIn(s) &&
            !turkishProfanity.containsMatchIn(t)) return Problem.LOST_PROFANITY
        return null
    }

    /** Only these high-confidence errors prevent displaying an output. */
    fun mustReject(problem: Problem?): Boolean = when (problem) {
        // A prohibition can be validly paraphrased in affirmative Turkish:
        // "Don't panic!" -> "Sakin ol!". Warn on missing negation but
        // never suppress a potentially correct paraphrase solely on that.
        Problem.REVERSED_COMMAND, Problem.IMPERATIVE_AS_INFINITIVE,
        Problem.UNTRANSLATED -> true
        else -> false
    }

    fun choose(source: String, primary: String, alternative: String?): String {
        if (check(source, primary) == null || alternative.isNullOrBlank()) return primary
        return if (check(source, alternative) == null) alternative else primary
    }

    fun mayRemember(source: String, translated: String): Boolean = check(source, translated) == null
}


/** English source echoed through OCR/translation with only tiny punctuation changes. */
object EnglishEchoGuard {
    private val word = Regex("""[\p{L}]+(?:['’][\p{L}]+)?""")
    fun looksEnglish(source: String, result: String): Boolean {
        fun terms(s: String): List<String> = word.findAll(s.lowercase())
            .map { it.value.replace('’', '\'') }.toList()
        val a = terms(source)
        val b = terms(result)
        if (a.size < 3 || b.size < 3) return false
        // Do not inspect names: a translation containing two preserved names
        // should not be rejected as English.
        val freq = a.groupingBy { it }.eachCount()
        val common = b.count { w -> (freq[w] ?: 0) > 0 }
        return common >= 3 && common * 100 >= b.size * 85 &&
            kotlin.math.abs(a.size - b.size) <= 1
    }
}
