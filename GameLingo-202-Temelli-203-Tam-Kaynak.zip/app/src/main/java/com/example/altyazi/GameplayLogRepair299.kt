package com.example.altyazi

/**
 * 10.42.5 / APK-299 saha kaydına dayalı dar kapsamlı OCR ve çıktı düzeltmeleri.
 * Buradaki kurallar motor seçmez, yeni altyazı üretmez ve bilinmeyen
 * eksik kelimeleri tahmin etmez. Sadece iki tarafta da açık kanıt bulunan
 * teknik terim/parçalanma sorunlarına dokunur.
 */
object GameplayLogRepair299 {
    private val ocrFixes = listOf(
        // Her kural yalnız kayıtla doğrulanan cümle parçasında çalışır.
        Regex("(?i)^Ata time(?=\\s+this\\s+dangerous\\b)") to "At a time",
        Regex("(?i)\\bsouls\\s+of\\s+our\\s+fatten\\b") to "souls of our fallen",
        Regex("(?i)\\bretun(?=\\s+to\\s+the\\s+Blight\\b)") to "return",
        Regex("(?i)\\bSha[ -]Chi\\s+unleased\\b") to "Sha-Chi unleashed",
        Regex("(?i)\\bunieasned\\s+otter(?=\\s+any\\s+swing\\b)") to "unleashed after",
        Regex("(?i)\\bStandand(?=\\s+Combo\\b|\\s*$)") to "Standard",
        Regex("(?i)\\btem\\s+per(?=\\s+this\\s+sword['’]s\\s+soul\\b)") to "temper",
        Regex("(?i)\\bIH(?=\\s+can['’]t\\s+explain\\s+it\\b)") to "I",
        Regex("(?i)^I['’]mused(?=\\s+to\\s+the\\s+wind\\b)") to "I'm used",
        // 15 Kasım APK-299 ikinci saha kaydı: düzeltmeler yalnız açık bağlamda.
        Regex("(?i)\\bTranscended\\s+heaters\\b") to "Transcended healers",
        Regex("(?i)^Xie\\s+iudong(?=\\s+[1Il]gave\\b)") to "Xie Qiudong",
        Regex("(?i)\\b1gave(?=\\s+her\\s+more\\s+time\\b)") to "I gave",
        Regex("(?i)\\bevershouldve(?=\\s+had[lI]?[.!]?\\s*$)") to "ever should've",
        Regex("(?i)(?<=should\'ve\\s)hadl\\s*$") to "had!",
        Regex("(?i)^Enpthe\\s+liew\\s+Meditine\\?$") to "Equip the new Medicine?",
        Regex("(?i)\\bpro\\s+longed(?=\\s+sleep\\b)") to "prolonged"
    )

    fun repairOcr(text: String): String {
        var fixed = text
        for ((pattern, replacement) in ocrFixes) fixed = pattern.replace(fixed, replacement)
        return fixed
    }

    /** Bir sonraki OCR karesini bekle; bozuk metni çevirip hafızaya yazma. */
    fun waitForCleanReading(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        // Bunlar gerçek saha logunda kopmuş veya ağır biçimde bozulmuştu.
        if (Regex("(?i)\\b(?:witti\\s+enogi|jtfarkwith|hdtd\\s+bieak|ineroa|inrrea)\\b")
                .containsMatchIn(t)) return true
        if (Regex("(?i)\\bcharge\\s+thg\\s*$").containsMatchIn(t)) return true
        if (Regex("(?i)\\bcan be unleashed after any swing during a Standard\\s*$")
                .containsMatchIn(t)) return true
        // Bozuk menü yazısını veya sözcüklerin parçalanmış hâlini normal
        // bir replik olarak çevirmeyelim; sonraki temiz OCR okumasını bekle.
        if (Regex("(?i)^(?:Traverse\\s+Ungrade\\s+Equipnjenl|sys\\s+Tems\\.|nevertr\\s+UIy\\s+runs\\s+dry\\.?)$")
                .containsMatchIn(t)) return true
        // Gerçek yetenek metni, ancak OCR'nin yarım bıraktığı son kelimeyi uyduramayız.
        if (Regex("(?i)\\b(?:deal|restore)\\s+ineroa\\s*$").containsMatchIn(t)) return true
        return false
    }

    /** Süsleme süzgeci teknik oyun açıklamalarını çöp sanmamalı. */
    fun isGameplayInstruction(text: String): Boolean =
        Regex("(?i)^\\s*(?:These attacks convert HP|Press after dodging|Reduces damage taken|Can be unleashed after|Switching to this weapon|The Order maintains a tavern)\\b")
            .containsMatchIn(text)

    /** Hatalı OCR'den sahte konuşmacı öğrenilmesini azaltır. */
    fun plausibleSpeakerName(name: String): Boolean {
        val words = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 4 || name.length > 32) return false
        // "WU Xra H" gibi tek harfli OCR kırıntılarını ada dönüştürme.
        return words.all { w ->
            val cleaned = w.trimEnd('.')
            cleaned.length >= 2 && cleaned.first().isUpperCase() &&
                cleaned.all { it.isLetter() || it == '\'' || it == '’' }
        }
    }

    /** Tekrar eden oyun menüsü etiketleri. Sadece tam eşleşmeye uygulanır. */
    fun verifiedUiLabel(source: String): String? = when (source.trim()) {
        "Soul Temper Leave" -> "Ruh Tavlama · Ayrıl"
        "8 Soul Temper" -> "8 Ruh Tavlama"
        "Upgrade Medicine Leave" -> "İlacı geliştir · Ayrıl"
        "Controller Preset 1" -> "Kontrol düzeni 1"
        "Equip the new Medicine?" -> "Yeni ilacı kuşanmak istiyor musun?"
        else -> null
    }

    /** Kaynak iki kelimelik oyun terimiyse modelin ürettiği yapay 've' bağını düzelt. */
    fun repairTranslation(source: String, translated: String): String {
        var out = translated
        if (Regex("(?i)\\bBronze Essence\\b").containsMatchIn(source)) {
            out = out.replace(Regex("(?iu)\\bBronze\\s+ve\\s+Essence(?:['’](?:ü|u|i|yi|yü))?"), "Bronze Essence'i")
        }
        if (Regex("(?i)\\bSha[ -]Chi\\b").containsMatchIn(source)) {
            out = out.replace(Regex("(?iu)\\bSha\\s+ve\\s+Chi(?:['’](?:ü|u|i|yi|yü))?"), "Sha-Chi'yi")
        }
        if (Regex("(?i)\\bPerfect Transcension\\b").containsMatchIn(source)) {
            out = out.replace(Regex("(?iu)\\bPerfect\\s+ve\\s+Transcension\\b"), "Perfect Transcension")
        }
        // Bu kalıplar yalnız İngilizce kaynakta ilgili tam terim varsa
        // devreye girer. İsimleri çevirmeyiz, cümledeki Türkçe ekleri koruruz.
        if (source.contains(Regex("(?i)\\bHollow Heart\\b"))) {
            out = out.replace(Regex("(?iu)\\bHollow\\s+ve\\s+Heart(?:['’](?:yi|yı|i|ı|ü|u))?"), "Hollow Heart'i")
        }
        if (source.contains(Regex("(?i)\\bXie Huichun\\b"))) {
            out = out.replace(Regex("(?iu)\\bXie\\s+ve\\s+Huichun\\b"), "Xie Huichun")
        }
        if (source.contains(Regex("(?i)\\bMeigu Lake\\b"))) {
            out = out.replace(Regex("(?iu)\\bMeigu\\s+ve\\s+Lake(?:['’](?:in|nin|ı|i))?"), "Meigu Lake'in")
        }
        if (source.contains(Regex("(?i)\\bWhite Serpent House\\b"))) {
            out = out.replace(Regex("(?iu)\\bWhite[, ]+Serpent\\s+ve\\s+House\\b"), "White Serpent House")
        }
        if (source.contains(Regex("(?i)\\bPhantom Edge\\b"))) {
            out = out.replace(Regex("(?iu)\\bPhantom\\s+(?:ile|ve)\\s+Edge\\b"), "Phantom Edge")
        }
        if (source.trimStart().startsWith("Third Stage", ignoreCase = true)) {
            out = out.replace(Regex("(?i)^Third Stage(?=[:\\s])"), "Üçüncü evre")
        }
        return out
    }
}
