package com.example.altyazi

/** Only disambiguate a short answer to an explicit, recent game question. */
object DialogueChoice192 {
    fun translate(previous: String, current: String, elapsedMs: Long): String? {
        if (elapsedMs !in 0..10_000) return null
        if (!Regex("(?i)\\btruth\\s+or\\s+dare\\s*\\?").containsMatchIn(previous)) return null
        val m = Regex("(?i)^\\s*(?:(h+m+)[. ,…]*)?(truth|dare)[.!?… ]*$").matchEntire(current) ?: return null
        val answer = if (m.groupValues[2].equals("truth", true)) "Doğruluk." else "Cesaret."
        return if (m.groupValues[1].isNotEmpty()) "Hımm… $answer" else answer
    }
}
