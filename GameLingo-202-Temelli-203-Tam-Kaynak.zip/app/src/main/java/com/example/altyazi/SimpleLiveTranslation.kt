package com.example.altyazi

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** Ordered fallback, with no rewriting and no second publication. */
object SimpleLiveTranslation {
    data class Engine(val name: String, val translate: suspend (String, String) -> String?)
    data class Result(val engine: String, val text: String)

    /**
     * Ordered fallback, one publication. Soft semantic warnings trigger the
     * next engine. If none is better, retain the first usable translation.
     * Hard-rejected results (English source echo, reversed commands) never
     * become the fallback.
     *
     * Budget prevents 5 sequential engine timeouts from stalling one caption.
     * The final built-in translator is always offered a small chance.
     */
    suspend fun translate(
        source: String,
        context: String,
        engines: List<Engine>,
        valid: (String, String) -> Boolean,
        suboptimal: (String, String) -> Boolean = { _, _ -> false },
        failed: (String) -> Unit = {},
        totalBudgetMs: Long = 3900L,
    ): Result? {
        val startedNs = System.nanoTime()
        var softFallback: Result? = null
        for ((index, engine) in engines.withIndex()) {
            currentCoroutineContext().ensureActive()
            val elapsedMs = (System.nanoTime() - startedNs) / 1_000_000L
            val finalEngine = index == engines.lastIndex
            val remaining = (totalBudgetMs - elapsedMs).coerceAtLeast(0L)
            if (remaining < 250L && !finalEngine) continue
            val timeout = if (finalEngine) remaining.coerceAtLeast(500L)
                else remaining.coerceAtMost(2200L).coerceAtLeast(250L)
            val output = try {
                kotlinx.coroutines.withTimeoutOrNull(timeout) {
                    engine.translate(source, context)?.trim()
                }
            } catch (e: CancellationException) { throw e }
              catch (_: Exception) { null }
            currentCoroutineContext().ensureActive()
            if (!output.isNullOrEmpty() &&
                !output.equals(source.trim(), ignoreCase = true) && valid(source, output)) {
                val candidate = Result(engine.name, output)
                if (!suboptimal(source, output)) return candidate
                if (softFallback == null) softFallback = candidate
                continue // A usable but imperfect answer is not a motor failure.
            }
            failed(engine.name)
        }
        return softFallback
    }
}

/** Only preceding English lines; each request gets its own immutable snapshot. */
class LiveContextHistory {
    private val lines = ArrayDeque<String>()
    private var lastAt = 0L
    @Synchronized fun accept(source: String, now: Long): String {
        if (now - lastAt > 30_000L || now < lastAt) lines.clear()
        val context = (if (lines.lastOrNull() == source) lines.dropLast(1) else lines.toList()).joinToString("\n")
        if (lines.lastOrNull() != source) {
            lines.add(source)
            while (lines.size > 3) lines.removeFirst()
        }
        lastAt = now
        return context
    }
    @Synchronized fun clear() { lines.clear(); lastAt = 0L }
}
