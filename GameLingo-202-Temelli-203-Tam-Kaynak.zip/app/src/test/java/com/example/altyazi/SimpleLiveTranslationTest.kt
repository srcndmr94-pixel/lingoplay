package com.example.altyazi

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class SimpleLiveTranslationTest {
    @Test fun primaryReceivesOriginalAndReturnsUnmodified() = runBlocking {
        val source = "Yo, what's up? Y'all tryna smoke?"
        val result = SimpleLiveTranslation.translate(source, "Earlier dialogue.", listOf(
            SimpleLiveTranslation.Engine("DeepL") { text, context ->
                assertEquals(source, text)
                assertEquals("Earlier dialogue.", context)
                "Hey, naber? İçmek ister misiniz?"
            },
            SimpleLiveTranslation.Engine("OPUS") { _, _ -> error("Fallback must not run after success") }
        ), { _, _ -> true })
        assertEquals("Hey, naber? İçmek ister misiniz?", result!!.text)
        assertEquals("DeepL", result.engine)
    }
    @Test fun fallbackIsOrderedAndRejectsEmptySameAndUnsafe() = runBlocking {
        val seen = mutableListOf<String>()
        val engines = listOf("DeepL" to "", "OPUS" to "Leave no one alive.",
            "Google" to "Kimseyi canlı bırak.", "Firefox" to "Kimseyi sağ bırakma.").map { (name, answer) ->
            SimpleLiveTranslation.Engine(name) { _, _ -> seen += name; answer }
        }
        val result = SimpleLiveTranslation.translate("Leave no one alive.", "", engines,
            { source, output -> !TranslationQualityGate.mustReject(TranslationQualityGate.check(source, output)) })
        assertEquals(listOf("DeepL", "OPUS", "Google", "Firefox"), seen)
        assertEquals("Firefox", result!!.engine)
    }
    @Test fun cancellationNeverBecomesFallback() = runBlocking {
        var fallback = false
        try {
            SimpleLiveTranslation.translate("Hello", "", listOf(
                SimpleLiveTranslation.Engine("first") { _, _ -> throw CancellationException("obsolete") },
                SimpleLiveTranslation.Engine("second") { _, _ -> fallback = true; "Merhaba" }
            ), { _, _ -> true })
            fail("Cancellation expected")
        } catch (_: CancellationException) { }
        assertFalse(fallback)
    }
    @Test fun contextIsPreviousThreeAndResetsAfterSilence() {
        val history = LiveContextHistory()
        assertEquals("", history.accept("One", 1))
        assertEquals("One", history.accept("Two", 2))
        assertEquals("One\nTwo", history.accept("Three", 3))
        assertEquals("One\nTwo\nThree", history.accept("Four", 4))
        assertEquals("Two\nThree", history.accept("Four", 5))
        assertEquals("Two\nThree\nFour", history.accept("Five", 6))
        assertEquals("", history.accept("New scene", 40_000))
        history.clear()
        assertEquals("", history.accept("Restart", 40_001))
    }
    @Test fun generationCannotPublishAnEarlierSubtitle() {
        val gate = SubtitleGenerationGate()
        val first = gate.newSubtitle()
        val second = gate.newSubtitle()
        assertFalse(gate.isCurrent(first))
        assertTrue(gate.isCurrent(second))
        gate.invalidate()
        assertFalse(gate.isCurrent(second))
    }
}
