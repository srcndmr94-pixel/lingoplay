# GameLingo 10.42.8 — İngilizcenin tam üzerinde Türkçe

VersionCode 192. Son gönderilen OCR band-guard kaynağına dayanan 191 sürümünden devam edildi.

## Değişiklik
- Sabit alt konum yerine seçilen İngilizce OCR bloğunun gerçek sol/üst/sağ/alt koordinatları kullanılır. Kırpma başlangıcı ve OCR büyütme oranı ekran koordinatlarına dönüştürülür.
- Türkçe kutu İngilizce bloğunun üzerinde, kaynak bloğu örtecek asgari boyutta ve opak siyah zeminle gösterilir. Önceki çeviri ayrı üst satırda yığılmaz.
- Yalnızca yakın geçmişte açıkça Truth or dare? sorusu varsa kısa Truth/Dare yanıtı Doğruluk/Cesaret olarak ele alınır. Diğer Truth kullanımlarına bu kural uygulanmaz.
- Motor sırası ve DeepL/Google/OPUS/OfflineFix/Prefs dosyaları 191 sürümüyle karşılaştırıldı: değiştirilmedi. Tüm çeviri anlam hatalarının giderildiği iddia edilmez.

## Kullanım koşulu
Android izin ekranında Tek uygulama seçilip oyun veya video uygulaması paylaşılmalıdır. Tüm ekran seçildiğinde çeviri kutusu kaynak görüntüyü örtebilir. Sistem seçimi kullanıcıya aittir; bu sürüm seçimi zorlayamaz veya otomatik doğrulayamaz. Tek uygulama paylaşımında koordinat eşleşmesi ve katman ayrımı Pixel'de henüz test edilmedi.

## Kontroller
- 11/11 kaynak kutusu koordinat/örtme ve bağlam kuralı kontrolü.
- 33/33 OCR okuma kuralı kontrolü.
- 22/22 OCR akış/yardımcı yerleşim kontrolü (kaynak bağlantısı beklentisi yeni örtme davranışına güncellendi).
- 31/31 kaynak entegrasyonu kontrolü.
- Android debug APK derlemesi ve kriptografik imza doğrulaması başarılı.
- Gerçek Pixel üzerinde çalıştırılmadı; canlı OCR ve görüntü doğruluğu ölçülmedi.

Önceki sürümlerin paket içindeki raporları tarihsel kayıttır; bu sürümün davranışı bu belgedir.
