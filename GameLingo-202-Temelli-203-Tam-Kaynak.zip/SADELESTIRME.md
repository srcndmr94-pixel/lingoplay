# GameLingo 10.42.9-simplified (202)

Baseline: 10.42.8-source-cover (192). This is the phone live subtitle simplification, not a new translation model.

Removed from phone live translation:
- Bundled exact dialogue substitutions and forced slang/profanity additions.
- Automatic name guessing, decorative-prefix trimming and word substitution in the accepted OCR text.
- Legacy translation-memory reads that bypassed the selected engine.
- Concatenation of preceding subtitles into the text being translated.
- Local E4B refinement and draft-to-final replacement, including their unused service methods.
- Automatic legacy cache migrations/purges at service startup.

Current flow: personal full-line dictionary first, then enabled DeepL → OPUS-MT → Google → Firefox → ML Kit. First valid result is final. Blank, unchanged and clearly reversed-command results fall back. Other semantic warnings are diagnostic, not automatic rewriting; this does not guarantee translation accuracy or profanity preservation by the selected model.

DeepL receives the previous three accepted English lines in its separate context parameter. The current line is sent unchanged apart from whitespace. Context expires after 30 seconds without accepted dialogue. Source generation guards reject obsolete results. The previous Turkish overlay is hidden on acceptance of a new line, retaining the current OCR coordinates.

UI: the experimental model-download/comparison panel and obsolete live mode selectors are no longer displayed or initialized. Unused content/LLM API settings are hidden. Personal dictionary, existing model files and engine opt-ins remain. Installed model deletion still requires the existing user action. TV bridge and menu translation retain their existing separate behavior; their legacy support code remains, as do model libraries used by the bridge. APK size is not claimed to be reduced.

The existing English-cover overlay placement is retained. Whole-screen capture can still capture the overlay itself; use Android's single-app capture for the target game/video. No claim of Pixel 9 Pro runtime or screen-rotation validation is made from a successful build.

API reference: https://github.com/DeepL/deepl-java (TextTranslationOptions.setContext).

Validation: assembleDebug and testDebugUnitTest succeeded. Five new JVM flow tests: 5 passed, 0 failed, 0 skipped. Legacy standalone scripts were not run. APK signature verification succeeded. Pixel 9 Pro live playback and screen-capture exclusion remain unverified.
