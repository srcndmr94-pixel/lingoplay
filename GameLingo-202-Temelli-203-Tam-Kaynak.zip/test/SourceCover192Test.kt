import com.example.altyazi.CaptionCoverBounds as C
import com.example.altyazi.DialogueChoice192 as D
fun main() {
 var n = 0
 fun ok(v: Boolean) { check(v); n++ }
 val b = C.map(600,100,1000,180,0,600,1f,1f)
 ok(b == C.Box(600,700,1000,780))
 val p = C.place(b,420,96,2142,960,4)
 ok(p.top == 696 && p.left <= b.left && p.right >= b.right && p.bottom >= b.bottom)
 ok(C.map(1200,200,2000,360,0,600,2f,1f) == b)
 ok(C.map(0,0,100,50,20,30,1f,2f) == C.Box(40,60,240,160))
 ok(C.place(C.Box(500,900,700,950),220,100,2142,960,4).bottom == 960)
 ok(D.translate("My turn. Truth or dare?", "Hmm.. Truth.", 500) == "Hımm… Doğruluk.")
 ok(D.translate("Truth or dare?", "Dare!", 500) == "Cesaret.")
 ok(D.translate("Tell me the truth.", "Truth.", 500) == null)
 ok(D.translate("Truth or dare?", "The truth hurts.", 500) == null)
 ok(D.translate("Truth or dare?", "Truth.", 11000) == null)
 ok(D.translate("Truth or dare?", "Truth.", -1) == null)
 println("SourceCover192: $n/$n PASS")
}
