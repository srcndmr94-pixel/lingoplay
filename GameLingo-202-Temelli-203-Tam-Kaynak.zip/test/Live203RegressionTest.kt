import com.example.altyazi.EnglishEchoGuard
import com.example.altyazi.SubtitleReadGuard299
import com.example.altyazi.TranslationQualityGate
import com.example.altyazi.SimpleLiveTranslation
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    var checks = 0
    fun verify(name: String, result: Boolean) { check(result) { name }; checks++ }

    verify("English source echo", EnglishEchoGuard.looksEnglish("You are not going anywhere.", "You are not going anywhere!"))
    verify("Turkish sentence not an echo", !EnglishEchoGuard.looksEnglish("You are not going anywhere.", "Hiçbir yere gitmiyorsun."))
    verify("Proper names preserved", !EnglishEchoGuard.looksEnglish("Mark told Eve to wait outside.", "Mark, Eve'ye dışarıda beklemesini söyledi."))
    verify("Only 2 shared proper names", !EnglishEchoGuard.looksEnglish("Mark and Cecil are upstairs.", "Mark ve Cecil yukarıda."))
    verify("Echo rejected at output gate", TranslationQualityGate.mustReject(TranslationQualityGate.check("You are not going anywhere.", "You are not going anywhere!")))
    verify("Good short answer stays", TranslationQualityGate.check("Come on!", "Hadi!") == null)
    verify("Profanity warning", TranslationQualityGate.check("What the fuck are you doing?", "Ne yapıyorsun?") == TranslationQualityGate.Problem.LOST_PROFANITY)
    verify("Profanity present", TranslationQualityGate.check("What the fuck are you doing?", "Ne bok yiyorsun?") == null)

    verify("Completed long new ending", SubtitleReadGuard299.distinctCompletedTail(
        "You need to find the entrance. Get everybody inside.",
        "You need to find the entrance. Don't let anyone escape."))
    verify("Different completed ending meaningful", SubtitleReadGuard299.meaningfulRevision(
        "You need to find the entrance. Get everybody inside.",
        "You need to find the entrance. Don't let anyone escape."))
    verify("Tiny OCR typo not distinct tail", !SubtitleReadGuard299.distinctCompletedTail(
        "You need to get everybody inside.", "You need to get everybody inslde."))
    verify("Same text not new turn", !SubtitleReadGuard299.meaningfulRevision("I know.", "I know!"))
    verify("Negation change significant", SubtitleReadGuard299.meaningfulRevision("You should go now.", "You should not go now."))

    val seen = mutableListOf<String>()
    val sequence = listOf(
        SimpleLiveTranslation.Engine("DeepL") { _, _ -> seen += "DeepL"; "Ne yapıyorsun?" },
        SimpleLiveTranslation.Engine("OPUS-MT") { _, _ -> seen += "OPUS-MT"; "Ne bok yiyorsun?" },
        SimpleLiveTranslation.Engine("Google") { _, _ -> seen += "Google"; "No" }
    )
    val result = SimpleLiveTranslation.translate("What the fuck are you doing?", "", sequence,
        valid = { s,t -> !TranslationQualityGate.mustReject(TranslationQualityGate.check(s,t)) },
        suboptimal = { s,t -> TranslationQualityGate.check(s,t) == TranslationQualityGate.Problem.LOST_PROFANITY })
    verify("Prefer contextual profanity when second engine has it", result?.engine == "OPUS-MT")
    verify("Preserve priority order", seen == listOf("DeepL", "OPUS-MT"))

    val fallback = SimpleLiveTranslation.translate("What the fuck are you doing?", "", listOf(
        SimpleLiveTranslation.Engine("DeepL") { _, _ -> "Ne yapıyorsun?" },
        SimpleLiveTranslation.Engine("OPUS-MT") { _, _ -> null }
    ), valid = {_,_->true}, suboptimal = {_,_->true})
    verify("Soft fallback instead of blank", fallback?.engine == "DeepL")

    val late = SimpleLiveTranslation.translate("Hello there.", "", listOf(
        SimpleLiveTranslation.Engine("Slow") { _, _ -> delay(1500L); null },
        SimpleLiveTranslation.Engine("ML Kit") { _, _ -> "Merhaba." }
    ), valid = {_,_->true}, totalBudgetMs = 120L)
    verify("Final local fallback after overall budget", late?.text == "Merhaba.")
    println("$checks/$checks Live203 regression PASS")
}
