from . import _W
class _F(_W):
    def __init__(self,*a,**k):
        super().__init__(*a,**k)
        self._v={}
    def __setitem__(self,k,v): self._v[k]=v
    def __getitem__(self,k): return self._v.get(k)
Frame=Label=Entry=Button=Combobox=LabelFrame=_F
