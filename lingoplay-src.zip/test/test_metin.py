"""
OCR onarımını kullanıcının gerçek çalışma kaydındaki satırlarla sınar.

Buradaki bozulmaların hepsi gerçekten yaşandı:
  "Right youare!"            -> "Sağ Yout!" diye çevrilmişti
  "foryou as.Repayment."     -> "yararlı yazıcıyı" diye çevrilmişti
  "Rd be everobliged."       -> "Rd everobliged" diye çıkmıştı
  "withye Cap'n"             -> "ve Drake Aparting Cap'n" olmuştu

Kelime havuzunu Kotlin kaynağından okuyoruz; havuz orada değişince test de
onunla değişir, ikisi ayrışmaz.

Testin ikinci yarısı en az birincisi kadar önemli: bölme kuralının GERÇEK
kelimeleri bölmediğini doğruluyor. Fazla cömert bir kural "notice" kelimesini
"no tice" yapar ve çeviriyi iyileştirmek yerine bozar.
"""

import os
import re
import sys

KAYNAK = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main",
                      "java", "com", "example", "altyazi", "TextFix.kt")

metin = open(KAYNAK, encoding="utf-8").read()

blok = re.search(r"WORDS:\s*Set<String>\s*=\s*setOf\((.*?)\n\s*\)", metin, re.S)
if not blok:
    print("WORDS havuzu kaynakta bulunamadi")
    sys.exit(1)
WORDS = {w.lower() for w in re.findall(r'"((?:[^"\\]|\\.)*)"', blok.group(1))}


def bilinen(k):
    return bool(k) and k.lower() in WORDS


def bol(govde):
    for i in range(len(govde) - 2, 1, -1):
        sol, sag = govde[:i], govde[i:]
        if not bilinen(sol):
            continue
        if bilinen(sag) or (len(sag) >= 4 and len(sol) >= 3):
            return sol + " " + sag
    return None


def parcayi_ayir(parca):
    if "'" in parca:
        yarim = parca.split("'")
        if len(yarim) == 2 and bilinen(yarim[0]) and bilinen(yarim[1]):
            return yarim[0] + " " + yarim[1]

    bas = ""
    for c in parca:
        if c.isalpha():
            break
        bas += c
    son = ""
    for c in reversed(parca):
        if c.isalpha():
            break
        son = c + son
    govde = parca[len(bas):len(parca) - len(son)] if son else parca[len(bas):]

    if len(govde) < 5 or bilinen(govde):
        return parca
    b = bol(govde)
    return parca if b is None else bas + b + son


def onar(raw):
    t = raw.replace("…", "...")
    t = re.sub(r"\s*\.\s*\.\s*\.", "...", t)
    t = re.sub(r"\s+", " ", t).strip()
    t = t.strip("-—«»\"").strip()
    t = re.sub(r"(?<=[a-z])\.(?=[A-Z])", ". ", t)
    t = " ".join(parcayi_ayir(p) for p in t.split(" "))
    return re.sub(r"\s+", " ", t).strip()


hata = []

# --- Kayittan gelen gercek bozulmalar: duzelmeli --------------------
DUZELMELI = [
    ("Right youare!", "you are"),
    ("'l not play Duck and Drake withye Cap'n,", "with ye"),
    ("I need Coin to build a little Emporium. Rd be everobliged.",
     "ever obliged"),
    ("and a local Shop'would bring in many a usefulWare foryou as.Repayment.",
     "for you"),
    ("and a local Shop'would bring in many a usefulWare foryou as.Repayment.",
     "Shop would"),
    ("and a local Shop'would bring in many a usefulWare foryou as.Repayment.",
     "as. Repayment"),
]

for giris, beklenen in DUZELMELI:
    cikti = onar(giris)
    if beklenen not in cikti:
        hata.append(f'"{beklenen}" bekleniyordu, cikan: "{cikti}"')

# --- Bozulmamasi gereken gercek kelimeler ---------------------------
BOZULMAMALI = [
    "notice", "building", "heading", "playing", "window", "manage",
    "forest", "better", "wonder", "important", "Gregory", "Emporium",
    "another", "without", "something", "anytime", "therefore", "sometimes",
    "everyone", "understand", "tonight", "anywhere", "forever",
]

for kelime in BOZULMAMALI:
    cikti = onar(kelime)
    if cikti != kelime:
        hata.append(f'"{kelime}" bolunmemeliydi, cikan: "{cikti}"')

# --- Tam cumleler bozulmadan gecmeli --------------------------------
GECMELI = [
    "I can put my finger on Gregory anytime, anywhere.",
    "Calm? How can I stay calm? Thorne can find me here!",
    "We need to talk about what happened last night.",
]

for cumle in GECMELI:
    cikti = onar(cumle)
    if cikti != cumle:
        hata.append(f'cumle degisti:\n    once: {cumle}\n    sonra: {cikti}')

if hata:
    print("Metin onarim testi DUSTU:")
    for h in hata:
        print("  ✗", h)
    sys.exit(1)

print(f"Metin onarim testi temiz: {len(DUZELMELI)} bozulma duzeldi, "
      f"{len(BOZULMAMALI)} gercek kelime ve {len(GECMELI)} cumle korundu.")
