"""
"Altyazı değil" süzgecini, kullanıcının gerçek çalışma kaydından alınmış
satırlara karşı sınar.

Engel listelerini Kotlin kaynağından okuyoruz; böylece liste orada değişince
test de onunla birlikte değişir, ikisi ayrışmaz.
"""

import os
import re
import sys

KAYNAK = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main",
                      "java", "com", "example", "altyazi", "CaptureService.kt")


def liste_cek(metin, ad):
    """Kotlin'deki setOf/listOf blogundan dizeleri cikarir."""
    m = re.search(rf"{ad}\s*=\s*(?:setOf|listOf)\((.*?)\n\s*\)", metin, re.S)
    if not m:
        raise AssertionError(f"{ad} kaynakta bulunamadi")
    return [s for s in re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1))]


metin = open(KAYNAK, encoding="utf-8").read()
ENGEL = liste_cek(metin, "BLOCK_PHRASES")
CUMLE = set(liste_cek(metin, "SENTENCE_WORDS"))


def altyazi_degil(text):
    """CaptureService.altyaziDegil ile ayni mantik."""
    kucuk = text.lower()
    for kalip in ENGEL:
        if kalip in kucuk:
            return True

    kelimeler = [k for k in re.split(r"\s+", text) if k]
    if len(kelimeler) < 5:
        return False

    for k in kelimeler:
        if k.lower().strip(".,!?:;\"'") in CUMLE:
            return False

    if sum(text.count(c) for c in ".!?") >= 2:
        return False

    ozel_ad = 0
    for k in kelimeler:
        if len(k) > 1 and k[0].isupper() and all(
                c.islower() or c in ".-" for c in k[1:]):
            ozel_ad += 1
    return ozel_ad >= 5


# --- Kayittan gelen gercek satirlar -------------------------------------
ENGELLENMELI = [
    "Uygulama içerikleri, güvenlik nedeniyle gizlendi",
    "Uygulama içerikleri, güvenlik nedeniyle gizlendi. Bölümler",
    "Hamish Linklater Bruce Wayne Michelle C. Bonilla Renee Montoya "
    "Krystal Joy Brown",
    "Hamish Linklater: Bruce Wayne Michelle C. Bonilla: Renee Montoya "
    "Alt YazKEystal Joy Brown Dialogue Boost",
    "Hamish Linklater - Batman X-Ray",
    "prime Ekran görüntüsü",
]

GECMELI = [
    "[straining] Go on! Do it!",
    "I can put my finger on Gregory anytime, anywhere. Bank on it.",
    "Get down!",
    "We need to talk about what happened last night.",
    "You should have told me.",
    "Bruce Wayne. Gotham City. Arkham Asylum.",
]

hata = []

for s in ENGELLENMELI:
    if not altyazi_degil(s):
        hata.append(f"ENGELLENMELIYDI ama gecti: {s[:60]}")

for s in GECMELI:
    if altyazi_degil(s):
        hata.append(f"GERCEK ALTYAZI ama engellendi: {s[:60]}")

if hata:
    print("Filtre testi DUSTU:")
    for h in hata:
        print("  ✗", h)
    sys.exit(1)

print(f"Filtre testi temiz: {len(ENGELLENMELI)} cop satiri engellendi, "
      f"{len(GECMELI)} gercek altyazi gecti.")
