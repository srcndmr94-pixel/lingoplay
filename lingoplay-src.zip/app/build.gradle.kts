plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.altyazi"
    compileSdk = 34

    defaultConfig {
        // Paket kimliği yeni: eski LingoPlay telefonda kalsın, Lingo onun
        // yanına ayrı bir uygulama olarak kurulsun. Namespace değişmiyor,
        // çünkü tüm kaynak dosyalar o ad altında duruyor.
        applicationId = "com.lingo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 23
        versionName = "6.5"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = false
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:translate:17.0.2")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
