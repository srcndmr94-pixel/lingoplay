package com.example.altyazi

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Ekranın üzerine çizilen çeviri katmanı.
 *
 * İki tür yazı var:
 *  - Altyazı kutusu: büyük, ortalı, altyazı şeridinin hemen üstünde durur.
 *  - Küçük etiketler: menü, görev ve tuş yazılarının kendi yanında durur.
 *
 * Böylece farklı yerlerden gelen çeviriler tek kutuda toplanıp birbirine karışmaz.
 */
class Overlay(private val context: Context) {

    data class Label(val text: String, val x: Int, val y: Int)

    /** Altyazı kutusunun görünümü; ayarlardan geliyor. */
    data class Stil(
        val boyutSp: Float = 18f,
        val yaziRengi: Int = Color.WHITE,
        val arkaAlfa: Int = 190,
        val kenarlik: Boolean = true,
    )

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var subtitleView: TextView? = null
    private val labelViews = ArrayList<TextView>()

    @Volatile
    private var stil = Stil()

    /** Ayarlar değişince çağrılır; kutu anında yeni görünüme geçer. */
    fun setStil(yeni: Stil) {
        stil = yeni
        subtitleView?.post { stiliUygula() }
    }

    private fun stiliUygula() {
        val t = subtitleView ?: return
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, stil.boyutSp)
        t.setTextColor(stil.yaziRengi)
        if (stil.kenarlik) t.setShadowLayer(7f, 0f, 2f, Color.BLACK)
        else t.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        t.background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.argb(stil.arkaAlfa, 0, 0, 0))
        }
    }

    fun show() {
        if (root != null) return

        val container = FrameLayout(context)

        val subtitle = makeText(stil.boyutSp, stil.arkaAlfa).apply { visibility = View.GONE }
        container.addView(
            subtitle,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        )

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            wm.addView(container, lp)
            root = container
            subtitleView = subtitle
            stiliUygula()
        } catch (_: Throwable) {
        }
    }

    private fun makeText(sizeSp: Float, alpha: Int): TextView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setShadowLayer(6f, 0f, 2f, Color.BLACK)
        setPadding(dp(10), dp(5), dp(10), dp(5))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.argb(alpha, 0, 0, 0))
        }
    }

    /** Altyazı çevirisi. topPx, kutunun ekranın üstünden uzaklığı. */
    fun setSubtitle(value: String?, topPx: Int) {
        val t = subtitleView ?: return
        t.post {
            if (value.isNullOrBlank()) {
                t.visibility = View.GONE
                t.text = ""
                return@post
            }
            val lp = t.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = topPx.coerceAtLeast(dp(8))
            lp.leftMargin = dp(12)
            lp.rightMargin = dp(12)
            t.layoutParams = lp
            t.text = value
            t.visibility = View.VISIBLE
        }
    }

    /** Menü, görev ve tuş yazılarının çevirileri; her biri kendi yerinde. */
    fun setLabels(labels: List<Label>) {
        val container = root ?: return
        container.post {
            while (labelViews.size < labels.size) {
                val tv = makeText(13f, 205)
                container.addView(
                    tv,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT
                    ).apply { gravity = Gravity.TOP or Gravity.START }
                )
                labelViews.add(tv)
            }

            for (i in labelViews.indices) {
                val tv = labelViews[i]
                val label = labels.getOrNull(i)
                if (label == null) {
                    tv.visibility = View.GONE
                    continue
                }
                val lp = tv.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin = label.x.coerceAtLeast(0)
                lp.topMargin = label.y.coerceAtLeast(0)
                tv.layoutParams = lp
                tv.text = label.text
                tv.visibility = View.VISIBLE
            }
        }
    }

    fun clearLabels() = setLabels(emptyList())

    fun hide() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (_: Throwable) {
        }
        root = null
        subtitleView = null
        labelViews.clear()
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
