package com.example.altyazi

import android.content.Context

/** Tüm ayarlar burada saklanır. Servis ve ekran aynı yerden okur. */
class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("altyazi", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v.trim()).apply()

    /** Oyun, Dizi, Film gibi içerik türü. Çeviri talimatına girer. */
    var contentType: String
        get() = (sp.getString("contentType", "") ?: "").ifBlank { "Oyun" }
        set(v) = sp.edit().putString("contentType", v.trim()).apply()

    var gameName: String
        get() = sp.getString("gameName", "") ?: ""
        set(v) = sp.edit().putString("gameName", v.trim()).apply()

    /** 0 = Anthropic (ücretli), 1 = Google Gemini (ücretsiz katman). */
    var provider: Int
        get() = sp.getInt("provider", PROVIDER_GEMINI)
        set(v) = sp.edit().putInt("provider", v).apply()

    /** Google AI Studio anahtarı. */
    var geminiKey: String
        get() = (sp.getString("geminiKey", "") ?: "").ifBlank { GOMULU_ANAHTAR }
        set(v) = sp.edit().putString("geminiKey", v.trim()).apply()

    var geminiModel: String
        get() = (sp.getString("geminiModel", "") ?: "").ifBlank { DEFAULT_GEMINI_MODEL }
        set(v) = sp.edit().putString("geminiModel", v.trim()).apply()

    /** Seçili sağlayıcının anahtarı. */
    val activeKey: String
        get() = if (provider == PROVIDER_GEMINI) geminiKey else apiKey

    var model: String
        get() = (sp.getString("model", "") ?: "").ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    /**
     * 0 = Anında: sadece telefonun içindeki çeviri, ~0,3 sn, hiç değişmez.
     * 1 = Yapay zekâ: ~1 sn gecikir, hiç değişmez, en doğru çeviri.
     * 2 = Karma: önce anında çıkar, yapay zekâ gelince bir kez düzelir.
     */
    var mode: Int
        get() = sp.getInt("mode", MODE_AI)
        set(v) = sp.edit().putInt("mode", v).apply()

    val useAi: Boolean
        get() = mode != MODE_INSTANT

    var showSpeaker: Boolean
        get() = sp.getBoolean("showSpeaker", true)
        set(v) = sp.edit().putBoolean("showSpeaker", v).apply()

    /** Menü, görev ve tuş yazılarını da kendi yerlerinde anında çevirsin mi? */
    var menuTranslate: Boolean
        get() = sp.getBoolean("menuTranslate", false)
        set(v) = sp.edit().putBoolean("menuTranslate", v).apply()

    /** Açıkken, çeviri çıkmadığında ekranda sebebini ve okunan metni gösterir. */
    var diagnostics: Boolean
        get() = sp.getBoolean("diagnostics", false)
        set(v) = sp.edit().putBoolean("diagnostics", v).apply()

    init {
        // Yeni sürümde altyazı bölgesi daha dar; eski kayıt varsa bir kez güncellenir.
        if (sp.getInt("defaultsVersion", 0) < 10) {
            sp.edit()
                .putInt("topPct", 74)
                .putInt("bottomPct", 99)
                .putBoolean("menuTranslate", false)
                .putInt("mode", MODE_AI)
                .putInt("intervalMs", 150)
                .putBoolean("diagnostics", false)
                // Eski kayıtlardaki geçersiz model adını temizliyoruz; boş
                // kalınca aşağıdaki geçerli varsayılan devreye girer.
                .putString("geminiModel", "")
                .putInt("defaultsVersion", 10)
                .apply()
        }
    }

    /** Altyazı bölgesinin ekran yüksekliğine göre üst sınırı, yüzde. */
    var topPct: Int
        get() = sp.getInt("topPct", 74)
        set(v) = sp.edit().putInt("topPct", v).apply()

    /** Altyazı bölgesinin alt sınırı, yüzde. */
    var bottomPct: Int
        get() = sp.getInt("bottomPct", 99)
        set(v) = sp.edit().putInt("bottomPct", v).apply()

    /** İki tarama arasındaki bekleme, milisaniye. Küçük = hızlı ama daha çok pil. */
    var intervalMs: Int
        get() = sp.getInt("intervalMs", 150)
        set(v) = sp.edit().putInt("intervalMs", v).apply()

    // ---------------------------------------------------- altyazı görünümü

    /** Altyazı yazı boyutu (sp). */
    var subtitleSize: Int
        get() = sp.getInt("subtitleSize", 18).coerceIn(12, 34)
        set(v) = sp.edit().putInt("subtitleSize", v.coerceIn(12, 34)).apply()

    /** 0 beyaz · 1 sarı · 2 açık yeşil · 3 turkuaz */
    var subtitleColor: Int
        get() = sp.getInt("subtitleColor", COLOR_WHITE)
        set(v) = sp.edit().putInt("subtitleColor", v).apply()

    /** 0 yarı saydam · 1 tam siyah · 2 arka plan yok */
    var subtitleBg: Int
        get() = sp.getInt("subtitleBg", BG_SEMI)
        set(v) = sp.edit().putInt("subtitleBg", v).apply()

    /** 0 şeridin üstünde · 1 şeridin üstünü kapat · 2 ekranın en altı */
    var subtitlePos: Int
        get() = sp.getInt("subtitlePos", POS_ABOVE)
        set(v) = sp.edit().putInt("subtitlePos", v).apply()

    /** Yazının çevresine koyu kenarlık; parlak sahnelerde okunurluğu artırır. */
    var subtitleOutline: Boolean
        get() = sp.getBoolean("subtitleOutline", true)
        set(v) = sp.edit().putBoolean("subtitleOutline", v).apply()

    companion object {
        /** Gömülü Google anahtarı; ayarlardan değiştirilebilir. */
        /** Kasıtlı boş: açık depoya gömülen anahtarlar iptal ediliyor. */
        const val GOMULU_ANAHTAR = ""

        const val DEFAULT_MODEL = "claude-haiku-5-5"

        /**
         * Hesapta gerçekten bulunan, hızlı ve hafif model.
         * Önceki varsayılan ("gemini-3.8") hiçbir hesapta yoktu; her replikte
         * "Model bulunamadı" alınmasının kaynağı buydu.
         */
        const val DEFAULT_GEMINI_MODEL = "gemini-3.1-flash-lite-preview"

        const val PROVIDER_ANTHROPIC = 0
        const val PROVIDER_GEMINI = 1
        const val MODE_INSTANT = 0
        const val MODE_AI = 1
        const val MODE_HYBRID = 2

        // Altyazı görünümü seçenekleri
        const val COLOR_WHITE = 0
        const val COLOR_YELLOW = 1
        const val COLOR_GREEN = 2
        const val COLOR_CYAN = 3

        const val BG_SEMI = 0
        const val BG_SOLID = 1
        const val BG_NONE = 2

        const val POS_ABOVE = 0
        const val POS_COVER = 1
        const val POS_BOTTOM = 2
    }
}
