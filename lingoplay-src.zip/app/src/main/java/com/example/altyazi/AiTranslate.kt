package com.example.altyazi

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Oyun adını ve son replikleri bağlam olarak verip Anthropic API'sinden
 * daha doğru, karakter tutarlı bir Türkçe çeviri ister.
 */
class AiTranslate(private val prefs: Prefs) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** Son çevrilen replikler; karakter ve konu tutarlılığı için gönderilir. */
    private val history = ArrayDeque<Pair<String, String>>()

    @Volatile
    var lastError: String? = null
        private set

    companion object Usage {
        const val FALLBACK_MODEL = "claude-3-5-haiku-latest"

        /** Bu oturumda harcanan jetonlar; ana ekranda gösterilir. */
        @Volatile var requests = 0
        @Volatile var inputTokens = 0
        @Volatile var outputTokens = 0
        @Volatile var cacheHits = 0

        /** Aynı repliği ikinci kez sunucuya göndermemek için. */
        private val cache = LinkedHashMap<String, String>()

        fun cached(text: String): String? = synchronized(cache) { cache[text] }

        fun remember(text: String, translation: String) = synchronized(cache) {
            if (cache.size > 400) cache.remove(cache.keys.first())
            cache[text] = translation
        }

        fun summary(): String =
            "Bu oturum: $requests istek · ${inputTokens} giriş · ${outputTokens} çıkış jetonu · " +
                "$cacheHits tekrar ücretsiz karşılandı"
    }

    fun remember(english: String, turkish: String) {
        history.addLast(english to turkish)
        while (history.size > 2) history.removeFirst()
    }

    fun clearHistory() = history.clear()

    suspend fun translate(text: String): String? = withContext(Dispatchers.IO) {
        val key = prefs.activeKey
        if (key.isBlank()) {
            lastError = "API anahtarı girilmemiş. aistudio.google.com/api-keys " +
                "adresinden alıp Gelişmiş bölümündeki kutuya yapıştırın."
            return@withContext null
        }

        Usage.cached(text)?.let {
            Usage.cacheHits++
            lastError = null
            return@withContext it
        }

        val activeModel =
            if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel else prefs.model
        val first = request(text, activeModel, key)
        if (first != null) return@withContext first

        // Model adı kabul edilmediyse hesapta gerçekte hangi modeller varsa onu sor.
        val err = lastError ?: ""
        if (err.contains("404") || err.contains("not_found", ignoreCase = true)) {
            val auto = pickBest(fetchModels(key))
            if (auto != null && auto != prefs.model) {
                val second = request(text, auto, key)
                if (second != null) {
                    if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel = auto
                    else prefs.model = auto
                    return@withContext second
                }
            }
            if (lastError != null) {
                lastError = "Hesabınızda kullanılabilir model bulunamadı. " +
                    "Uygulamada MODELLERİ BUL tuşuna basın."
            }
        }
        null
    }

    /** Hesabın gerçekten erişebildiği model adlarını getirir. */
    /**
     * Anahtar HTTP başlığına konulacağı için yalnızca ASCII olabilir.
     * Yanlış metin yapıştırıldığında uygulamanın çökmemesi gerekiyor.
     */
    /**
     * Google'ın belgelediği yöntem x-goog-api-key. Bazı anahtar türlerinde
     * bu reddedilirse (401) Bearer ile ikinci bir deneme yapılıyor.
     */
    private fun geminiBasliklari(key: String): List<Pair<String, String>> = listOf(
        "x-goog-api-key" to key,
        "Authorization" to "Bearer $key",
    )

    /** Tek bir başlıkla dener. Başarılıysa liste, değilse null döner. */
    private fun fetchGeminiModels(ad: String, deger: String): List<String>? {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models")
            .get()
            .addHeader(ad, deger)
            .build()
        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return null
                }
                val arr = JSONObject(raw).optJSONArray("models") ?: return null
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val yontemler = item.optJSONArray("supportedGenerationMethods")
                    var uygun = yontemler == null
                    if (yontemler != null) {
                        for (j in 0 until yontemler.length()) {
                            if (yontemler.optString(j) == "generateContent") uygun = true
                        }
                    }
                    if (!uygun) continue
                    val id = item.optString("name").removePrefix("models/")
                    if (id.isNotBlank()) out.add(id)
                }
                lastError = null
                out
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            null
        }
    }

    private fun safeKey(key: String): String? {
        val trimmed = key.trim()
        if (trimmed.isEmpty()) {
            lastError = "API anahtarı girilmemiş. aistudio.google.com/api-keys " +
                "adresinden alıp Gelişmiş bölümündeki kutuya yapıştırın."
            return null
        }
        if (trimmed.any { it.code < 33 || it.code > 126 }) {
            lastError = "API anahtarı hatalı: içinde boşluk veya özel karakter var. " +
                "Kutuyu temizleyip anahtarı yeniden yapıştırın."
            return null
        }
        if (trimmed.length < 20) {
            lastError = "API anahtarı çok kısa, eksik yapıştırılmış olabilir"
            return null
        }
        return trimmed
    }

    fun fetchModels(key: String): List<String> {
        val clean = safeKey(key) ?: return emptyList()
        val gemini = prefs.provider == Prefs.PROVIDER_GEMINI
        if (gemini) {
            for ((ad, deger) in geminiBasliklari(clean)) {
                val sonuc = fetchGeminiModels(ad, deger)
                if (sonuc != null) return sonuc
                if (lastError?.startsWith("401") != true) return emptyList()
            }
            return emptyList()
        }
        val builder = Request.Builder()
            .url("https://api.anthropic.com/v1/models?limit=100")
            .get()
            .addHeader("x-api-key", clean)
            .addHeader("anthropic-version", "2023-06-01")
        val req = builder.build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return emptyList()
                }
                val arr = JSONObject(raw).optJSONArray("data") ?: return emptyList()
                val out = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val id = arr.optJSONObject(i)?.optString("id").orEmpty()
                    if (id.isNotBlank()) out.add(id)
                }
                lastError = null
                out
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            emptyList()
        }
    }

    /** Altyazı için en uygunu: en hızlı olan. Yoksa eldeki ilk model. */
    fun pickBest(models: List<String>): String? {
        if (models.isEmpty()) return null
        if (prefs.provider == Prefs.PROVIDER_GEMINI) {
            // Hızlı ve ücretsiz katmanda olanlar önce.
            return models.firstOrNull { it.contains("flash", ignoreCase = true) && !it.contains("thinking") }
                ?: models.firstOrNull { it.startsWith("gemini-3") }
                ?: models.firstOrNull { it.startsWith("gemini") && !it.contains("embedding") }
                ?: models.firstOrNull()
        }
        return models.firstOrNull { it.contains("haiku", ignoreCase = true) }
            ?: models.firstOrNull { it.contains("sonnet", ignoreCase = true) }
            ?: models.first()
    }

    private fun request(text: String, model: String, key: String): String? =
        if (prefs.provider == Prefs.PROVIDER_GEMINI) {
            requestGemini(text, if (model.startsWith("gemini")) model else prefs.geminiModel, key)
        } else {
            requestAnthropic(text, model, key)
        }

    /**
     * Google Gemini: ücretsiz katmanı olduğu için varsayılan sağlayıcı.
     * Aynı sistem talimatını ve son replik geçmişini kullanır.
     */
    private fun requestGemini(text: String, model: String, rawKey: String): String? {
        val key = safeKey(rawKey) ?: return null
        val contents = JSONArray()
        for ((en, tr) in history) {
            contents.put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", en)))
            )
            contents.put(
                JSONObject().put("role", "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", tr)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text)))
        )

        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt())))
            )
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject()
                    .put("maxOutputTokens", 512)
                    // Düşünme kapalı: altyazı çevirisi kısa bir iş, düşünme
                    // hem cevabı geciktiriyor hem de cevap sınırını tüketip
                    // boş yanıt dönmesine yol açıyor.
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
            )
            .toString()
            .toRequestBody("application/json".toMediaType())

        for ((ad, deger) in geminiBasliklari(key)) {
            val sonuc = geminiIstek(text, model, ad, deger, body)
            if (sonuc != null) return sonuc
            if (lastError?.startsWith("401") != true) return null
        }
        return null
    }

    /** Tek bir başlıkla Gemini isteği. */
    private fun geminiIstek(
        text: String,
        model: String,
        ad: String,
        deger: String,
        body: okhttp3.RequestBody,
    ): String? {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .addHeader(ad, deger)
            .addHeader("content-type", "application/json")
            .post(body)
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                Usage.requests++
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return null
                }
                val json = JSONObject(raw)
                val cand = json.optJSONArray("candidates")?.optJSONObject(0)
                val parts = cand?.optJSONObject("content")?.optJSONArray("parts")
                val out = StringBuilder()
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        out.append(parts.optJSONObject(i)?.optString("text").orEmpty())
                    }
                }
                val result = out.toString().trim().trim('"')
                if (result.isBlank()) {
                    val finish = cand?.optString("finishReason").orEmpty().ifBlank { "?" }
                    lastError = "boş yanıt · model=$model · bitiş=$finish"
                    null
                } else {
                    lastError = null
                    json.optJSONObject("usageMetadata")?.let { u ->
                        Usage.inputTokens += u.optInt("promptTokenCount")
                        Usage.outputTokens += u.optInt("candidatesTokenCount")
                    }
                    Usage.remember(text, result)
                    result
                }
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            null
        }
    }

    /** Her iki sağlayıcıda da aynı talimat kullanılıyor; kısa tutuluyor. */
    private fun systemPrompt(): String {
        val tur = prefs.contentType
        val ad = prefs.gameName.ifBlank { "bilinmeyen bir ${tur.lowercase()}" }
        val sb = StringBuilder()
        sb.append(tur).append(" altyazısı çevirmeni. ").append(tur).append(": ").append(ad).append(". ")
        sb.append("OCR ile okunmuş İngilizce repliği doğal Türkçeye çevir. ")
        sb.append("Özel isimleri çevirme. OCR hatalarını bağlamdan düzelt. Argoyu yumuşatma. ")
        if (prefs.showSpeaker) {
            sb.append("Replikte konuşan adı varsa 'İsim: çeviri' biçiminde koru. ")
        }
        sb.append("Altyazı tek bakışta okunacak, kısa ve akıcı olsun. ")
        sb.append("Sadece çeviriyi yaz, açıklama yazma, mutlaka bir çeviri ver.")
        return sb.toString()
    }

    private fun requestAnthropic(text: String, model: String, rawKey: String): String? {
        val key = safeKey(rawKey) ?: return null
        val messages = JSONArray()
        for ((en, tr) in history) {
            messages.put(JSONObject().put("role", "user").put("content", en))
            messages.put(JSONObject().put("role", "assistant").put("content", tr))
        }
        messages.put(JSONObject().put("role", "user").put("content", text))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 400)
            .put("system", systemPrompt())
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", key)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body)
            .build()

        return try {
            client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    lastError = shortError(resp.code, raw)
                    return null
                }
                val json = JSONObject(raw)
                json.optJSONObject("usage")?.let { u ->
                    Usage.requests++
                    Usage.inputTokens += u.optInt("input_tokens")
                    Usage.outputTokens += u.optInt("output_tokens")
                }
                val content = json.optJSONArray("content")
                val out = StringBuilder()
                val types = StringBuilder()
                if (content != null) {
                    for (i in 0 until content.length()) {
                        val part = content.optJSONObject(i) ?: continue
                        val type = part.optString("type")
                        if (types.isNotEmpty()) types.append(",")
                        types.append(type)
                        // Bazı modeller önce düşünme bloğu döndürür; metin bloklarını topluyoruz.
                        if (type == "text") out.append(part.optString("text"))
                    }
                }
                val result = out.toString().trim().trim('"')
                if (result.isBlank() || result == "-") {
                    // Boş dönüşün sebebini görebilmek için özetini saklıyoruz.
                    val stop = json.optString("stop_reason", "?")
                    lastError = "boş yanıt · model=$model · stop=$stop · blok=$types"
                    null
                } else {
                    lastError = null
                    Usage.remember(text, result)
                    result
                }
            }
        } catch (e: Throwable) {
            lastError = e.message ?: "bağlantı hatası"
            null
        }
    }

    /** Sunucu hatasını, ne yapılacağını söyleyen bir cümleye çevirir. */
    private fun anlasilirHata(code: Int, mesaj: String): String = when (code) {
        401 -> "Anahtar geçersiz veya iptal edilmiş. " +
            "aistudio.google.com/api-keys adresinden yeni anahtar alıp yapıştırın."
        429 -> "Günlük ücretsiz kota doldu. Yarın yenilenir ya da başka anahtar kullanın."
        404 -> "Model bulunamadı. MODELLERİ BUL tuşuna basıp listeden seçin."
        403 -> "Bu anahtarın Gemini yetkisi yok. AI Studio'dan yeni anahtar alın."
        else -> "$code: ${mesaj.take(120)}"
    }

    private fun shortError(code: Int, raw: String): String {
        val msg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Throwable) {
            ""
        }
        return anlasilirHata(code, if (msg.isBlank()) raw else msg)
    }

}
