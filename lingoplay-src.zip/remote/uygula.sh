#!/usr/bin/env bash
#
# LingoPlay Remote — Chiaki kaynağını alıp bizim değişikliklerimizi uygular.
#
# Aşama 1: uygulama kendi adıyla, kendi paket kimliğiyle derlensin.
# Böylece telefonda mevcut LingoPlay'in yanına ayrı bir uygulama olarak kurulur,
# birbirlerini silmezler.
#
set -euo pipefail

KAYNAK_DEPO="https://github.com/streetpea/chiaki-ng.git"
HEDEF="${1:-chiaki-kaynak}"

# YAYINLANMIŞ SÜRÜME SABİTLİYORUZ.
# Geliştirme ucunda (main) yayından sonra 100'den fazla değişiklik birikmiş ve
# bunların hiçbiri Android'de denenmemiş — Chiaki ekibi Android'i otomatik
# derlemiyor. Kayıt sırasındaki "failed to send search" hatası oradan geliyordu.
# v1.10.0 ise yayınlanmış, test edilmiş sürüm.
SURUM="v1.10.0"

PAKET_ESKI="com.metallic.chiaki"
PAKET_YENI="com.lingoplay.remote"
AD_YENI="LingoPlay Remote"

echo "==> Chiaki kaynağı indiriliyor (sürüm: $SURUM)"
rm -rf "$HEDEF"
# --recurse-submodules şart: nanopb, jerasure, gf-complete ve oboe ayrı
# depolarda duruyor. Onlarsız native derleme CMake aşamasında düşer.
git clone --depth 1 --branch "$SURUM" --recurse-submodules --shallow-submodules \
    "$KAYNAK_DEPO" "$HEDEF"

# Gerçekten o sürümde miyiz, doğrulayalım.
ALINAN=$(git -C "$HEDEF" describe --tags --exact-match 2>/dev/null || echo "?")
if [ "$ALINAN" != "$SURUM" ]; then
    echo "HATA: beklenen sürüm $SURUM, gelen: $ALINAN"
    exit 1
fi
echo "    doğrulandı: $ALINAN"

echo "==> Alt modüller kontrol ediliyor"
for ALT in third-party/nanopb third-party/jerasure third-party/gf-complete \
           android/app/src/main/cpp/oboe; do
    if [ -z "$(ls -A "$HEDEF/$ALT" 2>/dev/null)" ]; then
        echo "HATA: $ALT boş geldi, alt modül indirilememiş"
        exit 1
    fi
    echo "    tamam: $ALT"
done

cd "$HEDEF/android"

echo "==> Paket kimliği değiştiriliyor: $PAKET_ESKI -> $PAKET_YENI"
# Yalnızca applicationId değişiyor; namespace aynı kalıyor çünkü tüm kaynak
# dosyalar o ad altında. Android için ayrı uygulama olmasına applicationId yeter.
sed -i "s|applicationId \"$PAKET_ESKI\"|applicationId \"$PAKET_YENI\"|" app/build.gradle
grep -q "applicationId \"$PAKET_YENI\"" app/build.gradle || {
    echo "HATA: applicationId değiştirilemedi"; exit 1; }

echo "==> Uygulama adı değiştiriliyor: $AD_YENI"
sed -i "s|<string name=\"app_name\">[^<]*</string>|<string name=\"app_name\">$AD_YENI</string>|" \
    app/src/main/res/values/strings.xml
grep -q "<string name=\"app_name\">$AD_YENI</string>" app/src/main/res/values/strings.xml || {
    echo "HATA: uygulama adı değiştirilemedi"; exit 1; }

# Diğer dillerdeki ad dosyaları da varsa aynı ada çekiliyor.
for f in app/src/main/res/values-*/strings.xml; do
    [ -f "$f" ] || continue
    sed -i "s|<string name=\"app_name\">[^<]*</string>|<string name=\"app_name\">$AD_YENI</string>|" "$f"
done

echo "==> Dosya sağlayıcı adresi ayrıştırılıyor"
# Bu adres manifest'te ve kodda SABİT yazılmış. Değiştirilmezse, telefonda
# Chiaki zaten kuruluysa Android ikinci uygulamayı "yüklenmedi" diye reddeder.
sed -i "s|android:authorities=\"$PAKET_ESKI.fileprovider\"|android:authorities=\"$PAKET_YENI.fileprovider\"|" \
    app/src/main/AndroidManifest.xml
grep -q "android:authorities=\"$PAKET_YENI.fileprovider\"" app/src/main/AndroidManifest.xml || {
    echo "HATA: manifest'teki sağlayıcı adresi değiştirilemedi"; exit 1; }

sed -i "s|\"$PAKET_ESKI.fileprovider\"|\"$PAKET_YENI.fileprovider\"|" \
    app/src/main/java/com/metallic/chiaki/common/LogManager.kt
grep -q "\"$PAKET_YENI.fileprovider\"" \
    app/src/main/java/com/metallic/chiaki/common/LogManager.kt || {
    echo "HATA: koddaki sağlayıcı adresi değiştirilemedi"; exit 1; }

# Eski adres hiçbir yerde kalmamalı.
if grep -rn "$PAKET_ESKI\.fileprovider" app/src/main 2>/dev/null; then
    echo "HATA: eski sağlayıcı adresi hâlâ duruyor"; exit 1
fi

echo "==> Kısa yoldan çağrılan sınıf adları tam hâline çevriliyor"
# Düzen dosyalarında sınıflar başında nokta ile yazılmış:
#   app:layout_behavior=".main.FloatingActionButtonBackgroundBehavior"
# Android bu noktayı UYGULAMA KİMLİĞİNE göre çözüyor. Kimliği değiştirdiğimiz
# için sınıf bulunamıyor ve uygulama açılır açılmaz çöküyor. Tam ad yazıyoruz.
for DOSYA in app/src/main/res/layout/*.xml; do
    [ -f "$DOSYA" ] || continue
    sed -i "s|app:layout_behavior=\"\.|app:layout_behavior=\"$PAKET_ESKI.|g" "$DOSYA"
done

if grep -rn 'app:layout_behavior="\.' app/src/main/res/ 2>/dev/null; then
    echo "HATA: kısa yoldan çağrılan sınıf adı kaldı"; exit 1
fi
grep -q "app:layout_behavior=\"$PAKET_ESKI\.main\." \
    app/src/main/res/layout/activity_main.xml || {
    echo "HATA: sınıf adları tam hâline çevrilemedi"; exit 1; }
echo "    çevrildi: $(grep -c "layout_behavior=\"$PAKET_ESKI" \
    app/src/main/res/layout/activity_main.xml) adet"

echo "==> Sürüm bilgisi ekleniyor"
sed -i "s|versionName chiakiVersion|versionName \"R1.3\"|" app/build.gradle
grep -q 'versionName "R1.3"' app/build.gradle || {
    echo "HATA: sürüm adı değiştirilemedi"; exit 1; }

echo "==> Hata yakalayıcı ekleniyor"
# Uygulama çökerse sebebini İndirilenler klasörüne dosya olarak yazar.
# Yakalayıcı attachBaseContext içinde kuruluyor: böylece onCreate'ten
# ÖNCE, içerik sağlayıcıları oluşturulurken olan çökmeleri de yakalar.
cat > app/src/main/java/com/metallic/chiaki/LingoPlayApp.kt <<'KOTLIN'
package com.metallic.chiaki

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * LingoPlay Remote — çökme kaydedici.
 * Çökünce sebebi İndirilenler klasörüne "LingoPlayRemote_hata.txt" olarak yazar.
 */
class LingoPlayApp : Application()
{
	override fun attachBaseContext(base: Context?)
	{
		super.attachBaseContext(base)
		val onceki = Thread.getDefaultUncaughtExceptionHandler()
		Thread.setDefaultUncaughtExceptionHandler { thread, hata ->
			try { kaydet(rapor(thread, hata)) } catch (_: Throwable) {}
			onceki?.uncaughtException(thread, hata)
		}
	}

	private fun rapor(thread: Thread, hata: Throwable): String
	{
		val yazi = StringWriter()
		PrintWriter(yazi).use { hata.printStackTrace(it) }
		return buildString {
			append("LingoPlay Remote R1.3\n")
			append("Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
			append("Cihaz: ${Build.MANUFACTURER} ${Build.MODEL}\n")
			append("Mimari: ${Build.SUPPORTED_ABIS.joinToString()}\n")
			append("Is parcacigi: ${thread.name}\n\n")
			append(yazi.toString())
		}
	}

	private fun kaydet(metin: String)
	{
		try { File(getExternalFilesDir(null), "son_hata.txt").writeText(metin) }
		catch (_: Throwable) {}

		try {
			if (Build.VERSION.SDK_INT >= 29) {
				val bilgi = ContentValues().apply {
					put(MediaStore.Downloads.DISPLAY_NAME, "LingoPlayRemote_hata.txt")
					put(MediaStore.Downloads.MIME_TYPE, "text/plain")
				}
				val adres = contentResolver
					.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, bilgi)
				adres?.let {
					contentResolver.openOutputStream(it)?.use { akis ->
						akis.write(metin.toByteArray())
					}
				}
			} else {
				val klasor = Environment.getExternalStoragePublicDirectory(
					Environment.DIRECTORY_DOWNLOADS)
				File(klasor, "LingoPlayRemote_hata.txt").writeText(metin)
			}
		} catch (_: Throwable) {}
	}
}
KOTLIN
[ -s app/src/main/java/com/metallic/chiaki/LingoPlayApp.kt ] || {
    echo "HATA: hata yakalayıcı dosyası yazılamadı"; exit 1; }

sed -i "s|<application|<application\n        android:name=\".LingoPlayApp\"|" \
    app/src/main/AndroidManifest.xml
grep -q 'android:name=".LingoPlayApp"' app/src/main/AndroidManifest.xml || {
    echo "HATA: hata yakalayıcı manifest'e bağlanamadı"; exit 1; }

echo "==> Tek mimariye indiriliyor (arm64-v8a)"
# Chiaki normalde 4 mimari için derliyor: OpenSSL, curl, json-c ve miniupnpc
# dört kez baştan derleniyor. Modern Android telefonların hepsi arm64-v8a.
# Tek mimari: süre ~4 kat kısalıyor, hata ihtimali de aynı oranda azalıyor.
sed -i "s|versionName \"R1.3\"|versionName \"R1.3\"\n        ndk { abiFilters \"arm64-v8a\" }|" \
    app/build.gradle
grep -q 'abiFilters "arm64-v8a"' app/build.gradle || {
    echo "HATA: mimari filtresi eklenemedi"; exit 1; }

echo "==> Değişiklikler tamam"
echo "    applicationId : $PAKET_YENI"
echo "    uygulama adı  : $AD_YENI"
echo "    sürüm         : R1.3"
