#!/usr/bin/env bash
#
# LingoPlay Remote — Chiaki kaynağını alıp bizim değişikliklerimizi uygular.
#
# Aşama 1: uygulama kendi adıyla, kendi paket kimliğiyle derlensin.
# Böylece telefonda mevcut LingoPlay'in yanına ayrı bir uygulama olarak kurulur,
# birbirlerini silmezler.
#
set -euo pipefail

KAYNAK_DEPO="https://github.com/streetpea/chiaki-ng.git"
HEDEF="${1:-chiaki-kaynak}"

PAKET_ESKI="com.metallic.chiaki"
PAKET_YENI="com.lingoplay.remote"
AD_YENI="LingoPlay Remote"

echo "==> Chiaki kaynağı indiriliyor"
rm -rf "$HEDEF"
# --recurse-submodules şart: nanopb, jerasure, gf-complete ve oboe ayrı
# depolarda duruyor. Onlarsız native derleme CMake aşamasında düşer.
git clone --depth 1 --recurse-submodules --shallow-submodules \
    "$KAYNAK_DEPO" "$HEDEF"

echo "==> Alt modüller kontrol ediliyor"
for ALT in third-party/nanopb third-party/jerasure third-party/gf-complete \
           android/app/src/main/cpp/oboe; do
    if [ -z "$(ls -A "$HEDEF/$ALT" 2>/dev/null)" ]; then
        echo "HATA: $ALT boş geldi, alt modül indirilememiş"
        exit 1
    fi
    echo "    tamam: $ALT"
done

cd "$HEDEF/android"

echo "==> Paket kimliği değiştiriliyor: $PAKET_ESKI -> $PAKET_YENI"
# Yalnızca applicationId değişiyor; namespace aynı kalıyor çünkü tüm kaynak
# dosyalar o ad altında. Android için ayrı uygulama olmasına applicationId yeter.
sed -i "s|applicationId \"$PAKET_ESKI\"|applicationId \"$PAKET_YENI\"|" app/build.gradle
grep -q "applicationId \"$PAKET_YENI\"" app/build.gradle || {
    echo "HATA: applicationId değiştirilemedi"; exit 1; }

echo "==> Uygulama adı değiştiriliyor: $AD_YENI"
sed -i "s|<string name=\"app_name\">[^<]*</string>|<string name=\"app_name\">$AD_YENI</string>|" \
    app/src/main/res/values/strings.xml
grep -q "<string name=\"app_name\">$AD_YENI</string>" app/src/main/res/values/strings.xml || {
    echo "HATA: uygulama adı değiştirilemedi"; exit 1; }

# Diğer dillerdeki ad dosyaları da varsa aynı ada çekiliyor.
for f in app/src/main/res/values-*/strings.xml; do
    [ -f "$f" ] || continue
    sed -i "s|<string name=\"app_name\">[^<]*</string>|<string name=\"app_name\">$AD_YENI</string>|" "$f"
done

echo "==> Dosya sağlayıcı adresi ayrıştırılıyor"
# Bu adres manifest'te ve kodda SABİT yazılmış. Değiştirilmezse, telefonda
# Chiaki zaten kuruluysa Android ikinci uygulamayı "yüklenmedi" diye reddeder.
sed -i "s|android:authorities=\"$PAKET_ESKI.fileprovider\"|android:authorities=\"$PAKET_YENI.fileprovider\"|" \
    app/src/main/AndroidManifest.xml
grep -q "android:authorities=\"$PAKET_YENI.fileprovider\"" app/src/main/AndroidManifest.xml || {
    echo "HATA: manifest'teki sağlayıcı adresi değiştirilemedi"; exit 1; }

sed -i "s|\"$PAKET_ESKI.fileprovider\"|\"$PAKET_YENI.fileprovider\"|" \
    app/src/main/java/com/metallic/chiaki/common/LogManager.kt
grep -q "\"$PAKET_YENI.fileprovider\"" \
    app/src/main/java/com/metallic/chiaki/common/LogManager.kt || {
    echo "HATA: koddaki sağlayıcı adresi değiştirilemedi"; exit 1; }

# Eski adres hiçbir yerde kalmamalı.
if grep -rn "$PAKET_ESKI\.fileprovider" app/src/main 2>/dev/null; then
    echo "HATA: eski sağlayıcı adresi hâlâ duruyor"; exit 1
fi

echo "==> Sürüm bilgisi ekleniyor"
sed -i "s|versionName chiakiVersion|versionName \"R1.0\"|" app/build.gradle
grep -q 'versionName "R1.0"' app/build.gradle || {
    echo "HATA: sürüm adı değiştirilemedi"; exit 1; }

echo "==> Tek mimariye indiriliyor (arm64-v8a)"
# Chiaki normalde 4 mimari için derliyor: OpenSSL, curl, json-c ve miniupnpc
# dört kez baştan derleniyor. Modern Android telefonların hepsi arm64-v8a.
# Tek mimari: süre ~4 kat kısalıyor, hata ihtimali de aynı oranda azalıyor.
sed -i "s|versionName \"R1.0\"|versionName \"R1.0\"\n        ndk { abiFilters \"arm64-v8a\" }|" \
    app/build.gradle
grep -q 'abiFilters "arm64-v8a"' app/build.gradle || {
    echo "HATA: mimari filtresi eklenemedi"; exit 1; }

echo "==> Değişiklikler tamam"
echo "    applicationId : $PAKET_YENI"
echo "    uygulama adı  : $AD_YENI"
echo "    sürüm         : R1.0"
