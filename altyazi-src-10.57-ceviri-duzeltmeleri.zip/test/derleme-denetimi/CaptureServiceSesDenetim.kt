package com.example.altyazi

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager

class CaptureServiceSesDenetim(private val ctx: Context) {
    /** Gercekte companion alani; burada ornek alani. */
    @Volatile private var sonSesli: SesliOku? = null
    private val prefs = Prefs(ctx)
    @Volatile private var shownValue = ""
    @Volatile private var shownSource = ""
    private fun log(satir: String) {}
    private fun checkSelfPermission(p: String): Int = ctx.checkSelfPermission(p)

    @Volatile private var sesli: SesliOku? = null
    @Volatile private var canliSes: CanliSesDinleyici? = null
    private val TASLAK_SES_BEKLE = 1600L
    private val SES_KARARLILIK_TAM = 220L
    private val SES_KARARLILIK_YARIM = 520L
    private val SON_NOKTALAMA = listOf('.', '!', '?', '…', '"', '\'', '»')
    private val sesHandler = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var sesBekleyen: Runnable? = null
    @Volatile private var sesSonKaynak = ""
    @Volatile private var sesOkunanKaynak = ""

    private fun sesliKur() {
        if (!prefs.sesliOku) return
        val s = SesliOku(ctx) { mesaj -> log(mesaj) }
        s.hiz = prefs.sesHiz / 100f
        s.ton = prefs.sesTon / 100f
        // Ad öneki yalnız bu ayar açıkken eklenir; ses de yalnız o zaman atar.
        s.adiAtla = prefs.showSpeaker
        s.cinsiyetAyrimi = prefs.sesCinsiyet
        s.karakterAyrimi = prefs.sesKarakter
        s.internetSesi = prefs.sesInternet
        s.varsayilanSesAdi = prefs.sesVarsayilanAdi
        s.havuz = SesHavuzu.oku(prefs.sesHavuzu)
        s.dogalSesAcik = prefs.sesDogalGenAi
        s.erkekSesAdi = prefs.sesErkekAdi
        s.kadinSesAdi = prefs.sesKadinAdi
        // 10.54 duygu katmanı
        s.duyguAcik = prefs.duyguAcik
        s.duyguNotModu = prefs.duyguNotModu
        s.duyguUnlem = prefs.duyguUnlem
        s.duyguCumle = prefs.duyguCumle
        s.duyguTr = prefs.duyguTr
        s.duyguSiddet = prefs.duyguSiddet / 100f
        // 10.55 akış ve çalışma kaydı
        s.akisModu = prefs.sesAkisModu
        SesAkisi.kayitAcik = prefs.sesKaydi
        if (prefs.sesKaydi) {
            SesAkisi.temizle()
            SesAkisi.yaz("--- ses çalışma kaydı başladı · mod=" + when (prefs.sesAkisModu) {
                SesAkisi.KES -> "kes"
                SesAkisi.BITIR_ATLA -> "cümleyi bitir, atla"
                else -> "hızlanarak yetiş"
            } + " · hız %" + prefs.sesHiz + " · doğal ses " +
                (if (prefs.sesDogalGenAi) "açık" else "kapalı") + " ---")
        }
        s.baslat { ok, mesaj -> log("SESLİ OKUMA durumu: ${if (ok) "açık" else "kapalı"} · $mesaj") }
        sesli = s
        sonSesli = s
    }

    private fun sesBekleyeniIptal() {
        sesBekleyen?.let { sesHandler.removeCallbacks(it) }
        sesBekleyen = null
    }

    private fun cumleTamamMi(metin: String): Boolean {
        val son = metin.trimEnd().lastOrNull() ?: return false
        return son in SON_NOKTALAMA
    }

    private fun seslendir(value: String?, refined: Boolean, draft: Boolean) {
        val s = sesli ?: return
        sesBekleyeniIptal()
        if (value == null) {
            s.sus()
            sesSonKaynak = ""
            sesOkunanKaynak = ""
            return
        }
        if (!SesliOku.okunurMu(value)) return
        val kaynak = shownSource
        // Bu replik zaten sese verildi: düzeltmesi tekrarlanmaz.
        if (kaynak.isNotEmpty() && kaynak == sesSonKaynak) return

        // UZANTI: okunan cümlenin devamı geldiyse yeniden okuma. OCR satırı
        // açıldıkça büyüttüğü için aynı replik üç dört kez okunup kesilirdi.
        if (sesOkunanKaynak.isNotEmpty() && kaynak.length > sesOkunanKaynak.length &&
            kaynak.startsWith(sesOkunanKaynak)
        ) {
            log("SES: uzantı, tekrar okunmadı (${kaynak.take(40)})")
            return
        }

        val konusan = konusaniBul(value, kaynak)
        // Taslak satır daha uzun bekler (yapay zekâ düzeltmesi yetişsin);
        // kesin satır yalnız kararlılık kadar bekler.
        val bekleme = when {
            draft && !refined -> TASLAK_SES_BEKLE
            cumleTamamMi(value) -> SES_KARARLILIK_TAM
            else -> SES_KARARLILIK_YARIM
        }
        val r = Runnable {
            // Satır bu arada değiştiyse okuma düşer; ses ekranın gerisine kalmaz.
            if (shownValue == value && shownSource == kaynak) {
                sesSonKaynak = kaynak
                sesOkunanKaynak = kaynak
                // ÖLÇÜM OKUMA ANINDA ALINIR: bekleme boyunca sahne
                // değişebilir, en taze ölçüm en doğrusudur. Ad varsa zaten
                // ada öncelik verilir (bkz. SesliOku.cinsiyetiSec).
                val algilanan = canliSes?.cinsiyet() ?: SesPerdeOlcer.BELIRSIZ
                s.oku(value, konusan, algilanan)
                // Kendi okumamızı ölçüp yeni karaktere bağlamayalım.
                canliSes?.ttsBastir()
            }
        }
        sesBekleyen = r
        sesHandler.postDelayed(r, bekleme)
    }

    private fun konusaniBul(ceviri: String?, kaynak: String?): String? =
        KonusanCinsiyeti.adiAyikla(kaynak) ?: KonusanCinsiyeti.adiAyikla(ceviri)
}
