package com.example.altyazi

/**
 * High-confidence game-dialogue corrections. Exact, complete lines only:
 * never infer missing words from a partial OCR fragment.
 * This is a small deterministic supplement, not a replacement for ML Kit.
 */
object DialogueQuality {
    private val exact = mapOf(
        "we're in some deep fucking shit." to "Fena boka battık.",
        "you know, we're in some deep fucking shit." to "Biliyorsun, fena boka battık.",
        "what did i fucking say?" to "Ben sana ne demiştim lan?!",
        "this is so fucked!" to "Bu iş fena sıçtı!",
        "we need this intro, lu." to "Bu bağlantıya ihtiyacımız var, Lu.",
        "brian's doing us a favor, you know? we need this intro, lu." to "Brian bize iyilik yapıyor. Bu bağlantıya ihtiyacımız var, Lu.",
        "we're not that late." to "O kadar da geç kalmadık.",
        "were not that late." to "O kadar da geç kalmadık.",
        "all talk. pathetic." to "Hep laf, icraat yok. Acınası.",
        "damien. always snatching defeat from the jaws of victory." to "Damien, tam kazanacakken yine kaybetmeyi başarıyorsun.",
        "oh my god, as i live and breathe. look at the two of you." to "Aman Tanrım! Şu ikinize de bakın!",
        "look, i was just sightseeing with my girl." to "Bak, sevgilimle sadece etrafı geziyorduk.",
        "cal might have said he was like former dominican intelligence or something." to "Cal, eskiden Dominik istihbaratında çalıştığını söylemiş olabilir, öyle bir şey.",
        "fuck, oh no! argh-uh!" to "Siktir! Olamaz! Ah!",
        "where you at, vice city girls?" to "Neredesiniz, Vice City kızları?",
        "pity i can only end your life once!" to "Yazık, seni yalnızca bir kez öldürebiliyorum!"
    )

    fun translateExact(source: String): String? {
        val normalized = source.trim().replace(Regex("\\s+"), " ").lowercase(java.util.Locale.ROOT)
        return exact[normalized]
    }
}
