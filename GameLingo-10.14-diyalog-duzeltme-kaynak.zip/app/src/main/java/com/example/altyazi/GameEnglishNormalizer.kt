package com.example.altyazi

/**
 * Oyun diyaloglarında kelimesi kelimesine çevrildiğinde anlamı bozulan
 * kalıpları, çevirmeden önce eşdeğer sade İngilizceye dönüştürür.
 * Yalnızca belirgin deyimler dönüştürülür; özel isimler korunur.
 * GameTranslator GameEnglish yaklaşımından esinlenilmiştir.
 */
object GameEnglishNormalizer {
    private val rules: List<Pair<Regex, String>> = listOf(
        Regex("\\b(?:I've|I have) got your six\\b", RegexOption.IGNORE_CASE) to "I have got your back",
        Regex("\\bcheck your six\\b", RegexOption.IGNORE_CASE) to "watch behind you",
        Regex("\\bheads up(?=[!.,? ]|$)", RegexOption.IGNORE_CASE) to "watch out",
        Regex("\\btook you long enough\\b", RegexOption.IGNORE_CASE) to "you are late",
        Regex("\\bwe(?:'ve| have) got company\\b", RegexOption.IGNORE_CASE) to "enemies are coming",
        Regex("\\block and load\\b", RegexOption.IGNORE_CASE) to "get ready for battle",
        Regex("\\bsitting ducks\\b", RegexOption.IGNORE_CASE) to "easy targets"
    )

    fun normalize(source: String): String {
        var result = source
        for ((pattern, replacement) in rules) {
            result = pattern.replace(result) { match ->
                if (match.value.firstOrNull()?.isUpperCase() == true)
                    replacement.replaceFirstChar { it.uppercase() }
                else replacement
            }
        }
        return result
    }
}
