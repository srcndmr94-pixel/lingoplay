# GameLingo 10.14 — güvenli diyalog düzeltme

- `DialogueQuality.kt`: test kayıtlarında açıkça hatalı çevrilen 15 tam replik için bağlama duyarlı, kesin eşleşmeli Türkçe karşılıklar eklendi.
- `CaptureService.fastTranslateKeepingName`: bu düzeltmeler mevcut ML Kit / Firefox / web motoru zincirinden önce uygulanıyor; başka satırlar eski zincire devam ediyor.
- Eksik OCR cümlelerine otomatik tamamlama uygulanmıyor; karakter adları korunuyor.
- Mevcut çeviri motoru ayarları, ağ erişimi ve ekran döndürme kodu değiştirilmedi.

## Sınırlar
Bu, genel amaçlı yeni bir çeviri modeli değildir; 15 örneğe özel, deterministik kalite düzeltmesidir. APK derlemesi ve cihaz testi yapılmadı. Ekran döndürme sorunu ayrıca çözülmeli. Gerçek performans için yeni loglarda her satırın kaynak motorunu göstermek gerekir.
