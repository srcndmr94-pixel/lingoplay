# GameLingo 10.13 — ML Kit öncelikli ayar geçişi

- Var olan Google ML Kit İngilizce→Türkçe `FastTranslate` motoru korunmuştur; yeni bir motor yazılmamıştır.
- İlk açılışta eski kurulumlardaki Firefox ve anahtarsız Google web çevirisi varsayılanları **bir kez** kapatılır. HTTP 429 üreten web motoru bu durumda çağrılmaz.
- Gemini sağlayıcısı seçilir; ancak çevrimdışı mod varsayılandır ve API anahtarı olmadan çağrı yapılmaz. Mevcut internet modu ve geçerli Gemini anahtarı olan kurulumlar otomatik olarak çevrimdışı moda alınmaz.
- Firefox ve web çevirisi kodu ve ayarları **henüz kaldırılmadı**; ML Kit'in gerçek cihazda karşılaştırmalı testi olmadan geri dönüş yolu korunuyor.
- Anthropic API kodu ve ayarı **henüz kaldırılmadı**; bu değişiklik güvenli geçiş aşamasıdır.
- Sürüm 10.13 / versionCode 147.

## Test durumu
Android SDK/Gradle ile APK derlemesi bu ortamda doğrulanmadı. Gerçek cihaz çeviri kalitesi test edilmedi.
