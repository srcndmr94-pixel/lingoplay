from pathlib import Path
root=Path(__file__).resolve().parents[1]
code=(root/'app/src/main/java/com/example/altyazi/CaptureService.kt').read_text()
http=(root/'app/src/main/java/com/example/altyazi/DeepLCeviri.kt').read_text()
source=(root/'app/src/main/java/com/example/altyazi/OfflineFix.kt').read_text()
jvm=(root/'test/jvm/OfflineFixJvm.kt').read_text()
assert jvm.replace('private val sonSatirlar = java.util.ArrayDeque<String>()',
                   'private val sonSatirlar = ArrayDeque<String>()') == source, 'JVM test code drifted from production'
assert 'OfflineFix.strongOnlyLive = strongLive' in code
assert 'val strongLive = useDeepL || prefs.opusMtEnabled' in code
start=code.index('OfflineFix.gucluFn = if (strongLive)')
end=code.index('} else null',start)
assert 'GoogleCeviri.cevir' not in code[start:end], 'Google may silently become the live fallback'
start=code.index('private suspend fun fastTranslateKeepingName(')
end=code.index('private suspend fun processMenu(',start) if 'private suspend fun processMenu(' in code[start:] else len(code)
assert 'GoogleCeviri.cevir(parca)' not in code[start:end]
assert 'subtitleRetry.failed(source' in code
assert 'if (value.startsWith("⚠") || value.trim().equals(source.trim(), ignoreCase = true))' in code
assert 'client.newCall(request).execute()' not in http
assert 'continuation.invokeOnCancellation { call.cancel() }' in http
assert 'suspendCancellableCoroutine' in http
print('PASS: production/JVM source aligned, strict fallback, no English success, retries, HTTP cancellation')
