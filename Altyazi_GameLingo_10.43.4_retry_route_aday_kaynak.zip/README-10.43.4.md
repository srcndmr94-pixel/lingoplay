# GameLingo 10.43.4

Base: 10.43.3. Identical capture-size callbacks no longer reset rotation diagnostics or OCR signature. Elapsed measurement uses a fresh monotonic reading. Common sentence starters and honorifics are excluded from name shielding. Honorific-led text is protected from decorative-text clipping. Missing soft-exhale/distant-dog cues and the observed [Igiggles] OCR artifact are repaired.

18 JVM test groups passed; Android assembleDebug passed. APK package com.example.altyazi, versionCode 182. No device latency or live engine-quality benchmark performed. Engine order unchanged. GitHub was not modified.
