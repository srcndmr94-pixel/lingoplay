package com.example.altyazi

/**
 * OCR kaynaklı, yüksek güvenli metin düzeltmeleri ve ilk kare güven denetimi.
 * Dil modeli değildir; cümleyi yeniden yazmaz, özel isimleri tahmin etmez.
 * GameTranslator'ın kararlı okuma yaklaşımının Android'e uyarlanmış küçük kısmı.
 */
object SubtitlePreparation {
    private val repairs = listOf(
        // Örnekleri gerçek test loglarından alındı; dar bağlam dışına uygulanmaz.
        Regex("(?i)\\bmost hand some\\b") to "most handsome",
        Regex("(?i)\\bmnonths\\b") to "months",
        Regex("(?i)\\bmomn\\b") to "mom",
        Regex("(?i)\\bhave never been mnore\\b") to "have never been more",
        Regex("(?i)\\bit is timne we were at war\\b") to "it is time we were at war",
        Regex("^H don't know\\b") to "I don't know",
        Regex("(?i)\\btw\\s+O-week\\b") to "two-week",
        Regex("(?i)\\bwara million\\b") to "war a million",
        Regex("(?i)\\bthere'sa\\b") to "there's a",
        Regex("(?i)\\bain['’]?t\\b") to "ain't",
        // Yalnız ayırt edici bağlamda OCR harf/boşluk kayıpları.
        Regex("(?i)\\bwhat,\\s*didl\\s+leave\\b") to "What, did I leave",
        Regex("(?i)^wet,\\s+that sounds like a challenge\\b") to "Well, that sounds like a challenge",
        Regex("(?i)\\b(suit)\\s+Al(?=])") to "suit AI",
        // 10.31: only high-confidence OCR repairs supported by actual logs.
        Regex("(?i)\\bmnom\\b") to "mom",
        Regex("(?i)\\bwhen you were born, your mnom\\b") to "When you were born, your mom",
        Regex("(?i)\\b(?<=\\[)all gruntingl$") to "all grunting]",
        Regex("(?i)\\b(?<=\\[)oliver gruntingl$") to "Oliver grunting]",
        Regex("(?i)\\b(?<=\\[)alien gruntingl$") to "Alien grunting]",
        Regex("(?i)\\bit always find my way back to you\\b") to "I always find my way back to you",
        Regex("(?i)\\byou take the left,\\s*t[iIl1]l take the right\\b") to "You take the left, I'll take the right",
        Regex("(?i)\\bshe's stronger than she look\\s+s\\b") to "She's stronger than she looks",
        // 10.34 — kaynak tarafından doğrulanabilen başlangıç OCR bozulmaları.
        // "lever tell you about" -> "Ever tell you about"; diğer lever metinleri korunur.
        Regex("(?i)^lever(?=\\s+tell\\s+you\\s+about\\b)") to "Ever",
        // "Wet, Ill walk" -> "Well, I'll walk"; belirsiz kelimeleri uydurma.
        Regex("(?i)^wet,\\s+[Il1]{2,3}(?=\\s+(?:walk|take|go|call|see|show|meet|drive|bring)\\b)") to "Well, I'll"
    )

    // A clipped CC sound label often loses its closing bracket. Repair only
    // sound-like -ing words ending with OCR's extra 'l' (']' -> 'l'). No names
    // or ordinary dialogue words are modified.
    private val clippedSoundEnd = Regex("""(?i)^(\[[a-z]+(?:[ -][a-z]+){0,4}ing)l$""")
    // OCR may lose the bracket between a sound cue and the first spoken word:
    // "(sighs Stick to the plan." is two segments, not one sentence.
    private val clippedSoundStart = Regex(
        """(?i)^[\[(](sighs|gasps|grunts|groans|laughs|chuckles|cries|coughs|exhales|inhales|yells|screams)\s+(?=[A-Z])"""
    )

    // The OCR sometimes adds an I/l immediately INSIDE a cue: [Igasping].
    // Strip it only when a known sound verb follows; never touch speech like [I wonder].
    private val ghostIInCue = Regex(
        """(?i)\[[Il|](?=(?:gasp(?:ing|s)?|grunt(?:ing|s)?|groan(?:ing|s)?|sigh(?:ing|s)?|scream(?:ing|s)?|pant(?:ing|s)?|laugh(?:s|ing)|chuckl(?:es|ing)|yell(?:s|ing))\])"""
    )
    // A missing opening bracket before NAME + action: "Jane screams]".
    // The trailing ']' and an explicit cue verb are required to avoid rewriting dialogue.
    private val missingCueOpen = Regex(
        """(?<![\p{L}\[])(\p{Lu}[\p{Ll}]{1,24}(?:\s+\p{Lu}[\p{Ll}]{1,24})?)\s+(screams|screaming|grunts|groans|gasping|panting|crying|chuckling|laughing|yells|sighs)]"""
    )
    // "[Jane] pantingl" is one damaged sound cue, not spoken English.
    private val separatedNameAction = Regex(
        """^\[(\p{Lu}[\p{Ll}]{1,24})]\s+(panting|gasping|grunting|groaning|screaming|crying|chuckling|laughing|sighing)[lI]$"""
    )

    fun repair(text: String): String {
        var current = ghostIInCue.replace(text.trim(), "[")
        current = missingCueOpen.replace(current) { "[${it.groupValues[1]} ${it.groupValues[2]}]" }
        current = separatedNameAction.replace(current) { "[${it.groupValues[1]} ${it.groupValues[2]}]" }
        current = clippedSoundEnd.replace(current) { "${it.groupValues[1]}]" }
        current = clippedSoundStart.replace(current) { "[${it.groupValues[1].lowercase()}] " }
        for ((pattern, replacement) in repairs) {
            current = pattern.replace(current) { match ->
                if (match.value.firstOrNull()?.isUpperCase() == true) {
                    replacement.replaceFirstChar { it.uppercase() }
                } else replacement
            }
        }
        return current
    }

    private val safeShortWords = setOf(
        "a", "i", "o", "an", "am", "as", "at", "be", "by", "do", "go", "ha",
        "he", "hi", "if", "in", "is", "it", "me", "mr", "ms", "my", "no",
        "of", "oh", "ok", "on", "or", "so", "to", "tv", "uh", "um", "up",
        "us", "we", "ya", "ye", "ai", "dr", "st", "id", "vs"
    )
    private val words = Regex("[\\p{L}]+(?:['’][\\p{L}]+)?")
    private val suspiciousChars = Regex("[|#@%]|[\\p{L}]\\d[\\p{L}]|\\d[\\p{L}]\\d")

    /** Şüpheli OCR: ilk karede acele etmeyip ikinci, aynı okumayı bekle. */
    fun confidentFirstRead(text: String): Boolean {
        if (text.isBlank()) return false
        // Sahne/ses etiketlerini gereksiz yere yavaşlatma.
        if (text.trim().matches(Regex("^\\[[^]\\n]+]$"))) return true
        if (suspiciousChars.containsMatchIn(text)) return false
        val tokens = words.findAll(text).map { it.value }.toList()
        if (tokens.isEmpty()) return false
        return tokens.none { word ->
            word.length <= 2 && word.lowercase() !in safeShortWords
        }
    }
}

/**
 * Yalnız Google yolunda güvenli anlamsal normalleştirme.
 * Cümle sonundaki ", too" çoğu zaman "ben de" anlamındadır;
 * "too much/too late" hiçbir zaman değiştirilmez.
 */
object GoogleSourcePreparation {
    private val finalToo = Regex("(?i),\\s*too([.!?…]*)$")

    fun prepare(text: String): String = finalToo.replace(text) { match ->
        " as well" + match.groupValues[1]
    }
}
