package com.example.altyazi

/**
 * SES AKIŞI VE YETİŞME (10.55)
 *
 * SORUN: Oyun altyazısı 1-3 saniyede bir değişiyor, Türkçe TTS ise bir
 * repliği 4-6 saniyede okuyor. Her yeni replik `QUEUE_FLUSH` ile
 * öncekini kesiyordu. Duyulan şey cümleler değil, her cümlenin ilk
 * yarısı oluyordu — dublaj hissi bu yüzden yoktu. Duygu eklemek bu
 * sorunu çözmez; önce yetişmek gerekiyor.
 *
 * Bu nesne üç işi yapar:
 *
 *  1. OKUMA SÜRESİ TAHMİNİ — harf sayısından süre. Taban değer
 *     ölçümle güncellenir: her TAMAMLANAN okumada gerçek süre
 *     kaydedilir ve harf/saniye öğrenilir. Böylece tahmin cihazın
 *     gerçek motoruna oturuyor, benim varsayımıma değil.
 *
 *  2. YETİŞME KARARI — üç mod: kes, cümleyi bitir ve araya gireni
 *     atla, hızlanarak yetiş.
 *
 *  3. ÇALIŞMA KAYDI — her repliğin geliş zamanı, okunan biçimi,
 *     sesi, duygusu, gerçek süresi ve kesilip kesilmediği. Sonunda
 *     özet: kaç replik, kaçı kesildi, ortalama ihtiyaç ne kadardı.
 *
 * TASARIM NOTU: Android bağımlılığı yok; tek başına derlenip
 * sınanabiliyor. Zaman bile dışarıdan veriliyor.
 */
object SesAkisi {

    // ------------------------------------------------------------ modlar

    /** Yeni replik gelince okunanı kes (10.54'e kadarki davranış). */
    const val KES = 0

    /** Okunan cümleyi bitir, o sırada gelen repliği atla. */
    const val BITIR_ATLA = 1

    /** Hızlanarak yetiş; gerekirse yine de keser. Varsayılan. */
    const val HIZLAN = 2

    /**
     * Türkçe TTS'in hız 1.0'da okuduğu harf/saniye için başlangıç değeri.
     *
     * NEREDEN: Türkçe ortalama 4,8 harf/hece ve normal konuşma 3,2
     * hece/saniye üzerinden yaklaşık 15. Ölçüm geldikçe bu değer
     * kullanılmıyor, öğrenilen değer kullanılıyor.
     */
    const val TABAN_HARF_SN = 15.0

    /** Öğrenme için en az bu kadar tam okuma gerekir. */
    const val EN_AZ_OLCUM = 3

    /** Öğrenmede tutulan en çok ölçüm sayısı. */
    const val OLCUM_PENCERESI = 24

    /** Hızlanmanın üst sınırı. Üstünde anlaşılmaz oluyor. */
    const val EN_YUKSEK_CARPAN = 1.6f

    /** Kesilme oranı bunun altındaysa hiç hızlanmaz. */
    const val HIZLANMA_ESIGI = 0.20

    /** BITIR_ATLA modunda: okuma bu kadarını geçtiyse bitirilir. */
    const val BITIRME_ESIGI = 0.55

    /** Kayıtta tutulan en çok satır. */
    const val KAYIT_SINIRI = 400

    // ------------------------------------------------------- süre tahmini

    /**
     * Gerçek okuma sürelerinden harf/saniye öğrenir.
     *
     * Yalnız TAMAMLANAN okumalar sayılır: kesilen okumanın süresi
     * metnin tamamına ait değil, o yüzden öğrenmeyi bozar.
     */
    class Tahminci {
        private val harfler = ArrayDeque<Int>()
        private val sureler = ArrayDeque<Long>()
        private val hizlar = ArrayDeque<Float>()

        /** Tamamlanmış bir okumayı öğrenmeye katar. */
        fun ekle(harf: Int, ms: Long, hiz: Float) {
            if (harf < 8 || ms < 200L || ms > 60_000L) return
            if (hiz <= 0.05f) return
            harfler.addLast(harf)
            sureler.addLast(ms)
            hizlar.addLast(hiz)
            while (harfler.size > OLCUM_PENCERESI) {
                harfler.removeFirst()
                sureler.removeFirst()
                hizlar.removeFirst()
            }
        }

        fun olcumSayisi(): Int = harfler.size

        /**
         * Hız 1.0'a indirgenmiş harf/saniye. Yeterli ölçüm yoksa taban.
         *
         * İNDİRGEME: motor hız 1,3 ile okuduysa aynı metni 1,0 ile
         * okuma hızı oranla daha düşüktür; ölçümler farklı hızlardan
         * gelebildiği için her biri kendi hızına bölünür.
         */
        fun harfSn(): Double {
            if (harfler.size < EN_AZ_OLCUM) return TABAN_HARF_SN
            var toplam = 0.0
            var adet = 0
            val h = harfler.toList()
            val s = sureler.toList()
            val z = hizlar.toList()
            for (i in h.indices) {
                val hs = h[i] * 1000.0 / s[i]      // o okumadaki harf/sn
                toplam += hs / z[i]                // hız 1.0'a indir
                adet++
            }
            if (adet == 0) return TABAN_HARF_SN
            return (toplam / adet).coerceIn(4.0, 40.0)
        }

        /** Bu metnin bu hızda kaç ms süreceği. */
        fun tahminMs(metin: String, hiz: Float): Long = tahmin(metin, hiz, harfSn())

        fun temizle() {
            harfler.clear()
            sureler.clear()
            hizlar.clear()
        }
    }

    /**
     * Süre tahmini. Noktalama duraklama ekler: her cümle sonu ~180 ms,
     * her virgül ~90 ms. Kısa repliklerde motorun açılış gecikmesi
     * baskın olduğu için 250 ms taban eklenir.
     */
    fun tahmin(metin: String, hiz: Float, harfSn: Double): Long {
        if (metin.isBlank()) return 0L
        val h = hiz.coerceIn(0.3f, 3.0f)
        val hs = harfSn.coerceIn(4.0, 40.0)
        val harf = metin.length
        var ms = harf * 1000.0 / (hs * h)
        ms += metin.count { it == '.' || it == '!' || it == '?' || it == '…' } * 180.0
        ms += metin.count { it == ',' || it == ';' || it == ':' } * 90.0
        ms += 250.0
        return ms.toLong().coerceIn(120L, 120_000L)
    }

    // -------------------------------------------------------- yetişme kararı

    /**
     * Yeni replik geldiğinde ne yapılacak.
     *
     * @param oku okunacak mı
     * @param hizCarpani okuma hızına uygulanacak ek çarpan
     * @param kes okunmakta olan kesilecek mi (false: kuyruğa eklenmez, atlanır)
     * @param neden kayda yazılacak kısa açıklama
     */
    data class Karar(
        val oku: Boolean,
        val hizCarpani: Float,
        val kes: Boolean,
        val neden: String,
    )

    /**
     * @param mod [KES] / [BITIR_ATLA] / [HIZLAN]
     * @param okunuyor o anda bir replik okunuyor mu
     * @param gecenMs okunan repliğin kaç ms'dir okunduğu
     * @param tahminMs okunan repliğin tahmini toplam süresi
     * @param kesilmeOrani son repliklerde kesilme oranı (0..1)
     */
    fun karar(
        mod: Int,
        okunuyor: Boolean,
        gecenMs: Long,
        tahminMs: Long,
        kesilmeOrani: Double,
    ): Karar {
        val carpan = if (mod == HIZLAN) hizlanmaCarpani(kesilmeOrani) else 1f
        if (!okunuyor) {
            return Karar(true, carpan, false, if (carpan > 1.01f) "yetişme hızı ×%.2f".format(carpan) else "boşta")
        }
        if (mod == BITIR_ATLA) {
            val oran = if (tahminMs <= 0L) 1.0 else gecenMs.toDouble() / tahminMs
            if (oran >= BITIRME_ESIGI) {
                return Karar(false, 1f, false, "cümle bitiyor (%%%d), replik atlandı".format((oran * 100).toInt()))
            }
            return Karar(true, carpan, true, "cümlenin başındaydı (%%%d), kesildi".format((oran * 100).toInt()))
        }
        // KES ve HIZLAN: yeni replik her zaman öne geçer.
        val oran = if (tahminMs <= 0L) 0.0 else gecenMs.toDouble() / tahminMs
        val neden = if (carpan > 1.01f) "kesildi (%%%d) · yetişme hızı ×%.2f".format((oran * 100).toInt(), carpan)
        else "kesildi (%%%d)".format((oran * 100).toInt())
        return Karar(true, carpan, true, neden)
    }

    /**
     * Kesilme oranına göre hızlanma çarpanı.
     *
     * %20'ye kadar hiç hızlanmaz — tek tük kesilme normaldir. Sonra
     * doğrusal olarak artar ve %80 kesilmede üst sınıra oturur.
     */
    fun hizlanmaCarpani(kesilmeOrani: Double): Float {
        val k = kesilmeOrani.coerceIn(0.0, 1.0)
        if (k <= HIZLANMA_ESIGI) return 1f
        val pay = (k - HIZLANMA_ESIGI) / (0.80 - HIZLANMA_ESIGI)
        val c = 1.0 + pay.coerceIn(0.0, 1.0) * (EN_YUKSEK_CARPAN - 1f)
        return c.toFloat().coerceIn(1f, EN_YUKSEK_CARPAN)
    }

    // ------------------------------------------------------- kesilme sayacı

    /** Son repliklerin kesilip kesilmediğini tutar. */
    class Sayac(private val pencere: Int = 12) {
        private val kesildi = ArrayDeque<Boolean>()
        private var toplamReplik = 0
        private var toplamKesilen = 0
        private var toplamOkunanMs = 0L
        private var toplamTahminMs = 0L
        private var atlanan = 0

        fun replik(kesildiMi: Boolean, okunanMs: Long, tahminMs: Long) {
            kesildi.addLast(kesildiMi)
            while (kesildi.size > pencere) kesildi.removeFirst()
            toplamReplik++
            if (kesildiMi) toplamKesilen++
            if (okunanMs > 0L) toplamOkunanMs += okunanMs
            if (tahminMs > 0L) toplamTahminMs += tahminMs
        }

        fun atlandi() {
            atlanan++
        }

        /** Son pencerede kesilme oranı. */
        fun oran(): Double {
            if (kesildi.isEmpty()) return 0.0
            return kesildi.count { it }.toDouble() / kesildi.size
        }

        fun ozet(harfSn: Double, olcumSayisi: Int): String {
            if (toplamReplik == 0 && atlanan == 0) return "ÖZET: hiç replik okunmadı"
            val oranYuzde = if (toplamReplik == 0) 0 else toplamKesilen * 100 / toplamReplik
            val ortOkunan = if (toplamReplik == 0) 0L else toplamOkunanMs / toplamReplik
            val ortTahmin = if (toplamReplik == 0) 0L else toplamTahminMs / toplamReplik
            val acik = if (ortTahmin <= 0L) 0 else ((1.0 - ortOkunan.toDouble() / ortTahmin) * 100).toInt()
            return "ÖZET: $toplamReplik replik · $toplamKesilen kesildi (%$oranYuzde) · " +
                "$atlanan atlandı · ortalama okunan ${sn(ortOkunan)} / gereken ${sn(ortTahmin)} · " +
                "yetişme açığı %$acik · öğrenilen hız ${"%.1f".format(harfSn)} harf/sn ($olcumSayisi ölçüm)"
        }

        fun temizle() {
            kesildi.clear()
            toplamReplik = 0
            toplamKesilen = 0
            toplamOkunanMs = 0L
            toplamTahminMs = 0L
            atlanan = 0
        }
    }

    fun sn(ms: Long): String = "%.1f sn".format(ms / 1000.0)

    // ------------------------------------------------------- çalışma kaydı

    private val kayit = ArrayDeque<String>()

    @Volatile
    var kayitAcik = false

    fun yaz(satir: String) {
        if (!kayitAcik) return
        synchronized(kayit) {
            kayit.addLast(satir)
            while (kayit.size > KAYIT_SINIRI) kayit.removeFirst()
        }
    }

    fun tumu(): List<String> = synchronized(kayit) { kayit.toList() }

    fun satirSayisi(): Int = synchronized(kayit) { kayit.size }

    fun temizle() = synchronized(kayit) { kayit.clear() }

    /** Saat:dakika:saniye.milisaniye — zaman dışarıdan verilir. */
    fun saat(ms: Long): String {
        val t = ms / 1000
        val s = t % 60
        val d = (t / 60) % 60
        val h = (t / 3600) % 24
        return "%02d:%02d:%02d.%03d".format(h, d, s, ms % 1000)
    }
}
