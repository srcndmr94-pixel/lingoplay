import com.example.altyazi.SesAkisi

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") {
    if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") }
}
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

fun main() {
    println("== tahmin ==")
    val t1 = SesAkisi.tahmin("Kenton: Maskelerinizde iletisim sistemi var", 1f, 15.0)
    kontrol("42 harf ~3 sn", t1 in 2600L..3800L, "$t1 ms")
    kontrol("bos metin 0", SesAkisi.tahmin("", 1f, 15.0) == 0L)
    val t2 = SesAkisi.tahmin("Kenton: Maskelerinizde iletisim sistemi var", 2f, 15.0)
    kontrol("iki kat hiz yarisi surer", t2 < t1, "$t2 < $t1")
    val t3 = SesAkisi.tahmin("Kenton: Maskelerinizde iletisim sistemi var", 0.5f, 15.0)
    kontrol("yarim hiz iki kati surer", t3 > t1, "$t3 > $t1")
    val nokta = SesAkisi.tahmin("Gel. Gel. Gel.", 1f, 15.0)
    val noktasiz = SesAkisi.tahmin("Gel  Gel  Gel ", 1f, 15.0)
    kontrol("noktalama duraklama ekler", nokta > noktasiz, "$nokta > $noktasiz")
    kontrol("kisa replikte taban var", SesAkisi.tahmin("Ah", 1f, 15.0) >= 250L)
    kontrol("hiz kirpilir", SesAkisi.tahmin("Gel buraya hemen", 99f, 15.0) > 0L)
    kontrol("harfSn kirpilir", SesAkisi.tahmin("Gel buraya hemen", 1f, 0.001) > 0L)

    println("== tahminci ogrenme ==")
    val tc = SesAkisi.Tahminci()
    esit("basta taban", SesAkisi.TABAN_HARF_SN, tc.harfSn())
    esit("basta olcum yok", 0, tc.olcumSayisi())
    // 100 harf 5000 ms, hiz 1.0 -> 20 harf/sn
    repeat(3) { tc.ekle(100, 5000L, 1f) }
    kontrol("ogrenildi ~20", kotlin.math.abs(tc.harfSn() - 20.0) < 0.5, tc.harfSn().toString())
    esit("3 olcum", 3, tc.olcumSayisi())
    // hiz 2.0 ile ayni metin yarisi surerse temel hiz ayni kalmali
    val tc2 = SesAkisi.Tahminci()
    repeat(3) { tc2.ekle(100, 2500L, 2f) }
    kontrol("hiza indirgeme dogru (~20)", kotlin.math.abs(tc2.harfSn() - 20.0) < 0.5, tc2.harfSn().toString())
    // bozuk olcumler alinmaz
    val tc3 = SesAkisi.Tahminci()
    tc3.ekle(3, 5000L, 1f); tc3.ekle(100, 50L, 1f); tc3.ekle(100, 90_000L, 1f); tc3.ekle(100, 5000L, 0f)
    esit("bozuk olcum alinmaz", 0, tc3.olcumSayisi())
    // pencere sinirli
    val tc4 = SesAkisi.Tahminci()
    repeat(60) { tc4.ekle(100, 5000L, 1f) }
    esit("pencere siniri", SesAkisi.OLCUM_PENCERESI, tc4.olcumSayisi())
    tc4.temizle()
    esit("temizlenir", 0, tc4.olcumSayisi())
    // iki olcumle hala taban
    val tc5 = SesAkisi.Tahminci()
    repeat(2) { tc5.ekle(100, 5000L, 1f) }
    esit("iki olcum yetmez", SesAkisi.TABAN_HARF_SN, tc5.harfSn())

    println("== hizlanma carpani ==")
    esit("kesilme yok", 1f, SesAkisi.hizlanmaCarpani(0.0))
    esit("esik altinda hizlanma yok", 1f, SesAkisi.hizlanmaCarpani(0.20))
    kontrol("ortada ara deger", SesAkisi.hizlanmaCarpani(0.50) in 1.2f..1.4f,
        SesAkisi.hizlanmaCarpani(0.50).toString())
    esit("ust sinir", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.hizlanmaCarpani(0.80))
    esit("tam kesilme ust sinir", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.hizlanmaCarpani(1.0))
    esit("eksi deger guvenli", 1f, SesAkisi.hizlanmaCarpani(-5.0))
    kontrol("artan monoton",
        SesAkisi.hizlanmaCarpani(0.3) < SesAkisi.hizlanmaCarpani(0.5) &&
            SesAkisi.hizlanmaCarpani(0.5) < SesAkisi.hizlanmaCarpani(0.7))

    println("== karar: bosta ==")
    val b = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.0)
    kontrol("bosta okur", b.oku && !b.kes, b.toString())
    esit("bosta carpan 1", 1f, b.hizCarpani)
    val b2 = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.9)
    kontrol("bosta ama geride: hizli okur", b2.oku && b2.hizCarpani > 1.3f, b2.toString())

    println("== karar: KES modu ==")
    val k = SesAkisi.karar(SesAkisi.KES, true, 500L, 5000L, 0.9)
    kontrol("KES her zaman keser", k.oku && k.kes, k.toString())
    esit("KES modunda hizlanma yok", 1f, k.hizCarpani)
    kontrol("KES nedeni yuzde icerir", k.neden.contains("%"), k.neden)

    println("== karar: BITIR_ATLA modu ==")
    val ba1 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 4500L, 5000L, 0.5)
    kontrol("sonlardaysa bitir ve atla", !ba1.oku && !ba1.kes, ba1.toString())
    kontrol("atlama nedeni yazili", ba1.neden.contains("atlandı"), ba1.neden)
    val ba2 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 300L, 5000L, 0.5)
    kontrol("basindaysa kes", ba2.oku && ba2.kes, ba2.toString())
    val ba3 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 2750L, 5000L, 0.0)
    kontrol("tam esikte bitir", !ba3.oku, ba3.toString())
    val ba4 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 100L, 0L, 0.0)
    kontrol("tahmin 0 ise bitmis sayilir", !ba4.oku, ba4.toString())

    println("== karar: HIZLAN modu ==")
    val h1 = SesAkisi.karar(SesAkisi.HIZLAN, true, 500L, 5000L, 0.9)
    kontrol("HIZLAN keser ve hizlanir", h1.oku && h1.kes && h1.hizCarpani > 1.3f, h1.toString())
    val h2 = SesAkisi.karar(SesAkisi.HIZLAN, true, 500L, 5000L, 0.0)
    kontrol("kesilme yoksa hizlanmaz", h2.hizCarpani == 1f, h2.toString())

    println("== sayac ==")
    val s = SesAkisi.Sayac(4)
    esit("basta oran 0", 0.0, s.oran())
    s.replik(true, 1000L, 5000L)
    s.replik(true, 1000L, 5000L)
    s.replik(false, 5000L, 5000L)
    s.replik(false, 5000L, 5000L)
    esit("yarisi kesildi", 0.5, s.oran())
    // pencere 4: [T,T,F,F] + T -> ilk T dusur -> [T,F,F,T] = 0.5
    s.replik(true, 1000L, 5000L)
    esit("pencere kayiyor, oran ayni", 0.5, s.oran())
    s.replik(true, 1000L, 5000L)
    s.replik(true, 1000L, 5000L)
    esit("pencere dolunca yukselir", 0.75, s.oran())
    s.replik(true, 1000L, 5000L)
    esit("hepsi kesildi", 1.0, s.oran())
    val s2 = SesAkisi.Sayac()
    kontrol("bos ozet", s2.ozet(15.0, 0).contains("hiç replik okunmadı"), s2.ozet(15.0, 0))
    s2.replik(true, 1000L, 5000L)
    s2.replik(false, 4000L, 4000L)
    s2.atlandi()
    val oz = s2.ozet(18.5, 7)
    kontrol("ozet replik sayisi", oz.contains("2 replik"), oz)
    kontrol("ozet kesilen", oz.contains("1 kesildi"), oz)
    kontrol("ozet atlanan", oz.contains("1 atlandı"), oz)
    kontrol("ozet ogrenilen hiz", oz.contains("18.5") || oz.contains("18,5"), oz)
    s2.temizle()
    kontrol("temizlenir", s2.ozet(15.0, 0).contains("hiç replik"), s2.ozet(15.0, 0))

    println("== kayit ==")
    SesAkisi.temizle()
    SesAkisi.kayitAcik = false
    SesAkisi.yaz("gorunmez")
    esit("kapaliyken yazmaz", 0, SesAkisi.satirSayisi())
    SesAkisi.kayitAcik = true
    SesAkisi.yaz("bir")
    SesAkisi.yaz("iki")
    esit("acikken yazar", 2, SesAkisi.satirSayisi())
    esit("sirayla", listOf("bir", "iki"), SesAkisi.tumu())
    repeat(SesAkisi.KAYIT_SINIRI + 50) { SesAkisi.yaz("x$it") }
    esit("kayit siniri", SesAkisi.KAYIT_SINIRI, SesAkisi.satirSayisi())
    kontrol("bas kesilir, son kalir", SesAkisi.tumu().last() == "x${SesAkisi.KAYIT_SINIRI + 49}",
        SesAkisi.tumu().last())
    SesAkisi.temizle()
    esit("temizlenir", 0, SesAkisi.satirSayisi())
    SesAkisi.kayitAcik = false

    println("== bicimleme ==")
    esit("sn bicimi", "1.5 sn", SesAkisi.sn(1500L).replace(',', '.'))
    esit("saat bicimi", "01:02:03.004", SesAkisi.saat(3_723_004L))
    esit("sifir saat", "00:00:00.000", SesAkisi.saat(0L))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
