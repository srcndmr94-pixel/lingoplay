import java.io.*;
import java.util.*;

/** SesPerdeOlcer.kt mantığının birebir karşılığı + sentetik ses üreteci. */
public class PerdeTest {

    static final int BELIRSIZ=0, ERKEK=1, KADIN=2;
    static final double ERKEK_SINIRI=155.0, KADIN_SINIRI=175.0;
    static final double EN_DUSUK_HZ=70.0, EN_YUKSEK_HZ=320.0;
    static final double SESLI_ESIK=0.30;
    static final int EN_AZ_SESLI_CERCEVE=8;

    static class Sonuc {
        final double hz; final int sesliCerceve, cinsiyet;
        Sonuc(double h,int s,int c){hz=h;sesliCerceve=s;cinsiyet=c;}
        boolean olculdu(){ return hz>0 && sesliCerceve>=EN_AZ_SESLI_CERCEVE; }
        public String toString(){
            if(!olculdu()) return "ölçülemedi";
            String c = cinsiyet==ERKEK?"erkek":cinsiyet==KADIN?"kadın":"belirsiz";
            return c+" ("+(int)hz+" Hz)";
        }
    }
    static final Sonuc BOS = new Sonuc(0,0,BELIRSIZ);

    static Sonuc olc(float[] x, int sr) {
        if (sr<=0 || x.length < sr/10) return BOS;
        int cerceve = Math.max(256,(int)(sr*0.040));
        int adim = Math.max(64,(int)(sr*0.010));
        int enKisa = Math.max(2,(int)(sr/EN_YUKSEK_HZ));
        int enUzun = Math.min(cerceve-1,(int)(sr/EN_DUSUK_HZ));
        if (enUzun<=enKisa) return BOS;
        ArrayList<Double> bulunan = new ArrayList<>();
        for (int bas=0; bas+cerceve<=x.length; bas+=adim) {
            double f0 = cerceveF0(x,bas,cerceve,enKisa,enUzun,sr);
            if (f0>0) bulunan.add(f0);
        }
        if (bulunan.size()<EN_AZ_SESLI_CERCEVE) return new Sonuc(0,bulunan.size(),BELIRSIZ);
        Collections.sort(bulunan);
        int n=bulunan.size();
        double med = n%2==1 ? bulunan.get(n/2) : (bulunan.get(n/2-1)+bulunan.get(n/2))/2.0;
        int c = med<ERKEK_SINIRI?ERKEK : med>KADIN_SINIRI?KADIN : BELIRSIZ;
        return new Sonuc(med,n,c);
    }

    static final double TEPE_ORANI = 0.85;

    static double cerceveF0(float[] x,int bas,int uzunluk,int enKisa,int enUzun,int sr){
        double ort=0; for(int i=0;i<uzunluk;i++) ort+=x[bas+i]; ort/=uzunluk;
        double sifir=0; for(int i=0;i<uzunluk;i++){ double d=x[bas+i]-ort; sifir+=d*d; }
        if (sifir<1e-6) return 0;
        double[] r = new double[enUzun+2];
        double enYuksek=0;
        for(int g=enKisa;g<=enUzun;g++){
            double t=0; int son=uzunluk-g;
            for(int i=0;i<son;i++) t += (x[bas+i]-ort)*(x[bas+i+g]-ort);
            double oran = t/sifir;
            r[g]=oran;
            if (oran>enYuksek) enYuksek=oran;
        }
        if (enYuksek<SESLI_ESIK) return 0;
        int secilen=-1;
        for(int g=enKisa+1; g<enUzun; g++){
            if (r[g]>=r[g-1] && r[g]>=r[g+1] && r[g]>=TEPE_ORANI*enYuksek){ secilen=g; break; }
        }
        if (secilen<0) for(int g=enKisa;g<=enUzun;g++) if (r[g]>=enYuksek){ secilen=g; break; }
        if (secilen<=0) return 0;
        return (double)sr/secilen;
    }

    // ------------------------------------------------ sentetik konusma sesi

    /** Harmonikli, formant benzeri zarfı olan sesli bir ses üretir. */
    static float[] konusma(double f0, int sr, double saniye, double gurultu, long tohum) {
        Random r = new Random(tohum);
        int n = (int)(sr*saniye);
        float[] x = new float[n];
        int harmonik = (int)Math.min(20, (sr/2.0)/f0);
        for (int i=0;i<n;i++){
            double t = (double)i/sr;
            double v = 0;
            for (int h=1; h<=harmonik; h++) {
                // 1/h genlik: insan gırtlak dalgasına yakın spektrum
                v += Math.sin(2*Math.PI*f0*h*t + h*0.4) / h;
            }
            // Hafif genlik dalgalanmasi (titresim)
            v *= 0.8 + 0.2*Math.sin(2*Math.PI*4.5*t);
            v += (r.nextDouble()*2-1)*gurultu;
            x[i] = (float)(v*0.25);
        }
        return x;
    }

    static float[] sessizlik(int sr, double saniye){ return new float[(int)(sr*saniye)]; }

    static float[] birlestir(float[]... parcalar){
        int n=0; for(float[] p:parcalar) n+=p.length;
        float[] o=new float[n]; int i=0;
        for(float[] p:parcalar){ System.arraycopy(p,0,o,i,p.length); i+=p.length; }
        return o;
    }

    // ------------------------------------------------------- WAV yaz / oku

    static void wavYaz(File f, float[] x, int sr, int kanal) throws IOException {
        int veriBoyu = x.length*2*kanal;
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)))) {
            o.writeBytes("RIFF"); leInt(o,36+veriBoyu); o.writeBytes("WAVE");
            o.writeBytes("fmt "); leInt(o,16); leShort(o,1); leShort(o,kanal);
            leInt(o,sr); leInt(o,sr*kanal*2); leShort(o,kanal*2); leShort(o,16);
            o.writeBytes("data"); leInt(o,veriBoyu);
            for (float v : x) {
                int s = (int)Math.max(-32768,Math.min(32767, Math.round(v*32767)));
                for (int k=0;k<kanal;k++) leShort(o,s);
            }
        }
    }
    static void leInt(DataOutputStream o,int v) throws IOException {
        o.write(v&0xFF); o.write((v>>8)&0xFF); o.write((v>>16)&0xFF); o.write((v>>24)&0xFF);
    }
    static void leShort(DataOutputStream o,int v) throws IOException {
        o.write(v&0xFF); o.write((v>>8)&0xFF);
    }

    static class Ses { float[] ornekler; int sr; }

    static Ses wavOku(File dosya) throws IOException {
        if (!dosya.isFile() || dosya.length()<44) return null;
        try (RandomAccessFile f = new RandomAccessFile(dosya,"r")) {
            byte[] bas = new byte[12]; f.readFully(bas);
            if (!new String(bas,0,4,"US-ASCII").equals("RIFF")) return null;
            if (!new String(bas,8,4,"US-ASCII").equals("WAVE")) return null;
            int sr=0, kanal=1, bit=16; byte[] veri=null;
            while (f.getFilePointer()+8 <= f.length()) {
                byte[] b=new byte[8]; f.readFully(b);
                String ad=new String(b,0,4,"US-ASCII"); int boy=leiInt(b,4);
                if (boy<0) return null;
                if (ad.equals("fmt ")) {
                    byte[] fmt=new byte[boy]; f.readFully(fmt);
                    kanal=leiShort(fmt,2); sr=leiInt(fmt,4); bit=leiShort(fmt,14);
                } else if (ad.equals("data")) {
                    int kalan=(int)(f.length()-f.getFilePointer());
                    int ok = (boy>0 && boy<=kalan)?boy:kalan;
                    if (ok<=0) return null;
                    veri=new byte[ok]; f.readFully(veri);
                } else f.seek(f.getFilePointer()+boy+(boy&1));
                if (veri!=null) break;
            }
            if (veri==null || sr<=0 || kanal<=0 || bit!=16) return null;
            int toplam=veri.length/2, cf=toplam/kanal;
            if (cf<=0) return null;
            float[] out=new float[cf]; int o=0;
            for(int c=0;c<cf;c++){
                int t=0;
                for(int k=0;k<kanal;k++){
                    int lo=veri[o]&0xFF, hi=veri[o+1];
                    t += (hi<<8)|lo; o+=2;
                }
                out[c]=((float)t/kanal)/32768f;
            }
            Ses s=new Ses(); s.ornekler=out; s.sr=sr; return s;
        }
    }
    static int leiInt(byte[] b,int i){
        return (b[i]&0xFF)|((b[i+1]&0xFF)<<8)|((b[i+2]&0xFF)<<16)|((b[i+3]&0xFF)<<24);
    }
    static int leiShort(byte[] b,int i){ return (b[i]&0xFF)|((b[i+1]&0xFF)<<8); }

    // ------------------------------------------------------------- testler

    static int gecti=0, kaldi=0;
    static void dogru(String ad, boolean k, String ek){
        if(k){gecti++;System.out.println("  OK   "+ad+(ek.isEmpty()?"":"  "+ek));}
        else {kaldi++;System.out.println("  HATA "+ad+"  "+ek);}
    }

    static void olcumTesti(String ad, double gercekF0, int sr, double gurultu, int beklenenCinsiyet) {
        float[] x = konusma(gercekF0, sr, 1.2, gurultu, (long)(gercekF0*1000));
        Sonuc s = olc(x, sr);
        double sapma = Math.abs(s.hz-gercekF0)/gercekF0*100;
        dogru(ad, s.olculdu() && sapma < 5.0 && s.cinsiyet==beklenenCinsiyet,
              String.format(Locale.ROOT,"olculen=%.1f Hz gercek=%.0f sapma=%%%.1f -> %s",
                            s.hz, gercekF0, sapma, s));
    }

    public static void main(String[] a) throws Exception {
        System.out.println("== A) Bilinen frekanslar dogru olculuyor mu (temiz ses) ==");
        olcumTesti("erkek 95 Hz",  95, 22050, 0.0, ERKEK);
        olcumTesti("erkek 120 Hz", 120, 22050, 0.0, ERKEK);
        olcumTesti("erkek 145 Hz", 145, 22050, 0.0, ERKEK);
        olcumTesti("kadin 190 Hz", 190, 22050, 0.0, KADIN);
        olcumTesti("kadin 220 Hz", 220, 22050, 0.0, KADIN);
        olcumTesti("kadin 255 Hz", 255, 22050, 0.0, KADIN);

        System.out.println("== B) Gurultu altinda ==");
        olcumTesti("erkek 110 Hz + gurultu", 110, 22050, 0.08, ERKEK);
        olcumTesti("kadin 210 Hz + gurultu", 210, 22050, 0.08, KADIN);

        System.out.println("== C) Farkli ornekleme hizlari ==");
        olcumTesti("erkek 120 Hz @16k", 120, 16000, 0.0, ERKEK);
        olcumTesti("kadin 200 Hz @44.1k", 200, 44100, 0.0, KADIN);

        System.out.println("== D) Sinir bolgesi BELIRSIZ kalmali ==");
        float[] orta = konusma(165, 22050, 1.2, 0.0, 7);
        Sonuc so = olc(orta, 22050);
        dogru("165 Hz -> belirsiz", so.olculdu() && so.cinsiyet==BELIRSIZ, so.toString());

        System.out.println("== E) Olculemeyen girdiler ==");
        dogru("sessizlik", !olc(sessizlik(22050,1.0),22050).olculdu(), olc(sessizlik(22050,1.0),22050).toString());
        dogru("bos dizi", !olc(new float[0],22050).olculdu(), "");
        dogru("ornekleme hizi 0", !olc(konusma(120,22050,1.0,0,1),0).olculdu(), "");
        float[] beyaz = new float[22050]; Random r=new Random(3);
        for(int i=0;i<beyaz.length;i++) beyaz[i]=(float)((r.nextDouble()*2-1)*0.3);
        Sonuc bs = olc(beyaz,22050);
        dogru("saf gurultu guvenilir sayilmamali", bs.cinsiyet==BELIRSIZ || !bs.olculdu(), bs.toString());

        System.out.println("== F) Sessizlik araya girse de replik olculuyor ==");
        float[] karisik = birlestir(sessizlik(22050,0.3), konusma(115,22050,0.8,0.02,11), sessizlik(22050,0.3));
        Sonuc ks = olc(karisik,22050);
        dogru("sessizlik-konusma-sessizlik", ks.olculdu() && ks.cinsiyet==ERKEK, ks.toString());

        System.out.println("== G) WAV yaz/oku dongusu ==");
        File tek = File.createTempFile("ses_tek",".wav");
        wavYaz(tek, konusma(130,22050,1.0,0.0,21), 22050, 1);
        Ses okunan = wavOku(tek);
        dogru("tek kanal okundu", okunan!=null && okunan.sr==22050, okunan==null?"null":okunan.sr+" Hz, "+okunan.ornekler.length+" ornek");
        Sonuc ws = olc(okunan.ornekler, okunan.sr);
        dogru("dosyadan olculen 130 Hz", ws.olculdu() && Math.abs(ws.hz-130)/130<0.05 && ws.cinsiyet==ERKEK, ws.toString());

        File cift = File.createTempFile("ses_cift",".wav");
        wavYaz(cift, konusma(205,22050,1.0,0.0,22), 22050, 2);
        Ses okunan2 = wavOku(cift);
        Sonuc ws2 = olc(okunan2.ornekler, okunan2.sr);
        dogru("iki kanal (stereo) okundu ve olculdu", ws2.olculdu() && ws2.cinsiyet==KADIN, ws2.toString());

        File bozuk = File.createTempFile("bozuk",".wav");
        try (FileOutputStream o=new FileOutputStream(bozuk)) { o.write("DEGILWAVEDOSYASI123456789012345678901234567890".getBytes("US-ASCII")); }
        dogru("bozuk dosya null doner", wavOku(bozuk)==null, "");
        tek.delete(); cift.delete(); bozuk.delete();

        System.out.println("== H) Iki sesi karsilastirip atama ==");
        Sonuc s1 = olc(konusma(115,22050,1.0,0.03,31),22050);
        Sonuc s2 = olc(konusma(215,22050,1.0,0.03,32),22050);
        dogru("alcak olan erkek secilir", s1.hz < s2.hz && s1.cinsiyet==ERKEK && s2.cinsiyet==KADIN,
              s1+" / "+s2);

        System.out.println("\nGecti: "+gecti+" · Kaldi: "+kaldi);
        if (kaldi>0) System.exit(1);
    }
}
