package com.example.altyazi

import java.io.File
import java.io.RandomAccessFile

/**
 * SES PERDE ÖLÇER — 10.46
 *
 * Bir WAV dosyasındaki konuşmanın temel frekansını (F0) ölçer.
 * Amaç: telefondaki Türkçe seslerin erkek mi kadın mı olduğunu KENDİLİĞİNDEN
 * anlamak.
 *
 * NEDEN GEREKLİ: Android'in `Voice` sınıfı cinsiyet bildirmiyor, ses adından
 * ("tr-tr-x-ama-local") da anlaşılmıyor. Ama sesin kendisi ölçülebilir:
 * erkek konuşması kabaca 85-180 Hz, kadın 165-255 Hz bandında.
 *
 * YÖNTEM: otokorelasyon. Her çerçeve kendi gecikmeli kopyasıyla çarpılır;
 * en güçlü tekrar hangi gecikmedeyse periyot odur, frekans da 1/periyot.
 * Yalnız yeterince periyodik (sesli) çerçeveler sayılır; sessizlik ve
 * gürültü atılır. Sonuç, sesli çerçevelerin MEDYANI — tek bir bozuk çerçeve
 * sonucu kaydırmasın.
 *
 * Bu dosya saf hesap: Android'e bağlı değil, dosyadan okur. Böylece
 * telefona kurmadan sınanabiliyor.
 */
object SesPerdeOlcer {

    const val BELIRSIZ = 0
    const val ERKEK = 1
    const val KADIN = 2

    /** Bu eşiğin altı erkek sayılır (Hz). */
    const val ERKEK_SINIRI = 155.0

    /** Bu eşiğin üstü kadın sayılır (Hz). Arası BELIRSIZ. */
    const val KADIN_SINIRI = 175.0

    /** İnsan konuşmasında aranan en düşük ve en yüksek temel frekans. */
    private const val EN_DUSUK_HZ = 70.0
    private const val EN_YUKSEK_HZ = 320.0

    /** Çerçeve "sesli" sayılması için gereken en az otokorelasyon oranı. */
    private const val SESLI_ESIK = 0.30

    /** Güvenilir sonuç için gereken en az sesli çerçeve sayısı. */
    private const val EN_AZ_SESLI_CERCEVE = 8

    /**
     * Bir tepenin "gerçek periyot" sayılması için en yüksek tepenin
     * kaçta kaçına ulaşması gerektiği. Oktav hatasını önler; bkz. cerceveF0.
     */
    private const val TEPE_ORANI = 0.85

    data class Sonuc(
        /** Ölçülen temel frekansın medyanı (Hz); ölçülemediyse 0. */
        val hz: Double,
        /** Sesli sayılan çerçeve sayısı. */
        val sesliCerceve: Int,
        /** ERKEK / KADIN / BELIRSIZ. */
        val cinsiyet: Int,
    ) {
        val olculdu: Boolean get() = hz > 0.0 && sesliCerceve >= EN_AZ_SESLI_CERCEVE

        val aciklama: String
            get() = when {
                !olculdu -> "ölçülemedi"
                cinsiyet == ERKEK -> "erkek (${hz.toInt()} Hz)"
                cinsiyet == KADIN -> "kadın (${hz.toInt()} Hz)"
                else -> "belirsiz (${hz.toInt()} Hz)"
            }
    }

    val BOS = Sonuc(0.0, 0, BELIRSIZ)

    /** WAV dosyasını okuyup ölçer. Dosya bozuksa [BOS]. */
    fun olc(dosya: File): Sonuc {
        val ses = try {
            wavOku(dosya)
        } catch (_: Throwable) {
            null
        } ?: return BOS
        return olc(ses.ornekler, ses.ornekHizi)
    }

    /** Hazır örnekleri ölçer (-1..1 aralığında, tek kanal). */
    fun olc(ornekler: FloatArray, ornekHizi: Int): Sonuc {
        if (ornekHizi <= 0 || ornekler.size < ornekHizi / 10) return BOS

        // 40 ms çerçeve, 10 ms adım: konuşma analizinde olağan değerler.
        val cerceve = (ornekHizi * 0.040).toInt().coerceAtLeast(256)
        val adim = (ornekHizi * 0.010).toInt().coerceAtLeast(64)
        val enKisaGecikme = (ornekHizi / EN_YUKSEK_HZ).toInt().coerceAtLeast(2)
        val enUzunGecikme = (ornekHizi / EN_DUSUK_HZ).toInt().coerceAtMost(cerceve - 1)
        if (enUzunGecikme <= enKisaGecikme) return BOS

        val bulunan = ArrayList<Double>()
        var bas = 0
        while (bas + cerceve <= ornekler.size) {
            val f0 = cerceveF0(ornekler, bas, cerceve, enKisaGecikme, enUzunGecikme, ornekHizi)
            if (f0 > 0) bulunan.add(f0)
            bas += adim
        }
        if (bulunan.size < EN_AZ_SESLI_CERCEVE) return Sonuc(0.0, bulunan.size, BELIRSIZ)

        bulunan.sort()
        val medyan = if (bulunan.size % 2 == 1) bulunan[bulunan.size / 2]
        else (bulunan[bulunan.size / 2 - 1] + bulunan[bulunan.size / 2]) / 2.0

        val cinsiyet = when {
            medyan < ERKEK_SINIRI -> ERKEK
            medyan > KADIN_SINIRI -> KADIN
            else -> BELIRSIZ
        }
        return Sonuc(medyan, bulunan.size, cinsiyet)
    }

    /**
     * Tek çerçevenin temel frekansı; çerçeve sesli değilse 0.
     *
     * OKTAV TUZAĞI: otokorelasyon periyodun KATLARINDA da güçlü tepe verir.
     * En yüksek tepeyi körü körüne seçersek 255 Hz'lik bir ses 127,5 Hz
     * ölçülür — tam bir oktav aşağı — ve kadın sesi erkek sanılır. (Bu hata
     * geliştirme sırasında testte yakalandı: 255, 215 ve 205 Hz seslerin
     * üçü de yarıya düşüyordu.)
     *
     * Çözüm: en yüksek tepeyi değil, en yüksek tepenin [TEPE_ORANI] kadarına
     * ulaşan İLK tepeyi seçmek. Gerçek periyot en kısa olandır; katları ondan
     * sonra gelir.
     */
    private fun cerceveF0(
        x: FloatArray,
        bas: Int,
        uzunluk: Int,
        enKisa: Int,
        enUzun: Int,
        ornekHizi: Int,
    ): Double {
        // Ortalama kaydırması (DC) atılır: yoksa otokorelasyon hep pozitif
        // kalır ve tepe bulunamaz.
        var ortalama = 0.0
        for (i in 0 until uzunluk) ortalama += x[bas + i]
        ortalama /= uzunluk

        var sifirGecikme = 0.0
        for (i in 0 until uzunluk) {
            val d = x[bas + i] - ortalama
            sifirGecikme += d * d
        }
        // Sessizlik: ölçecek bir şey yok.
        if (sifirGecikme < 1e-6) return 0.0

        // Otokorelasyon. UZUNLUK DÜZELTMESİ YOK: uzun gecikmeleri ödüllendiren
        // bir çarpan oktav hatasını besliyordu.
        val r = DoubleArray(enUzun + 2)
        var enYuksek = 0.0
        for (gecikme in enKisa..enUzun) {
            var toplam = 0.0
            var i = 0
            val son = uzunluk - gecikme
            while (i < son) {
                toplam += (x[bas + i] - ortalama) * (x[bas + i + gecikme] - ortalama)
                i++
            }
            val oran = toplam / sifirGecikme
            r[gecikme] = oran
            if (oran > enYuksek) enYuksek = oran
        }
        if (enYuksek < SESLI_ESIK) return 0.0

        // En yüksek tepenin TEPE_ORANI kadarına ulaşan ilk yerel tepe.
        var secilen = -1
        for (gecikme in (enKisa + 1) until enUzun) {
            if (r[gecikme] >= r[gecikme - 1] &&
                r[gecikme] >= r[gecikme + 1] &&
                r[gecikme] >= TEPE_ORANI * enYuksek
            ) {
                secilen = gecikme
                break
            }
        }
        if (secilen < 0) {
            // Yerel tepe bulunamadı (çok kısa gecikme sınırında olabilir):
            // en güçlü gecikmeye düşülür.
            for (gecikme in enKisa..enUzun) {
                if (r[gecikme] >= enYuksek) {
                    secilen = gecikme
                    break
                }
            }
        }
        if (secilen <= 0) return 0.0
        return ornekHizi.toDouble() / secilen
    }

    // ------------------------------------------------------------ WAV okuma

    data class Ses(val ornekler: FloatArray, val ornekHizi: Int)

    /**
     * Basit RIFF/WAVE okuyucu: 16 bit PCM, tek ya da çok kanal.
     * TextToSpeech.synthesizeToFile tam bunu üretiyor.
     * Çok kanallıysa kanallar ortalanır.
     */
    fun wavOku(dosya: File): Ses? {
        if (!dosya.isFile || dosya.length() < 44) return null
        RandomAccessFile(dosya, "r").use { f ->
            val bas = ByteArray(12)
            f.readFully(bas)
            if (String(bas, 0, 4, Charsets.US_ASCII) != "RIFF") return null
            if (String(bas, 8, 4, Charsets.US_ASCII) != "WAVE") return null

            var ornekHizi = 0
            var kanal = 1
            var bitDerinligi = 16
            var veri: ByteArray? = null

            while (f.filePointer + 8 <= f.length()) {
                val baslik = ByteArray(8)
                f.readFully(baslik)
                val ad = String(baslik, 0, 4, Charsets.US_ASCII)
                val boy = kucukUcInt(baslik, 4)
                if (boy < 0) return null
                when (ad) {
                    "fmt " -> {
                        val fmt = ByteArray(boy)
                        f.readFully(fmt)
                        kanal = kucukUcShort(fmt, 2)
                        ornekHizi = kucukUcInt(fmt, 4)
                        bitDerinligi = kucukUcShort(fmt, 14)
                    }
                    "data" -> {
                        val kalan = (f.length() - f.filePointer).toInt()
                        val okunacak = if (boy in 1..kalan) boy else kalan
                        if (okunacak <= 0) return null
                        val d = ByteArray(okunacak)
                        f.readFully(d)
                        veri = d
                    }
                    else -> f.seek(f.filePointer + boy + (boy and 1))
                }
                if (veri != null) break
            }

            val d = veri ?: return null
            if (ornekHizi <= 0 || kanal <= 0 || bitDerinligi != 16) return null

            val toplamOrnek = d.size / 2
            val cerceveSayisi = toplamOrnek / kanal
            if (cerceveSayisi <= 0) return null
            val out = FloatArray(cerceveSayisi)
            var o = 0
            for (c in 0 until cerceveSayisi) {
                var toplam = 0
                for (k in 0 until kanal) {
                    val lo = d[o].toInt() and 0xFF
                    val hi = d[o + 1].toInt()
                    toplam += (hi shl 8) or lo
                    o += 2
                }
                out[c] = (toplam.toFloat() / kanal) / 32768f
            }
            return Ses(out, ornekHizi)
        }
    }

    private fun kucukUcInt(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8) or
            ((b[i + 2].toInt() and 0xFF) shl 16) or ((b[i + 3].toInt() and 0xFF) shl 24)

    private fun kucukUcShort(b: ByteArray, i: Int): Int =
        (b[i].toInt() and 0xFF) or ((b[i + 1].toInt() and 0xFF) shl 8)
}
