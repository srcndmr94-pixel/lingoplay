package com.example.altyazi

/**
 * SES HAVUZU — 10.46
 *
 * Ölçülmüş seslerin kaydı: hangi ses kaç Hz, erkek mi kadın mı, internet
 * ister mi. Ayarlar ekranında bir kez ölçülüp Prefs'e yazılır; çeviri
 * servisi bunu okur. Böylece servis her açılışta yeniden ölçmek zorunda
 * kalmaz (ölçüm 15 seste yarım dakika sürebiliyor).
 *
 * Biçim satır satır: ad|hz|cinsiyet|ag
 * Ayraç olarak "|" seçildi; ses adlarında ("tr-tr-x-ama-local") geçmiyor.
 */
object SesHavuzu {

    data class Kayit(
        val ad: String,
        val hz: Double,
        val cinsiyet: Int,
        val agGerekir: Boolean,
    )

    fun yaz(kayitlar: List<Kayit>): String = kayitlar.joinToString("\n") {
        "${it.ad}|${it.hz.toInt()}|${it.cinsiyet}|${if (it.agGerekir) 1 else 0}"
    }

    fun oku(metin: String?): List<Kayit> {
        if (metin.isNullOrBlank()) return emptyList()
        val out = ArrayList<Kayit>()
        for (satir in metin.split('\n')) {
            val p = satir.split('|')
            if (p.size < 4) continue
            val ad = p[0].trim()
            if (ad.isEmpty()) continue
            val hz = p[1].trim().toDoubleOrNull() ?: continue
            val cinsiyet = p[2].trim().toIntOrNull() ?: continue
            out.add(Kayit(ad, hz, cinsiyet, p[3].trim() == "1"))
        }
        return out
    }

    /**
     * Bu cinsiyet için kullanılabilecek sesler, en uygundan başlayarak.
     *
     * [mevcutAdlar] motorun şu an gerçekten sunduğu sesler; kayıt eskiyse
     * (ses paketi silinmişse) oradan düşer. [internetVar] kapalıyken
     * internet isteyen sesler elenir.
     *
     * Sıralama: erkekte EN KALIN, kadında EN İNCE başa gelir. Böylece
     * karakterler arasında cinsiyet en net duyulan uçtan dağıtılır.
     */
    fun havuz(
        kayitlar: List<Kayit>,
        cinsiyet: Int,
        mevcutAdlar: Set<String>,
        internetVar: Boolean,
    ): List<Kayit> {
        val uygun = kayitlar.filter {
            it.ad in mevcutAdlar &&
                it.cinsiyet == cinsiyet &&
                (internetVar || !it.agGerekir)
        }
        return if (cinsiyet == SesPerdeOlcer.KADIN) uygun.sortedByDescending { it.hz }
        else uygun.sortedBy { it.hz }
    }

    /** Ölçülmüş ama cinsiyeti belirsiz kalan sesler (yedek havuz). */
    fun belirsizler(
        kayitlar: List<Kayit>,
        mevcutAdlar: Set<String>,
        internetVar: Boolean,
    ): List<Kayit> = kayitlar.filter {
        it.ad in mevcutAdlar &&
            it.cinsiyet == SesPerdeOlcer.BELIRSIZ &&
            it.hz > 0.0 &&
            (internetVar || !it.agGerekir)
    }.sortedBy { it.hz }
}
