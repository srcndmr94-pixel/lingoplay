package com.example.altyazi

object MeaningSafety {
    enum class Risk {
        REVERSED_NEGATIVE_COMMAND,
        LOST_PROHIBITION,
        IMPERATIVE_AS_INFINITIVE
    }

    private val zeroSurvivors = Regex(
        """(?i)^(?:\[[^]]+]\s*)?(?:(?:leave|keep)\s+(?:no\s+one|nobody)\s+(?:alive|breathing)|spare\s+(?:no\s+one|nobody))[.!\s]*$"""
    )
    private val positiveMercy = Regex(
        """(?iu)^(?:hiç\s+)?(?:kimseyi|birini|onları|hepsini)\s+(?:(?:sağ|canlı)\s+)?(?:bırak|bağışla|affet)(?:ın|ınız)?[.!\s]*$"""
    )
    private val englishProhibition = Regex(
        """(?i)^(?:\[[^]]+]\s*)?(?:do\s+not|don['’]t|never)\s+(?!(?:worry|mind)\b)[a-z]"""
    )
    private val sourceImperative = Regex(
        """(?i)^(?:\[[^]]+]\s*)?(?:keep|go|come|move|stop|run|follow|leave|shut|hold|stay|take|look|listen|shoot|wait)\b"""
    )
    private val infinitiveEnding = Regex("""(?iu)\b[\p{L}]+m[ae]k\s*[!.]*$""")

    private val turkishProhibition = Regex(
        """(?iu)(?:\b(?:sakın|asla|hiçbir|değil|yok|hayır)\b|\b[\p{L}]+(?:ma|me)(?:\b|[mydznslıiuüae][\p{L}]*)|\b[\p{L}]+m[ıiuü]yor[\p{L}]*\b)"""
    )

    private val strongSourceProfanity = Regex("""(?i)\b(fuck|fucking|motherfucker|shit|bullshit|bitch|asshole)\b""")
    private val turkishToneMarkers = Regex("""(?iu)\b(siktir|siktiğim|amına|orospu|piç|bok|saçmalık|lan|kahretsin|lanet)\b""")

    /** Kaynakta güçlü küfür/argo varken çeviri motoru bunu tamamen sansürleyip yuttuysa tespit eder. */
    fun lostContextualProfanity(source: String, target: String): Boolean {
        if (!strongSourceProfanity.containsMatchIn(source)) return false
        // Kısa cümlelerde küfür tamamen yok edildiyse yedek motorun denenmesine izin ver
        val wordCount = source.trim().split(Regex("\\s+")).size
        if (wordCount <= 5 && !turkishToneMarkers.containsMatchIn(target)) return true
        return false
    }

    fun risk(source: String, target: String): Risk? {
        val s = source.trim()
        val t = target.trim().replace(Regex("""^\[[^]]+]\s*"""), "")
        if (s.isBlank() || t.isBlank()) return null
        if (zeroSurvivors.matches(s) && positiveMercy.matches(t))
            return Risk.REVERSED_NEGATIVE_COMMAND
        if (englishProhibition.containsMatchIn(s) && !turkishProhibition.containsMatchIn(t))
            return Risk.LOST_PROHIBITION
        if (s.trimEnd().endsWith('!') && sourceImperative.containsMatchIn(s) &&
            infinitiveEnding.containsMatchIn(t))
            return Risk.IMPERATIVE_AS_INFINITIVE
        return null
    }
}