package com.example.altyazi

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class Overlay(private val context: Context) {

    data class Label(val text: String, val x: Int, val y: Int)

    data class Stil(
        val boyutSp: Float = 18f,
        val yaziRengi: Int = Color.WHITE,
        val arkaAlfa: Int = 190,
        val arkaRenk: Int = Color.BLACK,
        val kenarlik: Boolean = true,
        val kenarPayYuzde: Int = 0,
    )

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var subtitleView: TextView? = null
    private var prevView: TextView? = null
    private val labelViews = ArrayList<TextView>()

    @Volatile private var protectedStripTop = -1
    @Volatile private var protectedStripBottom = -1

    @Volatile
    private var stil = Stil()

    private data class SubtitleRequest(
        val value: String?, val topPx: Int, val refined: Boolean, val draft: Boolean,
        val bottomPx: Int, val previous: String?, val protectedTopPx: Int,
        val protectedBottomPx: Int, val preferBelow: Boolean, val coverSource: Boolean
    )
    @Volatile private var lastSubtitleRequest: SubtitleRequest? = null

    fun setStil(yeni: Stil) {
        stil = yeni
        subtitleView?.post {
            stiliUygula()
            lastSubtitleRequest?.let { req ->
                setSubtitle(req.value, req.topPx, req.refined, req.draft,
                    req.bottomPx, req.previous, req.protectedTopPx,
                    req.protectedBottomPx, req.preferBelow, req.coverSource)
            }
        }
    }

    private fun stiliUygula() {
        subtitleView?.let { stiliUygula(it, stil.boyutSp) }
        prevView?.let { stiliUygula(it, stil.boyutSp * ONCEKI_ORAN) }
    }

    private fun stiliUygula(t: TextView, boyutSp: Float) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, boyutSp)
        t.setTextColor(stil.yaziRengi)
        if (stil.kenarlik) t.setShadowLayer(7f, 0f, 2f, Color.BLACK)
        else t.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        t.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(
                Color.argb(
                    stil.arkaAlfa,
                    Color.red(stil.arkaRenk),
                    Color.green(stil.arkaRenk),
                    Color.blue(stil.arkaRenk),
                )
            )
        }
    }

    fun show() {
        if (root != null) return

        val container = FrameLayout(context)

        val prev = makeText(stil.boyutSp * ONCEKI_ORAN, stil.arkaAlfa).apply {
            visibility = View.GONE
            alpha = ONCEKI_SOLUK
        }
        container.addView(
            prev,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        )

        val subtitle = makeText(stil.boyutSp, stil.arkaAlfa).apply { visibility = View.GONE }
        container.addView(
            subtitle,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        )

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            wm.addView(container, lp)
            root = container
            subtitleView = subtitle
            prevView = prev
            stiliUygula()
        } catch (_: Throwable) {
        }
    }

    private fun makeText(sizeSp: Float, alpha: Int): TextView = TextView(context).apply {
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        setShadowLayer(6f, 0f, 2f, Color.BLACK)
        setPadding(dp(12), dp(6), dp(12), dp(6))
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.argb(alpha, 0, 0, 0))
        }
    }

    @Volatile private var sourceBounds: CaptionCoverBounds.Box? = null
    fun setSourceBounds(bounds: CaptionCoverBounds.Box) { sourceBounds = bounds }

    fun hideForNewSubtitle() {
        lastSubtitleRequest = null
        subtitleView?.post {
            subtitleView?.animate()?.cancel()
            subtitleView?.visibility = View.GONE
            subtitleView?.text = ""
            oncekiGizle()
        }
    }

    fun setSubtitle(
        value: String?,
        topPx: Int,
        refined: Boolean = false,
        draft: Boolean = false,
        bottomPx: Int = -1,
        previous: String? = null,
        protectedTopPx: Int = -1,
        protectedBottomPx: Int = -1,
        preferBelow: Boolean = false,
        coverSource: Boolean = false,
    ) {
        lastSubtitleRequest = SubtitleRequest(value, topPx, refined, draft, bottomPx,
            previous, protectedTopPx, protectedBottomPx, preferBelow, coverSource)
        val t = subtitleView ?: return
        val cover = if (coverSource) sourceBounds else null
        t.post {
            if (value.isNullOrBlank()) {
                sourceBounds = null
                t.minHeight = 0
                t.animate().cancel()
                t.alpha = 1f
                t.minWidth = 0
                t.visibility = View.GONE
                t.text = ""
                oncekiGizle()
                return@post
            }
            val lp = t.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = topPx.coerceAtLeast(dp(8))
            val kenar = if (cover != null) 0 else maxOf(dp(12), context.resources.displayMetrics.widthPixels * stil.kenarPayYuzde / 100)
            lp.leftMargin = kenar
            lp.rightMargin = kenar
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            t.layoutParams = lp

            val wasVisible = t.visibility == View.VISIBLE
            t.minWidth = if (refined && wasVisible) t.width else 0

            val shown: CharSequence = if (refined) {
                SpannableStringBuilder(value).apply {
                    val start = length
                    append("  ●")
                    setSpan(ForegroundColorSpan(Color.rgb(46, 230, 214)), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    setSpan(RelativeSizeSpan(0.55f), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } else value
            t.text = shown

            val screenBounds = wm.currentWindowMetrics.bounds
            val ekranGen = screenBounds.width()
            val ekranYuk = screenBounds.height()

            if (cover != null) {
                // İngilizce metin kutusunu tam örten opak arka plan ve minimum boyutlandırma
                val padX = dp(14)
                val padY = dp(8)
                t.minWidth = (cover.right - cover.left + padX * 2).coerceAtMost(ekranGen - dp(16))
                t.minHeight = (cover.bottom - cover.top + padY * 2).coerceAtLeast(dp(34))
                t.background = GradientDrawable().apply {
                    setColor(Color.argb(255, Color.red(stil.arkaRenk), Color.green(stil.arkaRenk), Color.blue(stil.arkaRenk)))
                    cornerRadius = dp(6).toFloat()
                }
            } else {
                t.minHeight = 0
                stiliUygula(t, stil.boyutSp)
            }

            val genislik = (ekranGen - lp.leftMargin - lp.rightMargin).coerceAtLeast(dp(80))
            val widthSpec = View.MeasureSpec.makeMeasureSpec(genislik, View.MeasureSpec.AT_MOST)
            val heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            t.measure(widthSpec, heightSpec)

            var showPrevious = !previous.isNullOrBlank()
            val bandIsValid = protectedTopPx >= 0 &&
                protectedBottomPx > protectedTopPx && protectedBottomPx <= ekranYuk
            protectedStripTop = if (bandIsValid) protectedTopPx else -1
            protectedStripBottom = if (bandIsValid) protectedBottomPx else -1

            if (cover != null) {
                val placement = CaptionCoverBounds.place(cover, t.measuredWidth, t.measuredHeight, ekranGen, ekranYuk, dp(4))
                lp.gravity = Gravity.TOP or Gravity.LEFT
                lp.leftMargin = placement.left.coerceIn(dp(4), (ekranGen - t.measuredWidth - dp(4)).coerceAtLeast(dp(4)))
                lp.rightMargin = 0
                lp.topMargin = placement.top.coerceIn(dp(4), (ekranYuk - t.measuredHeight - dp(4)).coerceAtLeast(dp(4)))
                t.layoutParams = lp
                showPrevious = false
            } else if (bandIsValid) {
                val oldHeight = if (showPrevious) {
                    prevView?.let { prev ->
                        prev.text = previous
                        prev.measure(widthSpec, heightSpec)
                        prev.measuredHeight
                    } ?: 0
                } else 0
                val placement = SubtitleOverlayPlacement299.choose(
                    screenHeight = ekranYuk,
                    bandTop = protectedTopPx,
                    bandBottom = protectedBottomPx,
                    preferredTop = topPx,
                    currentHeight = t.measuredHeight,
                    previousHeight = oldHeight,
                    preferBelow = preferBelow,
                    margin = dp(8),
                    gap = dp(6)
                )
                if (placement == null) {
                    t.visibility = View.GONE
                    oncekiGizle()
                    return@post
                }
                lp.topMargin = placement.topPx
                showPrevious = placement.showPrevious
                t.layoutParams = lp
            } else {
                if (bottomPx >= 0) {
                    lp.topMargin = (bottomPx - t.measuredHeight).coerceAtLeast(dp(8))
                } else if (lp.topMargin > ekranYuk / 2) {
                    val maxTop = ekranYuk - t.measuredHeight - dp(2)
                    lp.topMargin = lp.topMargin.coerceAtMost(maxTop.coerceAtLeast(dp(8)))
                }
                t.layoutParams = lp
            }
            t.visibility = View.VISIBLE
            if (wasVisible && cover == null) {
                t.animate().cancel()
                t.alpha = 0.35f
                t.animate().alpha(1f).setDuration(150).start()
            } else {
                t.alpha = 1f
            }
            oncekiYerlestir(if (showPrevious) previous else null, lp.topMargin, lp.leftMargin, lp.rightMargin)
        }
    }

    private fun oncekiYerlestir(value: String?, altPx: Int, sol: Int, sag: Int) {
        val p = prevView ?: return
        if (value.isNullOrBlank()) {
            oncekiGizle()
            return
        }
        p.animate().cancel()
        p.text = value
        val lp = p.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = sol
        lp.rightMargin = sag
        val genislik = (context.resources.displayMetrics.widthPixels - sol - sag).coerceAtLeast(dp(80))
        p.measure(
            View.MeasureSpec.makeMeasureSpec(genislik, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ust = altPx - p.measuredHeight - dp(3)
        if (ust < dp(8) || (
            protectedStripTop >= 0 && protectedStripBottom > protectedStripTop &&
                ust < protectedStripBottom && ust + p.measuredHeight > protectedStripTop
        )) {
            oncekiGizle()
            return
        }
        lp.topMargin = ust
        p.layoutParams = lp
        p.alpha = ONCEKI_SOLUK
        p.visibility = View.VISIBLE
    }

    fun oncekiYaz(value: String?) {
        val t = subtitleView ?: return
        t.post {
            if (t.visibility != View.VISIBLE) {
                oncekiGizle()
                return@post
            }
            val lp = t.layoutParams as FrameLayout.LayoutParams
            oncekiYerlestir(value, lp.topMargin, lp.leftMargin, lp.rightMargin)
        }
    }

    fun oncekiSoldur(sureMs: Long) {
        val p = prevView ?: return
        p.post {
            if (p.visibility != View.VISIBLE) return@post
            p.animate().cancel()
            p.animate().alpha(0f).setDuration(sureMs).withEndAction {
                p.visibility = View.GONE
                p.text = ""
                p.alpha = ONCEKI_SOLUK
            }.start()
        }
    }

    private fun oncekiGizle() {
        val p = prevView ?: return
        p.animate().cancel()
        p.visibility = View.GONE
        p.text = ""
        p.alpha = ONCEKI_SOLUK
    }

    fun setLabels(labels: List<Label>) {
        val container = root ?: return
        container.post {
            while (labelViews.size < labels.size) {
                val tv = makeText(13f, 205)
                container.addView(
                    tv,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT
                    ).apply { gravity = Gravity.TOP or Gravity.START }
                )
                labelViews.add(tv)
            }

            for (i in labelViews.indices) {
                val tv = labelViews[i]
                val label = labels.getOrNull(i)
                if (label == null) {
                    tv.visibility = View.GONE
                    continue
                }
                val lp = tv.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin = label.x.coerceAtLeast(0)
                lp.topMargin = label.y.coerceAtLeast(0)
                tv.layoutParams = lp
                tv.text = label.text
                tv.visibility = View.VISIBLE
            }
        }
    }

    fun clearLabels() = setLabels(emptyList())

    fun hide() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (_: Throwable) {
        }
        root = null
        subtitleView = null
        prevView = null
        labelViews.clear()
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    companion object {
        const val ONCEKI_ORAN = 0.78f
        const val ONCEKI_SOLUK = 0.62f
    }
}