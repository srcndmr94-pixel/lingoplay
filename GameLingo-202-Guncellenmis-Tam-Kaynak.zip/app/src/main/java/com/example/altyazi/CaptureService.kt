package com.example.altyazi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.altyazi.START"
        const val ACTION_STOP = "com.example.altyazi.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "altyazi"
        private const val NOTIF_ID = 1001

        private const val TARGET_WIDTH = 2200
        private const val TARGET_WIDTH_TV = 1024
        private const val MIN_INTERVAL_TV = 300L
        private const val STALE_MS = 4000L

        private const val KURTARMA_DENEMESI = 2
        private const val KURTARMA_UST_SINIR = 20

        private const val ORTAK_BAS_EN_AZ = 22
        private const val ORTAK_BAS_ORAN = 0.65f
        private const val ORTAK_BAS_MUTLAK = 38

        private const val MENU_WIDTH = 1200
        private const val MENU_EVERY = 4
        private const val MAX_LABELS = 5
        private const val MAX_PARALLEL = 2
        private const val MENU_ZONE = 0.5f
        private const val TURKISH_ONLY = "ığşİĞŞ"

        @Volatile
        var running = false

        private val logLines = ArrayDeque<String>()

        @JvmStatic
        fun log(line: String) {
            synchronized(logLines) {
                logLines.addLast(line)
                while (logLines.size > 400) logLines.removeFirst()
            }
        }

        private val history = ArrayDeque<Pair<String, String>>()

        fun history(): List<Pair<String, String>> = synchronized(history) { history.toList() }

        fun lastPair(): Pair<String, String>? = synchronized(history) { history.lastOrNull() }

        @Volatile var sonOcrMs = 0L
        @Volatile var sonCeviriMs = 0L

        internal fun addHistory(source: String, value: String) {
            synchronized(history) {
                if (history.lastOrNull()?.first == source) history.removeLast()
                history.addLast(source to value)
                while (history.size > 150) history.removeFirst()
            }
        }

        @Volatile var lastPreview: Bitmap? = null
        @Volatile var lastPreviewRaw: Bitmap? = null

        fun dumpLog(): String = synchronized(logLines) {
            if (logLines.isEmpty()) "Kayıt yok. BAŞLAT'a basıp oyunda birkaç replik bekleyin."
            else logLines.joinToString("\n")
        }

        fun clearLog() = synchronized(logLines) { logLines.clear() }

        private val TURKCE_KELIMELER = setOf(
            "bir", "bu", "şu", "için", "ile", "çok", "daha", "var", "yok",
            "değil", "ama", "gibi", "kadar", "sonra", "önce", "şey", "evet",
            "hayır", "tamam", "devam", "edin", "halinde", "abone", "izlemeye",
            "ve", "veya", "ben", "sen", "biz", "siz", "onlar", "bizim",
            "senin", "benim", "nasıl", "neden", "nerede", "kim", "hangi",
            "oldu", "olur", "yapıyor", "geldi", "gitti", "dedi", "bilmiyorum",
        )

        private val UI_WORDS = setOf(
            "TOUCHPAD", "OPTIONS", "SKIP", "CONTINUE", "LOADING", "AUTOSAVE",
            "OBJECTIVE", "NEW OBJECTIVE", "MISSION", "CHECKPOINT"
        )

        private val CONTROLLER_LABELS = setOf(
            "L1", "L2", "L3", "R1", "R2", "R3",
            "X", "O", "□", "△", "▲", "●", "■", "✕",
            "PS", "START", "SELECT", "TOUCH", "SKIP", "HOLD", "MAP", "MENU",
            "BACK", "NEXT", "OPTION", "PAUSE", "WAIT"
        )

        private val BLOCK_PHRASES = listOf(
            "güvenlik nedeniyle", "uygulama içerikleri", "gizlendi",
            "secure content", "content is hidden",
            "dialogue boost", "x-ray", "xray", "ekran görüntüsü",
            "alt yazı", "alt yazi", "altyazılar", "subtitles",
            "audio and subtitles", "audio & subtitles",
            "skip intro", "skip recap", "next episode", "watch credits",
            "episodes", "bölümler", "ses artırma", "ayarlar ve",
            "playstation", "play station", "xbox", "nintendo", "steam deck",
            "remote play", "uzaktan oynat", "dualsense", "ps remote",
        )

        private val SENTENCE_WORDS = setOf(
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "i", "you", "he", "she", "we", "they", "it", "me", "him", "her",
            "my", "your", "his", "our", "their", "this", "that", "these",
            "to", "of", "in", "on", "at", "for", "with", "from", "by",
            "and", "or", "but", "if", "so", "not", "no", "yes",
            "do", "does", "did", "don't", "can", "can't", "will", "won't",
            "have", "has", "had", "get", "got", "go", "come", "know", "think",
            "what", "why", "how", "when", "where", "who",
        )

        private val KISA_KELIMELER = setOf(
            "a", "i", "am", "an", "as", "at", "be", "by", "do", "go", "he",
            "hi", "if", "in", "is", "it", "me", "my", "no", "of", "oh", "ok",
            "on", "or", "so", "to", "up", "us", "we", "ya", "yo", "ye", "ah",
            "ay", "eh", "uh", "um", "aw", "ow", "oi", "ha", "hm", "mm", "nah",
            "m", "s", "t", "d", "ll", "re", "ve", "em", "im", "id",
        )
    }

    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var projection: MediaProjection? = null
    @Volatile private var sanalEkraninIzni: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var readerThread: HandlerThread? = null
    private var readerHandler: Handler? = null

    private lateinit var prefs: Prefs
    private lateinit var overlay: Overlay
    private var fast: FastTranslate? = null
    private var firefox: FirefoxCeviri? = null
    private var opusMt: OpusMtEngine? = null
    private val opusAccepted = java.util.concurrent.atomic.AtomicInteger(0)
    private val opusRejected = java.util.concurrent.atomic.AtomicInteger(0)
    private val deepLAccepted = java.util.concurrent.atomic.AtomicInteger(0)
    private val deepLRejected = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var llmLatest = ""
    private val recentLines = ArrayDeque<String>()
    private var store: TranslationStore? = null
    private var storeAi: TranslationStore? = null

    private var recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    @Volatile private var recognizerClosed = false

    private var captureWidth = 0
    private var captureHeight = 0
    private var displayCreated = false

    private var screenWidth = 0
    private var screenHeight = 0

    private var frameBitmap: Bitmap? = null
    private var bandImza: IntArray? = null
    private var imzaPiksel: IntArray? = null
    private val subtitleReadGuard299 = SubtitleReadGuard299(idleRecheckMs = 420L, candidateRecheckMs = 120L)

    @Volatile private var shownSource = ""
    private var candidate = ""
    private var candidateSeen = 0
    @Volatile private var translatingFor = ""
    private val subtitleGeneration = SubtitleGenerationGate()

    private val inFlight = java.util.concurrent.ConcurrentHashMap<Long, kotlinx.coroutines.Job>()
    private val startedAt = java.util.concurrent.ConcurrentHashMap<String, Long>()
    @Volatile private var lastOcrRaw = ""
    @Volatile private var lastMlKitRaw = ""
    @Volatile private var lastFilteredOcr = ""
    @Volatile private var sonCaptureMs = 0L
    @Volatile private var lastOcrTrace = "ham=0 kalan=0 secilen=0"
    @Volatile private var diagOcrErrors = 0
    private var emptyFrames = 0
    private var everShown = false
    private var noTextWarned = false
    private val isTv: Boolean by lazy { TvMode.isTvDevice(this) }

    private var lastPreviewMs = 0L

    private fun onizlemeKaydet(full: Bitmap, left: Int, top: Int, right: Int, bottom: Int) {
        try {
            if (full.isRecycled || full.width <= 0) return
            val usable = if (captureWidth in 1..full.width) captureWidth else full.width
            val w = 640
            val h = (full.height * w / usable).coerceAtLeast(1)
            val k = w.toFloat() / usable
            val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            android.graphics.Canvas(raw).drawBitmap(
                full, android.graphics.Rect(0, 0, usable, full.height),
                android.graphics.Rect(0, 0, w, h),
                android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
            )
            if (!MainActivity.visible && !RegionActivity.visible) lastPreviewRaw = raw
            val prev = raw.copy(Bitmap.Config.ARGB_8888, true)
            val c = android.graphics.Canvas(prev)
            val p = android.graphics.Paint().apply {
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = 3f
                color = android.graphics.Color.rgb(46, 230, 214)
            }
            c.drawRect(left * k, top * k, right * k, bottom * k, p)
            lastPreview = prev
        } catch (_: Throwable) {
        }
    }

    private var subtitleAnchorPx = 0
    private var subtitleBottomPx = -1
    @Volatile private var protectedBandTopPx = -1
    @Volatile private var protectedBandBottomPx = -1

    private val liveContext = LiveContextHistory()
    private var sonBozukLog = 0L
    @Volatile private var textBottomScreenPx = -1
    @Volatile private var textBottomAt = 0L
    private var ocrBandTop = 0
    private var ocrBandScale = 1f
    private var ocrScreenPerCap = 1f
    private var ownTextFrames = 0

    private val menuCache = java.util.Collections.synchronizedMap(LinkedHashMap<String, String>())
    private var lastMenuKey = ""
    private var menuJob: Job? = null

    private val displayed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        overlay = Overlay(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == null) {
            log("Servis izinsiz yeniden başlatıldı, durduruluyor")
            stopEverything()
            return START_NOT_STICKY
        }

        when (intent.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }

            ACTION_START -> {
                if (EngineBenchmark1035.running) {
                    log("MODEL TESTI CALISIYOR: test tamamlanmadan ekran yakalama acilmaz")
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                startForegroundSafely()
                AiTranslate.devreyiAc()

                val code = intent.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
                if (data == null) {
                    stopEverything()
                    return START_NOT_STICKY
                }

                if (projection == null) {
                    if (!scope.isActive) {
                        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
                    }
                    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val mp = try {
                        mpm.getMediaProjection(code, data)
                    } catch (e: Throwable) {
                        CrashLog.note(this, "ekran izni", e)
                        null
                    }
                    if (mp == null) {
                        stopEverything()
                        return START_NOT_STICKY
                    }
                    mp.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() {
                            stopEverything()
                        }
                    }, Handler(mainLooper))
                    projection = mp

                    overlay.show()
                    TvMode.autoUpdate(this, prefs)
                    overlay.setStil(gorunumStili())
                    running = true
                    startPipeline()
                }
            }

            else -> {
                stopEverything()
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Lingo", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)

        return builder
            .setContentTitle("Lingo çalışıyor")
            .setContentText("Ekrandaki yazılar Türkçeye çevriliyor")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null as android.graphics.drawable.Icon?,
                    "Durdur",
                    stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    private fun startForegroundSafely() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            @Suppress("DEPRECATION")
            val d = wm.defaultDisplay
            @Suppress("DEPRECATION")
            val p = android.graphics.Point().also { d.getRealSize(it) }
            p.x to p.y
        }
    }

    private fun configureDisplay(): Boolean {
        val (sw, sh) = screenSize()
        if (sw <= 0 || sh <= 0) return false
        screenWidth = sw
        screenHeight = sh

        val scale = min(1f, (if (isTv) TARGET_WIDTH_TV else TARGET_WIDTH).toFloat() / max(sw, 1))
        val w = max(2, (sw * scale).toInt() / 2 * 2)
        val h = max(2, (sh * scale).toInt() / 2 * 2)

        if (displayCreated && w == captureWidth && h == captureHeight) return true

        if (readerThread == null) {
            val thread = HandlerThread(
                "altyazi-reader",
                if (isTv) android.os.Process.THREAD_PRIORITY_BACKGROUND else android.os.Process.THREAD_PRIORITY_DEFAULT
            ).also { it.start() }
            readerThread = thread
            readerHandler = Handler(thread.looper)
        }

        val reader = try {
            ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        } catch (e: Throwable) {
            CrashLog.note(this, "goruntu okuyucu", e)
            return false
        }

        return try {
            if (!displayCreated) {
                if (projection != null && projection === sanalEkraninIzni) {
                    reader.close()
                    log("Sanal ekran bu izinle zaten kurulmuştu; yeniden kurulamaz. DURDUR → BAŞLAT gerekiyor.")
                    return false
                }
                val vd = projection?.createVirtualDisplay(
                    "altyazi",
                    w, h,
                    resources.displayMetrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.surface,
                    null,
                    readerHandler
                )
                if (vd == null) {
                    reader.close()
                    return false
                }
                virtualDisplay = vd
                displayCreated = true
                sanalEkraninIzni = projection
            } else {
                val vd = virtualDisplay
                if (vd == null) {
                    reader.close()
                    return false
                }
                vd.setSurface(null)
                vd.resize(w, h, resources.displayMetrics.densityDpi)
                vd.setSurface(reader.surface)
            }

            val old = imageReader
            imageReader = reader
            try {
                old?.close()
            } catch (_: Throwable) {
            }

            captureWidth = w
            captureHeight = h
            true
        } catch (e: Throwable) {
            CrashLog.note(this, "ekran kurulumu", e)
            try {
                reader.close()
            } catch (_: Throwable) {
            }
            false
        }
    }

    private fun releaseDisplay() {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {
        }
        virtualDisplay = null
        try {
            imageReader?.close()
        } catch (_: Throwable) {
        }
        imageReader = null
        try {
            readerThread?.quitSafely()
        } catch (_: Throwable) {
        }
        readerThread = null
        readerHandler = null
        frameBitmap = null
        bandImza = null
        displayCreated = false
        captureWidth = 0
        captureHeight = 0
        sanalEkraninIzni = null
    }

    private val pipelineOn = java.util.concurrent.atomic.AtomicBoolean(false)

    @Volatile private var lastFrameMs = 0L
    @Volatile private var staleWarned = false
    @Volatile private var rotatedAtMs = 0L
    @Volatile private var framesSinceRotate = 0
    @Volatile private var reattachTries = 0
    @Volatile private var sonKurtarmaMs = 0L

    private fun recoverCapture(zorla: Boolean): Boolean = try {
        val vd = virtualDisplay
        val w = captureWidth
        val h = captureHeight
        if (vd == null || w <= 0 || h <= 0) {
            false
        } else {
            val dpi = resources.displayMetrics.densityDpi
            val yeni = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            vd.setSurface(null)
            if (zorla) {
                vd.resize(maxOf(2, w - 2), maxOf(2, h - 2), dpi)
            }
            vd.resize(w, h, dpi)
            vd.setSurface(yeni.surface)
            val eski = imageReader
            imageReader = yeni
            try { eski?.close() } catch (_: Throwable) {}
            frameBitmap = null
            bandImza = null
            true
        }
    } catch (e: Throwable) {
        CrashLog.note(this, "yakalama kurtarma", e)
        false
    }

    @Volatile private var diagFrames = 0
    @Volatile private var diagNoFrame = 0
    @Volatile private var diagText = 0
    @Volatile private var diagOwn = 0

    private fun startPipeline() {
        UserDict.apply(this)
        Sozluk.yukle(this)
        if (recognizerClosed) {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizerClosed = false
        }
        diagFrames = 0; diagNoFrame = 0; diagText = 0; diagOwn = 0
        AdDefteri.temizle()
        KonusanOnEki.temizle()
        prefs.bicimiOnar()
        liveContext.clear()
        rotatedAtMs = 0L; framesSinceRotate = 0; reattachTries = 0; sonKurtarmaMs = 0L
        lastFrameMs = 0L; staleWarned = false
        everShown = false
        if (!pipelineOn.compareAndSet(false, true)) {
            log("Çeviri zaten çalışıyor, ikinci başlatma yok sayıldı")
            return
        }
        val f = FastTranslate()
        fast = f
        firefox = if (prefs.firefoxMotoru) FirefoxCeviri(this).also {
            if (it.baglan()) log("FIREFOX MOTORU: bağlanılıyor (Offline Translator)")
            else log("FIREFOX MOTORU YOK: ${FirefoxCeviri.sonHata ?: "kurulu değil"} · taslak yerleşik motordan")
        } else null
        opusMt = if (prefs.opusMtEnabled && OpusModelPack.isInstalled(this)) {
            OpusMtEngine(this).also { opusCandidate ->
                scope.launch {
                    log("OPUS-MT: yerel model belleğe yükleniyor")
                    log(if (opusCandidate.prepare()) "OPUS-MT: ONNX modeli hazır"
                        else "OPUS-MT: yükleme başarısız (${opusCandidate.lastError}); Google/Firefox yedeği")
                }
            }
        } else {
            if (prefs.opusMtEnabled) log("OPUS-MT: paket yok; Google/Firefox kullanılacak")
            null
        }
        GoogleCeviri.temizle()
        GoogleCeviri.trace = if (prefs.diagnostics) { satir -> log(satir) } else null
        val deeplKey = if (prefs.deepLEnabled) DeepLCredentials.read(this) else ""
        val useDeepL = prefs.deepLEnabled && deeplKey.isNotBlank()
        DeepLCeviri.resetSession()
        OfflineFix.gucluFn = null
        if (useDeepL) log("DEEPL AÇIK (API, kullanım kotası/ücreti olabilir) · OPUS/Google yedeği")
        else if (prefs.deepLEnabled) log("DEEPL KAPALI: geçerli API anahtarı yok; yerel/Google motorları kullanılıyor")
        OfflineFix.clearCache()
        if (prefs.googleCeviri) log("GOOGLE ÇEVİRİ AÇIK")
        store = TranslationStore(this)
        storeAi = TranslationStore(this, TranslationStore.AI)

        scope.launch {
            var bekleme = 0
            while (isActive && !Sozluk.hazir && bekleme < 60) { delay(500); bekleme++ }
            log(if (Sozluk.hazir) "SÖZLÜK HAZIR: ${Sozluk.adet} kelime (${Sozluk.kaynak}) · OCR onarımı devrede"
                else "SÖZLÜK YÜKLENEMEDİ${Sozluk.sonHata?.let { ": $it" } ?: ""} · OCR onarımı elle kurallarla")
        }

        scope.launch {
            try {
                f.prepare()
                f.translate("Hello.")
            } catch (e: Throwable) {
                CrashLog.note(this@CaptureService, "ceviri modeli", e)
            }
        }

        scope.launch {
            if (!configureDisplay()) {
                stopEverything()
                return@launch
            }

            val chain = when {
                useDeepL -> "DeepL → OPUS-MT → Google/Firefox"
                prefs.opusMtEnabled && opusMt != null -> "OPUS-MT → Google/Firefox"
                prefs.googleCeviri -> "Google → Firefox/yerel"
                else -> "Firefox/yerel"
            }
            log("SÜRÜM $surumAdi · motor:$chain")
            overlay.setSubtitle("GameLingo çalışıyor…", dp(80))
            delay(1500)
            if (shownSource.isEmpty()) overlay.setSubtitle(null, 0)

            var lastScreen = screenWidth to screenHeight
            var cycle = 0L
            val startedMs = android.os.SystemClock.elapsedRealtime()
            var nextDiagMs = startedMs + 5000
            var nextKaynakMs = startedMs + 10_000
            var nextTvCheckMs = 0L
            var lastTv = prefs.tvMode
            log("Ekran ${screenWidth}x${screenHeight} · yakalama ${captureWidth}x${captureHeight}")

            while (isActive) {
                val interval = prefs.intervalMs.toLong().coerceIn(if (isTv) MIN_INTERVAL_TV else 75L, 800L)
                delay(interval)

                try {
                    var now = screenSize()
                    if (now != lastScreen) {
                        var oturdu = now
                        var deneme = 0
                        while (deneme < 8) {
                            delay(100)
                            val tekrar = screenSize()
                            if (tekrar == oturdu) break
                            oturdu = tekrar
                            deneme++
                        }
                        now = oturdu
                        lastScreen = now
                        val ok = configureDisplay()
                        log("Ekran döndü: ${now.first}x${now.second} · yakalama ${captureWidth}x${captureHeight}${if (ok) "" else " · KURULAMADI"}")
                        rotatedAtMs = android.os.SystemClock.elapsedRealtime()
                        framesSinceRotate = 0
                        reattachTries = 0
                        sonKurtarmaMs = rotatedAtMs
                        bandImza = null
                        subtitleReadGuard299.reset()
                        textBottomScreenPx = -1
                        textBottomAt = 0L
                        protectedBandTopPx = -1
                        protectedBandBottomPx = -1
                        shownSource = ""
                        candidate = ""
                        candidateSeen = 0
                        translatingFor = ""
                        subtitleGeneration.invalidate()
                        showSubtitle(null)
                        overlay.clearLabels()
                        lastMenuKey = ""
                        delay(250)
                        continue
                    }

                    val nowMs = android.os.SystemClock.elapsedRealtime()
                    if (nowMs >= nextTvCheckMs) {
                        nextTvCheckMs = nowMs + 2000
                        TvMode.autoUpdate(this@CaptureService, prefs)
                        if (prefs.tvMode != lastTv) {
                            lastTv = prefs.tvMode
                            overlay.setStil(gorunumStili())
                            log(if (lastTv) "TV MODU AÇIK · yazı büyük" else "TV modu kapalı · telefon boyutu")
                        }
                    }
                    if (nowMs >= nextKaynakMs) {
                        nextKaynakMs = nowMs + KAYNAK_ARALIK_MS
                        log(kaynakDurumu())
                        if (prefs.googleCeviri) log(GoogleCeviri.durum())
                    }
                    if (nowMs >= nextDiagMs && nowMs - startedMs <= 180_000) {
                        nextDiagMs = nowMs + 15_000
                        log("TANI: kare $diagFrames (boş $diagNoFrame) · okunan yazı $diagText · kendi $diagOwn · OCR hata $diagOcrErrors · $lastOcrTrace · yakalama=${sonCaptureMs}ms OCR=${sonOcrMs}ms")
                    }
                    val captureStart = android.os.SystemClock.elapsedRealtime()
                    val full = grabFull()
                    sonCaptureMs = android.os.SystemClock.elapsedRealtime() - captureStart
                    if (full == null) {
                        diagNoFrame++
                        if (shownSource.isNotEmpty() && lastFrameMs > 0 && nowMs - lastFrameMs > STALE_MS) {
                            shownSource = ""
                            candidate = ""
                            candidateSeen = 0
                            translatingFor = ""
                            subtitleGeneration.invalidate()
                            showSubtitle(null)
                            if (!staleWarned) {
                                staleWarned = true
                                log("GÖRÜNTÜ GELMİYOR: ${STALE_MS / 1000} sn'dir yeni kare yok, eski çeviri kaldırıldı.")
                            }
                        }
                        if (rotatedAtMs > 0 && framesSinceRotate == 0 &&
                            reattachTries < KURTARMA_UST_SINIR &&
                            nowMs - sonKurtarmaMs > minOf(2500L * (reattachTries + 1), 30_000L)
                        ) {
                            sonKurtarmaMs = nowMs
                            reattachTries++
                            val ok = recoverCapture(zorla = reattachTries > 1)
                            if (reattachTries <= KURTARMA_DENEMESI + 1) {
                                log("Döndükten sonra kare yok, okuyucu yenileniyor ($reattachTries)${if (ok) "" else " · başarısız"}")
                            }
                        }
                        continue
                    }
                    if (framesSinceRotate == 0 && rotatedAtMs > 0) {
                        log("Döndükten ${nowMs - rotatedAtMs} ms sonra görüntü geldi")
                    }
                    framesSinceRotate++
                    lastFrameMs = nowMs
                    diagFrames++
                    processSubtitle(full)

                    if (!isTv && prefs.menuTranslate && cycle % MENU_EVERY == 0L && menuJob?.isActive != true) {
                        val copy = try {
                            if (full.isRecycled) null
                            else full.copy(Bitmap.Config.ARGB_8888, false)
                        } catch (_: Throwable) {
                            null
                        }
                        if (copy != null) menuJob = scope.launch {
                            try {
                                processMenu(copy)
                            } catch (e: Throwable) {
                                CrashLog.note(this@CaptureService, "menu taramasi", e)
                            } finally {
                                copy.recycle()
                            }
                        }
                    }

                    cycle++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    CrashLog.note(this@CaptureService, "tarama dongusu", e)
                    delay(300)
                }
            }
        }
    }

    private fun grabFull(): Bitmap? {
        val reader = imageReader ?: return null
        val image = try {
            reader.acquireLatestImage()
        } catch (_: Throwable) {
            null
        } ?: return null

        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val paddedWidth = image.width + (rowStride - pixelStride * image.width) / pixelStride

            var bmp = frameBitmap
            if (bmp == null || bmp.isRecycled ||
                bmp.width != paddedWidth || bmp.height != image.height
            ) {
                bmp = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                frameBitmap = bmp
                bandImza = null
            }
            bmp.copyPixelsFromBuffer(buffer)
            bmp
        } catch (_: Throwable) {
            null
        } finally {
            try {
                image.close()
            } catch (_: Throwable) {
            }
        }
    }

    private suspend fun processSubtitle(full: Bitmap) {
        if (full.isRecycled) return

        val topPct = prefs.topPct.coerceIn(0, 98)
        val bottomPct = prefs.bottomPct.coerceIn(topPct + 1, 100)

        val top = (full.height * topPct / 100).coerceIn(0, full.height - 2)
        val bottom = (full.height * bottomPct / 100).coerceIn(top + 2, full.height)
        val usable = if (captureWidth in 1..full.width) captureWidth else full.width
        val left = (usable * prefs.leftPct / 100).coerceIn(0, usable - 4)
        val right = (usable * prefs.rightPct / 100).coerceIn(left + 4, usable)

        val seritUstu = screenHeight * topPct / 100
        subtitleAnchorPx = when (prefs.subtitlePos) {
            Prefs.POS_COVER -> seritUstu - dp(4)
            Prefs.POS_BOTTOM -> screenHeight - dp(110)
            Prefs.POS_BELOW -> screenHeight * prefs.bottomPct.coerceIn(1, 100) / 100 - dp(4)
            else -> seritUstu - dp(58)
        }
        subtitleBottomPx = if (prefs.subtitlePos == Prefs.POS_ABOVE) seritUstu - dp(6) else -1
        protectedBandTopPx = (top * screenHeight.toFloat() / full.height).toInt()
        protectedBandBottomPx = (bottom * screenHeight.toFloat() / full.height).toInt()

        var band = try {
            Bitmap.createBitmap(full, left, top, right - left, bottom - top)
        } catch (e: Throwable) {
            return
        }
        if (band.height < 110) {
            val scaled = Bitmap.createScaledBitmap(band, band.width * 2, band.height * 2, true)
            if (scaled != band) band.recycle()
            band = scaled
        }

        val simdiMs = android.os.SystemClock.elapsedRealtime()
        if (simdiMs - lastPreviewMs > 2000) {
            lastPreviewMs = simdiMs
            onizlemeKaydet(full, left, top, right, bottom)
        }

        if (MainActivity.visible) {
            band.recycle()
            return
        }

        val sampleUnchanged = bandDegismedi(band)
        val checkMs = android.os.SystemClock.elapsedRealtime()
        if (!subtitleReadGuard299.shouldOcr(sampleUnchanged, candidateSeen == 1, checkMs)) {
            band.recycle()
            return
        }

        ocrBandLeft = left
        ocrBandTop = top
        ocrBandScale = if (band.height >= (bottom - top) * 2 - 1) 2f else 1f
        ocrScreenPerCap = if (full.height > 0) screenHeight.toFloat() / full.height else 1f
        val ocrBasi = android.os.SystemClock.elapsedRealtime()
        val text = runOcr(band, filterEdges = true)
        sonOcrMs = android.os.SystemClock.elapsedRealtime() - ocrBasi
        band.recycle()
        if (text.isNotBlank()) diagText++
        lastOcrRaw = text
        handleText(text)
    }

    private fun handleText(raw: String) {
        // 1. Önce temel OCR çöp temizliği ve kelime onarımı yapılır
        val preCleaned = clean(raw)
        if (preCleaned.isEmpty()) {
            emptyFrames++
            if (prefs.diagnostics && !noTextWarned && !everShown && emptyFrames >= 60) {
                noTextWarned = true
                log("UYARI: ekranda hiç yazı okunamadı")
                if (prefs.diagnostics) {
                    showSubtitle("⚠ Ekranda yazı okunamıyor. Altyazı bölgesini kontrol edin.")
                }
                return
            }
            val yeterinceDurdu =
                android.os.SystemClock.elapsedRealtime() - shownAtMs >= okumaMs
            if (emptyFrames >= 5 && shownSource.isNotEmpty() && yeterinceDurdu) {
                shownSource = ""
                candidate = ""
                candidateSeen = 0
                translatingFor = ""
                subtitleGeneration.invalidate()
                showSubtitle(null)
            }
            return
        }
        emptyFrames = 0

        // Süslü font / çöp ön ek kırpma ve sözlüklü OCR onarımı
        val stripped = OcrOnar.copOnEki(preCleaned)
            ?: if (OcrOnar.susluCop(preCleaned)) {
                val kuyruk = OcrOnar.temizKuyruk(preCleaned)
                if (kuyruk != null && !OcrOnar.onEkGercek(preCleaned, kuyruk)) kuyruk else preCleaned
            } else preCleaned

        val text = adiAyir(OcrOnar.onar(TextFix.clean(stripped)))
        if (text.count(Char::isLetter) < 2) return

        // İngilizce üzerine yerleşim (POS_COVER) açıkken kendi çeviri kutumuz aynı bölgede durur.
        // Kendi Türkçe yazımızı yeniden yakalarsak İngilizce bitmiş demektir; ancak İngilizce
        // yeni geldiğinde zaten Türkçe harf taşımadığı için burayı geçer.
        if (isOurOwnText(text)) {
            if (prefs.subtitlePos != Prefs.POS_COVER) {
                ownTextFrames++
                diagOwn++
                candidate = ""
                candidateSeen = 0
                if (ownTextFrames >= 6 && shownSource.isNotEmpty()) {
                    ownTextFrames = 0
                    shownSource = ""
                    translatingFor = ""
                    subtitleGeneration.invalidate()
                    showSubtitle(null)
                }
            } else {
                dustu(text, "kendi yazımız (cover)")
            }
            return
        }
        ownTextFrames = 0

        if (OcrQuality.bozukMu(text) || OcrOnar.cokBozuk(text)) {
            val simdi = android.os.SystemClock.elapsedRealtime()
            if (simdi - sonBozukLog > 3000) {
                sonBozukLog = simdi
                log("BOZUK OKUMA (beklendi, çevrilmedi): $text")
            }
            candidate = ""
            candidateSeen = 0
            return
        }
        if (altyaziDegil(text)) {
            dustu(text, "altyazı değil")
            candidate = ""
            candidateSeen = 0
            return
        }

        // Ekrandakiyle veya halihazırda çevrilmekte olanla aynı mı kontrolü (yinelenen replik engeli)
        if (!SubtitleReadGuard299.meaningfulRevision(shownSource, text) &&
            (similar(text, shownSource) || OcrOnar.ayniGurultulu(text, shownSource))) {
            dustu(text, "ekrandakiyle aynı sayıldı: ${shownSource.take(40)}")
            candidate = ""
            candidateSeen = 0
            return
        }

        if (similar(text, candidate)) {
            candidateSeen++
        } else {
            candidate = text
            candidateSeen = 1
        }

        val tamamGorunuyor = text.length >= 10 ||
            text.trimEnd().lastOrNull() in listOf('.', '!', '?', '…')
        val ocrCorrection = SubtitleReadGuard299.smallCorrection(shownSource, text) ||
            SubtitleReadGuard299.smallCorrection(translatingFor, text)
        val gerekenOkuma = if (ocrCorrection) 2 else
            if (tamamGorunuyor && SubtitlePreparation.confidentFirstRead(text)) 1 else 2

        if (candidateSeen < gerekenOkuma) return
        if (!SubtitleReadGuard299.meaningfulRevision(translatingFor, text) &&
            (similar(text, translatingFor) || OcrOnar.ayniGurultulu(text, translatingFor))) {
            dustu(text, "çevrilmekte olanla aynı sayıldı: ${translatingFor.take(40)}")
            return
        }

        if (inFlight.size >= MAX_PARALLEL) {
            val oldestId = inFlight.keys.minOrNull()
            if (oldestId != null) {
                inFlight.remove(oldestId)?.cancel()
            }
        }
        val source = text
        if (translatingFor.isNotEmpty() && translatingFor != source) {
            sonGidenKaynak = translatingFor
            sonGidenMs = android.os.SystemClock.elapsedRealtime()
        }
        translatingFor = source
        val runId = subtitleGeneration.newSubtitle()
        val context = liveContext.accept(source, android.os.SystemClock.elapsedRealtime())

        // Yeni replik kesinleşti: önceki çeviriyi temizle ama İngilizce üzerine yerleşim koordinatlarını koru
        displayed.remove(normalize(shownValue))
        shownValue = ""
        shownSource = ""
        yiginiBosalt()
        overlay.hideForNewSubtitle()

        log("OKUNAN: $source")
        AdDefteri.ogren(source)
        val startedMs = android.os.SystemClock.elapsedRealtime()
        startedAt[source] = startedMs
        val job = scope.launch(start = kotlinx.coroutines.CoroutineStart.LAZY) {
            try {
                runTranslation(source, runId, context)
            } finally {
                inFlight.remove(runId)
                startedAt.remove(source, startedMs)
            }
        }
        inFlight[runId] = job
        job.start()
    }

    private var sonDusenMetin = ""
    private var sonDusenAn = 0L

    private fun dustu(metin: String, sebep: String) {
        val simdi = android.os.SystemClock.elapsedRealtime()
        if (metin == sonDusenMetin && simdi - sonDusenAn < 3000) return
        sonDusenMetin = metin
        sonDusenAn = simdi
        if (sebep.startsWith("ekrandakiyle aynı") || sebep.startsWith("çevrilmekte olanla aynı")) {
            if (prefs.diagnostics) log("TEKRAR ATLANDI ($sebep): ${metin.take(60)}")
        } else {
            log("ÇEVRİLMEDİ ($sebep): ${metin.take(60)}")
        }
    }

    @Volatile private var shownAtMs = 0L

    private fun ayniYazi(a: String, b: String): Boolean =
        a == b || sadeYazi(a) == sadeYazi(b)

    private fun sadeYazi(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() }

    @Volatile private var shownValue = ""
    @Volatile private var okumaMs = 0L

    private val YIGIN_ICINDE = 1500L
    private val ONCEKI_TUT = 1500L
    private val ONCEKI_SOLMA = 400L
    private val GEC_SINIR = 1500L
    private val GEC_GOSTER = 2500L
    private val YEDEK_TASLAK_MS = 1200L
    private val YER_TUTUCU = Regex("Qx\\d+")
    private val YEDEK_INTERNET_MS = 1500L
    private val TELEFON_BEKLE_MS = 1000L
    private val KAYNAK_ARALIK_MS = 300_000L
    @Volatile private var sonGidenKaynak = ""
    @Volatile private var sonGidenMs = 0L

    @Volatile private var yzOrtMs = 1500L

    private val taslakBekle: Long
        get() = (yzOrtMs + 300L).coerceIn(700L, 2000L)

    @Volatile private var oncekiMetin: String? = null
    @Volatile private var oncekiKaynak = ""
    private val yiginHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var oncekiKaldir: Runnable? = null

    private fun okumaSuresi(value: String): Long =
        maxOf(prefs.minShowSec * 1000L, minOf(OKUMA_EN_COK, 1800L + value.length * 55L))

    private val OKUMA_EN_COK = 5000L

    private fun oncekiyiZamanla() {
        oncekiKaldir?.let { yiginHandler.removeCallbacks(it) }
        val r = Runnable {
            oncekiMetin = null
            oncekiKaynak = ""
            overlay.oncekiSoldur(ONCEKI_SOLMA)
        }
        oncekiKaldir = r
        yiginHandler.postDelayed(r, ONCEKI_TUT)
    }

    private fun ustSiradaGoster(kaynak: String, deger: String) {
        oncekiMetin = deger
        oncekiKaynak = kaynak
        oncekiyiZamanla()
        overlay.oncekiYaz(deger)
    }

    private fun yiginiBosalt() {
        oncekiKaldir?.let { yiginHandler.removeCallbacks(it) }
        oncekiKaldir = null
        oncekiMetin = null
        oncekiKaynak = ""
    }

    private fun showSubtitle(value: String?, refined: Boolean = false, draft: Boolean = false) {
        if (value == null) {
            displayed.remove(normalize(shownValue))
            shownValue = ""
            yiginiBosalt()
        } else {
            displayed.add(normalize(value))
            shownAtMs = android.os.SystemClock.elapsedRealtime()
        }
        val coverMode = prefs.subtitlePos == Prefs.POS_COVER
        overlay.setSubtitle(
            value = value,
            topPx = subtitleAnchorPx,
            refined = refined,
            draft = draft,
            bottomPx = subtitleBottomPx,
            previous = if (prefs.yigin && !coverMode) oncekiMetin else null,
            protectedTopPx = if (coverMode) -1 else protectedBandTopPx,
            protectedBottomPx = if (coverMode) -1 else protectedBandBottomPx,
            preferBelow = prefs.subtitlePos == Prefs.POS_BELOW,
            coverSource = coverMode
        )
    }

    private val surumAdi: String get() = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (_: Throwable) { "?" }

    private val HARF_RAKAM = Regex("\\p{L}\\d|\\d\\p{L}")

    private fun hafizayaUygun(source: String): Boolean =
        !HARF_RAKAM.containsMatchIn(source) && !OcrOnar.cokBozuk(source)

    private fun saveToMemory(source: String, value: String, tag: String) {
        if (!hafizayaUygun(source) || !TranslationQualityGate.mayRemember(source, value)) {
            if (prefs.diagnostics) log("HAFIZAYA ALINMADI (bozuk okuma): ${source.take(60)}")
            return
        }
        if (tag.contains("YZ")) storeAi?.put(source, value) else store?.put(source, value)
    }

    private fun publish(
        source: String,
        rawValue: String?,
        remember: Boolean = true,
        tag: String = "",
        refined: Boolean? = null,
        runId: Long? = null,
    ) {
        val value = rawValue?.trim()
        if (value.isNullOrBlank()) return
        if (runId != null && !subtitleGeneration.isCurrent(runId)) {
            log("ESKİ İSTEK ATLANDI: ${source.take(65)}")
            return
        }
        val outputIssue = TranslationQualityGate.check(source, value)
        if (TranslationQualityGate.mustReject(outputIssue)) {
            log("ANLAM KORUMASI - REDDEDİLDİ ($outputIssue): ${source.take(65)} => ${value.take(65)}")
            return
        }
        val simdi = android.os.SystemClock.elapsedRealtime()
        val ayniSatirinCevabi = translatingFor != source &&
            tag.contains("YZ") && OcrOnar.ayniGurultulu(source, translatingFor)
        if (translatingFor != source && !ayniSatirinCevabi) {
            if (remember && !value.startsWith("⚠")) saveToMemory(source, value, tag)
            if (prefs.yigin && tag.contains("YZ") && oncekiKaynak == source &&
                simdi - shownAtMs < GEC_SINIR
            ) {
                ustSiradaGoster(source, value)
                return
            }
            return
        }
        val ms = startedAt.remove(source)?.let { simdi - it }
        if (ms != null) sonCeviriMs = ms

        if (shownSource == source && ayniYazi(shownValue, value)) {
            if (remember && !value.startsWith("⚠")) saveToMemory(source, value, tag)
            okumaMs = okumaSuresi(value)
            return
        }

        log(if (ms != null) "YAZILAN$tag ($ms ms): $value" else "YAZILAN$tag: $value")

        if (prefs.yigin && shownSource.isNotEmpty() && shownSource != source &&
            shownValue.isNotEmpty() && simdi - shownAtMs < YIGIN_ICINDE &&
            !benzerMetin(shownValue, value)
        ) {
            oncekiMetin = shownValue
            oncekiKaynak = shownSource
            oncekiyiZamanla()
        } else if (shownSource != source) {
            yiginiBosalt()
        }

        shownSource = source
        shownValue = value
        okumaMs = okumaSuresi(value)
        everShown = true
        if (remember && !value.startsWith("⚠")) saveToMemory(source, value, tag)
        if (!value.startsWith("⚠")) addHistory(source, value)
        showSubtitle(
            value,
            refined = refined ?: tag.contains("YZ"),
            draft = refined != true && tag.contains("taslak"),
        )
    }

    private val bridgeBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var bridgeNext: Pair<String, List<String>>? = null
    private val bridgeSeq = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var bridgeLastWarnMs = 0L

    private fun bridgeTranslate(source: String) {
        llmLatest = source
        val previous = synchronized(recentLines) { recentLines.toList() }
        synchronized(recentLines) {
            recentLines.addLast(source)
            while (recentLines.size > 3) recentLines.removeFirst()
        }
        scope.launch {
            val quick = fastTranslateKeepingName(source)
            val failed = quick.isNullOrBlank() || quick.trim().equals(source.trim(), ignoreCase = true)
            if (!failed && translatingFor == source && shownSource != source) {
                publish(source, quick!!, remember = false, tag = " · taslak")
            }
        }
        if (!bridgeBusy.compareAndSet(false, true)) {
            bridgeNext = source to previous
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                var job: Pair<String, List<String>>? = source to previous
                while (job != null) {
                    val (src, prev) = job
                    val seq = bridgeSeq.incrementAndGet()
                    val t0 = android.os.SystemClock.elapsedRealtime()
                    val r = PhoneBridge.translate(
                        prefs.bridgeHost, prefs.bridgePin, seq, aiInput(src), prev,
                        prefs.contentType, prefs.gameName
                    )
                    val ms = android.os.SystemClock.elapsedRealtime() - t0
                    when (r) {
                        is PhoneBridge.Result.Ok -> {
                            val duzgun = yzDuzelt(src, r.text)
                            val sebep = AiGuard.redSebebi(src, null, duzgun)
                            if (sebep != null) {
                                log("YZ REDDEDİLDİ ($sebep) · TV taslağı kalıyor: ${duzgun.take(50)}")
                            } else {
                                startedAt.remove(src)
                                publish(src, aiPrefix(src) + duzgun, remember = true, tag = " · YZ telefon $ms ms")
                            }
                        }
                        is PhoneBridge.Result.Skip -> {}
                        is PhoneBridge.Result.Err -> {
                            val now = android.os.SystemClock.elapsedRealtime()
                            if (now - bridgeLastWarnMs > 30_000) {
                                bridgeLastWarnMs = now
                                log("TELEFON ÇEVİRİSİ YOK (${r.reason})")
                            }
                        }
                    }
                    job = bridgeNext
                    bridgeNext = null
                }
            } finally {
                bridgeBusy.set(false)
            }
        }
    }

    private fun aiInput(source: String): String {
        val (name, body) = splitSpeaker(source)
        val fixed = OfflineFix.cleanForAi(body)
        if (name != null && OfflineFix.languageLabel(name) != null) return fixed
        return if (name == null) fixed else "$name: $fixed"
    }

    private fun aiPrefix(source: String): String {
        val (name, _) = splitSpeaker(source)
        return name?.let { OfflineFix.languageLabel(it) }?.let { "[$it] " } ?: ""
    }

    private fun yzDuzelt(kaynak: String, ham: String): String =
        AiGuard.hitapDuzelt(kaynak, NameFix.koru(kaynak, ham.trim()))

    private fun publishForRun(
        runId: Long,
        source: String,
        value: String?,
        remember: Boolean = true,
        tag: String = "",
        refined: Boolean? = null,
    ) = publish(source, value, remember, tag, refined, runId)

    /** Motor sırası korunur: DeepL → OPUS-MT → Google → Firefox → ML Kit. */
    private suspend fun runTranslation(source: String, runId: Long, context: String) {
        if (isTv && prefs.bridgeOn && prefs.bridgeHost.isNotBlank() && prefs.bridgePin.isNotBlank()) {
            bridgeTranslate(source)
            return
        }
        OfflineFix.lookupUser(source)?.let {
            publishForRun(runId, source, it, remember = false, tag = " · kişisel sözlük")
            return
        }

        val (speakerName, rawBody) = splitSpeaker(source)
        // Bağlama uygun küfür ve argo koruması: motorların sansürlemesini engellemek için ön hazırlık
        val preparedBody = Slang.preserveProfanityContext(rawBody)

        val engines = mutableListOf<SimpleLiveTranslation.Engine>()
        val key = if (prefs.deepLEnabled) DeepLCredentials.read(this) else ""
        if (key.isNotBlank()) engines += SimpleLiveTranslation.Engine("DeepL") { text, previous ->
            withTimeoutOrNull(1800L) { DeepLCeviri.translate(text, key, previous) }
        }
        if (prefs.opusMtEnabled) engines += SimpleLiveTranslation.Engine("OPUS-MT") { text, _ ->
            withTimeoutOrNull(1400L) { opusMt?.takeIf { it.ready }?.translate(text, 64) }
        }
        if (prefs.googleCeviri) engines += SimpleLiveTranslation.Engine("Google") { text, _ ->
            withTimeoutOrNull(1800L) { GoogleCeviri.cevir(text) }
        }
        if (prefs.firefoxMotoru) engines += SimpleLiveTranslation.Engine("Firefox") { text, _ ->
            withTimeoutOrNull(1200L) { firefox?.cevir(text) }
        }
        engines += SimpleLiveTranslation.Engine("ML Kit") { text, _ -> fast?.translate(text) }

        val result = SimpleLiveTranslation.translate(preparedBody, context, engines,
            valid = { text, output ->
                val restored = Slang.restoreProfanityContext(rawBody, output)
                !TranslationQualityGate.mustReject(TranslationQualityGate.check(rawBody, restored)) &&
                    !MeaningSafety.lostContextualProfanity(rawBody, restored)
            },
            failed = { name ->
                if (name == "DeepL") deepLRejected.incrementAndGet()
                if (name == "OPUS-MT") opusRejected.incrementAndGet()
                if (prefs.diagnostics) log("MOTOR YEDEĞİ: $name atlandı")
            })
        if (result == null) {
            log("ÇEVİRİ ALINAMADI: ${source.take(65)}")
            return
        }
        if (result.engine == "DeepL") deepLAccepted.incrementAndGet()
        if (result.engine == "OPUS-MT") opusAccepted.incrementAndGet()

        val finalBody = Slang.restoreProfanityContext(rawBody, result.text)
        val finalOutput = if (speakerName == null) finalBody else "$speakerName: $finalBody"
        publishForRun(runId, source, finalOutput, remember = true, tag = " · ${result.engine}")
    }

    private suspend fun processMenu(full: Bitmap) {
        val scale = min(1f, MENU_WIDTH.toFloat() / max(full.width, 1))
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                full,
                max(2, (full.width * scale).toInt()),
                max(2, (full.height * scale).toInt()),
                true
            )
        } else {
            full
        }

        val found = ArrayList<Triple<String, Int, Int>>()
        val subtitleTop = prefs.topPct.coerceIn(0, 98) / 100f

        try {
            val lines = ocrLines(small)
            for (line in lines) {
                val box = line.second ?: continue
                val raw = line.first.trim()
                if (raw.length < 3) continue
                if (isControllerLabel(raw)) continue
                if (raw.count { it.isLetter() } < 3) continue

                val relY = box.top.toFloat() / small.height
                if (relY >= min(subtitleTop, MENU_ZONE)) continue
                if (isOurOwnText(raw)) continue
                if (displayed.contains(normalize(raw))) continue

                val screenX = (box.left.toFloat() / small.width * screenWidth).toInt()
                val screenY = (box.bottom.toFloat() / small.height * screenHeight).toInt()
                found.add(Triple(raw, screenX, screenY))
                if (found.size >= MAX_LABELS) break
            }
        } finally {
            if (small != full) small.recycle()
        }

        val key = found.joinToString("|") { it.first }
        if (key == lastMenuKey) return
        lastMenuKey = key

        if (found.isEmpty()) {
            displayed.clear()
            shownValue.takeIf { it.isNotEmpty() }?.let { displayed.add(normalize(it)) }
            overlay.clearLabels()
            return
        }

        val labels = ArrayList<Overlay.Label>()
        for ((text, x, y) in found) {
            val translated = translateMenuText(text) ?: continue
            labels.add(Overlay.Label(translated, x, y))
            displayed.add(normalize(translated))
        }
        overlay.setLabels(labels)
    }

    private suspend fun translateMenuText(text: String): String? {
        menuCache[text]?.let { return it }
        val (name, body) = splitSpeaker(text)
        val translated = fast?.translate(body) ?: return null
        if (translated.isBlank()) return null
        val result = if (name == null) translated else "$name: $translated"
        if (menuCache.size > 300) {
            val oldest = synchronized(menuCache) { menuCache.keys.firstOrNull() }
            if (oldest != null) menuCache.remove(oldest)
        }
        menuCache[text] = result
        return result
    }

    private suspend fun ocrLines(bitmap: Bitmap): List<Pair<String, android.graphics.Rect?>> =
        suspendCancellableCoroutine { cont ->
            try {
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val out = ArrayList<Pair<String, android.graphics.Rect?>>()
                        for (block in result.textBlocks) {
                            for (line in block.lines) {
                                val t = line.text.trim()
                                if (t.isNotEmpty()) out.add(t to line.boundingBox)
                            }
                        }
                        if (cont.isActive) cont.resume(out)
                    }
                    .addOnFailureListener { error ->
                        diagOcrErrors++
                        if (prefs.diagnostics) log("OCR HATA: ${error.javaClass.simpleName}")
                        if (cont.isActive) cont.resume(emptyList())
                    }
            } catch (error: Throwable) {
                diagOcrErrors++
                if (prefs.diagnostics) log("OCR HATA: ${error.javaClass.simpleName}")
                if (cont.isActive) cont.resume(emptyList())
            }
        }

    private var ocrBandLeft = 0

    private suspend fun runOcr(bitmap: Bitmap, filterEdges: Boolean): String {
        val lines = ocrLines(bitmap)
        val width = bitmap.width.toFloat()
        val kept = ArrayList<SubtitleBlocks.Line>()
        fun ekranY(y: Int): Int = ((ocrBandTop + y / ocrBandScale) * ocrScreenPerCap).toInt()
        val altta = filterEdges && prefs.subtitlePos == Prefs.POS_BELOW
        lastMlKitRaw = lines.joinToString(" / ") { it.first }.take(240)
        var rejectedOwn = 0
        var rejectedHud = 0
        var rejectedNoise = 0
        var rejectedEdge = 0

        for ((text, box) in lines) {
            if (isControllerLabel(text)) { rejectedHud++; continue }
            if (isOurOwnText(text)) { rejectedOwn++; continue }
            if (OfflineFix.isNoiseLine(text)) { rejectedNoise++; continue }
            if (filterEdges && box != null) {
                val centerX = (box.left + box.right) / 2f / width
                val lineWidth = box.width() / width
                if (kotlin.math.abs(centerX - 0.5f) > 0.30f) { rejectedEdge++; continue }
                if (lineWidth < 0.18f && kotlin.math.abs(centerX - 0.5f) > 0.20f) { rejectedEdge++; continue }
            }
            val top = box?.top ?: 0
            kept.add(SubtitleBlocks.Line(top, box?.bottom ?: (top + 1), text))
        }

        lastFilteredOcr = kept.joinToString(" / ") { it.text }.take(240)
        val blok = SubtitleBlocks.bottomBlock(kept)
        if (filterEdges && blok.isNotEmpty()) {
            val boxes = lines.filter { (text, box) -> box != null &&
                blok.any { it.text == text && it.top == box.top } }.mapNotNull { it.second }
            if (boxes.isNotEmpty()) {
                overlay.setSourceBounds(CaptionCoverBounds.map(
                    boxes.minOf { it.left }, boxes.minOf { it.top },
                    boxes.maxOf { it.right }, boxes.maxOf { it.bottom },
                    ocrBandLeft, ocrBandTop, ocrBandScale, ocrScreenPerCap))
            }
        }
        lastOcrTrace = "ham=${lines.size} kalan=${kept.size} secilen=${blok.size} " +
            "kendi=$rejectedOwn hud=$rejectedHud gurultu=$rejectedNoise kenar=$rejectedEdge"
        if (altta && blok.isNotEmpty()) {
            textBottomScreenPx = ekranY(blok.maxOf { it.bottom })
            textBottomAt = android.os.SystemClock.elapsedRealtime()
        }
        return blok.joinToString(" ") { it.text }
    }

    private fun bandDegismedi(band: Bitmap): Boolean {
        if (band.isRecycled || band.width < 4 || band.height < 4) return false

        val sutun = 32
        val satir = 12
        val toplam = sutun * satir

        var piksel = imzaPiksel
        if (piksel == null || piksel.size != toplam) {
            piksel = IntArray(toplam)
            imzaPiksel = piksel
        }

        var i = 0
        for (y in 0 until satir) {
            val py = (band.height - 1) * y / (satir - 1)
            for (x in 0 until sutun) {
                val px = (band.width - 1) * x / (sutun - 1)
                val renk = band.getPixel(px, py)
                piksel[i++] =
                    ((renk shr 16 and 0xFF) + (renk shr 8 and 0xFF) + (renk and 0xFF)) / 3
            }
        }

        val onceki = bandImza
        if (onceki == null || onceki.size != toplam) {
            bandImza = piksel.copyOf()
            return false
        }

        var enBuyukFark = 0
        for (j in 0 until toplam) {
            val fark = kotlin.math.abs(piksel[j] - onceki[j])
            if (fark > enBuyukFark) enBuyukFark = fark
        }

        return if (enBuyukFark < 7) {
            true
        } else {
            System.arraycopy(piksel, 0, onceki, 0, toplam)
            false
        }
    }

    private fun zatenTurkce(text: String): Boolean {
        if (text.any { it in TURKISH_ONLY }) return true
        for (k in text.lowercase().split(Regex("[^\\p{L}]+"))) {
            if (k.length >= 2 && k in TURKCE_KELIMELER) return true
        }
        return false
    }

    private fun isOurOwnText(text: String): Boolean {
        if (zatenTurkce(text)) return true
        val simdi = normalize(text)
        if (simdi.isEmpty()) return false
        if (displayed.contains(simdi)) return true
        for (eski in displayed) {
            if (eski.length >= 6 && (simdi.contains(eski) || eski.contains(simdi))) {
                return true
            }
        }
        return false
    }

    private fun gorunumStili(): Overlay.Stil {
        val alfa = SubtitleStyle.arkaAlfa(prefs.subtitleBg)
        val tv = prefs.tvMode
        return Overlay.Stil(
            boyutSp = if (tv) maxOf(prefs.subtitleSize * 1.5f, 26f) else prefs.subtitleSize.toFloat(),
            yaziRengi = SubtitleStyle.yaziRengi(prefs.subtitleColor),
            arkaAlfa = when {
                prefs.subtitlePos == Prefs.POS_COVER -> 255
                tv -> maxOf(alfa, 215)
                else -> alfa
            },
            arkaRenk = SubtitleStyle.arkaRenk(prefs.subtitleBgColor),
            kenarlik = tv || prefs.subtitleOutline || alfa == 0,
            kenarPayYuzde = if (tv) 6 else 0,
        )
    }

    private fun altyaziDegil(text: String): Boolean {
        val kucuk = text.lowercase()
        for (kalip in BLOCK_PHRASES) {
            if (kucuk.contains(kalip)) return true
        }

        val kelimeler = text.split(Regex("\\s+")).filter { it.isNotBlank() }

        val sikisik = kucuk.filter { !it.isWhitespace() }
        if (sikisik.contains("en•tr") || sikisik.contains("tr•en")) return true

        if (Regex("\\.(zip|apk|rar|pdf|mp4|png|jpg)\\b").containsMatchIn(kucuk)) return true
        if (Regex("\\d+[.,]?\\d*\\s?(mb|kb|gb)\\b").containsMatchIn(kucuk)) return true
        if (Regex("\\d+[.,]?\\d*\\s?(mn|sa|dk|sn|hr|min)\\b").findAll(kucuk).count() >= 2) return true

        for (k in text.split(Regex("\\s+"))) {
            if (k.length < 16) continue
            if (k.any { it.isDigit() } && k.any { it.isLetter() }) return true
        }

        if (kelimeler.size >= 3) {
            val kirinti = kelimeler.count { k ->
                val sade = k.lowercase().trim('.', ',', '!', '?', ':', ';', '"', '\'', '’', '-', '…')
                sade.length <= 2 && sade !in KISA_KELIMELER
            }
            if (kirinti >= 3 && kirinti * 2 >= kelimeler.size) return true
        }

        if (kelimeler.size < 5) return false

        for (k in kelimeler) {
            val sade = k.lowercase().trim('.', ',', '!', '?', ':', ';', '"', '\'')
            if (sade in SENTENCE_WORDS) return false
        }

        if (text.count { it == '.' || it == '!' || it == '?' } >= 2) return false

        val ozelAd = kelimeler.count { k ->
            k.length > 1 && k[0].isUpperCase() &&
                k.drop(1).all { it.isLowerCase() || it == '.' || it == '-' }
        }
        return ozelAd >= 5
    }

    private fun isControllerLabel(text: String): Boolean {
        val t = text.trim().trim('.', ',', ':', ';')
        if (t.uppercase() in UI_WORDS) return true
        if (t.length > 6) return false
        if (t.uppercase() in CONTROLLER_LABELS) return true
        if (t.all { it.isDigit() || it == 'm' || it == 'M' || it == ' ' }) return true
        return false
    }

    private fun splitSpeaker(text: String): Pair<String?, String> {
        val idx = text.indexOf(':')
        if (idx !in 1..24) return null to text
        val name = text.substring(0, idx).trim()
        val rest = text.substring(idx + 1).trim()
        if (rest.length < 2) return null to text
        if (name.any { !it.isLetter() && it != ' ' && it != '.' && it != '\'' && it != '-' }) {
            return null to text
        }
        return name to rest
    }

    private suspend fun fastTranslateKeepingName(source: String): String? {
        val (name, body) = splitSpeaker(source)
        val f = fast
        val ff = firefox
        val google = prefs.googleCeviri
        if (f == null && ff == null && !google) return null
        val translated = OfflineFix.translate(body) { parca ->
            val yerTutucu = YER_TUTUCU.findAll(parca).map { it.value }.toSet()
            val gSonuc = if (google && OfflineFix.gucluFn == null) GoogleCeviri.cevir(parca) else null
            if (gSonuc != null && yerTutucu.all { gSonuc.contains(it) }) {
                gSonuc
            } else {
                val ffSonuc = if (ff != null && ff.hazir) ff.cevir(parca) else null
                if (ffSonuc != null && yerTutucu.all { ffSonuc.contains(it) }) ffSonuc else f?.translate(parca)
            }
        } ?: return null
        if (translated.isBlank()) return null

        fun render(candidate: String): String =
            GameplayLogRepair299.repairTranslation(
                body,
                DialogueDisambiguation1038.repair(
                    body, AiGuard.hitapDuzelt(body, NameFix.koru(body, TurkishFix.duzelt(candidate)))
                )
            )
        var duzgun = render(translated)
        val issue = TranslationQualityGate.check(body, duzgun)
        if (ClauseRecovery1042.needsSecondAttempt(
                body, duzgun, issue == TranslationQualityGate.Problem.LOST_PROFANITY ||
                    issue == TranslationQualityGate.Problem.MISSING_DETAIL)) {
            val clauses = ClauseRecovery1042.clauses(body)
            if (clauses != null) {
                val separate = clauses.map { piece ->
                    SourceAwareDialogueFix.correct(piece) ?: fastTranslateKeepingName(piece)
                }
                if (separate.all { !it.isNullOrBlank() } &&
                    separate.indices.all { i ->
                        TranslationQualityGate.check(clauses[i], separate[i]!!) == null
                    }) {
                    val complete = separate.joinToString(" ") { it!! }
                    if (TranslationQualityGate.check(body, complete) == null) {
                        return if (name == null) complete else "$name: $complete"
                    }
                }
            }
        }
        if (issue == TranslationQualityGate.Problem.MISSING_QUESTION) {
            val questions = body.trim().split(Regex("""(?<=\?)\s+(?=[\p{Lu}\[])"""))
            if (questions.size == 2 && questions.all { it.endsWith('?') }) {
                val separate = questions.map { fastTranslateKeepingName(it) }
                if (separate.all { !it.isNullOrBlank() } &&
                    separate.indices.all { i -> TranslationQualityGate.check(questions[i], separate[i]!!) == null }) {
                    val complete = separate.joinToString(" ") { it!! }
                    return if (name == null) complete else "$name: $complete"
                }
            }
        }
        if (TranslationQualityGate.mustReject(issue)) {
            val ffAlternative = if (ff != null && ff.hazir) {
                try { ff.cevir(body) } catch (_: Exception) { null }
            } else null
            val localAlternative = if (ffAlternative == null ||
                TranslationQualityGate.mustReject(TranslationQualityGate.check(body, render(ffAlternative)))) {
                try { f?.translate(body) } catch (_: Exception) { null }
            } else null
            val rescue = listOfNotNull(ffAlternative, localAlternative)
                .map(::render)
                .firstOrNull { !TranslationQualityGate.mustReject(TranslationQualityGate.check(body, it)) &&
                    !it.trim().equals(body.trim(), ignoreCase = true) }
            if (rescue == null) return null
            duzgun = rescue
        } else if (issue != null && LiveEnginePolicy.secondOpinionForWarning(prefs.ceviriBicimi) &&
            ff != null && ff.hazir) {
            val alternative = try { ff.cevir(body) } catch (_: Exception) { null }
            duzgun = TranslationQualityGate.choose(body, duzgun, alternative?.let(::render))
        }
        if (name != null) OfflineFix.languageLabel(name)?.let { return "[$it] $duzgun" }
        return if (name == null) duzgun else "$name: $duzgun"
    }

    private fun kaynakDurumu(): String = try {
        val rt = Runtime.getRuntime()
        val javaMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val yerelMb = android.os.Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
        val pil = applicationContext.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val seviye = pil?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val olcek = pil?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
        val isi = (pil?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val dakika = (System.currentTimeMillis() - oturumBasi) / 60_000
        "KAYNAK: ${dakika} dk · bellek ${javaMb} MB (+${yerelMb} MB yerel) · pil %" +
            (if (seviye >= 0 && olcek > 0) seviye * 100 / olcek else -1) + " · ısı ${isi}°C" +
            (if (prefs.opusMtEnabled) " · OPUS kabul=${opusAccepted.get()}, yedek=${opusRejected.get()}" else "") +
            (if (prefs.deepLEnabled) " · DeepL kabul=${deepLAccepted.get()}, yedek=${deepLRejected.get()}" else "")
    } catch (t: Throwable) {
        "KAYNAK: ölçülemedi (${t.javaClass.simpleName})"
    }

    private val oturumBasi = System.currentTimeMillis()

    private fun clean(raw: String): String {
        val text = raw.replace('\u00a0', ' ').replace(Regex("\\s+"), " ").trim()
        if (text.count(Char::isLetter) < 2) return ""
        if (arayuzYazisi(text) || turkceYazi(text)) return ""
        return text
    }

    private val TURKCE_HARF = "çğışöüÇĞİŞÖÜ"

    private fun turkceYazi(s: String): Boolean {
        if (OfflineFix.isAlreadyTurkish(s)) return true
        return s.split(Regex("[^\\p{L}]+"))
            .any { k -> k.length >= 5 && k.any { it in TURKCE_HARF } }
    }

    private val TUS_UYARISI = Regex(
        "(?i)\\b(press|hold|tap|push)\\s+(?:and\\s+hold\\s+)?(?:the\\s+)?" +
            "([a-z]|[lr][123]|△|○|□|✕|circle|square|triangle|cross|touchpad|options)\\b"
    )

    private val TEK_HARF_SIMGE = Regex("(?<![\\p{L}'])[B-HJ-Z](?![\\p{L}'])")

    private fun arayuzYazisi(metin: String): Boolean {
        val s = metin.trim()
        if (s.isEmpty()) return true
        if (s.last() in ".!?…,:;\"'’") return false
        if (s.startsWith("[") || s.startsWith("(")) return false
        if (TUS_UYARISI.containsMatchIn(s)) return true
        if (TEK_HARF_SIMGE.findAll(s).count() >= 2) return true
        val kelimeler = s.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (SubtitleReadGuard299.shortSpokenLine(s)) return false
        if (kelimeler.size <= 2) return true
        val harfler = s.filter { it.isLetter() }
        if (kelimeler.size <= 4 && harfler.isNotEmpty() && harfler.all { it.isUpperCase() }) return true
        return false
    }

    private fun normalize(s: String): String = s.lowercase()
        .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
        .replace('â', 'a').replace('î', 'i').replace('û', 'u')
        .filter { it.isLetterOrDigit() }

    private val konusanEtiketi = Regex("^\\p{Lu}[\\p{L}'.]*(?: \\p{Lu}[\\p{L}'.]*)?:\\s*")

    private fun similar(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return a == b
        val ka = konusanEtiketi.replace(a, "")
        val kb = konusanEtiketi.replace(b, "")
        if ((ka != a || kb != b) && ka.isNotBlank() && kb.isNotBlank() && benzerMetin(ka, kb)) return true
        if (adEkliMi(a, b) || adEkliMi(b, a)) { adOgren(a, b); return true }
        if (ayniBasMi(a, b)) { adOgren(a, b); return true }
        return benzerMetin(a, b)
    }

    private val konusanAdlari = LinkedHashSet<String>()
    private val AKSAN = Regex("\\p{Mn}+")

    private fun aksansiz(s: String): String =
        AKSAN.replace(java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD), "")

    private fun adOgren(a: String, b: String) {
        val wa = a.trim().split(Regex("\\s+"))
        val wb = b.trim().split(Regex("\\s+"))
        val uzun = if (wa.size >= wb.size) wa else wb
        val kisa = if (wa.size >= wb.size) wb else wa
        val fark = uzun.size - kisa.size
        if (fark !in 1..4 || kisa.size < 2) return
        for (i in 0 until fark) {
            if (uzun[i].firstOrNull()?.isUpperCase() != true) return
            if (uzun[i].any { !it.isLetter() && it != '.' && it != '\'' }) return
        }
        val kalanMetin = uzun.subList(fark, uzun.size).joinToString(" ")
        val kisaMetin = kisa.joinToString(" ")
        if (normalize(kalanMetin) != normalize(kisaMetin) && !ortakBas(kalanMetin, kisaMetin)) return
        val ad = aksansiz(uzun.subList(0, fark).joinToString(" "))
        if (ad.length !in 2..32 || !GameplayLogRepair299.plausibleSpeakerName(ad)) return
        synchronized(konusanAdlari) {
            if (konusanAdlari.add(ad)) {
                log("KONUŞAN ADI ÖĞRENİLDİ: $ad")
                while (konusanAdlari.size > 20) {
                    konusanAdlari.iterator().let { if (it.hasNext()) { it.next(); it.remove() } }
                }
            }
        }
    }

    private fun adiAyir(text: String): String {
        if (text.isBlank() || text.contains(':')) return text
        val adlar = synchronized(konusanAdlari) { konusanAdlari.toList() }
        val duz = aksansiz(text)
        for (ad in adlar) {
            if (text.length <= ad.length + 2) continue
            if (!duz.startsWith(ad, ignoreCase = true)) continue
            if (duz.getOrNull(ad.length)?.isLetterOrDigit() == true) continue
            val kalan = text.substring(ad.length).trimStart(' ', ':', '-', '.', ',')
            if (kalan.length < 3) continue
            return if (prefs.showSpeaker) "$ad: $kalan" else kalan
        }
        return text
    }

    private fun ayniBasMi(a: String, b: String): Boolean {
        for (x in basAdaylari(a)) {
            for (y in basAdaylari(b)) {
                if (ortakBas(x, y)) return true
            }
        }
        return false
    }

    private fun basAdaylari(s: String): List<String> {
        val out = ArrayList<String>(5)
        out.add(s)
        val w = s.trim().split(Regex("\\s+"))
        for (n in 1..4) {
            if (n >= w.size) break
            if (w[n - 1].firstOrNull()?.isUpperCase() != true) break
            out.add(w.subList(n, w.size).joinToString(" "))
        }
        return out
    }

    private fun ortakBas(a: String, b: String): Boolean {
        val na = normalize(a)
        val nb = normalize(b)
        val kisa = minOf(na.length, nb.length)
        if (kisa < ORTAK_BAS_EN_AZ) return false
        var i = 0
        while (i < kisa && na[i] == nb[i]) i++
        if (i >= ORTAK_BAS_MUTLAK) return true
        return i >= ORTAK_BAS_EN_AZ && i >= kisa * ORTAK_BAS_ORAN
    }

    private fun adEkliMi(kisa: String, uzun: String): Boolean {
        val nk = normalize(kisa)
        val nu = normalize(uzun)
        if (nk.length < 12 || nu.length <= nk.length) return false
        if (!nu.endsWith(nk)) return false
        val fazla = nu.length - nk.length
        if (fazla > nk.length) return false
        var birikim = 0
        var adet = 0
        for (w in uzun.trim().split(Regex("\\s+"))) {
            if (birikim >= fazla) break
            if (w.firstOrNull()?.isUpperCase() != true) return false
            birikim += normalize(w).length
            adet++
            if (adet > 4) return false
        }
        return adet in 1..4 && birikim == fazla
    }

    private fun benzerMetin(a: String, b: String): Boolean {
        val na = normalize(a)
        val nb = normalize(b)
        if (na == nb) return true
        if (na.isEmpty() || nb.isEmpty()) return false
        val longer = if (na.length >= nb.length) na else nb
        val shorter = if (na.length >= nb.length) nb else na
        if (shorter.length >= 20 && longer.startsWith(shorter)) return true
        if (shorter.length.toFloat() / longer.length < 0.8f) return false
        val mesafe = levenshtein(shorter, longer)
        if (longer.length >= 8 && mesafe <= maxOf(2, (0.14f * longer.length).toInt())) return true
        return mesafe.toFloat() / longer.length <= 0.14f
    }

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun stopEverything() {
        running = false
        pipelineOn.set(false)
        try {
            scope.cancel()
        } catch (_: Throwable) {
        }
        subtitleGeneration.invalidate()
        releaseDisplay()
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        fast?.close()
        fast = null
        firefox?.birak()
        firefox = null
        opusMt?.close()
        opusMt = null
        GoogleCeviri.trace = null
        OfflineFix.gucluFn = null
        store = null
        overlay.clearLabels()
        overlay.setSubtitle(null, 0)
        overlay.hide()
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
        recognizerClosed = true
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseDisplay()
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        yiginiBosalt()
        overlay.hide()
        super.onDestroy()
    }
}