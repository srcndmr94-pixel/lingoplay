package com.example.altyazi

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** Ordered fallback, with no rewriting and no second publication. */
object SimpleLiveTranslation {
    data class Engine(val name: String, val translate: suspend (String, String) -> String?)
    data class Result(val engine: String, val text: String)

    suspend fun translate(
        source: String,
        context: String,
        engines: List<Engine>,
        valid: (String, String) -> Boolean,
        failed: (String) -> Unit = {},
    ): Result? {
        for (engine in engines) {
            currentCoroutineContext().ensureActive()
            val text = try { engine.translate(source, context)?.trim() }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { null }
            currentCoroutineContext().ensureActive()
            if (!text.isNullOrEmpty() && !text.equals(source.trim(), ignoreCase = true) && valid(source, text)) {
                return Result(engine.name, text)
            }
            failed(engine.name)
        }
        return null
    }
}

/** Only preceding English lines; each request gets its own immutable snapshot. */
class LiveContextHistory {
    private val lines = ArrayDeque<String>()
    private var lastAt = 0L
    @Synchronized fun accept(source: String, now: Long): String {
        if (now - lastAt > 30_000L || now < lastAt) lines.clear()
        val context = (if (lines.lastOrNull() == source) lines.dropLast(1) else lines.toList()).joinToString("\n")
        if (lines.lastOrNull() != source) {
            lines.addLast(source)
            while (lines.size > 3) lines.removeFirst()
        }
        lastAt = now
        return context
    }
    @Synchronized fun clear() { lines.clear(); lastAt = 0L }
}
