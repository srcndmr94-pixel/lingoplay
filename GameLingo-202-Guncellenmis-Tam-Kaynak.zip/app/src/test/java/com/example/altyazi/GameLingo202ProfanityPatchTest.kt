package com.example.altyazi

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GameLingo202ProfanityPatchTest {
    @Test fun keepLongDialogIntact() {
        val result = Slang.restoreProfanityContext(
            "Fuck off, leave my family alone!", "Defol, ailemi rahat bırak!"
        )
        assertTrue(result.contains("ailemi rahat bırak"))
    }

    @Test fun preserveShortStrongAddress() {
        assertEquals("Siktir git.", Slang.restoreProfanityContext("Fuck off!", "Defol!"))
        assertEquals("Bu ne lan?", Slang.restoreProfanityContext("What the fuck?", "Ne oluyor?"))
    }

    @Test fun avoidInventedToneForOtherSentences() {
        assertEquals("Ne yapıyorsun?", Slang.restoreProfanityContext(
            "What the fuck are you doing?", "Ne yapıyorsun?"))
    }

    @Test fun repairLiteralMisinterpretation() {
        assertEquals("Bu saçmalık.", Slang.restoreProfanityContext("That's bullshit.", "Bu boğa boku."))
    }

    @Test fun safetyCheckPreserved() {
        assertTrue(MeaningSafety.lostContextualProfanity("Fuck off!", "Lütfen git."))
        assertFalse(MeaningSafety.lostContextualProfanity("Fuck off!", "Siktir git."))
    }
}
