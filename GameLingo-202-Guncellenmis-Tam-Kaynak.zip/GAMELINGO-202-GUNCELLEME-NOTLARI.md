# GameLingo 202 — kullanıcı dosyalarıyla kaynak güncellemesi

Temel: `GameLingo-202-Kaynak.zip` (tam Android kaynak projesi).
Güncellenenler: `CaptureService.kt`, `Overlay.kt`, `MeaningSafety.kt`, `Slang.kt`.
Kullanıcı tarafından sağlanan 4 dosya, paket adı `com.example.altyazi` korunarak kaynak ağacındaki aynı dosyaların üzerine uygulandı.

- CaptureService: mevcut motor önceliği **DeepL → OPUS-MT → Google → Firefox → ML Kit** korunuyor; motor çağrı süreleri, OCR onarımı ve altyazı akışı kullanıcının gönderdiği koda göre güncellendi.
- Overlay: yalnızca `Prefs.POS_COVER` modunda kaynak İngilizce yazıyı örten konumlama uygulanıyor.
- MeaningSafety: kısa küfürlü ifadelerde sansürü saptayan koruma eklendi.
- Slang: argo sözlüğü, koruma ve çeviri düzeltme işlevleri eklendi. Önemli düzeltme: `Fuck off, ...` gibi uzun satırların tümünü `Siktir.` ile değiştiren kural güvenli tam eşleşmeye daraltıldı.
- TextFix.kt, OcrSozluk.kt, SubtitleReadGuard299.kt, ClauseRecovery1042.kt dahil diğer mevcut kodlar korundu.
- `app/src/test/java/com/example/altyazi/GameLingo202ProfanityPatchTest.kt` regresyon testi eklendi.

**Sınır:** Android/Gradle SDK tabanlı APK derlemesi ve fiziksel cihaz testi bu ortamda yapılamadı. Kotlin saf işlev testleri yerel `kotlinc` ile ayrıca kontrol edilir; bu bir APK değildir.
Sürüm numarası, paket kimliği, imza ayarları ve kullanıcı verileriyle ilgili yapılandırma değiştirilmedi.
