package com.example.altyazi

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display

/**
 * TV modu: telefon kabloyla (USB-C → HDMI) TV'ye bağlıyken altyazı büyük ekrana göre ayarlanır.
 * Kablo bağlıyken TV telefonun ekranını birebir gösterir; TV modu ayrı bir ekran değil,
 * altyazının (yazı boyutu, kutu genişliği, kontrast) 2-3 metreden okunacak hâlidir.
 */
object TvMode {

    /** Harici bir ekran (TV/monitör) bağlı mı? Kendi yakalama ekranımız ("altyazi") sayılmaz. */
    fun externalDisplayConnected(context: Context): Boolean = try {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).any {
            it.displayId != Display.DEFAULT_DISPLAY && it.name != "altyazi"
        }
    } catch (_: Throwable) {
        false
    }

    /**
     * Otomatik geçiş: TV bağlanınca TV modunu açar, kablo çıkınca (otomatik açılmışsa) kapatır.
     * Kullanıcı TV bağlıyken elle "Telefon"u seçtiyse, kablo çıkana kadar zorlamaz.
     * Bir şey değiştiyse true döner.
     */
    fun autoUpdate(context: Context, prefs: Prefs): Boolean {
        val now = State(prefs.tvMode, prefs.tvAuto, prefs.tvAutoOn, prefs.tvAutoSuppressed)
        val next = decide(externalDisplayConnected(context), now)
        if (next == now) return false
        prefs.tvMode = next.tvMode
        prefs.tvAutoOn = next.autoOn
        prefs.tvAutoSuppressed = next.suppressed
        return next.tvMode != now.tvMode
    }

    data class State(val tvMode: Boolean, val auto: Boolean, val autoOn: Boolean, val suppressed: Boolean)

    /** Saf karar fonksiyonu (test edilebilir): bağlantı durumuna göre yeni TV durumu. */
    fun decide(connected: Boolean, s: State): State {
        if (!connected) {
            return if (s.tvMode && s.autoOn) s.copy(tvMode = false, autoOn = false, suppressed = false)
            else s.copy(suppressed = false)
        }
        if (s.auto && !s.tvMode && !s.suppressed) return s.copy(tvMode = true, autoOn = true)
        return s
    }

    /** Kullanıcı elle seçti. */
    fun setManual(context: Context, prefs: Prefs, tv: Boolean) {
        prefs.tvMode = tv
        prefs.tvAutoOn = false
        prefs.tvAutoSuppressed = !tv && externalDisplayConnected(context)
    }

    const val GUIDE_TITLE = "TV ile kullanım"

    val GUIDE: String = """
GEREKENLER
• Üzerinde "DP Alt Mode" ya da "video çıkışı" yazan USB-C → HDMI adaptör. Şarj girişi (PD) olan model önerilir; uzun oyunda pil bitmez.
• HDMI kablo ve TV.
• PS5 için: telefonda Chiaki-Up (PS Remote Play ekran kaydını engellediği için çeviri onunla çalışmaz).
• DualSense kol (Bluetooth ile telefona bağlanır).

BAĞLANTI
1. Adaptörü telefona, HDMI kabloyu TV'ye tak. TV'de o HDMI girişini seç.
2. Telefonda "Harici ekrana yansıtılsın mı?" sorusuna "Yansıt" de.
3. GameLingo'yu aç: üstte "TV" kendiliğinden seçilir (seçilmediyse dokun).
4. Çeviriyi başlat'a bas, ekran kaydına izin ver.
5. Chiaki-Up'ı aç, PS5'e bağlan, telefonu yatay tut.

TV MODU NE YAPAR
• Altyazı yaklaşık 1,5 kat büyür, kutu genişler, arka plan koyulaşır.
• Kutu TV kenarlarındaki kesilme payından uzak durur.
• Kablo çıkınca kendiliğinden Telefon moduna döner.

İYİ GÖRÜNTÜ İÇİN
• PS5 mümkünse kabloyla modeme bağlı olsun, telefon 5 GHz Wi-Fi'ye.
• Pil tasarrufu kapalı olsun; açıkken çeviri yavaşlayabilir.
• Yazı yine küçük gelirse Görünüm'den yazı boyutunu büyüt.
• TV'de kenarlarda ince siyah şerit normaldir (telefon 20:9, TV 16:9).

SORUN ÇIKARSA
• TV'de görüntü yok: adaptör video çıkışını desteklemiyordur (DP Alt Mode yazmalı).
• Oyun ekranı siyah, altyazı okunmuyor: PS Remote Play kullanıyorsundur; Chiaki-Up'a geç.
• Netflix / Disney+ siyah: kopya koruması; bu uygulamalarda çeviri çalışmaz.
• Altyazı hiç çıkmıyor: Ayarlar > Altyazı alanı'ndan bölgeyi telefon ekranına göre seç.
""".trim()
}
