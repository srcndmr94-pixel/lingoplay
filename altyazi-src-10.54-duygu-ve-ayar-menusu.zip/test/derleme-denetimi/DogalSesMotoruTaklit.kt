package com.example.altyazi
/** YALNIZ DERLEME DENETIMI: gercek DogalSesMotoru'nun disa acik yuzu. */
class DogalSesMotoru(
    private val log: (String) -> Unit,
    private val yedekOku: (String, String?, Int) -> Unit,
) {
    fun baslat() {}
    fun oku(metin: String, konusan: String?, cinsiyet: Int): Boolean = false
    fun sus() {}
    fun kapat() {}
}
