package com.example.altyazi

import android.app.Activity
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView

/** SALT DERLEME DENETIMI: MainActivity'nin ses fonksiyonlari. */
class MainActivitySesDenetim : Activity() {

    private val prefs = Prefs(this)
    private val ui = Handler(Looper.getMainLooper())
    private val SES_MIN = 50
    private val SES_DENEME_ARASI = 2600L
    private val MIKROFON_IZNI = 13

    private lateinit var tvSesDurum: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvSesHiz: TextView
    private lateinit var tvSesTon: TextView
    private lateinit var sbSesHiz: SeekBar
    private lateinit var sbSesTon: SeekBar
    private lateinit var boxSesSecim: View
    private lateinit var spSesErkek: Spinner
    private lateinit var spSesKadin: Spinner
    private lateinit var spSesVarsayilan: Spinner
    private lateinit var cbSesCinsiyet: CheckBox
    private lateinit var cbSesKarakter: CheckBox
    private lateinit var cbSesInternet: CheckBox
    private lateinit var cbSesDogalGenAi: CheckBox
    private lateinit var cbSesCanliAlgila: CheckBox
    private lateinit var btnSesDene: Button

    private var sesDeneme: SesliOku? = null
    private var bulunanSesler: List<SesliOku.SesBilgi> = emptyList()
    private var sesOlcumleri: List<SesliOku.SesOlcumu> = emptyList()
    private var sesSpinnerKuruluyor = false

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIKROFON_IZNI &&
            grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.sesCanliAlgila = false
            if (::cbSesCanliAlgila.isInitialized) cbSesCanliAlgila.isChecked = false
            tvStatus.text = "Ses izni verilmedi; ses algılama kapatıldı. " +
                "Altyazıyı normal başlatabilirsiniz."
        }
    }

    private fun sesMotoru(sonra: (SesliOku) -> Unit) {
        val mevcut = sesDeneme
        if (mevcut != null && mevcut.hazirMi()) {
            sesAyarlariniUygula(mevcut)
            sonra(mevcut)
            return
        }
        if (mevcut != null) return   // açılış sürüyor, ikinci motor kurma
        tvSesDurum.text = "Konuşma motoru açılıyor…"
        val yeni = SesliOku(this)
        sesDeneme = yeni
        sesAyarlariniUygula(yeni)
        yeni.baslat { ok, mesaj ->
            tvSesDurum.text = mesaj
            if (ok) sonra(yeni)
        }
    }

    private fun sesAyarlariniUygula(s: SesliOku) {
        prefs.sesHiz = sbSesHiz.progress + SES_MIN
        prefs.sesTon = sbSesTon.progress + SES_MIN
        s.hiz = prefs.sesHiz / 100f
        s.ton = prefs.sesTon / 100f
        s.adiAtla = prefs.showSpeaker
        s.cinsiyetAyrimi = cbSesCinsiyet.isChecked
        s.karakterAyrimi = cbSesKarakter.isChecked
        s.erkekSesAdi = prefs.sesErkekAdi
        s.kadinSesAdi = prefs.sesKadinAdi
        s.internetSesi = cbSesInternet.isChecked
        s.havuz = SesHavuzu.oku(prefs.sesHavuzu)
        s.varsayilanSesAdi = prefs.sesVarsayilanAdi
        s.dogalSesAcik = cbSesDogalGenAi.isChecked
    }

    private fun sesleriTara() {
        tvSesDurum.text = "Sesler taranıyor, her ses ölçülüyor…"
        sesMotoru { s ->
            bulunanSesler = s.bulunanSesler()
            if (bulunanSesler.isEmpty()) {
                boxSesSecim.visibility = View.GONE
                tvSesDurum.text = "Konuşma motoru ayrı ses listesi vermiyor. " +
                    "Erkek/kadın ayrımı perdeyle yapılacak: erkek kalın, kadın ince."
                return@sesMotoru
            }
            // Her sesi sessizce dosyaya okutup perdesini ölçer; hoparlörden
            // ses çıkmaz. Birkaç saniye sürebilir.
            s.seslerIncele(
                onIlerleme = { kacinci, toplam ->
                    tvSesDurum.text = "Sesler ölçülüyor… ($kacinci/$toplam)"
                },
            ) { olcumler ->
                sesOlcumleri = olcumler
                // Havuz kaydedilir: çeviri servisi yeniden ölçmesin.
                prefs.sesHavuzu = SesHavuzu.yaz(
                    olcumler.map {
                        SesHavuzu.Kayit(it.ses.ad, it.hz, it.cinsiyet, it.ses.agGerekir)
                    }
                )
                sesleriAta(olcumler)
            }
        }
    }

    private fun sesleriAta(olcumler: List<SesliOku.SesOlcumu>) {
        val olculen = olcumler.filter { it.olculdu }
        val erkekler = olculen.filter { it.cinsiyet == SesPerdeOlcer.ERKEK }
        val kadinlar = olculen.filter { it.cinsiyet == SesPerdeOlcer.KADIN }

        var erkekAd = erkekler.minByOrNull { it.hz }?.ses?.ad ?: ""
        var kadinAd = kadinlar.maxByOrNull { it.hz }?.ses?.ad ?: ""

        if ((erkekAd.isEmpty() || kadinAd.isEmpty()) && olculen.size >= 2) {
            val enKalin = olculen.minByOrNull { it.hz }
            val enInce = olculen.maxByOrNull { it.hz }
            if (enKalin != null && enInce != null && enKalin.ses.ad != enInce.ses.ad) {
                if (erkekAd.isEmpty()) erkekAd = enKalin.ses.ad
                if (kadinAd.isEmpty()) kadinAd = enInce.ses.ad
            }
        }
        // Aynı ses ikisine birden atanmasın: o durumda ayrım perdeyle yapılır.
        if (erkekAd.isNotEmpty() && erkekAd == kadinAd) kadinAd = ""

        prefs.sesErkekAdi = erkekAd
        prefs.sesKadinAdi = kadinAd
        // VARSAYILAN SES: konuşan adı olmayan altyazılarda her replik bununla
        // okunur. Seçilmemişse erkek sesine kurulur — önceki sürümde listenin
        // ilk sesine düşüyordu ve 19 sesin 15'i ince olduğu için her şey
        // kadın sesiyle okunuyordu.
        if (prefs.sesVarsayilanAdi.isBlank() ||
            olcumler.none { it.ses.ad == prefs.sesVarsayilanAdi }
        ) {
            prefs.sesVarsayilanAdi = when {
                erkekAd.isNotEmpty() -> erkekAd
                kadinAd.isNotEmpty() -> kadinAd
                else -> olcumler.firstOrNull { it.olculdu }?.ses?.ad ?: ""
            }
        }

        sesSpinnerKuruluyor = true
        val satirlar = ArrayList<String>()
        satirlar.add("En iyi ses (kendiliğinden)")
        for (o in olcumler) satirlar.add("${o.ses.etiket} · ${o.aciklama}")
        spSesErkek.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, satirlar
        )
        spSesKadin.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, satirlar
        )
        spSesVarsayilan.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, satirlar
        )
        spSesErkek.setSelection(sesSirasi(erkekAd))
        spSesKadin.setSelection(sesSirasi(kadinAd))
        spSesVarsayilan.setSelection(sesSirasi(prefs.sesVarsayilanAdi))
        spSesErkek.onItemSelectedListener = sesSecildi(true)
        spSesKadin.onItemSelectedListener = sesSecildi(false)
        spSesVarsayilan.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (sesSpinnerKuruluyor) return
                prefs.sesVarsayilanAdi =
                    if (pos <= 0) "" else bulunanSesler.getOrNull(pos - 1)?.ad ?: ""
                sesDeneme?.let { sesAyarlariniUygula(it) }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        boxSesSecim.visibility = View.VISIBLE
        // Yerleşimden sonra gelen ilk seçim olayları geçsin, sonra dinlemeye
        // başla: kayıtlı seçimler ezilmesin.
        ui.post { sesSpinnerKuruluyor = false }
        sesDeneme?.let { sesAyarlariniUygula(it) }

        // Kaç karakterin ayrı sesle konuşabileceğini söyle: asıl merak
        // edilen bu. Havuzda iki ses varsa iki erkek ayrı duyulur.
        val mevcutAdlar = bulunanSesler.map { it.ad }.toSet()
        val kayitlar = olcumler.map {
            SesHavuzu.Kayit(it.ses.ad, it.hz, it.cinsiyet, it.ses.agGerekir)
        }
        val internet = cbSesInternet.isChecked
        val erkekHavuz = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.ERKEK, mevcutAdlar, internet)
        val kadinHavuz = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.KADIN, mevcutAdlar, internet)

        tvSesDurum.text = when {
            erkekHavuz.size >= 2 || kadinHavuz.size >= 2 ->
                "${bulunanSesler.size} ses ölçüldü: ${erkekHavuz.size} erkek, " +
                    "${kadinHavuz.size} kadın sesi. Her karaktere ayrı bir gerçek " +
                    "ses verilecek; perdeyle oynanmayacak."
            erkekHavuz.isNotEmpty() && kadinHavuz.isNotEmpty() ->
                "${bulunanSesler.size} ses ölçüldü: birer erkek ve kadın sesi bulundu. " +
                    "Aynı cinsiyetten karakterler ton farkıyla ayrılacak."
            olculen.isEmpty() ->
                "${bulunanSesler.size} ses bulundu ama perdeleri ölçülemedi. " +
                    "Aşağıdan dinleyerek kendiniz seçebilirsiniz."
            else ->
                "${bulunanSesler.size} ses ölçüldü ama ayrı bir erkek ve kadın sesi " +
                    "seçilemedi. Ayrım perdeyle yapılacak: erkek kalın, kadın ince."
        }
    }

    private fun sesSirasi(ad: String): Int {
        if (ad.isBlank()) return 0
        val i = bulunanSesler.indexOfFirst { it.ad == ad }
        return if (i < 0) 0 else i + 1
    }

    private fun sesSecildi(erkek: Boolean) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
            if (sesSpinnerKuruluyor) return
            val ad = if (pos <= 0) "" else bulunanSesler.getOrNull(pos - 1)?.ad ?: ""
            if (erkek) prefs.sesErkekAdi = ad else prefs.sesKadinAdi = ad
            sesDeneme?.let { sesAyarlariniUygula(it) }
        }

        override fun onNothingSelected(p: AdapterView<*>?) {}
    }

    private fun sesCinsiyetDene(erkek: Boolean) {
        sesMotoru { s ->
            s.sus()
            // İKİ FARKLI karakter okunur: karakter ayrımı açıkken aradaki
            // ton farkı burada duyulsun, oyunda sürpriz olmasın.
            if (erkek) {
                s.oku("James: Arabaya bin, hemen gidiyoruz.", "James")
                sesGecikmeli { s.oku("Arthur: Sakin ol, bir planım var.", "Arthur") }
            } else {
                s.oku("Lucia: Buradan çıkmamız lazım, beni dinle.", "Lucia")
                sesGecikmeli { s.oku("Martha: Kapıyı açık bıraktım.", "Martha") }
            }
        }
    }

    private fun sesGecikmeli(islem: () -> Unit) {
        ui.postDelayed({ if (!isFinishing && !isDestroyed) islem() }, SES_DENEME_ARASI)
    }

    private fun sesiDene() {
        sesMotoru { s ->
            s.sus()
            s.oku("Lan buraya gel, şu kapıyı açmamız lazım.")
        }
    }

    private fun sesEtiketleri() {
        if (!::tvSesHiz.isInitialized) return
        tvSesHiz.text = "Konuşma hızı · %${sbSesHiz.progress + SES_MIN}"
        tvSesTon.text = "Ses tonu · %${sbSesTon.progress + SES_MIN}" +
            when {
                sbSesTon.progress + SES_MIN < 90 -> " (kalın)"
                sbSesTon.progress + SES_MIN > 110 -> " (ince)"
                else -> ""
            }
    }
}
