package android.os;
public class Build {
    public static class VERSION { public static final int SDK_INT = 34; }
    public static class VERSION_CODES { public static final int Q = 29, TIRAMISU = 33; }
}
