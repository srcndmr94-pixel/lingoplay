package android.os;
public class Bundle {
    public void putFloat(String key, float value) {}
    public void putInt(String key, int value) {}
    public void putString(String key, String value) {}
    public float getFloat(String key, float def) { return def; }
}
