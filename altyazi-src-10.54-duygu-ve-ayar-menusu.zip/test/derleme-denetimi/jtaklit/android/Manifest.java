package android;
public final class Manifest {
    public static final class permission {
        public static final String RECORD_AUDIO = "android.permission.RECORD_AUDIO";
        public static final String POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS";
    }
}
