package android.media;
import android.media.projection.MediaProjection;
public class AudioPlaybackCaptureConfiguration {
    public static class Builder {
        public Builder(MediaProjection p) {}
        public Builder addMatchingUsage(int usage) { return this; }
        public Builder excludeUid(int uid) { return this; }
        public AudioPlaybackCaptureConfiguration build() { return new AudioPlaybackCaptureConfiguration(); }
    }
}
