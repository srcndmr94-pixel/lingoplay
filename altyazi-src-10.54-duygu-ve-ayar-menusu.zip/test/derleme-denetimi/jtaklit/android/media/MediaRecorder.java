package android.media;
public class MediaRecorder {
    public static class AudioSource { public static final int MIC = 1, VOICE_RECOGNITION = 6; }
}
