package android.view;
public class ViewGroup extends View {
    public static class LayoutParams {
        public static final int MATCH_PARENT = -1;
        public static final int WRAP_CONTENT = -2;
        public int width, height;
        public LayoutParams(int w, int h) { width = w; height = h; }
    }
    public static class MarginLayoutParams extends LayoutParams {
        public int topMargin, bottomMargin, leftMargin, rightMargin;
        public MarginLayoutParams(int w, int h) { super(w, h); }
    }
    public void addView(View child) {}
    public void removeAllViews() {}
    public int getChildCount() { return 0; }
}
