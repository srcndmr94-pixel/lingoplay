package android.view;
public class View {
    public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;
    public void setVisibility(int v) {}
    public int getVisibility() { return 0; }
    public void setOnClickListener(OnClickListener l) {}
    public interface OnClickListener { void onClick(View v); }
    public void setLayoutParams(ViewGroup.LayoutParams p) {}
    public ViewGroup.LayoutParams getLayoutParams() { return null; }
    public int getTop() { return 0; }
    public void setClickable(boolean b) {}
    public void setFocusable(boolean b) {}
    public void setPadding(int l, int t, int r, int b) {}
    public void setOnFocusChangeListener(OnFocusChangeListener l) {}
    public interface OnFocusChangeListener { void onFocusChange(View v, boolean hasFocus); }
}
