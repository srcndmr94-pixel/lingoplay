package android.widget;
public class EditText extends TextView {
    public EditText(android.content.Context c) {}
    public void setInputType(int type) {}
    public int getInputType() { return 0; }
}
