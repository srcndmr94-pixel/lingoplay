package android.widget;
public class ScrollView extends android.view.ViewGroup {
    public ScrollView(android.content.Context c) {}
    public void smoothScrollTo(int x, int y) {}
    public boolean post(Runnable r) { return true; }
}
