package android.widget;
public class LinearLayout extends android.view.ViewGroup {
    public static final int HORIZONTAL = 0, VERTICAL = 1;
    public LinearLayout(android.content.Context c) {}
    public void setOrientation(int o) {}
    public static class LayoutParams extends android.view.ViewGroup.MarginLayoutParams {
        public static final int MATCH_PARENT = -1;
        public static final int WRAP_CONTENT = -2;
        public float weight;
        public LayoutParams(int w, int h) { super(w, h); }
    }
}
