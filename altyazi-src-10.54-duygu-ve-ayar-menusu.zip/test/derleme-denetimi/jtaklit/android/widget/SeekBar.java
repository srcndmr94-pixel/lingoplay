package android.widget;
public class SeekBar extends android.view.View {
    public SeekBar(android.content.Context c) {}
    public void setMax(int m) {}
    public int getProgress() { return 0; }
    public void setProgress(int p) {}
    public int getMax() { return 100; }
    public void setOnSeekBarChangeListener(OnSeekBarChangeListener l) {}
    public interface OnSeekBarChangeListener {
        void onProgressChanged(SeekBar sb, int progress, boolean fromUser);
        void onStartTrackingTouch(SeekBar sb);
        void onStopTrackingTouch(SeekBar sb);
    }
}
