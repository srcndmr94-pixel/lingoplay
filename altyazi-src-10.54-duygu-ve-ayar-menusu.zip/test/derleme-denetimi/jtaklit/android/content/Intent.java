package android.content;
public class Intent {
    public Intent(Context c, Class<?> cls) {}
    public Intent putExtra(String name, boolean value) { return this; }
    public boolean getBooleanExtra(String name, boolean def) { return def; }
}
