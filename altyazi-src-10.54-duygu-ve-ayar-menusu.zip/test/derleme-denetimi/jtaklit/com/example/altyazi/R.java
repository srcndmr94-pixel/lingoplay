package com.example.altyazi;
public final class R {
    public static final class id {
        public static final int ayarBaslikCubugu = 1000;
        public static final int ayarMenu = 1001;
        public static final int ayarOzet1 = 1002;
        public static final int ayarOzet2 = 1003;
        public static final int ayarOzet3 = 1004;
        public static final int ayarOzet4 = 1005;
        public static final int ayarOzet5 = 1006;
        public static final int ayarOzet6 = 1007;
        public static final int ayarOzet7 = 1008;
        public static final int ayarOzet8 = 1009;
        public static final int ayarSatir1 = 1010;
        public static final int ayarSatir2 = 1011;
        public static final int ayarSatir3 = 1012;
        public static final int ayarSatir4 = 1013;
        public static final int ayarSatir5 = 1014;
        public static final int ayarSatir6 = 1015;
        public static final int ayarSatir7 = 1016;
        public static final int ayarSatir8 = 1017;
        public static final int boxDuygu = 1018;
        public static final int boxOzel = 1019;
        public static final int btnAyarGeri = 1020;
        public static final int btnDuyguDene = 1021;
        public static final int btnOzelAktar = 1022;
        public static final int btnOzelSablon = 1023;
        public static final int btnOzelSil = 1024;
        public static final int cbDuygu = 1025;
        public static final int cbDuyguCumle = 1026;
        public static final int cbDuyguTr = 1027;
        public static final int cbDuyguUnlem = 1028;
        public static final int navHelp = 1029;
        public static final int navHistory = 1030;
        public static final int navHome = 1031;
        public static final int navSettings = 1032;
        public static final int rbDuyguAtla = 1033;
        public static final int rbDuyguCanli = 1034;
        public static final int rbDuyguKisik = 1035;
        public static final int rgDuyguNot = 1036;
        public static final int sbDuyguSiddet = 1037;
        public static final int scroll = 1038;
        public static final int secAdvanced = 1039;
        public static final int secAi = 1040;
        public static final int secContent = 1041;
        public static final int secDuygu = 1042;
        public static final int secLook = 1043;
        public static final int secOzel = 1044;
        public static final int secRegion = 1045;
        public static final int secSes = 1046;
        public static final int secSettings = 1047;
        public static final int segMode = 1048;
        public static final int tileAi = 1049;
        public static final int tileDict = 1050;
        public static final int tileLook = 1051;
        public static final int tileRegion = 1052;
        public static final int tvAyarBaslik = 1053;
        public static final int tvDuyguDurum = 1054;
        public static final int tvDuyguOrnek = 1055;
        public static final int tvDuyguSiddet = 1056;
        public static final int tvOzelDurum = 1057;
    }
    public static final class layout {
        public static final int activity_main = 1;
    }
    public static final class color {
        public static final int lingo_ok = 1, lingo_warn = 2, lingo_bad = 3;
    }
}
