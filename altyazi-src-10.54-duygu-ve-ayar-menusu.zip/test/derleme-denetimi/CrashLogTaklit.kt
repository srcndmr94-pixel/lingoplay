package com.example.altyazi

import android.content.Context

/** YALNIZ DERLEME DENETIMI: gercek CrashLog'un disa acik yuzu. */
object CrashLog {
    fun note(context: Context, etiket: String, t: Throwable) {}
    fun read(context: Context): String? = null
}
