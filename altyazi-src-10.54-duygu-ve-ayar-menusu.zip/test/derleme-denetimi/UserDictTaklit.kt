package com.example.altyazi

import android.content.Context

/** YALNIZ DERLEME DENETIMI. */
object UserDict {
    fun apply(context: Context) {}
}
