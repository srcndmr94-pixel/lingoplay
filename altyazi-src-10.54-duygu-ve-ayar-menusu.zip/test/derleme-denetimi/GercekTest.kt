import com.example.altyazi.*
import java.io.File
import java.io.DataOutputStream
import java.io.FileOutputStream
import java.io.BufferedOutputStream
import kotlin.math.*
import kotlin.random.Random

/**
 * GERCEK KOTLIN KODUNU calistiran test.
 * Onceki testler Java kopyalarini sinavdan geciriyordu; bu dogrudan
 * uygulamanin kendi siniflarini cagiriyor.
 */

var gecti = 0
var kaldi = 0
fun dogru(ad: String, ok: Boolean, ek: String = "") {
    if (ok) { gecti++; println("  OK   $ad${if (ek.isEmpty()) "" else "  $ek"}") }
    else { kaldi++; println("  HATA $ad  $ek") }
}

// ---- gercekci sentetik konusma (formant suzgecli glottal darbe)
fun formant(x: FloatArray, sr: Int, f: Double, bw: Double): FloatArray {
    val r = exp(-PI * bw / sr)
    val c = 2 * r * cos(2 * PI * f / sr)
    val y = FloatArray(x.size)
    var y1 = 0.0; var y2 = 0.0
    for (i in x.indices) {
        val v = x[i] + c * y1 - r * r * y2
        y[i] = v.toFloat(); y2 = y1; y1 = v
    }
    return y
}

fun ses(f0: Double, sr: Int, saniye: Double, formantlar: DoubleArray, gurultu: Double, tohum: Int): FloatArray {
    val rnd = Random(tohum)
    val n = (sr * saniye).toInt()
    val darbe = FloatArray(n)
    val periyot = sr / f0
    var sonraki = 0.0
    for (i in 0 until n) {
        if (i >= sonraki) { darbe[i] = 1f; sonraki += periyot }
        darbe[i] += ((rnd.nextDouble() * 2 - 1) * gurultu).toFloat()
    }
    var y = darbe
    for (f in formantlar) y = formant(y, sr, f, 90.0)
    var en = 0f
    for (v in y) en = max(en, abs(v))
    if (en > 0) for (i in y.indices) y[i] = y[i] / en * 0.7f
    return y
}

val ERKEK_F = doubleArrayOf(500.0, 1500.0, 2500.0)
val KADIN_F = doubleArrayOf(650.0, 1900.0, 2900.0)

fun leInt(o: DataOutputStream, v: Int) {
    o.write(v and 0xFF); o.write((v shr 8) and 0xFF); o.write((v shr 16) and 0xFF); o.write((v shr 24) and 0xFF)
}
fun leShort(o: DataOutputStream, v: Int) { o.write(v and 0xFF); o.write((v shr 8) and 0xFF) }

fun wavYaz(f: File, x: FloatArray, sr: Int, kanal: Int) {
    val veriBoyu = x.size * 2 * kanal
    DataOutputStream(BufferedOutputStream(FileOutputStream(f))).use { o ->
        o.writeBytes("RIFF"); leInt(o, 36 + veriBoyu); o.writeBytes("WAVE")
        o.writeBytes("fmt "); leInt(o, 16); leShort(o, 1); leShort(o, kanal)
        leInt(o, sr); leInt(o, sr * kanal * 2); leShort(o, kanal * 2); leShort(o, 16)
        o.writeBytes("data"); leInt(o, veriBoyu)
        for (v in x) {
            val s = max(-32768.0, min(32767.0, (v * 32767).toDouble())).toInt()
            for (k in 0 until kanal) leShort(o, s)
        }
    }
}

fun main() {
    println("== 1. SesPerdeOlcer: GERCEK Kotlin kodu, formantli konusma ==")
    for ((f0, bek) in listOf(
        85.0 to SesPerdeOlcer.ERKEK, 100.0 to SesPerdeOlcer.ERKEK,
        120.0 to SesPerdeOlcer.ERKEK, 145.0 to SesPerdeOlcer.ERKEK,
        185.0 to SesPerdeOlcer.KADIN, 210.0 to SesPerdeOlcer.KADIN,
        240.0 to SesPerdeOlcer.KADIN, 260.0 to SesPerdeOlcer.KADIN)) {
        val x = ses(f0, 22050, 1.2, if (bek == SesPerdeOlcer.ERKEK) ERKEK_F else KADIN_F, 0.01, (f0 * 13).toInt())
        val s = SesPerdeOlcer.olc(x, 22050)
        val sapma = if (s.hz > 0) abs(s.hz - f0) / f0 * 100 else 999.0
        dogru("%.0f Hz".format(f0), s.olculdu && sapma < 6.0 && s.cinsiyet == bek,
              "olculen=%.1f sapma=%%%.1f -> %s".format(s.hz, sapma, s.aciklama))
    }

    println("== 2. Oktav kaymasi yok ==")
    for (f0 in listOf(95.0, 110.0, 130.0, 150.0)) {
        val x = ses(f0, 22050, 1.2, ERKEK_F, 0.02, f0.toInt())
        val s = SesPerdeOlcer.olc(x, 22050)
        val cift = s.hz > f0 * 1.7 && s.hz < f0 * 2.3
        val yari = s.hz > f0 * 0.4 && s.hz < f0 * 0.6
        dogru("%.0f Hz kayma yok".format(f0), !cift && !yari, s.aciklama)
    }

    println("== 3. WAV dosyasindan okuma (gercek wavOku) ==")
    val tek = File.createTempFile("gercek_tek", ".wav")
    wavYaz(tek, ses(125.0, 22050, 1.2, ERKEK_F, 0.01, 7), 22050, 1)
    val s1 = SesPerdeOlcer.olc(tek)
    dogru("tek kanal 125 Hz erkek", s1.olculdu && s1.cinsiyet == SesPerdeOlcer.ERKEK, s1.aciklama)
    val cift = File.createTempFile("gercek_cift", ".wav")
    wavYaz(cift, ses(215.0, 22050, 1.2, KADIN_F, 0.01, 8), 22050, 2)
    val s2 = SesPerdeOlcer.olc(cift)
    dogru("stereo 215 Hz kadin", s2.olculdu && s2.cinsiyet == SesPerdeOlcer.KADIN, s2.aciklama)
    val bozuk = File.createTempFile("bozuk", ".wav")
    bozuk.writeText("BU BIR WAV DOSYASI DEGIL 1234567890123456789012345678901234567890")
    dogru("bozuk dosya olculemez", !SesPerdeOlcer.olc(bozuk).olculdu, "")
    dogru("olmayan dosya olculemez", !SesPerdeOlcer.olc(File("/yok/olmayan.wav")).olculdu, "")
    tek.delete(); cift.delete(); bozuk.delete()

    println("== 4. KonusanCinsiyeti: gercek kod ==")
    dogru("JASON: -> JASON", KonusanCinsiyeti.adiAyikla("JASON: Arabaya bin.") == "JASON")
    dogru("cumle ortasi iki nokta atlanir", KonusanCinsiyeti.adiAyikla("Sana diyecegim: kac.") == null)
    dogru("saat atlanir", KonusanCinsiyeti.adiAyikla("Saat 10:30'da gel.") == null)
    dogru("IRENE kadin (ROOT yerel)", KonusanCinsiyeti.tahmin("IRENE") == KonusanCinsiyeti.KADIN)
    dogru("IVAN erkek (ROOT yerel)", KonusanCinsiyeti.tahmin("IVAN") == KonusanCinsiyeti.ERKEK)
    dogru("ISMAIL erkek", KonusanCinsiyeti.tahmin("ISMAIL") == KonusanCinsiyeti.ERKEK)
    dogru("ZEYNEP kadin", KonusanCinsiyeti.tahmin("ZEYNEP") == KonusanCinsiyeti.KADIN)
    dogru("Lucia kadin", KonusanCinsiyeti.tahmin("Lucia") == KonusanCinsiyeti.KADIN)
    dogru("Kratos bilinmiyor", KonusanCinsiyeti.tahmin("Kratos") == KonusanCinsiyeti.BILINMIYOR)
    dogru("null bilinmiyor", KonusanCinsiyeti.tahmin(null) == KonusanCinsiyeti.BILINMIYOR)

    println("== 5. KarakterSesi: gercek dagitici ==")
    val d = KarakterSesi.Dagitici()
    val tonlar = listOf("James", "Arthur", "Michael", "Thomas")
        .map { d.ton(it, KonusanCinsiyeti.ERKEK).etiket }
    dogru("dort erkek dort ayri ton", tonlar.toSet().size == 4, tonlar.toString())
    dogru("ayni ad ayni ton",
        d.ton("James", KonusanCinsiyeti.ERKEK) == d.ton("james", KonusanCinsiyeti.ERKEK))
    dogru("adsiz -> varsayilan 'normal'",
        d.ton(null, KonusanCinsiyeti.ERKEK).etiket == "normal")
    dogru("erkek varsayilani normal",
        KarakterSesi.varsayilan(KonusanCinsiyeti.ERKEK).etiket == "normal")
    dogru("kadin varsayilani normal",
        KarakterSesi.varsayilan(KonusanCinsiyeti.KADIN).etiket == "normal")
    dogru("notr varsayilani normal",
        KarakterSesi.varsayilan(KonusanCinsiyeti.BILINMIYOR, true).etiket == "normal")
    val d2 = KarakterSesi.Dagitici()
    val yuvalar = listOf("A", "B", "C", "D").map { d2.yuva(it, "ses1", 4) }
    dogru("dort ayri yuva", yuvalar.toSet().size == 4, yuvalar.toString())
    dogru("bos havuz -1", d2.yuva("X", "ses1", 0) == -1)
    dogru("adsiz -1", d2.yuva(null, "ses1", 4) == -1)
    d2.unut()
    dogru("unut temizler", d2.yuva("A", "ses1", 4) >= 0)

    println("== 6. SesHavuzu: gercek kod ==")
    val kayitlar = listOf(
        SesHavuzu.Kayit("ama-local", 118.0, SesPerdeOlcer.ERKEK, false),
        SesHavuzu.Kayit("tmc-local", 108.0, SesPerdeOlcer.ERKEK, false),
        SesHavuzu.Kayit("cfs-local", 240.0, SesPerdeOlcer.KADIN, false),
        SesHavuzu.Kayit("efu-local", 212.0, SesPerdeOlcer.KADIN, false),
        SesHavuzu.Kayit("ama-network", 120.0, SesPerdeOlcer.ERKEK, true),
        SesHavuzu.Kayit("dil", 0.0, SesPerdeOlcer.BELIRSIZ, false))
    val mevcut = kayitlar.map { it.ad }.toSet()
    val metin = SesHavuzu.yaz(kayitlar)
    val geri = SesHavuzu.oku(metin)
    dogru("yaz/oku kayit sayisi", geri.size == kayitlar.size, "${geri.size}/${kayitlar.size}")
    dogru("yaz/oku alanlar", geri[0].ad == "ama-local" && geri[0].cinsiyet == SesPerdeOlcer.ERKEK)
    dogru("bos metin bos liste", SesHavuzu.oku("").isEmpty() && SesHavuzu.oku(null).isEmpty())
    dogru("bozuk satir atlanir", SesHavuzu.oku("cop\nx|1|1|0").size == 1)
    val eKapali = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.ERKEK, mevcut, false)
    val eAcik = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.ERKEK, mevcut, true)
    dogru("internet kapali: 2 erkek", eKapali.size == 2, eKapali.map { it.ad }.toString())
    dogru("internet acik: 3 erkek", eAcik.size == 3, eAcik.map { it.ad }.toString())
    dogru("internet acikken network basta", eAcik[0].ad == "ama-network", eAcik[0].ad)
    dogru("internet kapaliyken en kalin basta", eKapali[0].ad == "tmc-local", eKapali[0].ad)
    val k = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.KADIN, mevcut, false)
    dogru("kadinda en ince basta", k[0].ad == "cfs-local", k[0].ad)
    val silinmis = mevcut - "tmc-local"
    dogru("silinmis ses duser",
        SesHavuzu.havuz(kayitlar, SesPerdeOlcer.ERKEK, silinmis, false).none { it.ad == "tmc-local" })
    dogru("tumu: olculmeyen elenir", SesHavuzu.tumu(kayitlar, mevcut, false).none { it.hz == 0.0 })

    println("== 7. SesliOku metin islemleri: gercek kod ==")
    dogru("ad atilir", SesliOku.temizle("James: Gel buraya.", true) == "Gel buraya.")
    dogru("ad atma kapali korunur", SesliOku.temizle("James: Gel buraya.", false) == "James: Gel buraya.")
    dogru("Dikkat: korunur (ad atma kapali)", SesliOku.temizle("Dikkat: arkanda!", false) == "Dikkat: arkanda!")
    dogru("turkuaz nokta atilir", SesliOku.temizle("Isik sondu.  ●", false) == "Isik sondu.")
    dogru("uyari okunmaz", SesliOku.temizle("⚠ hata", false) == null)
    dogru("noktalama okunmaz", SesliOku.temizle("...!?", false) == null)
    dogru("okunurMu normal", SesliOku.okunurMu("Hadi gidelim."))
    dogru("okunurMu uyari", !SesliOku.okunurMu("⚠ hata"))
    dogru("sadeBicim noktalama atar",
        SesliOku.sadeBicim("Tam iceride.") == SesliOku.sadeBicim("Tam iceride!"))

    println("== 8. CanliSesSecimi: gercek kod ==")
    val simdi = 100_000L
    fun olcum(hz: Double, c: Int, cerceve: Int, yas: Long) =
        CanliSesSecimi.Olcum(hz, c, cerceve, simdi - yas)
    dogru("taze ve guclu dahili olcum kullanilir",
        CanliSesSecimi.sec(olcum(115.0, SesPerdeOlcer.ERKEK, 20, 300), null, simdi) == SesPerdeOlcer.ERKEK)
    dogru("eski olcum (1600 ms+) kullanilmaz",
        CanliSesSecimi.sec(olcum(115.0, SesPerdeOlcer.ERKEK, 20, 2000), null, simdi) == SesPerdeOlcer.BELIRSIZ)
    dogru("az sesli cerceve kullanilmaz",
        CanliSesSecimi.sec(olcum(115.0, SesPerdeOlcer.ERKEK, 10, 300), null, simdi) == SesPerdeOlcer.BELIRSIZ)
    dogru("araliktaki belirsiz olcum kullanilmaz",
        CanliSesSecimi.sec(olcum(165.0, SesPerdeOlcer.BELIRSIZ, 20, 300), null, simdi) == SesPerdeOlcer.BELIRSIZ)
    dogru("dahili yoksa mikrofona dusulur",
        CanliSesSecimi.sec(null, olcum(230.0, SesPerdeOlcer.KADIN, 20, 300), simdi) == SesPerdeOlcer.KADIN)
    dogru("dahili varken mikrofon kullanilmaz",
        CanliSesSecimi.sec(olcum(115.0, SesPerdeOlcer.ERKEK, 20, 300),
                           olcum(230.0, SesPerdeOlcer.KADIN, 20, 300), simdi) == SesPerdeOlcer.ERKEK)
    dogru("dahili zayifsa mikrofon devreye girer",
        CanliSesSecimi.sec(olcum(115.0, SesPerdeOlcer.ERKEK, 5, 300),
                           olcum(230.0, SesPerdeOlcer.KADIN, 20, 300), simdi) == SesPerdeOlcer.KADIN)
    dogru("ikisi de yoksa belirsiz",
        CanliSesSecimi.sec(null, null, simdi) == SesPerdeOlcer.BELIRSIZ)
    dogru("gelecekten gelen zaman damgasi kullanilmaz",
        CanliSesSecimi.sec(olcum(115.0, SesPerdeOlcer.ERKEK, 20, -500), null, simdi) == SesPerdeOlcer.BELIRSIZ)

    println()
    println("GERCEK KOD TESTI -> Gecti: $gecti · Kaldi: $kaldi")
    if (kaldi > 0) kotlin.system.exitProcess(1)
}
