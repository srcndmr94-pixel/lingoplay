package com.example.altyazi

import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.texttospeech.SpeechSynthesis
import com.google.mlkit.genai.texttospeech.SpeechSynthesizer
import com.google.mlkit.genai.texttospeech.SpeechSynthesizerRequest
import com.google.mlkit.genai.texttospeech.SpeechSynthesizerResponse
import com.google.mlkit.genai.texttospeech.VoiceInfo
import com.google.mlkit.genai.texttospeech.speechSynthesizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Google ML Kit GenAI TTS (cihaz içinde). Türkçe tr-TR ve Pixel 9 Pro destekli.
 * Bu motor için ücretli API, token veya bulut ses isteği yoktur.
 * Ses ilk kez indiriliyorsa / cihaz desteklemiyorsa Android TTS kullanılmalıdır.
 *
 * UYARI: Google SDK 1.0.0-alpha1. Cihaz ve uygulama üzerinde alan testi gerekir.
 */
class DogalSesMotoru(
    private val log: (String) -> Unit,
    private val yedekOku: (String, String?, Int) -> Unit,
) {
    private val ui = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val nesil = AtomicLong(0L)
    private val hazirSes = ConcurrentHashMap<String, VoiceInfo>()
    private var istemci: SpeechSynthesizer? = null
    private var aktif: Job? = null
    @Volatile private var kapali = false

    fun baslat() {
        scope.launch {
            try {
                val istemciYeni = SpeechSynthesis.getClient(speechSynthesizerOptions(TR) {
                    // İstenen ses henüz indirilmemişse sessizce başka sese geçme.
                    setVoiceFallbackEnabled(false)
                })
                if (kapali) { istemciYeni.close(); return@launch }
                istemci = istemciYeni
                val sesler = istemciYeni.getSupportedVoices(TR)
                if (sesler.isEmpty()) {
                    log("DOĞAL SES: Türkçe GenAI sesi yok; Android TTS yedeği")
                    return@launch
                }
                // Önce erkek, sonra kadın sesi hazırlanır. Adsız replik varsayılan erkek.
                // Yalnız iki model indirilir; gereksiz depolama/ağ tüketimi önlenir.
                val istenenler = listOf("star05", "star02")
                val secilenler = istenenler.mapNotNull { ad -> sesler.firstOrNull { it.name == ad } }
                if (secilenler.isEmpty()) {
                    log("DOĞAL SES: beklenen Türkçe sesler sunulmadı; Android TTS yedeği")
                    return@launch
                }
                for (ses in secilenler) {
                    if (kapali) break
                    try {
                        when (istemciYeni.checkStatus(ses)) {
                            FeatureStatus.AVAILABLE -> hazirSes[ses.name] = ses
                            FeatureStatus.DOWNLOADABLE -> {
                                log("DOĞAL SES: ${ses.name} modeli indiriliyor; bu sırada Android sesi kullanılır")
                                istemciYeni.download(ses).collect { durum ->
                                    if (durum is DownloadStatus.DownloadCompleted && !kapali &&
                                        istemciYeni.checkStatus(ses) == FeatureStatus.AVAILABLE
                                    ) {
                                        hazirSes[ses.name] = ses
                                        log("DOĞAL SES: ${ses.name} hazır (cihaz içi)")
                                    } else if (durum is DownloadStatus.DownloadFailed) {
                                        log("DOĞAL SES: ${ses.name} indirilemedi, yedek ses kullanılacak")
                                    }
                                }
                            }
                            else -> log("DOĞAL SES: ${ses.name} kullanılamıyor; Android TTS yedeği")
                        }
                        if (hazirSes.containsKey(ses.name)) log("DOĞAL SES: ${ses.name} hazır")
                    } catch (h: CancellationException) { throw h }
                    catch (h: Throwable) { log("DOĞAL SES: model sorunu ${h.javaClass.simpleName}") }
                }
            } catch (h: CancellationException) { throw h }
            catch (h: Throwable) { log("DOĞAL SES: başlatılamadı (${h.javaClass.simpleName}); Android yedeği") }
        }
    }

    /** Hazır model varsa repliği devralır; değilse çağıran Android TTS ile okur. */
    fun oku(metin: String, konusan: String?, cinsiyet: Int): Boolean {
        if (kapali) return false
        val adlar = if (cinsiyet == KonusanCinsiyeti.KADIN) listOf("star02")
                    else listOf("star05")
        val ses = adlar.firstNotNullOfOrNull { hazirSes[it] } ?: return false
        val sira = nesil.incrementAndGet()
        ui.post {
            if (kapali || nesil.get() != sira) return@post
            aktif?.cancel()
            val client = istemci ?: return@post
            try { client.stop() } catch (_: Throwable) {}
            aktif = scope.launch {
                var sesBasladi = false
                var tamamlandi = false
                // Model yavaşsa eski repliği geriden seslendirmek yerine yedeğe geç.
                val gecikmeDenetimi = Runnable {
                    if (!kapali && nesil.get() == sira && !sesBasladi && !tamamlandi) {
                        log("DOĞAL SES: 2 saniyeyi aştı; Android TTS yedeği")
                        nesil.incrementAndGet()
                        aktif?.cancel()
                        try { client.stop() } catch (_: Throwable) {}
                        yedekOku(metin, konusan, cinsiyet)
                    }
                }
                ui.postDelayed(gecikmeDenetimi, ILK_SES_ZAMAN_ASIMI)
                try {
                    val req = SpeechSynthesizerRequest(
                        input = SpeechSynthesizerRequest.Input.Text(metin, ses),
                        audioAttributes = AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build(),
                    )
                    client.synthesize(req).collect { cevap ->
                        if (kapali || nesil.get() != sira) return@collect
                        when (cevap) {
                            is SpeechSynthesizerResponse.AudioAvailable -> sesBasladi = true
                            is SpeechSynthesizerResponse.StatusUpdate -> {
                                when (cevap.status) {
                                    SpeechSynthesizerResponse.Status.START -> sesBasladi = true
                                    SpeechSynthesizerResponse.Status.DONE -> tamamlandi = true
                                    else -> {}
                                }
                            }
                            is SpeechSynthesizerResponse.Error -> {
                                if (!tamamlandi) {
                                    tamamlandi = true
                                    log("DOĞAL SES: ses üretilemedi (${cevap.errorCode})")
                                    if (!sesBasladi) yedekOku(metin, konusan, cinsiyet)
                                }
                            }
                        }
                    }
                    // SDK bazı motorlarda işitilebilir ses oluşmadan tamamlanabilir.
                    if (!sesBasladi && !kapali && nesil.get() == sira && !tamamlandi) {
                        tamamlandi = true
                        yedekOku(metin, konusan, cinsiyet)
                    }
                } catch (h: CancellationException) { throw h }
                catch (h: Throwable) {
                    log("DOĞAL SES: hata (${h.javaClass.simpleName}); Android TTS yedeği")
                    if (!sesBasladi && !kapali && nesil.get() == sira) yedekOku(metin, konusan, cinsiyet)
                } finally {
                    tamamlandi = true
                    ui.removeCallbacks(gecikmeDenetimi)
                }
            }
        }
        return true
    }

    fun sus() {
        nesil.incrementAndGet()
        ui.post {
            aktif?.cancel()
            try { istemci?.stop() } catch (_: Throwable) {}
        }
    }

    fun kapat() {
        kapali = true
        nesil.incrementAndGet()
        ui.post {
            aktif?.cancel()
            try { istemci?.stop() } catch (_: Throwable) {}
            try { istemci?.close() } catch (_: Throwable) {}
            istemci = null
            scope.cancel()
        }
    }

    companion object {
        private val TR = Locale("tr", "TR")
        private const val ILK_SES_ZAMAN_ASIMI = 2000L
    }
}
