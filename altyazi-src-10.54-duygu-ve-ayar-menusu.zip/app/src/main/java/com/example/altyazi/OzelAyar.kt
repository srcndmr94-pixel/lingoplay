package com.example.altyazi

import java.util.Locale

/**
 * ÖZEL AYAR TABLOSU (10.54)
 *
 * Kullanıcının gönderdiği tabloyu ayar kontrollerine çevirir. Tablo CSV,
 * noktalı virgüllü ya da sekmeyle ayrılmış olabilir; satır başına bir
 * ayar düşer:
 *
 *     Ad ; Tür ; Varsayılan ; Bölüm
 *     Altyazı gecikmesi ; kaydırak ; 0 ; Ekran alanı
 *     Küfrü yumuşat ; anahtar ; kapalı ; Dil ve çeviri
 *     Fısıltı sesi ; liste ; ahm-local|efu-local ; Sesli okuma
 *
 * TASARIM NOTU: Android bağımlılığı yok, tek başına sınanabiliyor.
 * Değerler Prefs'te "ozel_<anahtar>" adıyla saklanır; anahtar addan
 * türetilir, böylece tablo yeniden içe aktarılsa da kullanıcının
 * değiştirdiği değerler kaybolmaz.
 */
object OzelAyar {

    const val T_ANAHTAR = "anahtar"
    const val T_KAYDIRAK = "kaydırak"
    const val T_SAYI = "sayı"
    const val T_YAZI = "yazı"
    const val T_LISTE = "liste"

    /** Tablodaki bir satır. */
    data class Satir(
        val ad: String,
        val tur: String,
        val varsayilan: String,
        val bolum: String,
        val secenekler: List<String> = emptyList(),
    ) {
        /** Prefs anahtarı. */
        val anahtar: String get() = anahtarAdi(ad)

        /** Anahtar türü için varsayılanın açık/kapalı karşılığı. */
        val varsayilanAcik: Boolean
            get() = varsayilan.lowercase(TR) in ACIK

        /** Kaydırak ve sayı için varsayılanın sayı karşılığı. */
        val varsayilanSayi: Int
            get() = Regex("-?\\d+").find(varsayilan)?.value?.toIntOrNull() ?: 0
    }

    private val TR = Locale("tr", "TR")

    private val ACIK = setOf("açık", "acik", "aktif", "evet", "var", "1", "true", "on", "açik")

    /** Başlık satırı olabilecek ilk hücre değerleri. */
    private val BASLIKLAR = setOf("ad", "ayar", "isim", "name", "setting", "başlık", "baslik")

    private val TUR_ESLEME: Map<String, String> = buildMap {
        for (k in listOf("anahtar", "switch", "bool", "boolean", "aç-kapa", "ac-kapa", "onay", "checkbox", "toggle"))
            put(k, T_ANAHTAR)
        for (k in listOf("kaydırak", "kaydirak", "slider", "sürgü", "surgu", "yüzde", "yuzde", "seekbar"))
            put(k, T_KAYDIRAK)
        for (k in listOf("sayı", "sayi", "number", "int", "tam sayı", "tamsayı", "rakam"))
            put(k, T_SAYI)
        for (k in listOf("yazı", "yazi", "metin", "text", "string", "serbest"))
            put(k, T_YAZI)
        for (k in listOf("liste", "select", "seçim", "secim", "spinner", "açılır", "acilir", "dropdown"))
            put(k, T_LISTE)
    }

    /**
     * Addan prefs anahtarı: küçük harf, Türkçe harfler sadeleştirilir,
     * harf ve rakam dışı her şey alt çizgi olur.
     *
     * NEDEN SADELEŞTİRME: SharedPreferences anahtarı olarak Türkçe harf
     * sorun çıkarmaz ama aynı ayar farklı yazımlarla ("Küfrü" / "Kufru")
     * iki ayrı anahtara düşmesin diye tek biçime indiriliyor.
     */
    fun anahtarAdi(ad: String): String {
        val sb = StringBuilder("ozel_")
        for (c in ad.lowercase(TR)) {
            val d = when (c) {
                'ç' -> 'c'; 'ğ' -> 'g'; 'ı' -> 'i'; 'ö' -> 'o'; 'ş' -> 's'; 'ü' -> 'u'
                else -> c
            }
            if (d.isLetterOrDigit() && d.code < 128) sb.append(d) else sb.append('_')
        }
        return sb.toString().trimEnd('_')
    }

    /** Satırın ayırıcısı: önce sekme, sonra noktalı virgül, sonra virgül. */
    private fun ayirici(satir: String): Char = when {
        satir.contains('\t') -> '\t'
        satir.contains(';') -> ';'
        else -> ','
    }

    /** Tür adını tanınan türe çevirir; tanınmazsa [T_YAZI]. */
    fun tur(ham: String): String {
        val t = ham.trim().lowercase(TR)
        TUR_ESLEME[t]?.let { return it }
        for ((k, v) in TUR_ESLEME) if (t.startsWith(k)) return v
        return T_YAZI
    }

    /**
     * Tabloyu satırlara çevirir. Boş satırlar, "#" ile başlayanlar ve
     * başlık satırı atlanır. Adı olmayan satır atlanır — adsız bir ayarın
     * ne olduğu bilinemez.
     */
    fun coz(metin: String?): List<Satir> {
        if (metin.isNullOrBlank()) return emptyList()
        val sonuc = ArrayList<Satir>()
        val gorulen = HashSet<String>()
        for (hamSatir in metin.split('\n')) {
            val satir = hamSatir.trim().trimEnd('\r')
            if (satir.isEmpty() || satir.startsWith("#")) continue
            val h = satir.split(ayirici(satir)).map { it.trim().trim('"') }
            val ad = h.getOrNull(0).orEmpty()
            if (ad.isEmpty()) continue
            if (ad.lowercase(TR) in BASLIKLAR) continue
            val turHam = h.getOrNull(1).orEmpty()
            val varsayilanHam = h.getOrNull(2).orEmpty()
            val bolum = h.getOrNull(3).orEmpty().ifEmpty { "Diğer" }
            val besinci = h.getOrNull(4).orEmpty()
            val t = tur(turHam)
            // Liste seçenekleri: beşinci sütunda ya da varsayılan hücresinde
            // dikey çizgiyle ayrılmış olabilir. İlk seçenek varsayılandır.
            val secenekler = when {
                besinci.contains('|') -> besinci.split('|').map { it.trim() }.filter { it.isNotEmpty() }
                varsayilanHam.contains('|') -> varsayilanHam.split('|').map { it.trim() }.filter { it.isNotEmpty() }
                t == T_LISTE && varsayilanHam.isNotEmpty() -> listOf(varsayilanHam)
                else -> emptyList()
            }
            val varsayilan = if (varsayilanHam.contains('|')) secenekler.firstOrNull().orEmpty() else varsayilanHam
            val s = Satir(ad, t, varsayilan, bolum, secenekler)
            if (!gorulen.add(s.anahtar)) continue
            sonuc += s
        }
        return sonuc
    }

    /** Bölüme göre gruplar; bölüm sırası tabloda göründükleri sıradır. */
    fun bolumler(satirlar: List<Satir>): List<Pair<String, List<Satir>>> {
        val sira = LinkedHashMap<String, MutableList<Satir>>()
        for (s in satirlar) sira.getOrPut(s.bolum) { ArrayList() } += s
        return sira.map { it.key to it.value.toList() }
    }

    /** Kullanıcıya verilecek örnek tablo. */
    fun sablon(): String = listOf(
        "# GameLingo özel ayar tablosu",
        "# Sütunlar: Ad ; Tür ; Varsayılan ; Bölüm",
        "# Tür: anahtar · kaydırak · sayı · yazı · liste",
        "Ad;Tür;Varsayılan;Bölüm",
        "Altyazı gecikmesi;kaydırak;0;Ekran alanı",
        "Satır sayısı;sayı;2;Yazı ve görünüm",
        "Küfrü yumuşat;anahtar;kapalı;Dil ve çeviri",
        "Fısıltı sesi;liste;ahm-local|efu-local;Sesli okuma",
        "Kahkaha şiddeti;kaydırak;70;Duygu ve ünlemler",
    ).joinToString("\n")

    /** Tanı ve ekran için kısa özet. */
    fun ozet(satirlar: List<Satir>): String {
        if (satirlar.isEmpty()) return "Henüz tablo yüklenmedi."
        val b = bolumler(satirlar)
        return "${satirlar.size} ayar · ${b.size} bölüm: " + b.joinToString(", ") { it.first }
    }
}
