# GameLingo 10.17 — güvenli geri dönüş

Kaynak: Kullanıcının daha önce yüklediği `altyazi-src.zip` (10.12).

- 10.13–10.16 arasında eklenen çeviri ve arayüz müdahaleleri bu pakette bulunmaz.
- Orijinal 10.12 uygulama kodu korunmuştur.
- Sadece Android versionCode 146 -> 150 ve versionName 10.12 -> 10.17 değiştirildi (önceki kurulum üzerine güncelleme için).
- Bu paket APK değil kaynak ZIP'tir. APK derlenmedi, cihazda çalışması doğrulanmadı.
- Aynı uygulama kimliği ve imza anahtarıyla derlenmelidir; aksi durumda güncelleme olarak yüklenemez.
