package com.example.altyazi

/** Conservative detector for catastrophic changes in imperative polarity.
 * It does not pretend to judge idiomatic translation quality.
 */
object MeaningSafety {
    enum class Risk { REVERSED_NEGATIVE_COMMAND }
    private val noOneAlive = Regex("(?i)\\b(?:leave|keep)\\s+(?:no\\s+one|nobody)\\s+alive\\b")
    private val positiveLeaveAlive = Regex("(?i)\\b(?:kimseyi|hiç kimseyi|onları|hepsini)\\s+(?:canlı|sağ)\\s+bırak(?:ın|ınız)?[.!]?$")
    fun risk(source: String, target: String): Risk? =
        if (noOneAlive.containsMatchIn(source) && positiveLeaveAlive.containsMatchIn(target.trim()))
            Risk.REVERSED_NEGATIVE_COMMAND else null

    fun safeToRemember(source: String, target: String): Boolean = risk(source, target) == null
}
