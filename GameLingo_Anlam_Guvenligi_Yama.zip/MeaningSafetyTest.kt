import com.example.altyazi.MeaningSafety
import com.example.altyazi.TranslationQualityGate
fun main() {
  check(MeaningSafety.risk("Leave no one alive.", "Kimseyi canlı bırak.") != null)
  check(MeaningSafety.risk("Leave no one alive.", "Kimseyi sağ bırakmayın!") == null)
  check(MeaningSafety.risk("Leave no one alive.", "Kimseyi canlı bırakma.") == null)
  check(MeaningSafety.risk("Leave no one alive.", "Kimseyi sağ bırakmayın.") == null)
  check(MeaningSafety.risk("Leave him alive.", "Onu sağ bırak.") == null)
  check(TranslationQualityGate.check("Leave no one alive.", "Kimseyi canlı bırak.") == TranslationQualityGate.Problem.REVERSED_COMMAND)
  check(!TranslationQualityGate.mayRemember("Leave no one alive.", "Kimseyi canlı bırak."))
  println("7/7 critical polarity checks PASS")
}
