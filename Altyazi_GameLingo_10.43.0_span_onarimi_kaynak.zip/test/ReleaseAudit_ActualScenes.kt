package com.example.altyazi
fun main() {
 val ctx=DialogueContextRepair()
 fun run(title: String, inputs: List<String>) {
  ctx.reset()
  println("\nSCENARIO: $title")
  inputs.forEachIndexed { i, s ->
   ctx.remember(s, 1000L + i*450L)
   println(" $i  ${s} => JOINED: ${ctx.joinedTranslationInput(s, 1000L+i*450L) ?: "<none>"}")
  }
 }
 run("real live Nolan", listOf("[Nolan] We're about to leave orbit.", "The, uh..", "the view through the main screen is.", "really spectacular,", "if you'd like to see it."))
 run("real live Thragg", listOf("[Thragg] There's nothing he", "or anyone else can do to stop us."))
 run("partly clipped bomb",listOf("It's, it's like there's this.", "bomb that's gonna go off somewhere", "a-and kill so many people, and there's nothing I can do about it", "because i'm the reason it's there."))
 run("trailing warning sentence", listOf("The whole world will get behind us on this", "without getting rid of all the bugs."))
 run("same sentence early mistaken stop", listOf("I'm not sure I'll be here", "when the meeting starts."))
}
