package com.example.altyazi

fun main() {
    val noSplit = listOf(
        "[Thragg] There's nothing he or anyone else can do to stop us.",
        "We will live among you.", "Wear your clothes.",
        "the view through the main screen is really spectacular,",
        "until then, get the fuck off my planet.",
        "It's, it's like there's this bomb that's gonna go off somewhere",
        "No destination, not looking for trouble, just a flight.",
        "I will never not be afraid of you."
    )
    noSplit.forEach { check(DeepLRequestPolicy.sentenceSplitting(it) == "0") { it } }
    val split = listOf(
        "I'm okay. But you're not.",
        "Enjoy your dinner, guys. I'll be back for dessert.",
        "Did we win? What happened?"
    )
    split.forEach { check(DeepLRequestPolicy.sentenceSplitting(it) == "1") { it } }
    val ctx=DialogueContextRepair()
    ctx.remember("Let me explain your future to you.", 1000L)
    ctx.remember("We will live among you.", 1200L)
    ctx.remember("Wear your clothes.", 1400L)
    ctx.remember("Walk your streets.", 1600L)
    val previous = ctx.contextForTranslation("Walk your streets.", 1700L)
    check("We will live among you." in previous) { previous }
    check("Wear your clothes." in previous) { previous }
    check("Walk your streets." !in previous) { previous }
    println("PASS: 11 full-span DeepL scenarios and actual prior-context selection")
}
