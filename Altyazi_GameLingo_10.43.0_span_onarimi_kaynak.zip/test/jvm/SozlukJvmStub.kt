package com.example.altyazi
object Sozluk { val hazir=false; fun icinde(word:String)=false }
