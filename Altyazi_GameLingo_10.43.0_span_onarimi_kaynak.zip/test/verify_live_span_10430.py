from pathlib import Path
base=Path(__file__).resolve().parents[1]/"app/src/main/java/com/example/altyazi"
s=(base/"OfflineFix.kt").read_text()
start=s.index("suspend fun translate(text: String, ml:")
end=s.index("private suspend fun cachedRun",start)
method=s[start:end]
assert method.index("SoundTags.translate(text)") < method.index("if (gucluFn != null && cleaned.length <= 480)")
assert method.index("val turns = text.split(interruptedTurn)") < method.index("if (gucluFn != null && cleaned.length <= 480)")
assert method.index("val inner = inlineTag.findAll(text)") < method.index("if (gucluFn != null && cleaned.length <= 480)")
assert method.index("if (gucluFn != null && cleaned.length <= 480)") < method.index("if (sentences.size == 1)")
assert "sentences.none { lookup(it) != null }" not in method
assert method.index("lookupUser(cleaned)?.let { return it }") > method.index("if (gucluFn != null && cleaned.length <= 480)")
svc=(base/"CaptureService.kt").read_text(); pos=svc.index("private suspend fun runTranslation")
assert svc.index("dialogueContext.joinedTranslationInput(source)",pos) < svc.index("OfflineFix.lookup(bodyIn)",pos)
assert (base/"DeepLCeviri.kt").read_text().count("DeepLRequestPolicy.sentenceSplitting(source)")==1
assert "if (gucluFn == null) SourceAwareDialogueFix.correct(text)" in s
assert "fun lookupUser(text: String)" in s
assert "if (hizli && OfflineFix.gucluFn == null)" in svc
assert "val remembered = if (OfflineFix.gucluFn != null) null" in svc
print("PASS: actual live source branch ordering and DeepL policy wiring")
