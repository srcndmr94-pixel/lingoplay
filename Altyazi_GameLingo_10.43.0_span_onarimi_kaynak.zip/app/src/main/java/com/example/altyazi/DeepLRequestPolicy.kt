package com.example.altyazi

/** Do not split a single live subtitle into multiple independent sentences.
 * Real multi-sentence captions still use DeepL normal sentence segmentation.
 * Source text, not reference translations, determines this policy.
 */
object DeepLRequestPolicy {
    private val boundary = Regex("""[.!?](?:[\"'’)]*)\s+(?=[\p{Lu}\[])""")
    fun sentenceSplitting(source: String): String =
        if (boundary.containsMatchIn(source.trim())) "1" else "0"
}
