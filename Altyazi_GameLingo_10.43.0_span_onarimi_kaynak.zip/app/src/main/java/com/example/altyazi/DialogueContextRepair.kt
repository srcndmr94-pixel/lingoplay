package com.example.altyazi

/**
 * Güvenli oturum-içi isim onarımı. Yalnız kabul edilen altyazılar hatırlanır.
 * "Pout's" ancak yakın geçmişte "Paul" adı açık bağlamda geçerse "Paul's" olur.
 * Kanıt yoksa metin değiştirilmez. Yeni ağ isteği/çeviri gecikmesi yoktur.
 */
class DialogueContextRepair {
    private var acceptedCount = 0
    private var lastPaulAt = -1
    private var lastAccepted = ""
    // Kaynak -> hemen önce kabul edilen altyazı. Asenkron çeviri gelince de
    // doğru önceki satırı kullanmak için kabul anında kaydedilir.
    private data class AcceptedBefore(val text: String, val timestampMs: Long, val earlier: String = "", val earlierAtMs: Long = 0L,
                                      val oldest: String = "", val oldestAtMs: Long = 0L)
    private val preceding = object : LinkedHashMap<String, AcceptedBefore>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, AcceptedBefore>?): Boolean = size > 32
    }
    private var lastAcceptedAtMs = 0L
    private val incompleteEnding = Regex(
        "(?i)\\b(?:a|an|the|of|for|to|from|with|without|about|by|at|in|on|as|than|" +
            "because|if|when|while|and|but|or|that|which|who|whose|" +
            "am|is|are|was|were|have|has|had|do|does|did|will|would|can|could|should)\\s*$"
    )
    private val sentenceEnding = Regex("[.!?…][\"'’)]*$")
    // A following sound cue is not a speaker change. It may follow a spoken
    // continuation: "any difference at all. -[insects trilling]".
    private val trailingSoundCue = Regex("""(?i)\s*(?:-\s*)?\[[a-z]+(?:[ ,'-][a-z]+){0,5}]\s*$""")
    private val incompletePredicate = Regex("""(?i)\b(?:would|could|will|might|can|should)\s+make\s*$""")

    // A speaker label at the beginning of the OLD subtitle belongs to the
    // same unfinished utterance; a label on the NEW subtitle marks a turn change.
    // Never strip a sound cue such as [sighs] or [Mark grunting].
    private val speakerLead = Regex("""^\[([\p{Lu}][\p{L}'’.-]{1,28}(?:\s+[\p{Lu}][\p{L}'’.-]{1,24})?)\]\s+""")
    // OCR sometimes ends an unfinished auxiliary with an artificial period:
    // "the view through the main screen is." + "really spectacular,"
    private val clippedAuxiliary = Regex("""(?i)\b(?:is|are|was|were)[.]{1,3}$""")
    // These phrases are grammatical only when another noun/adverbial follows.
    // A speech break after an OCR period must not turn "there's this bomb"
    // into two unrelated Turkish fragments.
    private val clippedDeictic = Regex("""(?i)\b(?:there(?:'|’)s|there is)\s+this[.]{0,3}$""")
    // A following lowercase 'when ...' can qualify a specific unfinished
    // timing phrase without opening a generic and/or over-merge rule.
    private val timingClause = Regex("""(?i)\b(?:i(?:'|’)ll|i will|we(?:'|’)ll|we will)\s+be\s+(?:here|there)[.]{0,3}$""")
    // Coordinating conjunctions like "and" alone are NOT evidence of a
    // broken sentence; a full sentence without a period must stay separate.
    private val continuingStart = Regex("""(?i)^(?:trying|making|because|to|while|which|that|without)\b""")
    private val subjectDisjunction = Regex("""(?i)\b(?:he|she|they|we|you|i|it)$""")

    private fun spokenAndLabel(text: String): Pair<String, String>? {
        val start = speakerLead.find(text)
        val label = start?.value.orEmpty()
        val spoken = if (start == null) text else text.substring(start.range.last + 1)
        // A sound cue or a new speaker embedded in the body is not join-safe.
        if (spoken.any { it == '[' || it == ']' || it == ':' }) return null
        return label to spoken
    }

    private fun incomplete(text: String): Boolean =
        text.endsWith(',') || text.endsWith('—') || text.endsWith('-') ||
            incompleteEnding.containsMatchIn(text) || incompletePredicate.containsMatchIn(text) ||
            clippedAuxiliary.containsMatchIn(text) || clippedDeictic.containsMatchIn(text)

    private fun withoutFalseStop(text: String): String =
        if (clippedAuxiliary.containsMatchIn(text) || clippedDeictic.containsMatchIn(text)) text.trimEnd('.') else text

    /**
     * Merge only demonstrably unfinished same-speaker lines from the past
     * seven seconds. Never merge an explicit new speaker, a sound cue, or a
     * finished unrelated sentence. The joined input is translated as one unit;
     * no fabricated reference translation is supplied to the model.
     */
    @Synchronized fun joinedTranslationInput(source: String, nowMs: Long = System.currentTimeMillis()): String? {
        val before = preceding[source] ?: return null
        if (nowMs < before.timestampMs || nowMs - before.timestampMs > 7_000L) return null
        val previous = before.text.trim()
        val current = source.trim()
        val pair = spokenAndLabel(previous) ?: return null
        val speakerPrefix = pair.first
        val previousBody = pair.second
        val spokenCurrent = current.replace(trailingSoundCue, "").trimEnd()
        val splitNegation = previousBody.matches(Regex("""(?i)^not[.\s]{2,}$""")) &&
            spokenCurrent.matches(Regex("""(?i)^be\s+here[.!?]*$"""))
        if ((previousBody.length !in 10..140 && !splitNegation) || spokenCurrent.length !in 7..130 ||
            previous.length + current.length > 190) return null
        if (previous.equals(current, ignoreCase = true)) return null
        // New bracketed speaker -> different turn. Trailing sound cue has
        // already been separated above and can remain attached to current.
        if (spokenCurrent.any { it == '[' || it == ']' || it == ':' }) return null
        val interruptedJust = Regex("""(?i)^(?:i\s+(?:was|am)\s+just)[.\s]*$""")
            .matches(previousBody) && Regex("""(?i)^making\b""").containsMatchIn(spokenCurrent)
        val hasFinalPunctuation = sentenceEnding.containsMatchIn(previousBody)
        val clipped = clippedAuxiliary.containsMatchIn(previousBody) || clippedDeictic.containsMatchIn(previousBody)
        val timingContinuation = timingClause.containsMatchIn(previousBody) &&
            spokenCurrent.startsWith("when ", ignoreCase = true)
        if (hasFinalPunctuation && !interruptedJust && !splitNegation && !clipped && !timingContinuation) return null
        if (spokenCurrent.firstOrNull()?.isLowerCase() != true) return null
        val continuesClause = continuingStart.containsMatchIn(spokenCurrent) && !hasFinalPunctuation
        val disjunction = subjectDisjunction.containsMatchIn(previousBody) &&
            spokenCurrent.startsWith("or ", ignoreCase = true)
        val evidentlyIncomplete = incomplete(previousBody) || continuesClause || disjunction ||
            interruptedJust || splitNegation || timingContinuation
        val earlier = before.earlier.trim()
        val earlierPair = spokenAndLabel(earlier)
        val earlierBody = earlierPair?.second.orEmpty()
        val earlierIncomplete = earlierBody.isNotEmpty() && incomplete(earlierBody) &&
            (!sentenceEnding.containsMatchIn(earlierBody) || clippedAuxiliary.containsMatchIn(earlierBody) ||
                clippedDeictic.containsMatchIn(earlierBody))
        if (!evidentlyIncomplete && !(earlierIncomplete && !hasFinalPunctuation)) return null
        // A three-part line can inherit a speaker label only from its opener;
        // the middle fragment must not introduce a second speaker.
        if (earlierBody.length in 10..130 && nowMs >= before.earlierAtMs &&
            before.timestampMs - before.earlierAtMs in 0..7_000L &&
            earlier.length + previous.length + current.length <= 220 &&
            earlierIncomplete && previousBody.firstOrNull()?.isLowerCase() == true &&
            speakerPrefix.isEmpty()) {
            return "${earlierPair!!.first}${withoutFalseStop(earlierBody)} ${withoutFalseStop(previousBody)} $current"
        }
        val cleanPrevious = if (interruptedJust || splitNegation) previousBody.trimEnd('.', ' ')
            else withoutFalseStop(previousBody)
        return "$speakerPrefix$cleanPrevious $current"
    }
    /** Previous accepted English subtitles, never the current line or future dialog.
     * Used only for the DeepL live API's context parameter; no extra API call.
     * A fragment not attributable to the current subtitle gets NO context.
     */
    @Synchronized fun contextForTranslation(body: String, nowMs: Long = System.currentTimeMillis()): String {
        val requested = body.trim().replace(Regex("\\s+"), " ")
        val match = preceding.entries.toList().asReversed().firstOrNull { (source, record) ->
            nowMs >= record.timestampMs && nowMs - record.timestampMs <= 10_000L &&
                source.trim().removePrefixSpeaker().let { plain ->
                    plain.equals(requested, ignoreCase = true) ||
                        GoogleSourcePreparation.prepare(plain).equals(requested, ignoreCase = true)
                }
        } ?: return ""
        val first = match.value.text.trim()
        val older = match.value.earlier.trim()
        val context = listOf(match.value.oldest, older, first)
            .mapNotNull { spokenAndLabel(it.trim())?.second }
            .filter { it.length in 3..170 && it != requested && !it.startsWith("[") }
        return context.joinToString("\n").takeLast(340)
    }

    private fun String.removePrefixSpeaker(): String =
        replace(Regex("^\\[[^]]{1,35}]\\s*"), "").trim()

    private val paulEvidence = Regex("\\b(?:with\\s+Paul|about\\s+this\\s+Paul\\s+guy|Paul\\s+is)\\b")
    private val likelyPoutName = Regex("\\bPout(?=['’]s\\b)")

    @Synchronized fun reset() {
        acceptedCount = 0
        lastPaulAt = -1
        lastAccepted = ""
        lastAcceptedAtMs = 0L
        preceding.clear()
    }

    /** Saf işlem: aynı kare birden çok kez okunsa da geçmişi ilerletmez. */
    @Synchronized fun repair(text: String): String {
        if (lastPaulAt == -1 || acceptedCount - lastPaulAt > 40) return text
        return likelyPoutName.replace(text, "Paul")
    }

    /**
     * Yalnız anlamı açık, arka arkaya gelen KOPUK replikler için ikinci
     * altyazının tamamını doğal Türkçeye çevirir. Tahmin yok; eşleşme yoksa
     * Google/Firefox hattına aynen bırakılır. Ağ çağrısı / gecikme eklemez.
     * Hangi önceki repliğe ait olduğu kabul ANINDA sabitlenir.
     */
    @Synchronized fun contextualTranslation(source: String): String? {
        val previous = preceding[source]?.text?.lowercase()?.trim() ?: return null
        val current = source.lowercase().trim()
        return when {
            // "They" refers to powers when the immediately preceding speaker
            // explicitly said "my powers came back"; no noun is invented.
            previous.endsWith("my powers came back.") &&
                current.matches(Regex("""(?:\[mark\]\s*)?they just came back\?""")) ->
                "Kendiliğinden mi geri geldiler?"
            // "...back in the day" ardından "Was?!" zaman vurgusudur.
            current.matches(Regex("was[?!]+")) &&
                Regex("\\bback in the day[.!?]*$").containsMatchIn(previous) ->
                "Eskiden mi?!"
            previous == "have we been" && current == "here before?" ->
                "Daha önce buraya gelmiş miydik?"
            previous == "want to take our relationship" &&
                current.matches(Regex("to the next level[.!?, ]*so[.!?…]*")) ->
                "İlişkimizi bir sonraki aşamaya taşımak istiyorum. O yüzden..."
            previous.startsWith("oh, uh, what was it you wanted to tell me yesterday") &&
                current == "when my dad and allen showed up?" ->
                "Dün babamla Allen geldiğinde bana ne söyleyecektin?"
            previous == "the kid has enough to deal with" &&
                current == "without me messing him up the way i did mark." ->
                "Ben de Mark'e yaptıklarımı ona yaşatmayayım."
            else -> null
        }
    }

    /** Gerçekten çevirmeye alınan altyazıdan öğrenir. */
    @Synchronized fun remember(acceptedSubtitle: String, nowMs: Long = System.currentTimeMillis()) {
        acceptedCount++
        val previousRecord = preceding[lastAccepted]
        preceding[acceptedSubtitle] = AcceptedBefore(lastAccepted, lastAcceptedAtMs,
            previousRecord?.text.orEmpty(), previousRecord?.timestampMs ?: 0L,
            previousRecord?.earlier.orEmpty(), previousRecord?.earlierAtMs ?: 0L)
        lastAccepted = acceptedSubtitle
        lastAcceptedAtMs = nowMs
        if (paulEvidence.containsMatchIn(acceptedSubtitle)) lastPaulAt = acceptedCount
    }
}
