package com.example.altyazi

/**
 * PAKET DOSYASI OKUYUCU — 10.61
 *
 * Yalnız paket biçimini okur:
 *   {"format":1,"id":"…","title":"…","entries":{"<hex>":"Türkçe", …}}
 * Yalnız {"<hex>":"Türkçe"} nesnesi de kabul edilir (kimlik dosya adından).
 *
 * NEDEN ELDE YAZILDI: org.json Android'e bağlı; o kullanılsaydı paket yolu
 * telefona kurulmadan test edilemezdi. Bu okuyucu saf Kotlin, bu yüzden
 * 40.718 satırlık gerçek paket testte açılıp doğrulanabiliyor.
 *
 * Bilinçli sınır: iç içe nesneler atlanır, sayı/bool değerler atlanır.
 * Bu dosyalar makine üretimi; genel bir JSON kütüphanesi gerekmiyor.
 */
object PaketJson {

    data class Okunan(
        val kimlik: String?,
        val baslik: String?,
        val satirlar: Map<String, String>,
    )

    fun oku(metin: String): Okunan? {
        var i = bosluktanSonra(metin, 0)
        if (i >= metin.length || metin[i] != '{') return null
        i++
        var kimlik: String? = null
        var baslik: String? = null
        var satirlar: MutableMap<String, String>? = null
        val kok = LinkedHashMap<String, String>()

        while (true) {
            i = bosluktanSonra(metin, i)
            if (i >= metin.length) return null
            if (metin[i] == '}') { i++; break }
            if (metin[i] == ',') { i++; continue }
            if (metin[i] != '"') return null
            val ad = StringBuilder()
            i = dizeOku(metin, i, ad) ?: return null
            i = bosluktanSonra(metin, i)
            if (i >= metin.length || metin[i] != ':') return null
            i = bosluktanSonra(metin, i + 1)
            if (i >= metin.length) return null

            when {
                metin[i] == '"' -> {
                    val deger = StringBuilder()
                    i = dizeOku(metin, i, deger) ?: return null
                    when (ad.toString()) {
                        "id" -> kimlik = deger.toString()
                        "title" -> baslik = deger.toString()
                        else -> kok[ad.toString()] = deger.toString()
                    }
                }
                metin[i] == '{' -> {
                    if (ad.toString() == "entries") {
                        val harita = LinkedHashMap<String, String>()
                        i = nesneOku(metin, i, harita) ?: return null
                        satirlar = harita
                    } else {
                        i = atla(metin, i) ?: return null
                    }
                }
                else -> i = atla(metin, i) ?: return null
            }
        }
        val sonuc = satirlar ?: kok
        return Okunan(kimlik, baslik, sonuc)
    }

    /** `{ "a":"b", … }` okur; iç içe nesne/dizi atlanır. */
    private fun nesneOku(metin: String, bas: Int, hedef: MutableMap<String, String>): Int? {
        var i = bas + 1
        while (true) {
            i = bosluktanSonra(metin, i)
            if (i >= metin.length) return null
            if (metin[i] == '}') return i + 1
            if (metin[i] == ',') { i++; continue }
            if (metin[i] != '"') return null
            val ad = StringBuilder()
            i = dizeOku(metin, i, ad) ?: return null
            i = bosluktanSonra(metin, i)
            if (i >= metin.length || metin[i] != ':') return null
            i = bosluktanSonra(metin, i + 1)
            if (i >= metin.length) return null
            if (metin[i] == '"') {
                val deger = StringBuilder()
                i = dizeOku(metin, i, deger) ?: return null
                hedef[ad.toString()] = deger.toString()
            } else {
                i = atla(metin, i) ?: return null
            }
        }
    }

    /** Dize okur (kaçışlar dahil); kapanış tırnağından sonraki konumu döner. */
    private fun dizeOku(metin: String, bas: Int, hedef: StringBuilder): Int? {
        var i = bas + 1
        while (i < metin.length) {
            val c = metin[i]
            when {
                c == '"' -> return i + 1
                c == '\\' -> {
                    i++
                    if (i >= metin.length) return null
                    when (val k = metin[i]) {
                        '"' -> hedef.append('"')
                        '\\' -> hedef.append('\\')
                        '/' -> hedef.append('/')
                        'b' -> hedef.append('\b')
                        'f' -> hedef.append('\u000C')
                        'n' -> hedef.append('\n')
                        'r' -> hedef.append('\r')
                        't' -> hedef.append('\t')
                        'u' -> {
                            if (i + 4 >= metin.length) return null
                            val onalti = metin.substring(i + 1, i + 5)
                            val kod = onalti.toIntOrNull(16) ?: return null
                            hedef.append(kod.toChar())
                            i += 4
                        }
                        else -> hedef.append(k)
                    }
                    i++
                }
                else -> { hedef.append(c); i++ }
            }
        }
        return null
    }

    /** Değeri atlar (nesne, dizi, sayı, true/false/null). */
    private fun atla(metin: String, bas: Int): Int? {
        var i = bas
        when (metin[i]) {
            '{', '[' -> {
                val kapanis = if (metin[i] == '{') '}' else ']'
                val acilis = metin[i]
                var derinlik = 0
                while (i < metin.length) {
                    val c = metin[i]
                    when {
                        c == '"' -> { i = dizeOku(metin, i, StringBuilder()) ?: return null; continue }
                        c == acilis -> derinlik++
                        c == kapanis -> { derinlik--; if (derinlik == 0) return i + 1 }
                    }
                    i++
                }
                return null
            }
            '"' -> return dizeOku(metin, i, StringBuilder())
            else -> {
                while (i < metin.length && metin[i] != ',' && metin[i] != '}' && metin[i] != ']') i++
                return i
            }
        }
    }

    private fun bosluktanSonra(metin: String, bas: Int): Int {
        var i = bas
        while (i < metin.length && (metin[i] == ' ' || metin[i] == '\n' || metin[i] == '\r' || metin[i] == '\t')) i++
        return i
    }
}
