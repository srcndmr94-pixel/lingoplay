// SPDX-License-Identifier: AGPL-3.0-only
//
// Anahtar şeması (sadeleştirme + SHA-256'nın ilk 8 baytı) CouchSubs'tan
// uyarlanmıştır: CouchSubs, Copyright (C) 2026 Sinan Yorulmaz, AGPL-3.0.
// https://github.com/yorulmazsinan/couchsubs
// Paket dosyalarının anahtarları o şemayla üretildiği için adımların
// BİREBİR aynı kalması gerekir; tek karakterlik sapma 40.718 anahtarın
// hiçbirini tutturmaz. Bu bildirim kaldırılmamalıdır.
package com.example.altyazi

import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale
import java.util.zip.GZIPInputStream

/**
 * HAZIR ÇEVİRİ PAKETİ — 10.61
 *
 * NEDEN: en büyük gecikme kaynağı, her satır için çeviri motoruna gidilmesi.
 * Oyunun replikleri önceden çevrilip bir pakete konduysa, satır motorlara
 * hiç sorulmadan anında basılabilir.
 *
 * Android'e bağlı hiçbir şey yok (gzip ve SHA-256 saf JVM): bütün yol
 * testten geçirilebiliyor — bkz. test/derleme-denetimi/PaketTest.kt.
 *
 * Bilerek YAPILMAYAN: genel bulanık (fuzzy) tahmin. Alakasız bir repliği
 * benzetip hazır çeviri basmak, motora sorup beklemekten kötüdür.
 */
object PaketAnahtar {

    /** Biçim etiketi: en çok 40 karakterlik `<…>`. */
    const val EN_UZUN_ETIKET = 40

    /**
     * 1) `<…>` etiketleri boşluk olur, 2) NFKC, 3) küçük harf (Locale.ROOT),
     * 4) NFD ile aksan/işaretler atılır, 5) harf ve rakam dışındaki her şey
     * boşluk olur, 6) boşluklar teklenir, baş ve son kırpılır.
     *
     * Locale.ROOT bilerek: Türkçe yerel "I" harfini "ı" yapar ve anahtar
     * tutmaz. Paketi üreten betik de ROOT kullanıyor.
     */
    fun sadelestir(metin: String): String {
        val kucuk = Normalizer.normalize(etiketAt(metin), Normalizer.Form.NFKC).lowercase(Locale.ROOT)
        val ayrisik = Normalizer.normalize(kucuk, Normalizer.Form.NFD)
        val cikti = StringBuilder(ayrisik.length)
        var bosluk = false
        var i = 0
        while (i < ayrisik.length) {
            val kod = ayrisik.codePointAt(i)
            i += Character.charCount(kod)
            when (Character.getType(kod).toByte()) {
                Character.NON_SPACING_MARK, Character.COMBINING_SPACING_MARK,
                Character.ENCLOSING_MARK -> continue
                Character.UPPERCASE_LETTER, Character.LOWERCASE_LETTER, Character.TITLECASE_LETTER,
                Character.MODIFIER_LETTER, Character.OTHER_LETTER,
                Character.DECIMAL_DIGIT_NUMBER, Character.LETTER_NUMBER, Character.OTHER_NUMBER -> {
                    if (bosluk && cikti.isNotEmpty()) cikti.append(' ')
                    bosluk = false
                    cikti.appendCodePoint(kod)
                }
                else -> bosluk = true
            }
        }
        return cikti.toString()
    }

    /** 16 haneli küçük harf hex anahtar; satırda harf ya da rakam yoksa null. */
    fun anahtar(metin: String): String? {
        val sade = sadelestir(metin)
        if (sade.isEmpty()) return null
        val ozet = ozetleyici.get()!!.digest(sade.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(16)
        for (b in ozet.take(8)) sb.append(String.format("%02x", b.toInt() and 0xff))
        return sb.toString()
    }

    /** Anahtarın sayı hâli; hex dizesi kurulmadan. */
    fun anahtarSayisi(metin: String): Long? {
        val sade = sadelestir(metin)
        if (sade.isEmpty()) return null
        return java.nio.ByteBuffer.wrap(ozetleyici.get()!!.digest(sade.toByteArray(Charsets.UTF_8))).long
    }

    /** 16 haneli hex anahtarı sayıya çevirir; geçersizse null. */
    fun sayi(anahtar: String): Long? {
        if (anahtar.length != 16) return null
        for (c in anahtar) if (!(c in '0'..'9' || c in 'a'..'f' || c in 'A'..'F')) return null
        return java.lang.Long.parseUnsignedLong(anahtar, 16)
    }

    /** `<…>` etiketlerini (en çok 40 karakter, içinde < ya da > yok) değiştirir. */
    fun etiketAt(metin: String, yerine: String = " "): String {
        if (!metin.contains('<')) return metin
        val kod = metin.codePoints().toArray()
        val cikti = StringBuilder(metin.length)
        var i = 0
        while (i < kod.size) {
            if (kod[i] == '<'.code) {
                var son = i + 1
                while (son < kod.size && son - i - 1 <= EN_UZUN_ETIKET &&
                    kod[son] != '<'.code && kod[son] != '>'.code
                ) son++
                if (son < kod.size && kod[son] == '>'.code && son - i - 1 <= EN_UZUN_ETIKET) {
                    cikti.append(yerine)
                    i = son + 1
                    continue
                }
            }
            cikti.appendCodePoint(kod[i])
            i++
        }
        return cikti.toString()
    }

    private val ozetleyici = ThreadLocal.withInitial { MessageDigest.getInstance("SHA-256") }
}

/** Pakette bulunan satırın Türkçesi ve geldiği paketin kimliği. */
data class PaketEslesme(val metin: String, val paket: String? = null)

/**
 * Tek bir oyun paketi. Satırlar sıralı anahtar dizisi + tek UTF-8 bloğu
 * olarak tutulur (ikili arama). Satır başına nesne tutulmaz: 40 bin
 * satırlık HashMap'in birkaç katı belleğini istemez.
 */
class HazirPaket private constructor(
    val kimlik: String,
    val baslik: String,
    private val anahtarlar: LongArray,
    private val yerler: IntArray,
    private val blok: ByteArray,
) {
    val satirSayisi: Int get() = anahtarlar.size

    operator fun get(anahtar: Long): String? {
        val i = java.util.Arrays.binarySearch(anahtarlar, anahtar)
        if (i < 0) return null
        return String(blok, yerler[i], yerler[i + 1] - yerler[i], Charsets.UTF_8)
    }

    fun icerir(anahtar: Long): Boolean = java.util.Arrays.binarySearch(anahtarlar, anahtar) >= 0

    companion object {
        /** Gzip'li ya da düz JSON; bozuksa null (çeviri yine çalışsın). */
        fun coz(veri: ByteArray, ad: String): HazirPaket? = try {
            val json = if (veri.size >= 2 && veri[0] == 0x1f.toByte() && veri[1] == 0x8b.toByte())
                GZIPInputStream(ByteArrayInputStream(veri), 1 shl 16).use { it.readBytes() } else veri
            val okunan = PaketJson.oku(String(json, Charsets.UTF_8))
            if (okunan == null || okunan.satirlar.isEmpty()) null
            else kur(
                okunan.kimlik?.takeIf { it.isNotEmpty() } ?: ad,
                okunan.baslik?.takeIf { it.isNotEmpty() } ?: okunan.kimlik ?: ad,
                okunan.satirlar,
            )
        } catch (t: Throwable) {
            null
        }

        /** Anahtar→Türkçe eşlemesinden paket kurar; aynı anahtarda sonuncu kazanır. */
        fun kur(kimlik: String, baslik: String, satirlar: Map<String, String>): HazirPaket? {
            val cift = ArrayList<Pair<Long, String>>(satirlar.size)
            for ((hex, tr) in satirlar) {
                val sayi = PaketAnahtar.sayi(hex.lowercase(Locale.ROOT)) ?: continue
                val temiz = temizle(tr)
                if (temiz.isEmpty()) continue
                cift.add(sayi to temiz)
            }
            if (cift.isEmpty()) return null
            cift.sortBy { it.first }
            val anahtarlar = LongArray(cift.size)
            val yerler = IntArray(cift.size + 1)
            val govde = java.io.ByteArrayOutputStream(cift.size * 24)
            var n = 0
            for ((i, c) in cift.withIndex()) {
                if (i + 1 < cift.size && cift[i + 1].first == c.first) continue
                anahtarlar[n] = c.first
                yerler[n] = govde.size()
                govde.write(c.second.toByteArray(Charsets.UTF_8))
                n++
            }
            yerler[n] = govde.size()
            return HazirPaket(kimlik, baslik, anahtarlar.copyOf(n), yerler.copyOf(n + 1), govde.toByteArray())
        }

        /** Pakette oyunun biçim etiketleri kalmış olabilir; ekranda görünmesinler. */
        fun temizle(metin: String): String {
            if (!metin.contains('<')) return metin.trim()
            return PaketAnahtar.etiketAt(metin, "")
                .split(' ').filter { it.isNotEmpty() }.joinToString(" ").trim()
        }
    }
}
