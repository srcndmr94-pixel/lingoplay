package com.example.altyazi

import java.util.Locale

/**
 * OYUNA GÖRE PAKET SEÇİMİ — 10.63
 *
 * "Oyun açılınca paket kendiliğinden seçilir." Kullanıcının ana ekranda
 * yazdığı oyun adı ("Grand Theft Auto VI", "GTA 6", "gta6") paket
 * başlıklarıyla eşleştirilir.
 *
 * NEDEN GEREKLİ: on paket birden yüklüyken hepsinde birden aramak hem
 * yavaş hem riskli — başka oyunun repliği tutabilir. Doğru paket
 * seçilince arama tek pakette yapılır.
 *
 * EN KRİTİK AYRIM: "GTA V" ile "GTA VI" birbirine karışmamalı. Roma
 * rakamları sayıya çevriliyor (v→5, vi→6), yoksa ikisi de "gta" + bir
 * harf olarak görünüp yanlış paket seçilebilir.
 *
 * Android'e bağlı değil; testten geçiyor.
 */
object PaketSecimi {

    /** Bu eşiğin altındaki benzerlik "eşleşme yok" sayılır. */
    const val ESIK = 0.60

    private val ROMA = mapOf(
        "i" to "1", "ii" to "2", "iii" to "3", "iv" to "4", "v" to "5", "vi" to "6",
        "vii" to "7", "viii" to "8", "ix" to "9", "x" to "10", "xi" to "11", "xii" to "12",
    )

    /** Eşleşmeye katılmayan dolgu sözcükler. */
    private val DOLGU = setOf("the", "of", "and", "a", "an", "edition", "remastered", "definitive")

    /** Küçük harf + yalnız harf/rakam; Türkçe I tuzağı için ROOT. */
    fun parcala(ad: String): List<String> =
        ad.lowercase(Locale.ROOT)
            .split(Regex("[^\\p{L}0-9]+"))
            .filter { it.isNotEmpty() && it !in DOLGU }
            .map { ROMA[it] ?: it }
            .flatMap { ayirHarfRakam(it) }

    /** "gta6" → ["gta","6"]; harf ve rakam bitişikse ayrılır. */
    private fun ayirHarfRakam(parca: String): List<String> {
        if (parca.none { it.isDigit() } || parca.all { it.isDigit() }) return listOf(parca)
        val sonuc = ArrayList<String>()
        val sb = StringBuilder()
        var rakamdi = parca[0].isDigit()
        for (c in parca) {
            if (c.isDigit() != rakamdi) {
                if (sb.isNotEmpty()) sonuc.add(sb.toString())
                sb.setLength(0); rakamdi = c.isDigit()
            }
            sb.append(c)
        }
        if (sb.isNotEmpty()) sonuc.add(sb.toString())
        return sonuc.map { ROMA[it] ?: it }
    }

    /** Ardışık sözcüklerin baş harfleri: ["grand","theft","auto"] → "gta" */
    private fun basHarfler(parcalar: List<String>): Set<String> {
        val harfli = parcalar.filter { it.first().isLetter() }
        val sonuc = HashSet<String>()
        for (bas in harfli.indices) {
            val sb = StringBuilder()
            for (i in bas until harfli.size) {
                sb.append(harfli[i].first())
                if (sb.length >= 2) sonuc.add(sb.toString())
            }
        }
        return sonuc
    }

    /**
     * 0..1 arası benzerlik. Kullanıcının yazdığı her anlamlı parçanın
     * paket adında karşılığı var mı diye bakılır; kısaltmalar
     * ("gta" ↔ "grand theft auto") baş harflerle yakalanır.
     */
    fun benzerlik(yazilan: String, paketAdi: String): Double {
        val a = parcala(yazilan)
        val b = parcala(paketAdi)
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val bKume = b.toSet()
        val bBas = basHarfler(b)
        var tutan = 0.0
        for (p in a) {
            tutan += when {
                p in bKume -> 1.0
                p in bBas -> 1.0
                // Rakam tutmazsa ceza: "gta 5" ile "gta 6" karışmasın.
                p.all { it.isDigit() } -> 0.0
                b.any { it.length >= 4 && p.length >= 4 && (it.startsWith(p) || p.startsWith(it)) } -> 0.7
                else -> 0.0
            }
        }
        val oran = tutan / a.size
        // Kullanıcı rakam yazdıysa ve paketin rakamı başkaysa eşleşme yok.
        val aRakam = a.filter { it.all(Char::isDigit) }.toSet()
        val bRakam = b.filter { it.all(Char::isDigit) }.toSet()
        if (aRakam.isNotEmpty() && bRakam.isNotEmpty() && aRakam.intersect(bRakam).isEmpty()) return 0.0
        return oran
    }

    /** En iyi eşleşen paketin dizini; yoksa null. */
    fun sec(yazilan: String, paketAdlari: List<String>): Int? {
        if (yazilan.isBlank() || paketAdlari.isEmpty()) return null
        var enIyi = -1
        var enIyiPuan = 0.0
        for ((i, ad) in paketAdlari.withIndex()) {
            val p = benzerlik(yazilan, ad)
            if (p > enIyiPuan) { enIyiPuan = p; enIyi = i }
        }
        return if (enIyiPuan >= ESIK && enIyi >= 0) enIyi else null
    }
}
