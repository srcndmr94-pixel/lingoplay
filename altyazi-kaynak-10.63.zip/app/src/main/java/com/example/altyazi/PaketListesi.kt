package com.example.altyazi

/**
 * PAKET SUNUCUSU CEVABI VE YEREL KÜNYE — 10.62
 *
 * İki küçük JSON biçimi okunur/yazılır:
 *   sunucu listesi : {"packs":[{"id":…,"title":…,"version":…,"sha256":…,"size":…,"entries":…}, …]}
 *   yerel künye    : {"checked":…,"packs":[{…,"bundled":true|false}, …]}
 *
 * org.json yerine elde yazıldı: org.json Android'e bağlı, o kullanılsaydı
 * indirme mantığı telefona kurulmadan test edilemezdi. Buradaki her şey
 * saf Kotlin, bu yüzden sahte sunucuyla baştan sona sınanabiliyor.
 */
object PaketListesi {

    /** Sunucudaki bir paket. */
    data class Uzak(
        val kimlik: String,
        val baslik: String,
        val surum: Long,
        val sha256: String,
        val boyut: Long = 0,
        val satir: Int = 0,
    )

    /** Telefonda duran bir paket. [uygulamada] true ise dosyası yok, APK'dan geliyor. */
    data class Yerel(
        val kimlik: String,
        val baslik: String,
        val surum: Long,
        val sha256: String,
        val uygulamada: Boolean = false,
    )

    data class Kunye(val bakildi: Long, val paketler: List<Yerel>)

    /** Sunucu listesini çözer; bozuksa boş liste (çeviri yine çalışsın). */
    fun sunucuCevabi(govde: String): List<Uzak> = nesneler(govde, "packs").mapNotNull { alan ->
        val kimlik = alan["id"] ?: return@mapNotNull null
        val sha = alan["sha256"] ?: return@mapNotNull null
        if (kimlik.isBlank() || sha.isBlank()) return@mapNotNull null
        Uzak(
            kimlik = kimlik,
            baslik = alan["title"]?.takeIf { it.isNotBlank() } ?: kimlik,
            surum = alan["version"]?.toLongOrNull() ?: 0L,
            sha256 = sha.lowercase(),
            boyut = alan["size"]?.toLongOrNull() ?: 0L,
            satir = alan["entries"]?.toIntOrNull() ?: 0,
        )
    }

    fun kunyeOku(govde: String): Kunye {
        val bakildi = ustAlan(govde, "checked")?.toLongOrNull() ?: 0L
        val paketler = nesneler(govde, "packs").mapNotNull { alan ->
            val kimlik = alan["id"] ?: return@mapNotNull null
            Yerel(
                kimlik = kimlik,
                baslik = alan["title"]?.takeIf { it.isNotBlank() } ?: kimlik,
                surum = alan["version"]?.toLongOrNull() ?: 0L,
                sha256 = (alan["sha256"] ?: "").lowercase(),
                uygulamada = alan["bundled"] == "true",
            )
        }
        return Kunye(bakildi, paketler)
    }

    fun kunyeYaz(bakildi: Long, paketler: List<Yerel>): String = buildString {
        append("{\"checked\":").append(bakildi).append(",\"packs\":[")
        paketler.forEachIndexed { i, p ->
            if (i > 0) append(',')
            append("{\"id\":").append(kacir(p.kimlik))
            append(",\"title\":").append(kacir(p.baslik))
            append(",\"version\":").append(p.surum)
            append(",\"sha256\":").append(kacir(p.sha256))
            append(",\"bundled\":").append(p.uygulamada)
            append('}')
        }
        append("]}")
    }

    fun kacir(s: String): String = buildString {
        append('"')
        for (c in s) when (c) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (c < ' ') append(String.format("\\u%04x", c.code)) else append(c)
        }
        append('"')
    }

    /** Üst düzey basit alanın ham değeri ("checked" gibi). */
    private fun ustAlan(govde: String, ad: String): String? {
        val desen = Regex("\"" + Regex.escape(ad) + "\"\\s*:\\s*(-?[0-9]+|true|false)")
        return desen.find(govde)?.groupValues?.get(1)
    }

    /**
     * `"<ad>": [ {...}, {...} ]` dizisindeki her nesnenin basit alanlarını
     * (dize/sayı/bool) harita olarak döndürür. İç içe nesne/dizi atlanır.
     */
    private fun nesneler(govde: String, ad: String): List<Map<String, String>> {
        val bas = govde.indexOf("\"$ad\"")
        if (bas < 0) return emptyList()
        var i = govde.indexOf('[', bas)
        if (i < 0) return emptyList()
        val sonuc = ArrayList<Map<String, String>>()
        var derinlik = 0
        var nesneBas = -1
        while (i < govde.length) {
            when (govde[i]) {
                '"' -> { i = dizeSonu(govde, i) ?: return sonuc; continue }
                '{' -> { if (derinlik == 0) nesneBas = i; derinlik++ }
                '}' -> {
                    derinlik--
                    if (derinlik == 0 && nesneBas >= 0) {
                        sonuc.add(alanlar(govde.substring(nesneBas, i + 1)))
                        nesneBas = -1
                    }
                }
                ']' -> if (derinlik == 0) return sonuc
            }
            i++
        }
        return sonuc
    }

    private fun alanlar(nesne: String): Map<String, String> {
        val harita = LinkedHashMap<String, String>()
        val desen = Regex("\"([^\"\\\\]+)\"\\s*:\\s*(?:\"((?:[^\"\\\\]|\\\\.)*)\"|(-?[0-9]+(?:\\.[0-9]+)?|true|false|null))")
        for (m in desen.findAll(nesne)) {
            val ad = m.groupValues[1]
            val dize = m.groups[2]?.value
            val ham = m.groups[3]?.value
            harita[ad] = if (dize != null) cozKacis(dize) else (ham ?: "")
        }
        return harita
    }

    private fun cozKacis(s: String): String {
        if (!s.contains('\\')) return s
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '\\') { sb.append(c); i++; continue }
            i++
            if (i >= s.length) break
            when (val k = s[i]) {
                'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t')
                'b' -> sb.append('\b'); 'f' -> sb.append('\u000C')
                'u' -> {
                    if (i + 4 < s.length) {
                        s.substring(i + 1, i + 5).toIntOrNull(16)?.let { sb.append(it.toChar()) }
                        i += 4
                    }
                }
                else -> sb.append(k)
            }
            i++
        }
        return sb.toString()
    }

    private fun dizeSonu(s: String, bas: Int): Int? {
        var i = bas + 1
        while (i < s.length) {
            if (s[i] == '\\') { i += 2; continue }
            if (s[i] == '"') return i + 1
            i++
        }
        return null
    }
}
