// SPDX-License-Identifier: AGPL-3.0-only
// Fikir kaynağı: CouchSubs (Copyright (C) 2026 Sinan Yorulmaz), AGPL-3.0.
package com.example.altyazi

/**
 * HAZIR PAKETTE ARAMA — 10.61
 *
 * Kurallar bilerek dar: belirsizlikte null döner ve satır normal çeviri
 * zincirine (OPUS-MT / Google) gider. Yanlış bir hazır çeviri basmak,
 * motoru bekleyip doğrusunu almaktan kötüdür.
 *
 * Android'e bağlı değil; testten geçiyor.
 */
object PaketArama {

    /** "Turn Right 43 m" gibi tam eşleşen yön komutları. */
    private val yonler = Regex(
        """(?i)^\s*(turn|keep)\s+(left|right)(?:\s+([0-9]{1,4}|[Oo])\s*m)?\s*[.!]?\s*$"""
    )

    /** "JASON:" / "Mary Ann:" gibi konuşan öneki. */
    private val konusanOneki = Regex(
        """^([\p{Lu}][\p{L}'’-]{1,24}(?:\s+[\p{Lu}][\p{L}'’-]{1,19})?):\s*(.+)$"""
    )

    /**
     * Yalnız kesin yön komutlarını çevirir, mesafeyi koruyarak.
     * OCR'ın "0" yerine "O" okuması özel olarak ele alınır.
     * "Turn Left 39 km" ya da "North Vice Ave Turn Right 39 m" eşleşmez:
     * cümlenin tamamı komut değilse dokunulmaz.
     */
    fun yon(ham: String): PaketEslesme? {
        val temiz = ham.replace('\n', ' ').replace(Regex("""\s+"""), " ").trim()
        val m = yonler.matchEntire(temiz) ?: return null
        val fiil = m.groupValues[1].lowercase()
        val sol = m.groupValues[2].equals("left", ignoreCase = true)
        val komut = when (fiil) {
            "turn" -> if (sol) "Sola dön" else "Sağa dön"
            "keep" -> if (sol) "Soldan devam et" else "Sağdan devam et"
            else -> return null
        }
        val hamMetre = m.groupValues[3]
        val metre = if (hamMetre.equals("O", ignoreCase = true)) "0" else hamMetre
        return PaketEslesme(komut + if (metre.isBlank()) "" else " $metre m", "yon-komutlari")
    }

    /**
     * Önce satırın tamamı aranır. Bulunamazsa konuşan öneki ayrılıp gövde
     * aranır ve ad geri takılır — paket "JASON: Tamam." biçiminde değil,
     * "Tamam." biçiminde tutulduğu için.
     *
     * Çift etiket olmaz: paketten gelen değer zaten aynı adla başlıyorsa
     * ad ikinci kez eklenmez.
     */
    fun ara(ham: String, tam: (String) -> PaketEslesme?): PaketEslesme? {
        yon(ham)?.let { return it }
        val kirpik = ham.trim()
        val m = konusanOneki.matchEntire(kirpik)
        val ad = m?.groupValues?.get(1) ?: ""

        tam(ham)?.let { return adiKoru(it, ad) }
        if (kirpik != ham) tam(kirpik)?.let { return adiKoru(it, ad) }
        if (m == null) return null
        val govde = m.groupValues[2].trim()
        if (govde.isEmpty()) return null
        val bulunan = tam(govde) ?: return null
        return adiKoru(bulunan, ad)
    }

    /**
     * Konuşan adını korur.
     *
     * NEDEN: paket "Jason: Hello?" satırını da anahtarlıyor ama Türkçesini
     * adsız ("Alo?") tutuyor. Adı geri takmazsak ekranda kimin konuştuğu
     * kayboluyordu — oysa motora giden satırda ad duruyor, yani hazır
     * paket devreye girince konuşan adı sessizce siliniyordu.
     * Paketten gelen değer zaten adla başlıyorsa ikinci kez eklenmez.
     */
    private fun adiKoru(eslesme: PaketEslesme, ad: String): PaketEslesme? {
        val metin = eslesme.metin.trim()
        if (metin.isBlank()) return null
        if (ad.isEmpty()) return eslesme.copy(metin = metin)
        if (metin.startsWith("$ad:", ignoreCase = true)) return eslesme.copy(metin = metin)
        return eslesme.copy(metin = "$ad: $metin")
    }
}
