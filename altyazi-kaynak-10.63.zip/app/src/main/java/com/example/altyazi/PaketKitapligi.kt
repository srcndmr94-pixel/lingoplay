package com.example.altyazi

import android.content.Context
import java.io.File

/**
 * HAZIR PAKET KİTAPLIĞI — 10.61
 *
 * Uygulamayla gelen paketler (assets) ve kullanıcının kendi koyduğu
 * paketler (filesDir/paketler) okunur. Aynı anahtar birden çok pakette
 * varsa SONRAKİ kazanır; kullanıcının paketi uygulamanınkini ezer.
 *
 * Yükleme bir kez, arka planda yapılır. Yükleme bitmeden gelen satır
 * paketi beklemez: null döner ve normal çeviri zinciri çalışır. Hazır
 * paket bir hızlandırma; hiçbir koşulda çeviriyi geciktirmemeli.
 */
object PaketKitapligi {

    /** Kullanıcının kendi paketlerini koyacağı klasörün adı. */
    const val KULLANICI_KLASORU = "paketler"

    @Volatile private var paketler: List<HazirPaket> = emptyList()
    @Volatile private var yuklendi = false
    @Volatile private var yukleniyor = false
    @Volatile var sonDurum: String = "yüklenmedi"
        private set

    /** Ana ekranda "… paketi kullanılıyor" için: son isabetin paketi. */
    @Volatile var sonPaket: String? = null
        private set

    val hazir: Boolean get() = yuklendi
    val satirSayisi: Int get() = paketler.sumOf { it.satirSayisi }
    val paketAdlari: List<String> get() = paketler.map { it.baslik }

    /**
     * Arka planda yükler. Birden çok kez çağrılabilir; yalnız ilki iş yapar.
     * Çeviri başlarken çağrılır, ilk replik beklemesin.
     */
    fun isit(context: Context) {
        if (yuklendi || yukleniyor) return
        yukleniyor = true
        val uygulama = context.applicationContext
        Thread {
            try {
                yukle(uygulama)
            } catch (t: Throwable) {
                sonDurum = "yüklenemedi: ${t.javaClass.simpleName}"
            } finally {
                yuklendi = true
                yukleniyor = false
            }
        }.apply { isDaemon = true; name = "paket-yukle" }.start()
    }

    private fun yukle(context: Context) {
        val bulunan = ArrayList<HazirPaket>()
        val notlar = ArrayList<String>()

        // 1) Uygulamayla gelenler
        val varliklar = try {
            context.assets.list("")?.filter { paketDosyasiMi(it) }?.sorted() ?: emptyList()
        } catch (t: Throwable) {
            emptyList()
        }
        for (ad in varliklar) {
            val veri = try {
                context.assets.open(ad).use { it.readBytes() }
            } catch (t: Throwable) {
                notlar.add("$ad okunamadı"); continue
            }
            val paket = HazirPaket.coz(veri, temelAd(ad))
            if (paket == null) notlar.add("$ad çözülemedi") else bulunan.add(paket)
        }

        // 2) Kullanıcının kendi paketleri (aynı kimlik varsa onunki geçerli)
        val klasor = File(context.filesDir, KULLANICI_KLASORU)
        if (klasor.isDirectory) {
            val dosyalar = klasor.listFiles()?.filter { it.isFile && paketDosyasiMi(it.name) }?.sortedBy { it.name }
            for (dosya in dosyalar.orEmpty()) {
                val veri = try {
                    dosya.readBytes()
                } catch (t: Throwable) {
                    notlar.add("${dosya.name} okunamadı"); continue
                }
                val paket = HazirPaket.coz(veri, temelAd(dosya.name))
                if (paket == null) { notlar.add("${dosya.name} çözülemedi"); continue }
                bulunan.removeAll { it.kimlik == paket.kimlik }
                bulunan.add(paket)
            }
        }

        paketler = bulunan
        sonDurum = if (bulunan.isEmpty()) {
            "paket yok" + if (notlar.isEmpty()) "" else " (${notlar.joinToString("; ")})"
        } else {
            "${bulunan.size} paket · ${bulunan.sumOf { it.satirSayisi }} satır" +
                if (notlar.isEmpty()) "" else " (${notlar.joinToString("; ")})"
        }
    }

    /** Ayarlardan paket silinince/eklenince yeniden okunsun. */
    fun unut() {
        paketler = emptyList()
        yuklendi = false
        sonDurum = "yüklenmedi"
        sonPaket = null
    }

    /**
     * Satırın hazır paketteki Türkçesi; yoksa null.
     * Yükleme bitmediyse beklemeden null döner.
     */
    fun bul(metin: String): PaketEslesme? {
        if (!yuklendi) return null
        val su = paketler
        if (su.isEmpty()) return null
        val eslesme = PaketArama.ara(metin) { parca -> tamAra(su, parca) } ?: return null
        sonPaket = eslesme.paket
        return eslesme
    }

    /** Sondan başa: sonra yüklenen paket önce kazanır. */
    private fun tamAra(su: List<HazirPaket>, parca: String): PaketEslesme? {
        val sayi = PaketAnahtar.anahtarSayisi(parca) ?: return null
        for (i in su.indices.reversed()) {
            su[i][sayi]?.let { return PaketEslesme(it, su[i].kimlik) }
        }
        return null
    }

    /** İndirilen paketlerin durduğu klasör (okunan kullanıcı klasörünün aynısı). */
    fun klasor(context: Context): File = File(context.filesDir, KULLANICI_KLASORU)

    /**
     * 10.62 — Sunucudaki ücretsiz oyun paketleri.
     *
     * Uygulamayla gelen paketlerin SHA-256'ları depoya veriliyor; sunucudaki
     * sürüm aynıysa boşuna indirilmiyor.
     */
    fun depo(context: Context, sunucu: PaketSunucu = HttpPaketSunucu()): PaketDeposu {
        val uygulama = context.applicationContext
        return PaketDeposu(
            klasor = klasor(uygulama),
            sunucu = sunucu,
            uygulamaOzetleri = {
                val ozetler = HashSet<String>()
                try {
                    uygulama.assets.list("")?.filter { paketDosyasiMi(it) }?.forEach { ad ->
                        runCatching {
                            uygulama.assets.open(ad).use { ozetler.add(PaketDeposu.sha256(it.readBytes())) }
                        }
                    }
                } catch (t: Throwable) {
                    // Özet çıkaramazsak en kötü ihtimalle paket bir kez fazladan iner.
                }
                ozetler
            },
        )
    }

    /**
     * Paketleri arka planda yeniler ve bitince kitaplığı yeniden okur.
     * [bitince] ana iş parçacığında değil, indiren iş parçacığında çağrılır.
     */
    fun guncelle(context: Context, zorla: Boolean, bitince: (PaketDeposu.Yenileme) -> Unit) {
        val uygulama = context.applicationContext
        Thread {
            val sonuc = try {
                depo(uygulama).yenile(zorla)
            } catch (t: Throwable) {
                PaketDeposu.Yenileme(hata = t.message ?: t.javaClass.simpleName)
            }
            if (sonuc.inen.isNotEmpty() || sonuc.silinen.isNotEmpty()) {
                unut()
                isit(uygulama)
            }
            bitince(sonuc)
        }.apply { isDaemon = true; name = "paket-guncelle" }.start()
    }

    fun paketDosyasiMi(ad: String): Boolean = ad.endsWith(".json.gz") || ad.endsWith(".json")

    /** "gta6-live.json.gz" → "gta6-live" */
    fun temelAd(dosyaAdi: String): String {
        var ad = File(dosyaAdi).name
        for (son in listOf(".gz", ".json")) if (ad.endsWith(son)) ad = ad.dropLast(son.length)
        return ad
    }
}
