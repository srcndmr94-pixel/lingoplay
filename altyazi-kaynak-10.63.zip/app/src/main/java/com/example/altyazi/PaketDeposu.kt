// SPDX-License-Identifier: AGPL-3.0-only
// CouchSubs'tan uyarlandı: CouchSubs (Copyright (C) 2026 Sinan Yorulmaz), AGPL-3.0.
// Paket sunucusu ve biçimi CouchSubs'a ait; kaynaktaki not sunucunun
// yazarının izniyle kullanıldığını söylüyor. Bu bildirim kaldırılmamalı.
package com.example.altyazi

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Paket inmedi; [durum] HTTP kodu (429: sınır aşıldı), ağ hatasında null. */
class PaketIndirmeHatasi(val durum: Int?, mesaj: String) : IOException(mesaj)

/** Paket sunucusu. Gerçeği [HttpPaketSunucu]; testlerde sahtesi konur. */
interface PaketSunucu {
    fun liste(): List<PaketListesi.Uzak>
    fun indir(kimlik: String): ByteArray
}

/**
 * OYUN PAKETİ DEPOSU — 10.62
 *
 * Sunucudaki ücretsiz oyun paketleri (GTA VI 707 bin satır, GTA V, Elden
 * Ring, Mafia…) indirilir, SHA-256 ile doğrulanır, uygulamanın paket
 * klasörüne konur ve haftada bir yenilenir.
 *
 * Kurallar:
 * • Sürümü ve özeti değişmeyen paket yeniden inmez.
 * • Özet tutmazsa dosya atılır; yarım ya da bozuk paket asla yüklenmez
 *   (önce geçici dosyaya yazılır, doğrulanınca yerine konur).
 * • Sunucudan kalkan paket telefondan da silinir.
 * • Bir paket inemezse eldeki sürümü kalır ve bir sonraki açılışta
 *   yeniden denenir (kontrol zamanı ilerletilmez).
 * • Uygulamayla gelen paketin aynısı indirilmez.
 *
 * Ağ dışındaki her şey saf Kotlin: testlerde sahte sunucuyla sınanıyor.
 */
class PaketDeposu(
    private val klasor: File,
    private val sunucu: PaketSunucu,
    private val saat: () -> Long = System::currentTimeMillis,
    private val uygulamaOzetleri: () -> Set<String> = { emptySet() },
) {
    companion object {
        const val YENILEME_ARALIGI_MS = 7L * 24 * 60 * 60 * 1000
        const val VARSAYILAN_ADRES = "https://couchsubs-packs.enmera.workers.dev"
        private const val KUNYE = "paketler.state"

        fun sha256(veri: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(veri)
                .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    /** Yenilemenin sonucu. [atlandi] true ise süresi gelmediği için bakılmadı. */
    data class Yenileme(
        val inen: List<String> = emptyList(),
        val silinen: List<String> = emptyList(),
        val atlandi: Boolean = false,
        val hata: String? = null,
    )

    private val kilit = Any()

    val dizin: File get() = klasor

    /** Yüklenmeye hazır, doğrulanmış paket dosyaları. */
    fun dosyalar(): List<File> = synchronized(kilit) {
        kunyeOku().paketler.filter { !it.uygulamada }
            .mapNotNull { p -> paketDosyasi(p.kimlik).takeIf { it.isFile } }
    }

    fun kurulular(): List<PaketListesi.Yerel> =
        synchronized(kilit) { kunyeOku().paketler.filter { !it.uygulamada } }

    val sonBakis: Long get() = synchronized(kilit) { kunyeOku().bakildi }

    /** Süresi geldiyse (ya da [zorla]) sunucuya bakar ve değişenleri indirir. Bloklar. */
    fun yenile(zorla: Boolean = false): Yenileme = synchronized(kilit) {
        val mevcutKunye = kunyeOku()
        val simdiki = mevcutKunye.paketler
        if (!zorla && simdiki.isNotEmpty() && saat() - mevcutKunye.bakildi < YENILEME_ARALIGI_MS) {
            return Yenileme(atlandi = true)
        }
        val uzak = try {
            sunucu.liste()
        } catch (t: Throwable) {
            return Yenileme(hata = t.message ?: "liste alınamadı")
        }
        klasor.mkdirs()
        val kalan = ArrayList<PaketListesi.Yerel>()
        val inen = ArrayList<String>()
        var uygulamadakiler: Set<String>? = null

        for (paket in uzak) {
            val eski = simdiki.firstOrNull { it.kimlik == paket.kimlik }
            val dosya = paketDosyasi(paket.kimlik)

            if (eski != null && eski.uygulamada && eski.surum == paket.surum &&
                eski.sha256.equals(paket.sha256, true)
            ) { kalan.add(eski); continue }

            if (eski != null && !eski.uygulamada && eski.surum == paket.surum &&
                eski.sha256.equals(paket.sha256, true) && dosya.isFile &&
                sha256(dosya.readBytes()).equals(paket.sha256, true)
            ) { kalan.add(eski); continue }

            val icerde = uygulamadakiler
                ?: runCatching { uygulamaOzetleri() }.getOrDefault(emptySet()).also { uygulamadakiler = it }
            if (paket.sha256.lowercase() in icerde) {
                dosya.delete()
                kalan.add(PaketListesi.Yerel(paket.kimlik, paket.baslik, paket.surum, paket.sha256.lowercase(), true))
                continue
            }

            val veri = try {
                sunucu.indir(paket.kimlik)
            } catch (hata: Throwable) {
                if (eski != null && !eski.uygulamada && dosya.isFile) kalan.add(eski.copy(surum = -1))
                continue
            }
            if (!sha256(veri).equals(paket.sha256, true)) {
                if (eski != null && !eski.uygulamada && dosya.isFile) kalan.add(eski.copy(surum = -1))
                continue
            }
            val gecici = File(klasor, "${paket.kimlik}.indiriliyor")
            gecici.writeBytes(veri)
            if (!gecici.renameTo(dosya)) {
                dosya.delete()
                if (!gecici.renameTo(dosya)) { gecici.delete(); continue }
            }
            kalan.add(PaketListesi.Yerel(paket.kimlik, paket.baslik, paket.surum, paket.sha256.lowercase()))
            inen.add(paket.kimlik)
        }

        val silinen = simdiki.filter { y -> !y.uygulamada && uzak.none { it.kimlik == y.kimlik } }.map { it.kimlik }
        silinen.forEach { paketDosyasi(it).delete() }
        // İnemeyen paket varsa kontrol zamanı ilerletilmez: sonraki açılışta yeniden denensin.
        val tekrar = kalan.any { it.surum == -1L }
        kunyeYaz(if (tekrar) mevcutKunye.bakildi else saat(), kalan)
        Yenileme(inen, silinen)
    }

    /** "İndirilen paketleri sil". */
    fun temizle() = synchronized(kilit) { klasor.listFiles()?.forEach { it.delete() } }

    private fun paketDosyasi(kimlik: String) = File(klasor, "$kimlik.json.gz")

    private fun kunyeOku(): PaketListesi.Kunye {
        val dosya = File(klasor, KUNYE)
        if (!dosya.isFile) return PaketListesi.Kunye(0L, emptyList())
        return try {
            PaketListesi.kunyeOku(dosya.readText())
        } catch (t: Throwable) {
            PaketListesi.Kunye(0L, emptyList())
        }
    }

    private fun kunyeYaz(bakildi: Long, paketler: List<PaketListesi.Yerel>) {
        val gecici = File(klasor, "$KUNYE.tmp")
        gecici.writeText(PaketListesi.kunyeYaz(bakildi, paketler))
        if (!gecici.renameTo(File(klasor, KUNYE))) {
            File(klasor, KUNYE).delete()
            gecici.renameTo(File(klasor, KUNYE))
        }
    }
}

/** Gerçek sunucu: GET /v1/packs (liste), GET /v1/packs/{kimlik} (gzip paket). */
class HttpPaketSunucu(private val adres: String = PaketDeposu.VARSAYILAN_ADRES) : PaketSunucu {

    override fun liste(): List<PaketListesi.Uzak> =
        PaketListesi.sunucuCevabi(String(istek("$adres/v1/packs"), Charsets.UTF_8))

    override fun indir(kimlik: String): ByteArray = istek("$adres/v1/packs/$kimlik")

    private fun istek(adres: String): ByteArray {
        val baglanti = URL(adres).openConnection() as HttpURLConnection
        try {
            baglanti.connectTimeout = 15_000
            baglanti.readTimeout = 60_000
            val durum = baglanti.responseCode
            if (durum !in 200..299) throw PaketIndirmeHatasi(durum, "HTTP $durum")
            return baglanti.inputStream.use { it.readBytes() }
        } catch (hata: PaketIndirmeHatasi) {
            throw hata
        } catch (hata: IOException) {
            throw PaketIndirmeHatasi(null, hata.message ?: "ağ")
        } finally {
            baglanti.disconnect()
        }
    }
}
