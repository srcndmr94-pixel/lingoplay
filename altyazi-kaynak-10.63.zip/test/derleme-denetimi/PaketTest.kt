package com.example.altyazi

private var g = 0
private var k = 0
private fun ko(ad: String, kosul: Boolean, ek: String = "") {
    if (kosul) g++ else { k++; println("  BASARISIZ: $ad ${if (ek.isNotEmpty()) "-> $ek" else ""}") }
}

fun main(args: Array<String>) {
    println("== PaketAnahtar: sadelestirme ==")
    ko("etiket bosluk olur", PaketAnahtar.sadelestir("<b>Hello</b> there") == "hello there",
        PaketAnahtar.sadelestir("<b>Hello</b> there"))
    ko("noktalama bosluk olur", PaketAnahtar.sadelestir("Okay. Okay.") == "okay okay",
        PaketAnahtar.sadelestir("Okay. Okay."))
    ko("bosluklar teklenir", PaketAnahtar.sadelestir("  a   b  ") == "a b")
    ko("aksan atilir", PaketAnahtar.sadelestir("café") == "cafe", PaketAnahtar.sadelestir("café"))
    ko("rakam kalir", PaketAnahtar.sadelestir("Turn Right 43 m") == "turn right 43 m")
    ko("bos girdi bos cikti", PaketAnahtar.sadelestir("...!!!") == "")
    ko("harf yoksa anahtar null", PaketAnahtar.anahtar("...") == null)
    // Locale tuzagi: Turkce yerel "I" harfini "ı" yapar ve anahtar tutmaz.
    ko("I harfi ROOT ile kucultulur", PaketAnahtar.sadelestir("I DID IT") == "i did it",
        PaketAnahtar.sadelestir("I DID IT"))
    ko("40 karakterden uzun <...> etiket sayilmaz",
        PaketAnahtar.sadelestir("<" + "x".repeat(60) + ">ab").contains("x"))

    println("== PaketAnahtar: hex <-> sayi ==")
    ko("gecersiz uzunluk null", PaketAnahtar.sayi("abc") == null)
    ko("gecersiz harf null", PaketAnahtar.sayi("zzzzzzzzzzzzzzzz") == null)
    ko("16 hane cozulur", PaketAnahtar.sayi("3f8760c1dab36eb5") != null)
    ko("buyuk harf hex de cozulur", PaketAnahtar.sayi("3F8760C1DAB36EB5") == PaketAnahtar.sayi("3f8760c1dab36eb5"))
    ko("anahtar ve anahtarSayisi ayni seyi soyler",
        PaketAnahtar.sayi(PaketAnahtar.anahtar("Hello?")!!) == PaketAnahtar.anahtarSayisi("Hello?"))

    println("== GERCEK PAKETE KARSI CAPA DEGERLER ==")
    // Bu dort deger, paketi ureten CouchSubs semasindan geliyor. Tutmuyorsa
    // sadelestirme adimlarindan biri kaymistir ve 40.718 anahtarin hicbiri tutmaz.
    val capalar = listOf(
        "Okay. Okay." to "3f8760c1dab36eb5",
        "I don't think so." to "cd4d8c4a2ae7661e",
        "Hello?" to "2cf24dba5fb0a30e",
        "Thanks." to "a6a2729cbf6bcadc",
    )
    for ((metin, beklenen) in capalar) {
        ko("anahtar(\"$metin\") == $beklenen", PaketAnahtar.anahtar(metin) == beklenen,
            PaketAnahtar.anahtar(metin) ?: "null")
    }

    println("== PaketJson ==")
    val ornek = """{"format":1,"id":"deneme","title":"Deneme Paketi","entries":{"2cf24dba5fb0a30e":"Alo?"}}"""
    val okunan = PaketJson.oku(ornek)
    ko("json okundu", okunan != null)
    ko("kimlik", okunan?.kimlik == "deneme")
    ko("baslik", okunan?.baslik == "Deneme Paketi")
    ko("satir", okunan?.satirlar?.get("2cf24dba5fb0a30e") == "Alo?")
    ko("duz nesne de kabul", PaketJson.oku("""{"2cf24dba5fb0a30e":"Alo?"}""")?.satirlar?.size == 1)
    ko("kacisli dize", PaketJson.oku("""{"a":"bir \"iki\"\nuc"}""")?.satirlar?.get("a") == "bir \"iki\"\nuc")
    ko("unicode kacisi", PaketJson.oku("""{"a":"İstanbul"}""")?.satirlar?.get("a") == "İstanbul")
    ko("sayi degeri atlanir", PaketJson.oku("""{"format":2,"a":"b"}""")?.satirlar?.get("a") == "b")
    ko("ic ice nesne atlanir",
        PaketJson.oku("""{"fuzzy":{"x":{"y":"z"}},"entries":{"a":"b"}}""")?.satirlar?.get("a") == "b")
    ko("dizi atlanir", PaketJson.oku("""{"liste":[1,2,{"a":"b"}],"entries":{"c":"d"}}""")?.satirlar?.get("c") == "d")
    ko("bozuk json null", PaketJson.oku("""{"a":""") == null)
    ko("json olmayan null", PaketJson.oku("merhaba") == null)

    println("== PaketArama: yon komutlari ==")
    ko("Turn Right 43 m", PaketArama.yon("Turn Right\n43 m")?.metin == "Sağa dön 43 m")
    ko("Turn Left 0 m.", PaketArama.yon("Turn Left 0 m.")?.metin == "Sola dön 0 m")
    ko("Keep Right 102 m", PaketArama.yon("Keep Right\n102 m")?.metin == "Sağdan devam et 102 m")
    ko("Keep Left 9 m", PaketArama.yon("Keep Left 9 m")?.metin == "Soldan devam et 9 m")
    ko("OCR O -> 0", PaketArama.yon("Keep Right\nO m")?.metin == "Sağdan devam et 0 m")
    ko("mesafesiz", PaketArama.yon("Keep Right")?.metin == "Sağdan devam et")
    ko("cumlenin icindeyse eslesmez", PaketArama.yon("North Vice Ave Turn Right 39 m") == null)
    ko("km eslesmez", PaketArama.yon("Turn Left 39 km") == null)
    ko("duz cumle eslesmez", PaketArama.yon("I'm turning right now") == null)

    println("== PaketArama: konusan oneki ==")
    // 10.61'de bilerek degistirildi: tam satir bulunsa bile konusan adi korunur.
    // Kaynak uygulamada ad burada dusuyordu.
    ko("tam satir bulunsa da ad korunur",
        PaketArama.ara("Jason: A new line") { PaketEslesme("Hazır cümle", "t") }?.metin == "Jason: Hazır cümle",
        PaketArama.ara("Jason: A new line") { PaketEslesme("Hazır cümle", "t") }?.metin ?: "null")
    ko("adsiz satirda ad takilmaz",
        PaketArama.ara("A new line") { PaketEslesme("Hazır cümle", "t") }?.metin == "Hazır cümle")
    ko("ad ayrilip geri takilir",
        PaketArama.ara("Jason: A new line") { if (it == "A new line") PaketEslesme("Yeni cümle", "t") else null }
            ?.metin == "Jason: Yeni cümle")
    ko("cift etiket olmaz",
        PaketArama.ara("Jason: A new line") { if (it == "A new line") PaketEslesme("Jason: Yeni cümle", "t") else null }
            ?.metin == "Jason: Yeni cümle")
    ko("bulunamazsa null", PaketArama.ara("Random text") { null } == null)
    // Tam satir bulunamayinca govde bos kaliyorsa null donmeli.
    ko("bos govde null",
        PaketArama.ara("Jason:   ") { if (it.trim() == "Jason:") null else PaketEslesme("x") } == null)
    ko("iki sozcuklu ad", PaketArama.ara("Mary Ann: hi") { if (it == "hi") PaketEslesme("selam") else null }
        ?.metin == "Mary Ann: selam")
    ko("kucuk harfli onek ad sayilmaz", PaketArama.ara("note: hi") { if (it == "hi") PaketEslesme("selam") else null } == null)

    println("== GERCEK PAKET DOSYASI ==")
    val yol = args.firstOrNull()
    if (yol == null) {
        println("  (paket yolu verilmedi, atlandi)")
    } else {
        val veri = java.io.File(yol).readBytes()
        val paket = HazirPaket.coz(veri, "gta6-live")
        ko("paket acildi", paket != null)
        if (paket != null) {
            ko("40718 satir", paket.satirSayisi == 40718, "${paket.satirSayisi}")
            ko("kimlik", paket.kimlik == "gta6-corrected-live-ocr-v2", paket.kimlik)
            val bul = { s: String -> paket[PaketAnahtar.anahtarSayisi(s)!!] }
            ko("Okay. Okay. -> Tamam, tamam.", bul("Okay. Okay.") == "Tamam, tamam.", bul("Okay. Okay.") ?: "null")
            ko("Hello? -> Alo?", bul("Hello?") == "Alo?", bul("Hello?") ?: "null")
            ko("Thanks. -> Sağ ol...", bul("Thanks.") == "Sağ ol...", bul("Thanks.") ?: "null")
            ko("I don't think so. -> Hiç sanmıyorum!", bul("I don't think so.") == "Hiç sanmıyorum!")
            // Buyuk/kucuk harf ve noktalama farki ayni anahtari vermeli.
            ko("buyuk harf farki onemsiz", bul("OKAY. OKAY.") == "Tamam, tamam.")
            ko("fazladan bosluk onemsiz", bul("  Okay.   Okay.  ") == "Tamam, tamam.")
            ko("olmayan satir null", bul("zzzz qqqq yyyy hic olmayan replik") == null)
            // Konusan oneki gercek paketle
            val ara = { s: String -> PaketArama.ara(s) { x ->
                PaketAnahtar.anahtarSayisi(x)?.let { n -> paket[n]?.let { PaketEslesme(it, paket.kimlik) } } } }
            // Paket "Jason: Hello?" satirini adsiz Turkce ile tutuyor; ad korunmali.
            ko("Jason: Hello? -> Jason: Alo?", ara("Jason: Hello?")?.metin == "Jason: Alo?",
                ara("Jason: Hello?")?.metin ?: "null")
            ko("Lucia: Thanks. -> Lucia: Sağ ol...", ara("Lucia: Thanks.")?.metin == "Lucia: Sağ ol...",
                ara("Lucia: Thanks.")?.metin ?: "null")
            ko("adsiz satirda ad eklenmez", ara("Hello?")?.metin == "Alo?")
            ko("eslesmeyen satir null", ara("zzzz qqqq yyyy") == null)
            ko("paket kimligi dondu", ara("Hello?")?.paket == "gta6-corrected-live-ocr-v2")
        }
    }

    println("\nGECTI: $g   KALDI: $k")
    if (k > 0) kotlin.system.exitProcess(1)
}
