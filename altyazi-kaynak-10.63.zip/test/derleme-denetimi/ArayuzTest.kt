import java.io.File

/**
 * ARAYÜZ KURAL DENETİMİ — 10.63
 *
 * enmerasoftware/ai-design-check kural setinden, Android XML düzenine
 * uyan kuralları uyguluyor. O araç web/Compose/SwiftUI okuyor, bizim
 * arayüz klasik XML olduğu için taramıyordu; kuralları elle denetliyoruz.
 *
 * Amaç "bir kez düzeltmek" değil, GERİ GELMESİNİ ENGELLEMEK: yeni bir
 * sürümde biri 11sp etiket ya da büyük harf düğme eklerse test düşer.
 */
private var g = 0
private var k = 0
private fun ko(ad: String, kosul: Boolean, ek: String = "") {
    if (kosul) g++ else { k++; println("  BASARISIZ: $ad${if (ek.isNotEmpty()) " -> $ek" else ""}") }
}

private fun buyukOran(t: String): Double {
    val h = t.filter { it.isLetter() }
    return if (h.isEmpty()) 0.0 else h.count { it.isUpperCase() }.toDouble() / h.length
}

fun main(args: Array<String>) {
    val duzen = File(args[0]).readText()
    val tema = File(args[1]).readText()
    val kodlar = args.drop(2).map { File(it) }.filter { it.isFile }

    val metinler = Regex("""android:text="([^"]+)"""").findAll(duzen)
        .map { it.groupValues[1] }.filter { !it.startsWith("@") }.toList()
    println("denetlenen düzen metni: ${metinler.size}")

    // --- no-tiny-text: 12sp altı yok ---
    val boyutlar = Regex("""android:textSize="([0-9.]+)sp"""").findAll(duzen + tema)
        .map { it.groupValues[1].toDouble() }.toList()
    val kucuk = boyutlar.filter { it < 12.0 }
    ko("no-tiny-text: 12sp altı yazı yok", kucuk.isEmpty(), kucuk.toString())

    // --- no-decorative-uppercase: stilde textAllCaps yok ---
    ko("no-decorative-uppercase: stilde textAllCaps=true yok",
        !tema.contains("<item name=\"android:textAllCaps\">true</item>"))
    ko("no-decorative-uppercase: düzende textAllCaps=true yok",
        !duzen.contains("android:textAllCaps=\"true\""))

    // --- no-crushed/wide tracking: letterSpacing 0.05 üstü yok ---
    val aralik = Regex("""android:letterSpacing="(-?[0-9.]+)"""").findAll(duzen + tema)
        .map { it.groupValues[1].toDouble() }.filter { kotlin.math.abs(it) > 0.05 }.toList()
    ko("tracking: |letterSpacing| 0.05 üstü yok", aralik.isEmpty(), aralik.toString())

    // --- no-all-caps-sentences / no-decorative-uppercase: metinler ---
    val capsMetin = metinler.filter { it.length > 3 && buyukOran(it) > 0.8 && it.count { c -> c.isLetter() } > 3 }
    ko("düzende tamamı büyük harf etiket yok", capsMetin.isEmpty(), capsMetin.toString())

    // --- icons-not-emoji / no-arrow-suffix: ok ve onay simgeleri süs değil ---
    // Simge CÜMLE İÇİNDE anlam taşıyabilir ("ugh → ahh" bir eşleme gösterimi).
    // Kural, etiketin BAŞINDA ya da SONUNDA alışkanlıkla duran süs simgesini
    // hedefliyor; denetim oraya daraltıldı.
    val simge = "→←✓✔★●▶»«⟩⟨›‹"
    val simgeli = metinler.map { it.trim() }
        .filter { it.isNotEmpty() && (it.first() in simge || it.last() in simge) }
    ko("etiketin başında/sonunda süs simgesi yok", simgeli.isEmpty(), simgeli.take(3).toString())

    // --- no-trailing-period-labels: kısa etiket sonu nokta değil ---
    // Yalnız DÜĞME ve onay kutusu metinleri; ipucu cümleleri hariç.
    val dugmeMetni = Regex("""<(?:Button|CheckBox|RadioButton)\b[^>]*?android:text="([^"]+)"""", RegexOption.DOT_MATCHES_ALL)
        .findAll(duzen).map { it.groupValues[1] }.toList()
    // Kural KISA etiketler için; açıklama cümlesi taşıyan onay kutuları hariç.
    val noktali = dugmeMetni.filter {
        it.length <= 40 && it.trimEnd().endsWith(".") && !it.trimEnd().endsWith("...")
    }
    ko("no-trailing-period-labels: kısa etiket sonu nokta değil", noktali.isEmpty(), noktali.toString())

    // --- tap-target: elle yükseklik verilen düğme 48dp altı olmasın ---
    val dugmeYukseklik = Regex("""<Button\b[^>]*?android:layout_height="([0-9]+)dp"""", RegexOption.DOT_MATCHES_ALL)
        .findAll(duzen).map { it.groupValues[1].toInt() }.filter { it < 48 }.toList()
    ko("tap-target: düğme yüksekliği 48dp altı değil", dugmeYukseklik.isEmpty(), dugmeYukseklik.toString())

    // --- text-off-viewport-edge: kök dolgu en az 12dp ---
    val dolgu = Regex("""android:padding(?:Start|Horizontal)?="([0-9]+)dp"""").findAll(duzen)
        .map { it.groupValues[1].toInt() }.toList()
    ko("kenar boşluğu tanımlı", dolgu.isNotEmpty())

    // --- Kodla kurulan düğmeler AppCompat'tan büyük harf almasın ---
    for (dosya in kodlar) {
        val kod = dosya.readText()
        val kurulan = Regex("""Button\([A-Za-z]+\)\.apply \{""").findAll(kod).count()
        val kapatilan = Regex("""isAllCaps = false""").findAll(kod).count()
        if (kurulan > 0) {
            ko("${dosya.name}: kodla kurulan $kurulan düğmede büyük harf kapalı",
                kapatilan >= kurulan, "kapatılan=$kapatilan")
        }
        // Koddaki kullanıcıya görünen büyük harf etiketler
        val kodCaps = Regex(""""([A-ZÇĞİÖŞÜ][A-ZÇĞİÖŞÜ0-9 ()./·~-]{8,})"""").findAll(kod)
            .map { it.groupValues[1] }
            .filter { it !in setOf("OPUS-MT EN-TR (ONNX)") }   // motor adı, özel ad
            .filter { !kod.contains("log(\"$it") }
            .toList()
        ko("${dosya.name}: kullanıcıya görünen büyük harf etiket yok", kodCaps.isEmpty(), kodCaps.take(3).toString())
    }

    println("\nGECTI: $g   KALDI: $k")
    if (k > 0) kotlin.system.exitProcess(1)
}
