package android.content.res;

import java.io.IOException;
import java.io.InputStream;

public class AssetManager {
    public String[] list(String path) throws IOException { return new String[0]; }
    public InputStream open(String name) throws IOException { return null; }
}
