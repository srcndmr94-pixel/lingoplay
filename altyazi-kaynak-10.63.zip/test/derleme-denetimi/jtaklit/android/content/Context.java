package android.content;
import java.io.File;
public class Context {
    public static final int MODE_PRIVATE = 0;
    public Context getApplicationContext() { return this; }
    public File getCacheDir() { return new File("/tmp"); }
    public SharedPreferences getSharedPreferences(String name, int mode) { return null; }
    public int checkSelfPermission(String perm) { return 0; }
    public static final String CLIPBOARD_SERVICE = "clipboard";
    public Object getSystemService(String name) { return null; }
    public ContentResolver getContentResolver() { return new ContentResolver(); }
    public android.content.res.AssetManager getAssets() { return null; }
    public java.io.File getFilesDir() { return null; }
}
