package com.example.altyazi

import java.io.File

private var g = 0
private var k = 0
private fun ko(ad: String, kosul: Boolean, ek: String = "") {
    if (kosul) g++ else { k++; println("  BASARISIZ: $ad ${if (ek.isNotEmpty()) "-> $ek" else ""}") }
}

class SahteSunucu(
    var paketler: MutableMap<String, ByteArray> = LinkedHashMap(),
    var basliklar: MutableMap<String, String> = LinkedHashMap(),
    var surumler: MutableMap<String, Long> = LinkedHashMap(),
) : PaketSunucu {
    var listeCagrisi = 0
    var indirmeCagrisi = 0
    var bozukOzet: String? = null
    var dusenler: MutableSet<String> = mutableSetOf()
    var listeHata: Throwable? = null

    override fun liste(): List<PaketListesi.Uzak> {
        listeCagrisi++
        listeHata?.let { throw it }
        return paketler.map { (id, veri) ->
            PaketListesi.Uzak(id, basliklar[id] ?: id, surumler[id] ?: 1L,
                bozukOzet ?: PaketDeposu.sha256(veri), veri.size.toLong(), 10)
        }
    }

    override fun indir(kimlik: String): ByteArray {
        indirmeCagrisi++
        if (kimlik in dusenler) throw PaketIndirmeHatasi(429, "sınır")
        return paketler[kimlik] ?: throw PaketIndirmeHatasi(404, "yok")
    }
}

private fun gecici(ad: String): File =
    File(System.getProperty("java.io.tmpdir"), "depo-$ad-${System.nanoTime()}").also { it.mkdirs() }

fun main() {
    println("== PaketListesi ==")
    val cevap = """{"packs":[
      {"id":"gta6","title":"Grand Theft Auto VI","version":17,"sha256":"AABB","size":9,"entries":707000},
      {"id":"gta5","title":"Grand Theft Auto V","version":3,"sha256":"ccdd","size":4,"entries":197000}]}"""
    val uzak = PaketListesi.sunucuCevabi(cevap)
    ko("iki paket okundu", uzak.size == 2, "${uzak.size}")
    ko("kimlik", uzak[0].kimlik == "gta6")
    ko("baslik", uzak[0].baslik == "Grand Theft Auto VI")
    ko("surum sayi olarak", uzak[0].surum == 17L)
    ko("sha kucuk harfe cevrildi", uzak[0].sha256 == "aabb")
    ko("satir sayisi", uzak[0].satir == 707000)
    ko("ikinci paket", uzak[1].kimlik == "gta5" && uzak[1].surum == 3L)
    ko("sha yoksa atlanir",
        PaketListesi.sunucuCevabi("""{"packs":[{"id":"x","version":1}]}""").isEmpty())
    ko("bozuk govde bos liste", PaketListesi.sunucuCevabi("merhaba").isEmpty())
    ko("bos packs", PaketListesi.sunucuCevabi("""{"packs":[]}""").isEmpty())
    ko("kacisli baslik",
        PaketListesi.sunucuCevabi("""{"packs":[{"id":"a","title":"Bir \"iki\"","sha256":"ff"}]}""")[0].baslik == "Bir \"iki\"")

    println("== kunye yaz/oku ==")
    val yerel = listOf(
        PaketListesi.Yerel("gta6", "Grand Theft Auto VI", 17, "aabb", false),
        PaketListesi.Yerel("gta5", "GTA \"V\"", 3, "ccdd", true),
    )
    val yazili = PaketListesi.kunyeYaz(1234567890L, yerel)
    val geri = PaketListesi.kunyeOku(yazili)
    ko("bakildi korunur", geri.bakildi == 1234567890L, "${geri.bakildi}")
    ko("iki paket", geri.paketler.size == 2)
    ko("uygulamada bayragi", geri.paketler[1].uygulamada && !geri.paketler[0].uygulamada)
    ko("tirnakli baslik korunur", geri.paketler[1].baslik == "GTA \"V\"", geri.paketler[1].baslik)
    ko("bos kunye", PaketListesi.kunyeOku("{}").paketler.isEmpty())

    println("== PaketDeposu: indirme ==")
    val s = SahteSunucu()
    s.paketler["gta6"] = "paket-gta6".toByteArray()
    s.paketler["gta5"] = "paket-gta5".toByteArray()
    var zaman = 1_000_000L
    val klasor = gecici("ana")
    val depo = PaketDeposu(klasor, s, { zaman })

    var sonuc = depo.yenile()
    ko("ikisi de indi", sonuc.inen.toSet() == setOf("gta6", "gta5"), "${sonuc.inen}")
    ko("dosyalar yerinde", depo.dosyalar().size == 2)
    ko("gercek dosya var", File(klasor, "gta6.json.gz").isFile)
    ko("gecici dosya kalmadi", klasor.listFiles()!!.none { it.name.endsWith(".indiriliyor") })
    ko("kurulu listesi", depo.kurulular().size == 2)

    println("== degismeyen paket yeniden inmez ==")
    val oncekiIndirme = s.indirmeCagrisi
    zaman += PaketDeposu.YENILEME_ARALIGI_MS + 1
    sonuc = depo.yenile()
    ko("yeniden indirilmedi", s.indirmeCagrisi == oncekiIndirme, "${s.indirmeCagrisi - oncekiIndirme}")
    ko("inen bos", sonuc.inen.isEmpty())

    println("== haftasi dolmadan bakilmaz ==")
    val oncekiListe = s.listeCagrisi
    zaman += 1000
    sonuc = depo.yenile()
    ko("atlandi", sonuc.atlandi)
    ko("sunucuya bakilmadi", s.listeCagrisi == oncekiListe)
    ko("zorla bakilir", depo.yenile(zorla = true).atlandi.not())

    println("== surum degisince iner ==")
    s.paketler["gta6"] = "paket-gta6-yeni".toByteArray()
    s.surumler["gta6"] = 2L
    zaman += PaketDeposu.YENILEME_ARALIGI_MS + 1
    sonuc = depo.yenile()
    ko("yalniz gta6 indi", sonuc.inen == listOf("gta6"), "${sonuc.inen}")
    ko("yeni icerik yazildi", File(klasor, "gta6.json.gz").readText() == "paket-gta6-yeni")

    println("== BOZUK OZET: paket yuklenmez ==")
    val s2 = SahteSunucu()
    s2.paketler["kotu"] = "icerik".toByteArray()
    s2.bozukOzet = "0".repeat(64)
    val klasor2 = gecici("bozuk")
    val depo2 = PaketDeposu(klasor2, s2, { 5_000_000L })
    sonuc = depo2.yenile()
    ko("bozuk ozetli paket inmedi", sonuc.inen.isEmpty())
    ko("dosya olusmadi", !File(klasor2, "kotu.json.gz").isFile)
    ko("gecici dosya birakilmadi", klasor2.listFiles()!!.none { it.name.endsWith(".indiriliyor") })

    println("== INEMEYEN PAKET: eski surum kalir, zaman ilerlemez ==")
    val s3 = SahteSunucu()
    s3.paketler["a"] = "ilk".toByteArray()
    var zaman3 = 9_000_000L
    val klasor3 = gecici("hata")
    val depo3 = PaketDeposu(klasor3, s3, { zaman3 })
    depo3.yenile()
    ko("once indi", File(klasor3, "a.json.gz").readText() == "ilk")
    val bakis = depo3.sonBakis
    s3.paketler["a"] = "ikinci".toByteArray()
    s3.surumler["a"] = 2L
    s3.dusenler.add("a")
    zaman3 += PaketDeposu.YENILEME_ARALIGI_MS + 1
    sonuc = depo3.yenile()
    ko("inemedi", sonuc.inen.isEmpty())
    ko("eski dosya duruyor", File(klasor3, "a.json.gz").readText() == "ilk")
    ko("kontrol zamani ilerlemedi", depo3.sonBakis == bakis, "${depo3.sonBakis} vs $bakis")
    s3.dusenler.clear()
    sonuc = depo3.yenile()
    ko("sonraki denemede indi", sonuc.inen == listOf("a"))
    ko("yeni icerik", File(klasor3, "a.json.gz").readText() == "ikinci")

    println("== sunucudan kalkan paket silinir ==")
    s3.paketler.remove("a")
    zaman3 += PaketDeposu.YENILEME_ARALIGI_MS + 1
    sonuc = depo3.yenile()
    ko("silindi bildirildi", sonuc.silinen == listOf("a"), "${sonuc.silinen}")
    ko("dosya gitti", !File(klasor3, "a.json.gz").isFile)

    println("== uygulamayla gelen paket yeniden inmez ==")
    val s4 = SahteSunucu()
    val icerik = "uygulamadaki".toByteArray()
    s4.paketler["dahili"] = icerik
    val klasor4 = gecici("dahili")
    val depo4 = PaketDeposu(klasor4, s4, { 7_000_000L }, { setOf(PaketDeposu.sha256(icerik)) })
    sonuc = depo4.yenile()
    ko("indirilmedi", s4.indirmeCagrisi == 0, "${s4.indirmeCagrisi}")
    ko("dosya yazilmadi", !File(klasor4, "dahili.json.gz").isFile)
    ko("dosyalar listesinde yok", depo4.dosyalar().isEmpty())

    println("== sunucu listesi alinamazsa ==")
    val s5 = SahteSunucu()
    s5.listeHata = PaketIndirmeHatasi(null, "ağ yok")
    val klasor5 = gecici("agsiz")
    val depo5 = PaketDeposu(klasor5, s5, { 8_000_000L })
    sonuc = depo5.yenile()
    ko("hata bildirildi", sonuc.hata != null, "${sonuc.hata}")
    ko("cokmedi, inen bos", sonuc.inen.isEmpty())

    println("== temizle ==")
    depo.temizle()
    ko("klasor bosaldi", depo.dosyalar().isEmpty())

    println("\nGECTI: $g   KALDI: $k")
    if (k > 0) kotlin.system.exitProcess(1)
}
