package com.example.altyazi

/**
 * SES HAVUZU — 10.46
 *
 * Ölçülmüş seslerin kaydı: hangi ses kaç Hz, erkek mi kadın mı, internet
 * ister mi. Ayarlar ekranında bir kez ölçülüp Prefs'e yazılır; çeviri
 * servisi bunu okur. Böylece servis her açılışta yeniden ölçmek zorunda
 * kalmaz (ölçüm 15 seste yarım dakika sürebiliyor).
 *
 * Biçim satır satır: ad|hz|cinsiyet|ag
 * Ayraç olarak "|" seçildi; ses adlarında ("tr-tr-x-ama-local") geçmiyor.
 */
object SesHavuzu {

    data class Kayit(
        val ad: String,
        val hz: Double,
        val cinsiyet: Int,
        val agGerekir: Boolean,
    )

    fun yaz(kayitlar: List<Kayit>): String = kayitlar.joinToString("\n") {
        "${it.ad}|${it.hz.toInt()}|${it.cinsiyet}|${if (it.agGerekir) 1 else 0}"
    }

    fun oku(metin: String?): List<Kayit> {
        if (metin.isNullOrBlank()) return emptyList()
        val out = ArrayList<Kayit>()
        for (satir in metin.split('\n')) {
            val p = satir.split('|')
            if (p.size < 4) continue
            val ad = p[0].trim()
            if (ad.isEmpty()) continue
            val hz = p[1].trim().toDoubleOrNull() ?: continue
            val cinsiyet = p[2].trim().toIntOrNull() ?: continue
            out.add(Kayit(ad, hz, cinsiyet, p[3].trim() == "1"))
        }
        return out
    }

    /**
     * Bu cinsiyet için kullanılabilecek sesler, en uygundan başlayarak.
     *
     * [mevcutAdlar] motorun şu an gerçekten sunduğu sesler; kayıt eskiyse
     * (ses paketi silinmişse) oradan düşer. [internetVar] kapalıyken
     * internet isteyen sesler elenir.
     *
     * Sıralama: erkekte EN KALIN, kadında EN İNCE başa gelir. Böylece
     * karakterler arasında cinsiyet en net duyulan uçtan dağıtılır.
     */
    fun havuz(
        kayitlar: List<Kayit>,
        cinsiyet: Int,
        mevcutAdlar: Set<String>,
        internetVar: Boolean,
    ): List<Kayit> {
        val uygun = kayitlar.filter {
            it.ad in mevcutAdlar &&
                it.cinsiyet == cinsiyet &&
                (internetVar || !it.agGerekir)
        }
        // İNTERNET SESLERİ ÖNCE: Google'ın "-network" sesleri sunucuda
        // üretiliyor ve yerel seslerden belirgin şekilde daha doğal. Kullanıcı
        // bu seçeneği açtıysa karakterlere önce onlar dağıtılsın.
        val agOnce = compareByDescending<Kayit> { internetVar && it.agGerekir }
        return if (cinsiyet == SesPerdeOlcer.KADIN)
            uygun.sortedWith(agOnce.thenByDescending { it.hz })
        else uygun.sortedWith(agOnce.thenBy { it.hz })
    }

    /**
     * Kullanılabilecek BÜTÜN sesler (cinsiyet ayırmadan), kalından inceye.
     *
     * Adı okunan ama cinsiyeti bilinmeyen karakterler için: "Kratos" erkek mi
     * kadın mı bilinmiyor, ama en azından her bilinmeyen karakter birbirinden
     * farklı bir sesle konuşsun.
     */
    // ------------------------------------------- 10.58 elle cinsiyet seçimi

    /**
     * ELLE İŞARETLENEN CİNSİYETLER.
     *
     * NEDEN: perdeyi ölçüp cinsiyet tahmin etmek yeterince güvenilir
     * değil. Kullanıcının 19 Kasım ölçümünde 19 sesten 4'ü erkek,
     * 15'i kadın çıktı ve erkek karakterler kadın sesiyle okundu.
     * Ses dosyasının perdesi, motorun sesini seçerken kullandığı
     * cinsiyetle her zaman örtüşmüyor.
     *
     * Çözüm: ölçüm ÖNERİR, kullanıcı KARAR VERİR. Bir kez dinleyip
     * işaretliyor, sonra hiç şaşmıyor. Saklama biçimi basit:
     *   ad=1;ad=2   (1 erkek, 2 kadın)
     */
    fun elleYaz(elle: Map<String, Int>): String =
        elle.entries.filter { it.value == SesPerdeOlcer.ERKEK || it.value == SesPerdeOlcer.KADIN }
            .joinToString(";") { it.key + "=" + it.value }

    fun elleOku(metin: String?): Map<String, Int> {
        if (metin.isNullOrBlank()) return emptyMap()
        val sonuc = LinkedHashMap<String, Int>()
        for (parca in metin.split(';')) {
            val i = parca.lastIndexOf('=')
            if (i <= 0) continue
            val ad = parca.substring(0, i).trim()
            val deger = parca.substring(i + 1).trim().toIntOrNull() ?: continue
            if (ad.isEmpty()) continue
            if (deger != SesPerdeOlcer.ERKEK && deger != SesPerdeOlcer.KADIN) continue
            sonuc[ad] = deger
        }
        return sonuc
    }

    /** Elle işaretlenenleri ölçüm sonuçlarının üzerine yazar. */
    fun elleUygula(kayitlar: List<Kayit>, elle: Map<String, Int>): List<Kayit> {
        if (elle.isEmpty()) return kayitlar
        return kayitlar.map { k ->
            val d = elle[k.ad]
            if (d == null) k else k.copy(cinsiyet = d)
        }
    }

    /** Elle işaretlenmiş erkek ve kadın sayısı; ayar ekranında gösterilir. */
    fun elleOzet(kayitlar: List<Kayit>, elle: Map<String, Int>): String {
        if (kayitlar.isEmpty()) return "Henüz ses taranmadı."
        val son = elleUygula(kayitlar, elle)
        val erkek = son.count { it.cinsiyet == SesPerdeOlcer.ERKEK }
        val kadin = son.count { it.cinsiyet == SesPerdeOlcer.KADIN }
        val isaretli = kayitlar.count { it.ad in elle }
        return "${kayitlar.size} ses · $erkek erkek · $kadin kadın" +
            (if (isaretli > 0) " · $isaretli tanesi elle işaretlendi" else " · hiçbiri elle işaretlenmedi")
    }

    fun tumu(
        kayitlar: List<Kayit>,
        mevcutAdlar: Set<String>,
        internetVar: Boolean,
    ): List<Kayit> = kayitlar.filter {
        it.ad in mevcutAdlar && it.hz > 0.0 && (internetVar || !it.agGerekir)
    }.sortedWith(
        compareByDescending<Kayit> { internetVar && it.agGerekir }.thenBy { it.hz }
    )
}
