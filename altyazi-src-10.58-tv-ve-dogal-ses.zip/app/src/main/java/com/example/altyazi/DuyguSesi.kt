package com.example.altyazi

import java.util.Locale

/**
 * DUYGU VE ÜNLEM KATMANI (10.54)
 *
 * SORUN: Altyazıda "hmm", "ehh", "ahaha", "ugh" gibi yerler ve
 * "[laughs]" / "[gülüyor]" gibi sahne notları Android TTS'e olduğu gibi
 * verildiğinde ya harf harf okunuyor ("h-m-m"), ya da düz tonla
 * "gülüyor" diye okunuyordu. İkisi de gerçekçi değil.
 *
 * ÇÖZÜM, üç parça:
 *
 * 1) ÜNLEM SÖZLÜĞÜ — tanınan ünlem, okunabilir Türkçe bir biçime
 *    çevrilir ("hmm" -> "hımm") ve kendi perde/hız profiliyle okunur.
 *    Uzatmalar ("ahhhhhh") harf harf okunmak yerine tek heceye indirilir,
 *    uzunluk ise HIZA yazılır: ne kadar uzunsa o kadar yavaş.
 *
 * 2) SAHNE NOTLARI — köşeli/parantezli notlar konuşma değildir.
 *    Üç davranış: atla / kısık sesle oku / ünlem gibi canlandır.
 *
 * 3) CÜMLE DUYGUSU — normal cümlede noktalama ve büyük harften duygu
 *    çıkarılıp tüm satıra uygulanır.
 *
 * TASARIM NOTU: Bu nesnede HİÇ Android bağımlılığı yok. Böylece tek
 * başına derlenip sınanabiliyor; ses motoruna yalnız sayılar gidiyor.
 *
 * SATIR İÇİNDE PARÇALAMA YOK: "Hmm, bence gitmeliyiz." tek seferde,
 * tek profille okunur. Parça parça okumak için her parçadan sonra
 * motorun bitirmesini beklemek gerekir; bu da satır arasına boşluk
 * koyar ve ölçüm dinleyicisiyle çakışır. Bu yüzden satırın tamamına
 * baskın duygu uygulanır, ünlem ise yine okunabilir biçime çevrilir.
 */
object DuyguSesi {

    // ---------------------------------------------- sahne notu davranışı

    /** Sahne notu hiç okunmaz. */
    const val NOT_ATLA = 0

    /** Sahne notu kısık sesle, Türkçe karşılığıyla okunur. */
    const val NOT_KISIK = 1

    /** Sahne notu ünlem gibi canlandırılır (gülme, ağlama...). */
    const val NOT_CANLANDIR = 2

    /** Kısık okuma seviyesi. */
    const val KISIK_SEVIYE = 0.6f

    // ------------------------------------------- 10.58 doğallık sınırları

    /**
     * DUYGUNUN SES ÜZERİNDEKİ ETKİSİ ARTIK SIKI SINIRLI.
     *
     * 19 Kasım ses kaydında perde 1,15'e, hız 1,27'ye çıkmıştı ve
     * kullanıcı sesi "robotik" buldu. Sebep tek bir ayar değil,
     * çarpanların ÜST ÜSTE BİNMESİ: kullanıcının tabanı (hız %110,
     * ton %106), üstüne duygu profili, üstüne yetişme hızlanması.
     * Google'ın ağ sesi 1,27 hızda belirgin biçimde sentetik duyuluyor.
     *
     * Bu sınırlar yalnız OTOMATİK katmana uygulanıyor; kullanıcının
     * kaydıraçları hâlâ mutlak. Duygu duyulmaya devam ediyor ama
     * sesin doğallığını bozacak kadar ileri gidemiyor.
     */
    const val PERDE_EN_AZ = 0.90f
    const val PERDE_EN_COK = 1.10f
    const val HIZ_EN_AZ = 0.90f
    const val HIZ_EN_COK = 1.15f

    // ------------------------------------------------------ duygu profili

    /**
     * [perde] ve [hiz] motorun taban değerine uygulanacak ÇARPAN,
     * [seviye] ise okuma ses seviyesi (0..1).
     */
    data class Duygu(
        val ad: String,
        val perde: Float,
        val hiz: Float,
        val seviye: Float,
    )

    val DUZ = Duygu("düz", 1.00f, 1.00f, 1.00f)
    val DUSUNME = Duygu("düşünme", 0.80f, 0.70f, 0.92f)
    val GULME = Duygu("gülme", 1.15f, 1.25f, 1.00f)
    val ACI = Duygu("acı", 0.75f, 0.65f, 1.00f)
    val AGLAMA = Duygu("ağlama", 0.70f, 0.60f, 0.95f)
    val SASIRMA = Duygu("şaşırma", 1.20f, 1.10f, 1.00f)
    val BAGIRMA = Duygu("bağırma", 1.12f, 1.18f, 1.00f)
    val UZGUN = Duygu("üzgün", 0.88f, 0.80f, 0.90f)
    val KORKU = Duygu("korku", 1.18f, 1.22f, 1.00f)
    val OFKE = Duygu("öfke", 0.92f, 1.12f, 1.00f)
    val FISILTI = Duygu("fısıltı", 0.95f, 0.85f, 0.55f)
    val ONAY = Duygu("onay", 1.00f, 0.95f, 0.95f)

    /** Tanı satırında göstermek için. */
    fun tumDuygular(): List<Duygu> =
        listOf(DUZ, DUSUNME, GULME, ACI, AGLAMA, SASIRMA, BAGIRMA, UZGUN, KORKU, OFKE, FISILTI, ONAY)

    // ------------------------------------------------------------- sonuç

    /**
     * [metin] boşsa hiç okunmaz. [perde], [hiz] ve [seviye] şiddet
     * uygulandıktan sonraki son çarpanlardır.
     */
    data class Sonuc(
        val metin: String,
        val duygu: Duygu,
        val perde: Float,
        val hiz: Float,
        val seviye: Float,
    ) {
        val okunur: Boolean get() = metin.isNotBlank()
    }

    private val DUZ_SONUC_BOS = Sonuc("", DUZ, 1f, 1f, 1f)

    // ----------------------------------------------------------- desenler

    /** [not], (not), *not*, ~not~ — sahne notu kabukları. */
    private val NOT_DESENI = Regex("[\\[(*~]([^\\]()*~]{1,80})[\\])*~]")

    private val BOSLUK = Regex("\\s{2,}")

    /** Harf ve kesme dışındaki her şey ayırıcıdır. */
    private val AYIRICI = Regex("[^\\p{L}']+")

    private val ROOT: Locale = Locale.ROOT

    /**
     * TÜRKÇE KÜÇÜK HARF DE GEREKLİ.
     *
     * Locale.ROOT, "DİKKAT" içindeki İ'yi "i" + birleşen nokta olarak
     * küçültüyor; o biçim "dikkat" ile eşleşmiyor. Türkçe yerel ise
     * "IRENE" gibi ASCII I'li yazımları "ırene" yapıyor. İkisi de tek
     * başına yetmediği için her iki biçim de denenir.
     */
    private val TR: Locale = Locale("tr", "TR")

    private val YERELLER = listOf(ROOT, TR)

    /**
     * Kahkaha: "haha", "hehe", "hihi", "hah", "ahah", "muahaha", "bwahaha".
     *
     * İKİ YOL VAR: ya h+sesli en az iki kez yinelenir ("haha"), ya da
     * tam olarak "h-sesli-h" kalıbıdır ("hah", "ahah"). Tek yineleme
     * serbest bırakılınca "ahi", "oha" gibi gerçek sözcükler de kahkaha
     * sanılıyordu.
     */
    private val GULME_DESENI = Regex("^[bmgwu]{0,3}[aeo]?(?:(?:h[aeiı]){2,6}h?|h[aeiı]h)$")

    // ------------------------------------------------------- ünlem defteri

    /**
     * Ünlem -> (okunacak Türkçe biçim, duygu).
     *
     * Anahtarlar SIKIŞTIRILMIŞ hâlde aranır: aynı harfin üst üste
     * yinelenmesi en çok ikiye indirilir ("ahhhhh" -> "ahh").
     *
     * NEDEN TÜRKÇE BİÇİM: "hmm" içinde sesli harf yok, Türkçe TTS onu
     * "h-m-m" diye harfliyor. "hımm" ise tek hece olarak okunuyor.
     */
    private val DEFTER: Map<String, Pair<String, Duygu>> = buildMap {
        // --- düşünme / tereddüt
        for (k in listOf("hm", "hmm", "hmmm", "mm", "mmm", "mmh", "hmh")) put(k, "hımm" to DUSUNME)
        for (k in listOf("uhm", "um", "umm", "erm", "ehm", "eh", "ehh", "er", "uh", "uhh", "ah-ah")) put(k, "ııı" to DUSUNME)
        put("well", "şey" to DUSUNME)
        // --- gülme (desen de var; sık yazımlar burada)
        for (k in listOf("haha", "hahaha", "hehe", "heh", "hah", "hihi", "lol", "lmao", "teehee")) put(k, "ha ha ha" to GULME)
        put("kikir", "kıh kıh" to GULME)
        put("kıkır", "kıh kıh" to GULME)
        // --- acı / zorlanma
        for (k in listOf("ah", "ahh", "agh", "argh", "arg", "ugh", "ug", "ungh", "ngh", "nngh", "oof", "ow", "ouch", "aah", "aargh", "urgh"))
            put(k, "ahh" to ACI)
        put("grr", "hırr" to OFKE)
        put("tsk", "ıhıh" to OFKE)
        // --- ağlama
        for (k in listOf("sob", "sniff", "waa", "wah", "huhu", "boohoo", "buhu", "hik", "hık"))
            put(k, "hıh hıh" to AGLAMA)
        // --- şaşırma / fark etme
        for (k in listOf("oh", "ooh", "oo", "ohh", "whoa", "woah", "wow", "oho", "ooo", "gasp", "oha", "ohoo", "vay"))
            put(k, "oh" to SASIRMA)
        for (k in listOf("aha", "ah-ha", "aah-ha")) put(k, "aha" to SASIRMA)
        put("huh", "ha" to SASIRMA)
        put("eek", "iiy" to KORKU)
        put("yikes", "eyvah" to KORKU)
        put("oops", "eyvah" to KORKU)
        put("whoops", "eyvah" to KORKU)
        // --- tiksinme / rahatlama / sevinç
        put("ew", "ııy" to OFKE)
        put("eww", "ııy" to OFKE)
        put("yuck", "ııy" to OFKE)
        put("phew", "vay be" to ONAY)
        put("whew", "vay be" to ONAY)
        put("yay", "yaşa" to GULME)
        put("hooray", "yaşa" to GULME)
        put("hurray", "yaşa" to GULME)
        // --- sessizlik / çağırma
        put("shh", "şişt" to FISILTI)
        put("sh", "şişt" to FISILTI)
        put("psst", "pisst" to FISILTI)
        put("hey", "hey" to BAGIRMA)
        put("oi", "hey" to BAGIRMA)
        put("yo", "hey" to BAGIRMA)
        // --- onay / ret
        for (k in listOf("mhm", "mmhm", "uh-huh", "mm-hmm", "yeah", "yep", "yup")) put(k, "hı hı" to ONAY)
        for (k in listOf("nope", "nah", "uh-uh", "nuh-uh")) put(k, "yok" to ONAY)
        put("okay", "tamam" to ONAY)
        // --- diğer
        put("brr", "brr" to KORKU)
        put("achoo", "hapşu" to SASIRMA)
        put("ahem", "öhö" to DUSUNME)
    }

    /**
     * Sahne notu içeriğinden duygu. SoundTags notları Türkçeye çevirdiği
     * için Türkçe anahtarlar önce aranır; çevrilmemiş not da yakalanır.
     */
    private val NOT_DUYGUSU: List<Pair<String, Duygu>> = listOf(
        "kahkaha" to GULME, "gülüyor" to GULME, "gülme" to GULME, "kıkırd" to GULME,
        "laugh" to GULME, "chuckl" to GULME, "giggl" to GULME,
        "ağlıyor" to AGLAMA, "hıçkır" to AGLAMA, "sızlan" to AGLAMA, "ağlama" to AGLAMA,
        "cry" to AGLAMA, "sob" to AGLAMA, "whimper" to AGLAMA,
        "inliyor" to ACI, "inleme" to ACI, "acılı" to ACI, "homurd" to ACI, "homurtu" to ACI,
        "zorlan" to ACI, "groan" to ACI, "grunt" to ACI, "pained" to ACI, "strain" to ACI,
        "iç çek" to DUSUNME, "iç çeki" to DUSUNME, "sigh" to DUSUNME, "mırıldan" to DUSUNME,
        "nefesi kesil" to SASIRMA, "şaşkın" to SASIRMA, "gasp" to SASIRMA,
        "çığlık" to BAGIRMA, "bağırıyor" to BAGIRMA, "scream" to BAGIRMA, "shout" to BAGIRMA,
        "yell" to BAGIRMA, "shriek" to BAGIRMA,
        "fısıld" to FISILTI, "whisper" to FISILTI,
        "öksür" to ACI, "cough" to ACI,
    )

    /** Canlandırma modunda duyguya karşılık gelen ses. */
    private val CANLANDIRMA: Map<String, String> = mapOf(
        GULME.ad to "ha ha ha",
        AGLAMA.ad to "hıh hıh hıh",
        ACI.ad to "ahh",
        DUSUNME.ad to "hımm",
        SASIRMA.ad to "oh",
        BAGIRMA.ad to "aah",
        FISILTI.ad to "şişt",
        KORKU.ad to "iiy",
        OFKE.ad to "hırr",
    )

    /**
     * Bağırma göstergesi sözcükler (ünlem işaretiyle birlikte).
     *
     * TAM SÖZCÜK olarak aranır. İçerik aramasıyla denendiğinde "yapma"
     * sözcüğü "yapmamalıydın" içinde de bulunuyordu ve sıradan bir
     * sitem cümlesi bağırma sayılıyordu.
     */
    private val HAYKIRIS = setOf(
        "yardım", "imdat", "koş", "koşun", "kaç", "kaçın", "dikkat", "eğil",
        "yat", "çekil", "dur", "durun", "bırak", "bırakın", "hayır", "yapma",
        "yapmayın", "arkanda", "arkanızda", "silah", "bomba", "ateş", "yetişin",
    )

    /** Üzgün göstergesi sözcükler; bunlar da tam sözcük olarak aranır. */
    private val HUZUN = setOf(
        "üzgünüm", "özür", "öldü", "ölmüş", "öldüler", "kaybettim", "gitti",
        "elveda", "yapamadım", "affet", "affedersin", "keşke", "bitti",
    )

    // ------------------------------------------------------------ ana giriş

    /**
     * Okunacak metni ve ses çarpanlarını hesaplar.
     *
     * @param metin ekrandaki çeviri (konuşan adı atılmış hâli)
     * @param duyguAcik ana anahtar; kapalıysa yalnız kabuk temizliği yapılır
     * @param notModu [NOT_ATLA] / [NOT_KISIK] / [NOT_CANLANDIR]
     * @param unlemAcik ünlem sözlüğü ve uzatma düzeltmesi
     * @param cumleAcik noktalama ve büyük harften cümle duygusu
     * @param trAcik İngilizce ünlemlerin Türkçe karşılıkları
     * @param siddet 0..1; duygunun ne kadar belirgin uygulanacağı
     */
    fun hazirla(
        metin: String?,
        duyguAcik: Boolean = true,
        notModu: Int = NOT_ATLA,
        unlemAcik: Boolean = true,
        cumleAcik: Boolean = true,
        trAcik: Boolean = true,
        siddet: Float = 0.45f,
    ): Sonuc {
        if (metin.isNullOrBlank()) return DUZ_SONUC_BOS
        val ham = metin.trim()

        // Duygu kapalı: eski davranış. Yalnız kabukları atıyoruz, çünkü
        // köşeli parantezin kendisi hiçbir zaman okunmamalı.
        if (!duyguAcik) {
            val sade = kabukAt(ham)
            return if (sade.isBlank()) DUZ_SONUC_BOS else Sonuc(sade, DUZ, 1f, 1f, 1f)
        }

        val s = siddet.coerceIn(0f, 1f)
        val notlar = notlariBul(ham)
        val govde = BOSLUK.replace(NOT_DESENI.replace(ham, " "), " ").trim()

        // --- 1) SATIRIN TAMAMI SAHNE NOTU
        if (notlar.isNotEmpty() && !harfVar(govde)) {
            val duygu = notDuygusu(notlar) ?: DUZ
            return when (notModu) {
                NOT_ATLA -> DUZ_SONUC_BOS
                NOT_CANLANDIR -> {
                    val ses = CANLANDIRMA[duygu.ad]
                    if (ses == null) karistir(notlar.joinToString(", "), duygu, s, KISIK_SEVIYE)
                    else karistir(ses, duygu, s, 1f)
                }
                else -> karistir(notlar.joinToString(", "), DUZ, s, KISIK_SEVIYE)
            }
        }

        // --- 2) KONUŞMA VAR: notlar moda göre ya atılır ya okunur
        var govdeMetin = if (notModu == NOT_ATLA) govde else kabukAt(ham)
        if (govdeMetin.isBlank()) return DUZ_SONUC_BOS

        // --- 3) SATIR BAŞTAN SONA ÜNLEM Mİ?
        if (unlemAcik) {
            val tek = unlemSatiri(govdeMetin)
            if (tek != null) return karistir(tek.first, tek.second, s, 1f, tek.third)
        }

        // --- 4) KARIŞIK SATIR: ünlemler okunabilir hâle getirilir,
        //        duygu ise cümlenin tamamından çıkarılır.
        if (unlemAcik || trAcik) govdeMetin = iceridekiUnlemler(govdeMetin, trAcik)
        val duygu = if (cumleAcik) cumleDuygusu(govdeMetin) else DUZ
        return karistir(govdeMetin, duygu, s, 1f)
    }

    // ------------------------------------------------------------ parçalar

    /** Kabukları atar, içeriği bırakır: "[gülüyor]" -> "gülüyor". */
    fun kabukAt(metin: String): String =
        BOSLUK.replace(NOT_DESENI.replace(metin) { " " + it.groupValues[1].trim() + " " }, " ").trim()

    /** Satırdaki sahne notlarının içerikleri. */
    fun notlariBul(metin: String): List<String> =
        NOT_DESENI.findAll(metin).map { it.groupValues[1].trim() }.filter { it.isNotEmpty() }.toList()

    private fun harfVar(t: String): Boolean = t.any { it.isLetter() }

    /** Sahne notu içeriklerinden ilk tanınan duygu. */
    fun notDuygusu(notlar: List<String>): Duygu? {
        val hepsi = notlar.joinToString(" ").lowercase(ROOT)
        for ((anahtar, duygu) in NOT_DUYGUSU) if (hepsi.contains(anahtar)) return duygu
        return null
    }

    /**
     * Aynı harfin üst üste yinelenmesini en çok ikiye indirir.
     * "ahhhhh" -> "ahh", "hmmmm" -> "hmm", "aaaah" -> "aah"
     */
    fun sikistir(kelime: String): String {
        if (kelime.length < 3) return kelime
        val sb = StringBuilder(kelime.length)
        var yineleme = 0
        var oncekiHarf = '\u0000'
        for (c in kelime) {
            if (c == oncekiHarf) {
                yineleme++
                if (yineleme >= 2) continue
            } else {
                yineleme = 0
                oncekiHarf = c
            }
            sb.append(c)
        }
        return sb.toString()
    }

    /**
     * Tek bir sözcüğün ünlem karşılığı: (okunacak biçim, duygu).
     * Tanınmazsa null.
     */
    fun unlem(kelime: String?): Pair<String, Duygu>? {
        if (kelime.isNullOrBlank()) return null
        for (yerel in YERELLER) {
            val temiz = kelime.lowercase(yerel).filter { it.isLetter() || it == '-' }
            if (temiz.isEmpty()) continue
            DEFTER[temiz]?.let { return it }
            val sik = sikistir(temiz)
            DEFTER[sik]?.let { return it }
            val tekli = sikistirTek(temiz)
            DEFTER[tekli]?.let { return it }
            if (GULME_DESENI.matches(tekli) && tekli.length >= 3) return "ha ha ha" to GULME
            if (GULME_DESENI.matches(sik) && sik.length >= 3) return "ha ha ha" to GULME
        }
        return null
    }

    /** Yinelemeyi tamamen tekler: "ahh" -> "ah", "hmm" -> "hm". */
    private fun sikistirTek(kelime: String): String {
        val sb = StringBuilder(kelime.length)
        for (c in kelime) if (sb.isEmpty() || sb[sb.length - 1] != c) sb.append(c)
        return sb.toString()
    }

    /**
     * Satır baştan sona ünlemlerden mi oluşuyor?
     * Dönen: (okunacak biçim, duygu, hız çarpanı).
     * Hız çarpanı uzatmadan gelir: "ahhhhhh" daha yavaş okunur.
     */
    fun unlemSatiri(metin: String): Triple<String, Duygu, Float>? {
        val parcalar = metin.split(AYIRICI).filter { it.isNotBlank() }
        if (parcalar.isEmpty() || parcalar.size > 4) return null
        val bicimler = ArrayList<String>(parcalar.size)
        var duygu: Duygu? = null
        var fazlaHarf = 0
        for (p in parcalar) {
            val u = unlem(p) ?: return null
            bicimler += u.first
            if (duygu == null) duygu = u.second
            val sik = sikistir(p.lowercase(ROOT))
            fazlaHarf += (p.length - sik.length).coerceAtLeast(0)
        }
        val d = duygu ?: return null
        val yavaslik = (1f - 0.05f * fazlaHarf).coerceAtLeast(0.7f)
        // Aynı ünlem üst üste yazılmışsa ("ha ha ha ha") tek biçime indir
        val metinSon = if (bicimler.distinct().size == 1) bicimler.first()
        else bicimler.joinToString(" ")
        return Triple(metinSon, d, yavaslik)
    }

    /**
     * Cümle içindeki ünlem sözcüklerini okunabilir Türkçe biçime çevirir.
     * Cümlenin geri kalanına dokunmaz.
     */
    fun iceridekiUnlemler(metin: String, trAcik: Boolean): String {
        if (!trAcik) return metin
        val sb = StringBuilder(metin.length + 8)
        var i = 0
        while (i < metin.length) {
            val c = metin[i]
            if (!c.isLetter()) {
                sb.append(c)
                i++
                continue
            }
            var j = i
            while (j < metin.length && (metin[j].isLetter() || metin[j] == '-')) j++
            val kelime = metin.substring(i, j)
            val u = unlem(kelime)
            if (u != null) {
                val bicim = u.first
                sb.append(if (kelime[0].isUpperCase()) basHarfBuyut(bicim) else bicim)
            } else {
                sb.append(kelime)
            }
            i = j
        }
        return BOSLUK.replace(sb.toString(), " ").trim()
    }

    private fun basHarfBuyut(t: String): String =
        if (t.isEmpty()) t else t.substring(0, 1).uppercase(ROOT) + t.substring(1)

    /**
     * Noktalama ve büyük harften cümle duygusu.
     *
     * Sıra önemli: en belirgin göstergeden en zayıfa. Hiçbiri yoksa DÜZ
     * döner, yani ses hiç değişmez — yanlış duygu uygulamaktansa
     * dokunmamak yeğdir.
     */
    fun cumleDuygusu(metin: String): Duygu {
        val t = metin.trim()
        if (t.isEmpty()) return DUZ
        val harfler = t.filter { it.isLetter() }
        val buyukOran = if (harfler.isEmpty()) 0f
        else harfler.count { it.isUpperCase() }.toFloat() / harfler.length
        val unlemSayisi = t.count { it == '!' }
        val sozcukler = sozcukKumesi(t)
        val haykiris = sozcukler.any { it in HAYKIRIS }
        val huzun = sozcukler.any { it in HUZUN }

        // "?!" ya da "!?" -> panik
        if (t.contains("?!") || t.contains("!?")) return KORKU
        // TAMAMI BÜYÜK ve en az üç harf -> bağırma
        if (buyukOran > 0.8f && harfler.length >= 3) return BAGIRMA
        // Birden çok ünlem -> bağırma
        if (unlemSayisi >= 2) return BAGIRMA
        if (unlemSayisi == 1) return if (haykiris) BAGIRMA else OFKE
        // Üç nokta ile biten kısa cümle -> üzgün
        if ((t.endsWith("…") || t.endsWith("...")) && harfler.length <= 48) return UZGUN
        if (huzun) return UZGUN
        return DUZ
    }

    /**
     * Satırdaki sözcükler, her iki küçük harf biçimiyle.
     * Bir sözcüğün hem "dikkat" hem "dıkkat" hâli kümeye girer; hangisi
     * doğruysa o eşleşir.
     */
    fun sozcukKumesi(metin: String): Set<String> {
        val k = LinkedHashSet<String>()
        for (yerel in YERELLER) {
            for (p in metin.lowercase(yerel).split(AYIRICI)) {
                if (p.isNotBlank()) k += p
            }
        }
        return k
    }

    // ------------------------------------------------------------- şiddet

    private fun karistir(
        metin: String,
        duygu: Duygu,
        siddet: Float,
        seviyeTaban: Float,
        ekHiz: Float = 1f,
    ): Sonuc {
        val perde = 1f + (duygu.perde - 1f) * siddet
        val hiz = (1f + (duygu.hiz - 1f) * siddet) * ekHiz
        val seviye = (1f + (duygu.seviye - 1f) * siddet) * seviyeTaban
        return Sonuc(
            metin,
            duygu,
            perde.coerceIn(PERDE_EN_AZ, PERDE_EN_COK),
            hiz.coerceIn(HIZ_EN_AZ, HIZ_EN_COK),
            seviye.coerceIn(0.1f, 1.0f),
        )
    }
}
