package com.example.altyazi

/**
 * YAN YAZI ALANLARI (10.58)
 *
 * Altyazı dışındaki yazılar — oyun menüleri, görev metinleri, tuş
 * ipuçları, oyun içi telefon mesajları — ekranın her yerinde olabiliyor.
 * 10.53'te bunun için TEK dikdörtgen vardı. GTA 6'da telefon mesajları
 * hem solda hem sağda çıkabildiği için tek kutu ikisini birlikte
 * kapsamak zorunda kalıyor ve arada kalan tüm ekranı da tarıyordu.
 *
 * Artık birden çok kutu var (sol, sağ, özel) ve yazı BUNLARDAN BİRİNİN
 * içinde olması yeterli.
 *
 * Bir de MENÜ MODU var: oyun menüsündeyken alan sınırı tamamen kalkıyor,
 * tüm ekran taranıyor ve her yazı bulunduğu yerde çevriliyor —
 * "Settings" yazan yerde "Ayarlar" görünüyor.
 *
 * Android bağımlılığı yok, tek başına sınanabiliyor.
 */
object YanAlan {

    /** Yüzde cinsinden bir dikdörtgen. */
    data class Kutu(
        val acik: Boolean,
        val sol: Int,
        val ust: Int,
        val sag: Int,
        val alt: Int,
    ) {
        /** Kutu geçerli mi? Sol sağdan büyükse kullanıcı ters seçmiş. */
        val gecerli: Boolean get() = sol < sag && ust < alt
    }

    /** Nokta kutunun içinde mi? Oranlar 0..1, kutu yüzde. */
    fun kutuda(relX: Float, relY: Float, k: Kutu): Boolean =
        relX >= k.sol / 100f && relX <= k.sag / 100f &&
            relY >= k.ust / 100f && relY <= k.alt / 100f

    /**
     * Bu yazı yan yazı olarak çevrilecek mi?
     *
     * @param subtitleTop altyazı şeridinin başladığı oran; şeridin
     *        içindeki yazı HER DURUMDA dışta kalır, orası ayrı işleniyor
     * @param menuModu tüm ekranı tara
     * @param menuZone hiç kutu seçilmemişken taranan üst bölge oranı
     */
    fun icinde(
        relX: Float,
        relY: Float,
        subtitleTop: Float,
        menuModu: Boolean,
        menuZone: Float,
        kutular: List<Kutu>,
    ): Boolean {
        // Altyazı şeridi her zaman dışta: iki kez çevirmemek için.
        if (relY >= subtitleTop) return false
        if (menuModu) return true
        val acikKutular = kutular.filter { it.acik && it.gecerli }
        if (acikKutular.isEmpty()) return relY < minOf(subtitleTop, menuZone)
        return acikKutular.any { kutuda(relX, relY, it) }
    }

    /** Ayar ekranında gösterilecek özet. */
    fun ozet(k: Kutu): String =
        if (!k.acik) "kapalı"
        else if (!k.gecerli) "geçersiz seçim"
        else "yatay %${k.sol}–%${k.sag} · dikey %${k.ust}–%${k.alt}"
}
