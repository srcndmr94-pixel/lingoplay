package com.example.altyazi

/**
 * SES AKIŞI VE YETİŞME (10.55)
 *
 * SORUN: Oyun altyazısı 1-3 saniyede bir değişiyor, Türkçe TTS ise bir
 * repliği 4-6 saniyede okuyor. Her yeni replik `QUEUE_FLUSH` ile
 * öncekini kesiyordu. Duyulan şey cümleler değil, her cümlenin ilk
 * yarısı oluyordu — dublaj hissi bu yüzden yoktu. Duygu eklemek bu
 * sorunu çözmez; önce yetişmek gerekiyor.
 *
 * Bu nesne üç işi yapar:
 *
 *  1. OKUMA SÜRESİ TAHMİNİ — harf sayısından süre. Taban değer
 *     ölçümle güncellenir: her TAMAMLANAN okumada gerçek süre
 *     kaydedilir ve harf/saniye öğrenilir. Böylece tahmin cihazın
 *     gerçek motoruna oturuyor, benim varsayımıma değil.
 *
 *  2. YETİŞME KARARI — üç mod: kes, cümleyi bitir ve araya gireni
 *     atla, hızlanarak yetiş.
 *
 *  3. ÇALIŞMA KAYDI — her repliğin geliş zamanı, okunan biçimi,
 *     sesi, duygusu, gerçek süresi ve kesilip kesilmediği. Sonunda
 *     özet: kaç replik, kaçı kesildi, ortalama ihtiyaç ne kadardı.
 *
 * TASARIM NOTU: Android bağımlılığı yok; tek başına derlenip
 * sınanabiliyor. Zaman bile dışarıdan veriliyor.
 */
object SesAkisi {

    // ------------------------------------------------------------ modlar

    /** Yeni replik gelince okunanı kes (10.54'e kadarki davranış). */
    const val KES = 0

    /** Okunan cümleyi bitir, o sırada gelen repliği atla. */
    const val BITIR_ATLA = 1

    /** Hızlanarak yetiş; gerekirse yine de keser. Varsayılan. */
    const val HIZLAN = 2

    /**
     * Hız 1.0'da okunan harf/saniye için başlangıç değeri.
     *
     * NEREDEN: kullanıcının 19 Kasım ses kaydındaki 15 tam okumaya en
     * küçük kareler uygulandı: süre = 811 ms + (harf/hız) × 49,2 ms,
     * yani sabit 811 ms gecikme ve 20,3 harf/sn. Ölçüm geldikçe bu
     * değerler kullanılmıyor, öğrenilen değerler kullanılıyor.
     */
    const val TABAN_HARF_SN = 20.0

    /**
     * Her seslendirmenin SABİT maliyeti (ms).
     *
     * 10.55'teki tek parametreli model (süre = harf/hız) kısa
     * repliklerde çok yanılıyordu: 12 harflik replik 1,1 saniye
     * sürüyordu, bu da "9,9 harf/sn" diye öğreniliyor ve uzun
     * repliklerin tahminini %85 şişiriyordu. Ölçülen ortalama mutlak
     * hata 487 ms'ydi; iki parametreli modelle 171 ms'ye düştü.
     */
    const val TABAN_GECIKME_MS = 800.0

    /** Öğrenme için en az bu kadar tam okuma gerekir. */
    const val EN_AZ_OLCUM = 5

    /** Öğrenmede tutulan en çok ölçüm sayısı. */
    const val OLCUM_PENCERESI = 24

    /**
     * Hızlanmanın üst sınırı.
     *
     * 10.56'da 1,6'ydı. Gerçek kayıtta yetişme açığı %3 çıktı, yani
     * hızlanmaya neredeyse hiç gerek yok; buna karşılık 1,27 hızda
     * ses belirgin biçimde sentetik duyuluyor. Doğallık yetişmeden
     * önce geliyor.
     */
    const val EN_YUKSEK_CARPAN = 1.25f

    /** Kesilme oranı bunun altındaysa hiç hızlanmaz. */
    const val HIZLANMA_ESIGI = 0.20

    /**
     * BITIR_ATLA modunda: okuma bu kadarını geçtiyse bitirilir.
     *
     * NEDEN %40: kullanıcının gerçek kaydı (28 replik, 63,8 sn)
     * benzetildiğinde eşik %70'te kesik replik %25, %55'te %18,
     * %40'ta %14 oldu; tam okunan oran üçünde de %64. Daha aşağısı
     * (%25) kesmeyi sıfıra indiriyor ama duyulmayan replik %36'ya
     * çıkıyor, o da fazla.
     */
    const val BITIRME_ESIGI = 0.40

    /** Kayıtta tutulan en çok satır. */
    const val KAYIT_SINIRI = 400

    // ------------------------------------------------------- süre tahmini

    /**
     * Gerçek okuma sürelerinden harf/saniye öğrenir.
     *
     * Yalnız TAMAMLANAN okumalar sayılır: kesilen okumanın süresi
     * metnin tamamına ait değil, o yüzden öğrenmeyi bozar.
     */
    class Tahminci {
        private val harfler = ArrayDeque<Int>()
        private val sureler = ArrayDeque<Long>()
        private val hizlar = ArrayDeque<Float>()

        /** Tamamlanmış bir okumayı öğrenmeye katar. */
        fun ekle(harf: Int, ms: Long, hiz: Float) {
            if (harf < 4 || ms < 150L || ms > 60_000L) return
            if (hiz <= 0.05f) return
            harfler.addLast(harf)
            sureler.addLast(ms)
            hizlar.addLast(hiz)
            while (harfler.size > OLCUM_PENCERESI) {
                harfler.removeFirst()
                sureler.removeFirst()
                hizlar.removeFirst()
            }
        }

        fun olcumSayisi(): Int = harfler.size

        /**
         * İKİ PARAMETRELİ UYUM: süre = taban + (harf/hız) × eğim.
         *
         * Dönen: taban ms ve harf/saniye. En küçük kareler; yeterli
         * ölçüm yoksa ya da ölçümler aynı noktada yığılmışsa (eğim
         * hesaplanamaz) taban değerler döner.
         */
        private fun uyum(): Pair<Double, Double> {
            val n = harfler.size
            if (n < EN_AZ_OLCUM) return TABAN_GECIKME_MS to TABAN_HARF_SN
            val h = harfler.toList()
            val sr = sureler.toList()
            val z = hizlar.toList()
            val xs = DoubleArray(n) { h[it] / z[it].toDouble() }
            val ys = DoubleArray(n) { sr[it].toDouble() }
            var mx = 0.0
            var my = 0.0
            for (i in 0 until n) {
                mx += xs[i]
                my += ys[i]
            }
            mx /= n
            my /= n
            var sxy = 0.0
            var sxx = 0.0
            for (i in 0 until n) {
                sxy += (xs[i] - mx) * (ys[i] - my)
                sxx += (xs[i] - mx) * (xs[i] - mx)
            }
            if (sxx < 1.0) return TABAN_GECIKME_MS to TABAN_HARF_SN
            val egim = sxy / sxx
            if (egim < 10.0 || egim > 250.0) return TABAN_GECIKME_MS to TABAN_HARF_SN
            val taban = (my - egim * mx).coerceIn(0.0, 2500.0)
            val harfSn = (1000.0 / egim).coerceIn(4.0, 60.0)
            return taban to harfSn
        }

        /** Hız 1.0'a indirgenmiş harf/saniye. */
        fun harfSn(): Double = uyum().second

        /** Her seslendirmenin öğrenilen sabit maliyeti (ms). */
        fun tabanMs(): Double = uyum().first

        /** Bu metnin bu hızda kaç ms süreceği. */
        fun tahminMs(metin: String, hiz: Float): Long {
            val (taban, hs) = uyum()
            return tahmin(metin, hiz, hs, taban)
        }

        fun temizle() {
            harfler.clear()
            sureler.clear()
            hizlar.clear()
        }
    }

    /**
     * Süre tahmini: sabit maliyet + harf başına süre.
     *
     * NOKTALAMA EKLENTİSİ KALDIRILDI: 10.55'te her cümle sonuna 180 ms,
     * her virgüle 90 ms ekleniyordu. Gerçek ölçümlerin uyumu bu
     * duraklamaları zaten sabit maliyetin içinde buluyor; ikisini
     * birlikte saymak tahmini şişiriyordu.
     */
    fun tahmin(
        metin: String,
        hiz: Float,
        harfSn: Double,
        tabanMs: Double = TABAN_GECIKME_MS,
    ): Long {
        if (metin.isBlank()) return 0L
        val h = hiz.coerceIn(0.3f, 3.0f)
        val hs = harfSn.coerceIn(4.0, 60.0)
        val taban = tabanMs.coerceIn(0.0, 2500.0)
        val ms = taban + metin.length * 1000.0 / (hs * h)
        return ms.toLong().coerceIn(120L, 120_000L)
    }

    // -------------------------------------------------------- yetişme kararı

    /**
     * Yeni replik geldiğinde ne yapılacak.
     *
     * @param oku okunacak mı
     * @param hizCarpani okuma hızına uygulanacak ek çarpan
     * @param kes okunmakta olan kesilecek mi (false: kuyruğa eklenmez, atlanır)
     * @param neden kayda yazılacak kısa açıklama
     */
    data class Karar(
        val oku: Boolean,
        val hizCarpani: Float,
        val kes: Boolean,
        val neden: String,
    )

    /**
     * @param mod [KES] / [BITIR_ATLA] / [HIZLAN]
     * @param okunuyor o anda bir replik okunuyor mu
     * @param gecenMs okunan repliğin kaç ms'dir okunduğu
     * @param tahminMs okunan repliğin tahmini toplam süresi
     * @param kesilmeOrani son repliklerde kesilme oranı (0..1)
     */
    fun karar(
        mod: Int,
        okunuyor: Boolean,
        gecenMs: Long,
        tahminMs: Long,
        kesilmeOrani: Double,
        yeniTahminMs: Long = 0L,
        butceMs: Long = 0L,
    ): Karar {
        // HIZLANMA BITIR_ATLA'DA DA ÇALIŞIR. 10.55'te yalnız HIZLAN
        // modundaydı; gerçek kayıt benzetimi ikisini birlikte
        // kullanmanın kesik replik oranını düşürdüğünü gösterdi.
        val carpan = if (mod == KES) {
            1f
        } else {
            birlesikCarpan(
                hizlanmaCarpani(kesilmeOrani),
                ongoruluCarpan(yeniTahminMs, butceMs),
            )
        }
        if (!okunuyor) {
            return Karar(true, carpan, false, if (carpan > 1.01f) "yetişme hızı ×%.2f".format(carpan) else "boşta")
        }
        if (mod == BITIR_ATLA) {
            val oran = if (tahminMs <= 0L) 1.0 else gecenMs.toDouble() / tahminMs
            if (oran >= BITIRME_ESIGI) {
                return Karar(false, 1f, false, "cümle bitiyor (%%%d), replik atlandı".format((oran * 100).toInt()))
            }
            return Karar(true, carpan, true, "cümlenin başındaydı (%%%d), kesildi".format((oran * 100).toInt()))
        }
        // KES ve HIZLAN: yeni replik her zaman öne geçer.
        val oran = if (tahminMs <= 0L) 0.0 else gecenMs.toDouble() / tahminMs
        val neden = if (carpan > 1.01f) "kesildi (%%%d) · yetişme hızı ×%.2f".format((oran * 100).toInt(), carpan)
        else "kesildi (%%%d)".format((oran * 100).toInt())
        return Karar(true, carpan, true, neden)
    }

    /**
     * Kesilme oranına göre hızlanma çarpanı.
     *
     * %20'ye kadar hiç hızlanmaz — tek tük kesilme normaldir. Sonra
     * doğrusal olarak artar ve %80 kesilmede üst sınıra oturur.
     */
    fun hizlanmaCarpani(kesilmeOrani: Double): Float {
        val k = kesilmeOrani.coerceIn(0.0, 1.0)
        if (k <= HIZLANMA_ESIGI) return 1f
        val pay = (k - HIZLANMA_ESIGI) / (0.80 - HIZLANMA_ESIGI)
        val c = 1.0 + pay.coerceIn(0.0, 1.0) * (EN_YUKSEK_CARPAN - 1f)
        return c.toFloat().coerceIn(1f, EN_YUKSEK_CARPAN)
    }

    // --------------------------------------------- öngörülü hızlanma (10.56)

    /**
     * Bütçe hesabında hedeflenen aralık dilimi.
     *
     * NEDEN ORTANCA DEĞİL DAHA ALTI: ortanca aralığa göre ayarlanırsa
     * repliklerin yarısı yine yetişmez. %40'lık dilim, replikin
     * aralıkların çoğuna sığmasını hedefler.
     */
    const val BUTCE_DILIMI = 0.40

    /** Öngörülü hızlanma için en az bu kadar aralık ölçümü gerekir. */
    const val EN_AZ_ARALIK = 4

    /**
     * Altyazıların geliş aralığını ölçer.
     *
     * NEDEN: repliğin uzunluğu baştan biliniyor; aralık da ölçülebiliyorsa
     * kesilmeyi BEKLEMEDEN hızlanabiliriz. Tepkisel hızlanma ancak
     * replikler kesilmeye başladıktan sonra devreye giriyordu ve ilk
     * birkaç uzun replik hep parçalanıyordu.
     */
    class AralikOlcer(private val pencere: Int = 16) {
        private val araliklar = ArrayDeque<Long>()

        /** İki replik arası ms. Aşırı değerler alınmaz. */
        fun ekle(ms: Long) {
            if (ms < 150L || ms > 30_000L) return
            araliklar.addLast(ms)
            while (araliklar.size > pencere) araliklar.removeFirst()
        }

        fun sayi(): Int = araliklar.size

        /** Hedeflenen bütçe: aralıkların [BUTCE_DILIMI] dilimi. 0 = bilinmiyor. */
        fun butceMs(): Long {
            if (araliklar.size < EN_AZ_ARALIK) return 0L
            val sirali = araliklar.sorted()
            val yer = ((sirali.size - 1) * BUTCE_DILIMI).toInt().coerceIn(0, sirali.size - 1)
            return sirali[yer]
        }

        fun ortancaMs(): Long {
            if (araliklar.isEmpty()) return 0L
            val sirali = araliklar.sorted()
            return sirali[sirali.size / 2]
        }

        fun temizle() = araliklar.clear()
    }

    /**
     * Repliğin kendi uzunluğundan gelen hızlanma.
     *
     * Tahmini süre bütçeyi aşıyorsa oranı kadar hızlanır. Bütçe
     * bilinmiyorsa (yeterli ölçüm yok) hiç karışmaz.
     */
    fun ongoruluCarpan(tahminMs: Long, butceMs: Long): Float {
        if (butceMs <= 0L || tahminMs <= 0L) return 1f
        if (tahminMs <= butceMs) return 1f
        val oran = tahminMs.toDouble() / butceMs
        return oran.toFloat().coerceIn(1f, EN_YUKSEK_CARPAN)
    }

    /** İki hızlanma gerekçesinden büyüğü geçerli; ikisi birbirine eklenmez. */
    fun birlesikCarpan(tepkisel: Float, ongorulu: Float): Float =
        maxOf(tepkisel, ongorulu).coerceIn(1f, EN_YUKSEK_CARPAN)

    // ------------------------------------------------------- kesilme sayacı

    /** Son repliklerin kesilip kesilmediğini tutar. */
    class Sayac(private val pencere: Int = 12) {
        private val kesildi = ArrayDeque<Boolean>()
        private var toplamReplik = 0
        private var toplamKesilen = 0
        private var toplamOkunanMs = 0L
        private var toplamTahminMs = 0L
        private var atlanan = 0

        fun replik(kesildiMi: Boolean, okunanMs: Long, tahminMs: Long) {
            kesildi.addLast(kesildiMi)
            while (kesildi.size > pencere) kesildi.removeFirst()
            toplamReplik++
            if (kesildiMi) toplamKesilen++
            if (okunanMs > 0L) toplamOkunanMs += okunanMs
            if (tahminMs > 0L) toplamTahminMs += tahminMs
        }

        fun atlandi() {
            atlanan++
        }

        /** Son pencerede kesilme oranı. */
        fun oran(): Double {
            if (kesildi.isEmpty()) return 0.0
            return kesildi.count { it }.toDouble() / kesildi.size
        }

        fun ozet(harfSn: Double, olcumSayisi: Int): String {
            if (toplamReplik == 0 && atlanan == 0) return "ÖZET: hiç replik okunmadı"
            val oranYuzde = if (toplamReplik == 0) 0 else toplamKesilen * 100 / toplamReplik
            val ortOkunan = if (toplamReplik == 0) 0L else toplamOkunanMs / toplamReplik
            val ortTahmin = if (toplamReplik == 0) 0L else toplamTahminMs / toplamReplik
            val acik = if (ortTahmin <= 0L) 0 else ((1.0 - ortOkunan.toDouble() / ortTahmin) * 100).toInt()
            return "ÖZET: $toplamReplik replik · $toplamKesilen kesildi (%$oranYuzde) · " +
                "$atlanan atlandı · ortalama okunan ${sn(ortOkunan)} / gereken ${sn(ortTahmin)} · " +
                "yetişme açığı %$acik · öğrenilen hız ${"%.1f".format(harfSn)} harf/sn ($olcumSayisi ölçüm)"
        }

        fun temizle() {
            kesildi.clear()
            toplamReplik = 0
            toplamKesilen = 0
            toplamOkunanMs = 0L
            toplamTahminMs = 0L
            atlanan = 0
        }
    }

    fun sn(ms: Long): String = "%.1f sn".format(ms / 1000.0)

    // ------------------------------------------------- 10.58 tekrar süzgeci

    /**
     * AYNI SATIRIN BİRKAÇ KEZ OKUNMASI.
     *
     * 19 Kasım kaydında OCR aynı iletiyi üç ayrı biçimde okudu ve
     * üçü de sesli okundu:
     *   «Teşekkürler. Posta kutuna $$$.»
     *   «teşekkürler. Posta kutunda $$$.»
     *   «Teşekkürler. Posta kutuna $$$ gönderilecek.»
     * Birebir eşitlik süzgeci bunları yakalamıyor, çünkü metinler
     * farklı. Sözcük kümesi örtüşmesine bakmak gerekiyor.
     */
    /** Tekrar sayılmak için en çok bu kadar süre geçmiş olabilir (ms). */
    const val BENZERLIK_PENCERESI = 25_000L

    private val SOZCUK_AYIRICI = Regex("[^\\p{L}\\p{N}]+")

    /**
     * Sözcük karşılaştırmasında kullanılan ön ek uzunluğu.
     *
     * NEDEN GEREKLİ: Türkçe çekimli. OCR aynı iletiyi iki kez okuduğunda
     * çeviri "posta kutuna" ve "posta kutunda" olarak çıkabiliyor; bunlar
     * ayrı sözcük sayılınca örtüşme %50'de kalıyor ve tekrar yakalanmıyor.
     * İlk beş harf karşılaştırılınca "kutun" = "kutun" oluyor.
     */
    const val ON_EK = 5

    /** Üç ya da daha çok sözcüklü satırlarda eşik. */
    const val BENZERLIK_ESIGI = 0.62

    /** Kısa satırlarda eşik: yanlış eşleşme riski yüksek, daha sıkı. */
    const val BENZERLIK_ESIGI_KISA = 0.85

    private fun kokler(t: String): Set<String> =
        t.lowercase().split(SOZCUK_AYIRICI)
            .filter { it.length > 1 }
            .map { if (it.length > ON_EK) it.substring(0, ON_EK) else it }
            .toSet()

    /** İki satırın sözcük kökü örtüşmesi (Jaccard), 0..1. */
    fun ortusme(a: String, b: String): Double {
        val x = kokler(a)
        val y = kokler(b)
        if (x.isEmpty() || y.isEmpty()) return if (x == y) 1.0 else 0.0
        val kesisim = x.count { it in y }
        val birlesim = x.size + y.size - kesisim
        if (birlesim == 0) return 0.0
        return kesisim.toDouble() / birlesim
    }

    /** Aynı satırın tekrarı mı? Kısa satırlarda eşik daha sıkı. */
    fun benzerMi(a: String, b: String): Boolean {
        val x = kokler(a)
        val y = kokler(b)
        val esik = if (minOf(x.size, y.size) >= 3) BENZERLIK_ESIGI else BENZERLIK_ESIGI_KISA
        return ortusme(a, b) >= esik
    }

    /** Son okunan satırları tutar ve tekrarı söyler. */
    class TekrarSuzgeci(private val pencere: Int = 6) {
        private val metinler = ArrayDeque<Pair<String, Long>>()

        /** Tekrar ise true döner ve satırı EKLEMEZ. */
        fun tekrarMi(metin: String, simdi: Long): Boolean {
            while (metinler.isNotEmpty() && simdi - metinler.first().second > BENZERLIK_PENCERESI) {
                metinler.removeFirst()
            }
            for ((eski, _) in metinler) if (benzerMi(eski, metin)) return true
            metinler.addLast(metin to simdi)
            while (metinler.size > pencere) metinler.removeFirst()
            return false
        }

        fun temizle() = metinler.clear()
    }

    // ------------------------------------------------------- çalışma kaydı

    private val kayit = ArrayDeque<String>()

    @Volatile
    var kayitAcik = false

    /**
     * En son hesaplanan özet.
     *
     * NEDEN STATİK: servis durdurulduktan sonra ses motoru yok oluyor
     * ve ana ekran özeti alamıyordu; kullanıcı kaydı kopyaladığında
     * en üstte "Sesli okuma çalışmıyor." yazıyordu. Özet artık
     * motordan bağımsız yaşıyor.
     */
    @Volatile
    var sonOzet = ""

    fun yaz(satir: String) {
        if (!kayitAcik) return
        synchronized(kayit) {
            kayit.addLast(satir)
            while (kayit.size > KAYIT_SINIRI) kayit.removeFirst()
        }
    }

    fun tumu(): List<String> = synchronized(kayit) { kayit.toList() }

    fun satirSayisi(): Int = synchronized(kayit) { kayit.size }

    fun temizle() = synchronized(kayit) { kayit.clear() }

    /** Saat:dakika:saniye.milisaniye — zaman dışarıdan verilir. */
    fun saat(ms: Long): String {
        val t = ms / 1000
        val s = t % 60
        val d = (t / 60) % 60
        val h = (t / 3600) % 24
        return "%02d:%02d:%02d.%03d".format(h, d, s, ms % 1000)
    }
}
