package com.example.altyazi

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Locale

/**
 * SESLİ OKUMA — 10.43'te eklendi, 10.44'te ses seçimi geldi.
 *
 * Ekrana çıkan Türkçe çeviriyi telefonun Türkçe konuşma motoruyla okur.
 * Ücretsiz, anahtarsız, kota yok.
 *
 * BU DUBLAJ DEĞİL. Karakterlerin gerçek sesi klonlanmıyor; telefonda yüklü
 * Türkçe seslerden biri okuyor.
 *
 * 10.44 — ERKEK/KADIN AYRIMI:
 * Altyazıdaki konuşan adına bakıp ([KonusanCinsiyeti]) erkek ya da kadın
 * sesini seçer. Android'in `Voice` sınıfı cinsiyet bildirmediği için hangi
 * sesin erkek hangisinin kadın olduğunu kullanıcı ayarlardan DİNLEYEREK
 * seçer; burada yalnız seçilen ses uygulanır.
 *
 * Telefonda tek Türkçe ses varsa ayrım perdeyle yapılır: erkek biraz kalın,
 * kadın biraz ince. Klonlama değil ama iki karakter karışmaz.
 *
 * Tasarım kararları (10.43'ten):
 *  - BİRİKME YOK: yeni replik gelince okunan kesilir (QUEUE_FLUSH).
 *  - AYNI YAZI İKİ KEZ OKUNMAZ.
 *  - Motor hazır olmadan gelen replik bekletilir; yalnız en sonu okunur.
 */
class SesliOku(context: Context, private val log: (String) -> Unit = {}) {

    /** Ayarlarda listelenen bir Türkçe ses. */
    data class SesBilgi(
        val ad: String,
        val kalite: Int,
        val agGerekir: Boolean,
    ) {
        /** Kullanıcıya gösterilen satır. */
        val etiket: String
            get() {
                val k = when {
                    kalite >= 500 -> "çok yüksek kalite"
                    kalite >= 400 -> "yüksek kalite"
                    kalite >= 300 -> "orta kalite"
                    else -> "düşük kalite"
                }
                return if (agGerekir) "$ad · $k · internet ister" else "$ad · $k"
            }
    }

    /** Bir sesin ölçüm sonucu. */
    data class SesOlcumu(
        val ses: SesBilgi,
        val hz: Double,
        val cinsiyet: Int,
    ) {
        val olculdu: Boolean get() = hz > 0.0
        val aciklama: String
            get() = when {
                !olculdu -> "ölçülemedi"
                cinsiyet == SesPerdeOlcer.ERKEK -> "erkek · ${hz.toInt()} Hz"
                cinsiyet == SesPerdeOlcer.KADIN -> "kadın · ${hz.toInt()} Hz"
                else -> "belirsiz · ${hz.toInt()} Hz"
            }
    }

    private val app = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var hazir = false
    @Volatile private var kapandi = false

    /** Telefonda bulunan Türkçe sesler, kaliteden düşüğe sıralı. */
    @Volatile private var sesler: List<Voice> = emptyList()

    /** Şu an motora uygulanmış ses adı; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananSes: String? = null

    /** Şu an uygulanmış perde; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananTon: Float = -1f

    /** Şu an uygulanmış konuşma hızı; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananHiz: Float = -1f

    /** Karakter adlarını tonlara dağıtır (bkz. KarakterSesi.kt). */
    private val dagitici = KarakterSesi.Dagitici()

    /** Ölçüm sürerken ikinci bir tarama başlatılmasın. */
    private val olcumSuruyor = AtomicBoolean(false)

    /** En son okunan yazının sade hali; aynısı tekrar okunmasın. */
    @Volatile private var sonOkunan = ""

    /** Motor açılırken gelen replik ve konuşanı; yalnız en sonu saklanır. */
    private data class Bekleyen(val metin: String, val konusan: String?, val algilanan: Int)

    @Volatile private var bekleyen: Bekleyen? = null

    /** Taban konuşma hızı, 0.5 - 2.0. Karakter tonu bunun üstüne biner. */
    @Volatile
    var hiz: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            uygulananHiz = -1f   // bir sonraki okumada yeniden uygulansın
        }

    /** Taban ses tonu, 0.5 - 2.0. Cinsiyet ayrımı bunun üstüne eklenir. */
    @Volatile
    var ton: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            uygulananTon = -1f   // bir sonraki okumada yeniden uygulansın
        }

    /** Baştaki konuşan adı okunmasın mı? (prefs.showSpeaker) */
    @Volatile
    var adiAtla: Boolean = true

    /** Erkek/kadın ayrımı yapılsın mı? */
    @Volatile
    var cinsiyetAyrimi: Boolean = true

    /**
     * Her karaktere ayrı ton verilsin mi?
     *
     * Kapalıyken tüm erkekler tek tonla, tüm kadınlar tek tonla okunur
     * (10.44 davranışı). Açıkken iki erkek karşılıklı konuşsa bile
     * birbirinden ayrılır.
     */
    @Volatile
    var karakterAyrimi: Boolean = true

    /** Ayarlardan seçilen erkek sesinin adı; boşsa en iyi ses kullanılır. */
    @Volatile
    var erkekSesAdi: String = ""

    /** Ayarlardan seçilen kadın sesinin adı; boşsa en iyi ses kullanılır. */
    @Volatile
    var kadinSesAdi: String = ""

    /**
     * KONUŞAN ADI YOKKEN kullanılacak ses.
     *
     * NEDEN GEREKLİ: birçok film/dizi altyazısında ve bazı oyunlarda replikler
     * "JASON: ..." gibi bir önek taşımaz. O zaman uygulamanın cinsiyeti
     * anlayacak HİÇBİR dayanağı kalmaz. Böyle içerikte her replik bu sesle
     * okunur; kullanıcı hangi sesi istediğini ayarlardan seçer.
     *
     * Boş bırakılırsa en iyi kaliteli ses kullanılır — ki bu, 19 sesin 15'i
     * ince olan bir telefonda her şeyin kadın sesiyle okunması demekti.
     */
    @Volatile
    var varsayilanSesAdi: String = ""

    /**
     * Ölçülmüş ses havuzu (bkz. SesHavuzu.kt). Doluysa her karaktere AYRI
     * GERÇEK SES verilir; perdeyle oynanmaz. Telefonda 15 Türkçe ses varken
     * iki erkeği perde farkıyla ayırmak yerine iki ayrı ses vermek çok daha
     * doğal duyuluyor.
     */
    @Volatile
    var havuz: List<SesHavuzu.Kayit> = emptyList()

    /**
     * Elle işaretlenmiş cinsiyetler; ölçümün üzerine yazılır.
     * Bkz. [SesHavuzu.elleUygula] ve [Prefs.sesCinsiyetElle].
     */
    var cinsiyetElle: Map<String, Int> = emptyMap()

    /** Konuşan adı olmayan satırları hiç okuma. */
    var adsizAtla: Boolean = false

    /** Aynı satırın birkaç kez okunmasını engelle. */
    var tekrarSuz: Boolean = true

    private val tekrarSuzgeci = SesAkisi.TekrarSuzgeci()

    /**
     * Doğal ses motorunun durumu, kullanıcıya gösterilmek üzere.
     * Günlüğe gömülü kalmasın: ayar ekranında yazıyor.
     */
    @Volatile
    var dogalDurum: String = "henüz denenmedi"
        private set

    /**
     * Cihaz içi doğal GenAI Türkçe ses (bkz. DogalSesMotoru.kt).
     * Hazır değilse ya da cihaz desteklemiyorsa Android TTS'e düşülür.
     */
    @Volatile
    var dogalSesAcik: Boolean = false

    private var dogalMotor: DogalSesMotoru? = null

    /**
     * İnternet isteyen sesler kullanılsın mı?
     *
     * Google'ın "-network" Türkçe sesleri sunucuda üretiliyor ve yerel
     * seslerden belirgin şekilde daha doğal. Bedeli: internet gerekir ve
     * replik başına birkaç yüz milisaniye gecikme ekler.
     */
    @Volatile
    var internetSesi: Boolean = false

    // ------------------------------------------------- 10.54 duygu ayarları

    /** Duygu katmanı ana anahtarı. Kapalıysa her şey düz tonla okunur. */
    var duyguAcik: Boolean = true

    /** Sahne notu davranışı: [DuyguSesi.NOT_ATLA] / NOT_KISIK / NOT_CANLANDIR. */
    var duyguNotModu: Int = DuyguSesi.NOT_ATLA

    /** Ünlem sözlüğü ve uzatma düzeltmesi. */
    var duyguUnlem: Boolean = true

    /** Noktalama ve büyük harften cümle duygusu. */
    var duyguCumle: Boolean = true

    /** İngilizce ünlemlerin Türkçe karşılıkları. */
    var duyguTr: Boolean = true

    /** Duygu şiddeti 0..1. */
    var duyguSiddet: Float = 0.7f

    /** Son okunan satırın duygusu; tanı satırında gösterilir. */
    @Volatile private var sonDuygu: String = "-"

    // ------------------------------------------- 10.55 akış ve çalışma kaydı

    /** Yetişme modu: [SesAkisi.KES] / BITIR_ATLA / HIZLAN. */
    var akisModu: Int = SesAkisi.BITIR_ATLA

    private val tahminci = SesAkisi.Tahminci()
    private val sayac = SesAkisi.Sayac()
    private val aralikOlcer = SesAkisi.AralikOlcer()

    /** Son repliğin geliş anı; aralık ölçümü buradan. */
    @Volatile private var sonGelis = 0L

    @Volatile private var okumaSuruyor = false
    @Volatile private var okunanMetin = ""
    @Volatile private var okunanTahminMs = 0L
    @Volatile private var okunanHiz = 1f
    @Volatile private var okumaBaslangic = 0L

    /**
     * O anda okunan seslendirmenin kimliği.
     *
     * NEDEN GEREKLİ: QUEUE_FLUSH ile kesilen seslendirme de onDone
     * ya da onError çağırıyor. Kimlik karşılaştırılmasa, kesilen eski
     * repliğin geri çağrısı YENİ repliğin okumasını "bitti" sayıp
     * yetişme sayacını bozardı.
     */
    @Volatile private var okunanId = ""

    /** "android" ya da "doğal"; doğal motorda süre ÖLÇÜLEMEZ, tahmin edilir. */
    @Volatile private var okumaKaynagi = "android"

    /** Okunan repliğin konuşan adı; kayda yazılır. */
    @Volatile private var okunanKonusan = "-"

    /** Doğal motorda tahmini bitişi işaretleyen iş. */
    private var dogalBitisIsi: Runnable? = null

    /** Ölçüm sırasında bir sonraki adıma geçiren iş; dinleyici buna yönlendirir. */
    @Volatile private var olcumGeriCagri: Runnable? = null

    /** Tanı için: en son hangi duyguyla okundu. */
    fun sonDuyguAdi(): String = sonDuygu

    /**
     * Motoru açar. [onDurum] en çok bir kez, ana iş parçacığında çağrılır:
     * (çalışıyor mu, kullanıcıya gösterilecek açıklama).
     */
    fun baslat(onDurum: ((Boolean, String) -> Unit)? = null) {
        if (tts != null || kapandi) return
        try {
            tts = TextToSpeech(app, TextToSpeech.OnInitListener { status ->
                motorAcildi(status, onDurum)
            })
        } catch (t: Throwable) {
            log("SESLI OKUMA: motor kurulamadi (${t.javaClass.simpleName}: ${t.message})")
            bildir(onDurum, false, "Konuşma motoru başlatılamadı.")
        }
    }

    private fun motorAcildi(status: Int, onDurum: ((Boolean, String) -> Unit)?) {
        if (kapandi) return
        if (status != TextToSpeech.SUCCESS) {
            log("SESLI OKUMA: motor acilamadi (status=$status)")
            bildir(onDurum, false, "Telefonda çalışan bir konuşma motoru bulunamadı.")
            return
        }
        val motor = tts
        if (motor == null) {
            log("SESLI OKUMA: motor acilirken kapatildi")
            return
        }
        val sonuc = try {
            motor.setLanguage(TR)
        } catch (t: Throwable) {
            log("SESLI OKUMA: dil ayarlanamadi (${t.javaClass.simpleName})")
            TextToSpeech.LANG_NOT_SUPPORTED
        }
        val turkceVar = sonuc == TextToSpeech.LANG_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
        if (!turkceVar) {
            log("SESLI OKUMA: Turkce ses yok (sonuc=$sonuc)")
            bildir(
                onDurum, false,
                "Türkçe ses paketi yüklü değil. Telefon Ayarları ▸ Erişilebilirlik ▸ " +
                    "Metin okuma bölümünden Türkçe sesi indirin."
            )
            return
        }
        sesleriTopla(motor)
        uygulananSes = null
        uygulananTon = -1f
        uygulananHiz = -1f
        hazir = true
        dinleyiciKur(motor)
        log("SESLI OKUMA: hazir · ${sesler.size} Turkce ses")
        // Doğal motor ayrı çalışır; Android TTS yedek olarak hep açık kalır.
        if (dogalSesAcik && dogalMotor == null) {
            dogalDurum = "başlatılıyor"
            // KURULUM DA KORUMADA. baslat() kendi içinde yakalıyor ama
            // nesnenin KURULMASI da kütüphaneye dokunabiliyor; eski
            // Android sürümlerinde (TV'ler API 28) sınıf yüklenirken
            // düşebilir ve o hata baslat()'ın içine hiç girmez.
            try {
            dogalMotor = DogalSesMotoru({ mesaj ->
                // Doğal ses motorunun söylediği her şeyi hem günlüğe
                // hem ayar ekranına taşı: "neden robotik?" sorusunun
                // cevabı burada ve günlüğe gömülü kalmamalı.
                if (mesaj.startsWith("DOĞAL SES")) {
                    dogalDurum = mesaj.removePrefix("DOĞAL SES:").trim()
                }
                log(mesaj)
            }) { metin, konusan, cinsiyet ->
                if (!kapandi) androidOku(metin, konusan, cinsiyet)
            }.also { it.baslat() }
            } catch (t: Throwable) {
                dogalMotor = null
                dogalDurum = "bu cihazda kullanılamıyor (${t.javaClass.simpleName}); Android sesi"
                log("DOĞAL SES: kurulamadı (${t.javaClass.simpleName}); Android TTS yedeği")
            }
        }
        bildir(onDurum, true, durumYazisi())
        val sira = bekleyen
        bekleyen = null
        if (sira != null) oku(sira.metin, sira.konusan, sira.algilanan)
    }

    /**
     * Telefondaki Türkçe sesleri toplar, kaliteden düşüğe sıralar.
     * İnternet isteyen sesler listeye girer ama sona konur: uygulamanın
     * amacı internetsiz çalışmak.
     */
    private fun sesleriTopla(motor: TextToSpeech) {
        sesler = try {
            val hepsi = motor.voices ?: emptySet<Voice>()
            hepsi.filter { v ->
                try {
                    v.locale != null && v.locale.language.equals("tr", ignoreCase = true)
                } catch (_: Throwable) {
                    false
                }
            }.sortedWith(
                compareBy<Voice> { if (it.isNetworkConnectionRequired) 1 else 0 }
                    .thenByDescending { it.quality }
                    .thenBy { it.name }
            )
        } catch (t: Throwable) {
            log("SESLI OKUMA: ses listesi alinamadi (${t.javaClass.simpleName})")
            emptyList()
        }
        for (v in sesler) log("SESLI OKUMA: ses · ${v.name} · kalite=${v.quality} · ag=${v.isNetworkConnectionRequired}")
    }

    private fun durumYazisi(): String {
        if (sesler.isEmpty()) return "Türkçe ses hazır (motor ayrı ses listesi vermiyor)."
        val enIyi = sesler.first()
        val kalite = if (enIyi.quality >= 400) "yüksek kaliteli" else "standart"
        return "${sesler.size} Türkçe ses bulundu; en iyisi $kalite."
    }

    /** Ayarlar ekranı için: bulunan Türkçe sesler. */
    fun bulunanSesler(): List<SesBilgi> = sesler.map {
        SesBilgi(it.name, it.quality, it.isNetworkConnectionRequired)
    }

    fun hazirMi(): Boolean = hazir

    private fun bildir(onDurum: ((Boolean, String) -> Unit)?, ok: Boolean, mesaj: String) {
        if (onDurum == null) return
        ui.post { onDurum(ok, mesaj) }
    }

    /**
     * Çeviriyi okur. Okunmakta olan replik KESİLİR.
     * [konusan] altyazıdaki konuşan adı; ses seçimi buna göre yapılır.
     */
    fun oku(
        metin: String?,
        konusan: String? = null,
        algilananCinsiyet: Int = KonusanCinsiyeti.BILINMIYOR,
    ) {
        if (kapandi) return
        val temiz = temizle(metin, adiAtla) ?: return
        if (!hazir) {
            bekleyen = Bekleyen(temiz, konusan, algilananCinsiyet)
            return
        }
        val sade = sadeBicim(temiz)
        if (sade.isEmpty()) return
        if (sade == sonOkunan) return
        sonOkunan = sade

        val cinsiyet = cinsiyetiSec(konusan, algilananCinsiyet)

        // DUYGU KATMANI: okunacak metin burada son hâlini alır.
        // "[gülüyor]" atlanabilir, "hmm" okunabilir hâle gelir, perde ve
        // hız çarpanları çıkar. Hiç okunmayacaksa SUSMUYORUZ: o anda
        // okunan replik kesilmesin, sahne notu için konuşmayı bölmek
        // doğallığı bozardı.
        val duygu = DuyguSesi.hazirla(
            temiz,
            duyguAcik = duyguAcik,
            notModu = duyguNotModu,
            unlemAcik = duyguUnlem,
            cumleAcik = duyguCumle,
            trAcik = duyguTr,
            siddet = duyguSiddet,
        )
        if (!duygu.okunur) {
            sonDuygu = "atlandı"
            log("SESLI OKUMA: sahne notu atlandi")
            return
        }
        sonDuygu = duygu.duygu.ad

        // ----------------------------------- 10.58 KONUŞAN ADI VE TEKRAR
        // Radyo istasyonu adları, menü ve reklam yazıları ekranın altına
        // altyazı gibi düşüyor ve sesli okunuyordu. Gerçek repliklerin
        // konuşan adı var, bu yazıların yok.
        if (adsizAtla && konusan.isNullOrBlank()) {
            kayit("ATLANDI", "konuşan adı yok · «${kisalt(duygu.metin)}»")
            return
        }
        // OCR aynı iletiyi birkaç farklı biçimde okuyabiliyor; birebir
        // eşitlik süzgeci bunları yakalamıyor, sözcük örtüşmesi yakalıyor.
        if (tekrarSuz && tekrarSuzgeci.tekrarMi(duygu.metin, System.currentTimeMillis())) {
            kayit("ATLANDI", "aynı satır yeniden okundu · «${kisalt(duygu.metin)}»")
            return
        }

        // ----------------------------------------- YETİŞME KARARI (10.55)
        // Oyun altyazısı 1-3 sn'de değişiyor, Türkçe TTS bir repliği
        // 4-6 sn'de okuyor. Eski davranışta her yeni replik öncekini
        // ortasından kesiyordu; duyulan şey cümleler değil parçalardı.
        val etkinHiz = (hiz * duygu.hiz).coerceIn(0.3f, 2.0f)
        val tahminMs = tahminci.tahminMs(duygu.metin, etkinHiz)
        val gecenMs = if (okumaSuruyor) simdi() - okumaBaslangic else 0L

        // ALTYAZI GELİŞ ARALIĞI: repliğin uzunluğu baştan biliniyor,
        // aralık da ölçülüyorsa kesilmeyi beklemeden hızlanabiliriz.
        val an = simdi()
        if (sonGelis > 0L) aralikOlcer.ekle(an - sonGelis)
        sonGelis = an
        val butce = aralikOlcer.butceMs()

        val karar = SesAkisi.karar(
            akisModu, okumaSuruyor, gecenMs, okunanTahminMs, sayac.oran(),
            yeniTahminMs = tahminMs,
            butceMs = butce,
        )

        kayit(
            "GELDİ",
            "«${kisalt(duygu.metin)}» ${duygu.metin.length} harf · " +
                "tahmin ${SesAkisi.sn(tahminMs)} · bütçe " +
                (if (butce > 0L) SesAkisi.sn(butce) else "-") +
                " · duygu ${duygu.duygu.ad} · ${karar.neden}"
        )

        if (!karar.oku) {
            sayac.atlandi()
            kayit("ATLANDI", "«${kisalt(duygu.metin)}»")
            return
        }
        if (karar.kes && okumaSuruyor) {
            sayac.replik(true, gecenMs, okunanTahminMs)
            okumaSuruyor = false
            dogalBitisIsiIptal()
        }

        okunanMetin = duygu.metin
        okunanKonusan = if (konusan.isNullOrBlank()) "-" else konusan
        okunanTahminMs = tahminci.tahminMs(duygu.metin, (etkinHiz * karar.hizCarpani).coerceIn(0.3f, 2.0f))
        okunanHiz = (etkinHiz * karar.hizCarpani).coerceIn(0.3f, 2.0f)
        okumaSuruyor = true
        okumaBaslangic = simdi()

        // ÖNCE DOĞAL SES: hazırsa o okur. Değilse ya da hata verirse
        // DogalSesMotoru yedek geri çağrısıyla androidOku'yu çağırır.
        // Doğal motor perde/hız almıyor; metin düzeltmesinden yine
        // yararlanıyor ("hmm" -> "hımm").
        val dogal = dogalMotor
        if (dogal != null && dogal.oku(duygu.metin, konusan, cinsiyet)) {
            try {
                tts?.stop()
            } catch (_: Throwable) {
            }
            // DOĞAL MOTOR SÜRE BİLDİRMİYOR: bitişi tahminle işaretliyoruz,
            // yoksa "okuma sürüyor" sonsuza kadar açık kalır ve yetişme
            // kararı hep "kes" derdi. Bu süre ÖĞRENMEYE KATILMAZ.
            okumaKaynagi = "doğal"
            // Android tarafının kimliği geçersizleşsin: kesilen eski
            // seslendirmenin geri çağrısı doğal okumayı bitirmesin.
            okunanId = ""
            kayit("BAŞLADI", "kaynak=doğal · süre ölçülemez, tahmin ${SesAkisi.sn(okunanTahminMs)}")
            dogalBitisIsiIptal()
            val isim = Runnable { okumaBitti(false) }
            dogalBitisIsi = isim
            ui.postDelayed(isim, okunanTahminMs)
            return
        }
        dogal?.sus()
        okumaKaynagi = "android"
        androidOku(duygu.metin, konusan, cinsiyet, duygu, karar.hizCarpani)
    }

    /** Kayıtta satır şişmesin: uzun replik kısaltılır. */
    private fun kisalt(metin: String): String =
        if (metin.length <= 46) metin else metin.take(44) + "…"

    /**
     * Android TTS ile okur. Doğal motor hata verdiğinde de buraya gelinir;
     * [sonOkunan] filtresi burada yeniden uygulanmaz, yoksa yedek okuma
     * "aynı yazı" sayılıp hiç okunmazdı.
     */
    private fun androidOku(
        temiz: String,
        konusan: String?,
        gelenCinsiyet: Int = KonusanCinsiyeti.BILINMIYOR,
        duygu: DuyguSesi.Sonuc? = null,
        yetismeCarpani: Float = 1f,
    ) {
        if (kapandi) return
        if (!hazir) return
        val motor = tts ?: return
        val cinsiyet = cinsiyetiSec(konusan, gelenCinsiyet)
        sesiUygula(
            motor, cinsiyet, konusan,
            duygu?.perde ?: 1f,
            (duygu?.hiz ?: 1f) * yetismeCarpani,
        )
        // SES SEVİYESİ replik başına verilir; motorun genel seviyesi
        // değişmez. Fısıltı ve kısık sahne notu bunu kullanıyor.
        val parametre = if (duygu != null && duygu.seviye < 0.999f) {
            Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, duygu.seviye) }
        } else {
            null
        }
        val id = "gl-" + System.nanoTime()
        okunanId = id
        try {
            val sonuc = motor.speak(temiz, TextToSpeech.QUEUE_FLUSH, parametre, id)
            if (sonuc != TextToSpeech.SUCCESS) log("SESLI OKUMA: Android TTS reddetti")
        } catch (t: Throwable) {
            log("SESLI OKUMA: okunamadi (${t.javaClass.simpleName})")
        }
    }

    // ------------------------------------------ okuma izleme (10.55)

    /**
     * TEK dinleyici kurar ve kimliğe göre yönlendirir.
     *
     * NEDEN TEK: Android TTS'te dinleyici tektir, sonradan kurulan
     * öncekini siler. Ölçüm (synthesizeToFile) ve okuma (speak) ayrı
     * dinleyici kursa ölçümden sonra okuma izlemesi sessizce ölürdü.
     */
    private fun dinleyiciKur(motor: TextToSpeech) {
        try {
            motor.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {
                    if (olcumMu(id)) return
                    if (!guncelMi(id)) return
                    okumaBasladi()
                }

                override fun onDone(id: String?) {
                    if (olcumMu(id)) {
                        olcumIlerle()
                        return
                    }
                    if (!guncelMi(id)) return
                    okumaBitti(false)
                }

                @Deprecated("eski imza; yenisi aşağıda")
                override fun onError(id: String?) {
                    if (olcumMu(id)) {
                        olcumIlerle()
                        return
                    }
                    if (!guncelMi(id)) return
                    okumaBitti(true)
                }

                override fun onError(id: String?, kod: Int) {
                    if (olcumMu(id)) {
                        log("SESLI OKUMA: sentez hatasi kod=$kod")
                        olcumIlerle()
                        return
                    }
                    if (!guncelMi(id)) return
                    okumaBitti(true)
                }
            })
        } catch (t: Throwable) {
            log("SESLI OKUMA: dinleyici kurulamadi (${t.javaClass.simpleName})")
        }
    }

    private fun olcumMu(id: String?): Boolean = id != null && id.startsWith(OLCUM_ONEKI)

    /** Geri çağrı o anda okunan seslendirmeye mi ait? */
    private fun guncelMi(id: String?): Boolean = id != null && id == okunanId

    private fun olcumIlerle() {
        val is_ = olcumGeriCagri ?: return
        ui.post(is_)
    }

    private fun simdi(): Long = System.nanoTime() / 1_000_000L

    /** Motor gerçekten konuşmaya başladı: başlangıcı buradan alıyoruz. */
    private fun okumaBasladi() {
        okumaBaslangic = simdi()
        // KONUŞAN ADI DA YAZILIYOR: hangi karaktere hangi sesin
        // düştüğü ancak böyle görülebiliyor. Önceki kayıtta yedi ayrı
        // ses görünüyordu ama adlar yazılmadığı için bunun doğru
        // karakter dağılımı mı yoksa ad okuma kararsızlığı mı olduğu
        // anlaşılamıyordu.
        kayit("BAŞLADI", "konuşan=$okunanKonusan ses=${uygulananSes ?: "-"} " +
            "perde=${bicim(uygulananTon)} hız=${bicim(uygulananHiz)} " +
            "duygu=$sonDuygu tahmin=${SesAkisi.sn(okunanTahminMs)}")
    }

    /**
     * Okuma kendiliğinden bitti (ya da hata verdi).
     *
     * ÖĞRENME yalnız buradan olur ve yalnız Android motorunda: kesilen
     * okumanın süresi metnin tamamına ait değil, doğal motorun süresi
     * ise hiç ölçülemiyor.
     */
    private fun okumaBitti(hata: Boolean) {
        if (!okumaSuruyor) return
        val gecen = simdi() - okumaBaslangic
        okumaSuruyor = false
        dogalBitisIsiIptal()
        sayac.replik(false, gecen, okunanTahminMs)
        if (!hata && okumaKaynagi == "android") {
            tahminci.ekle(okunanMetin.length, gecen, okunanHiz)
        }
        val etiket = if (hata) "HATA" else "BİTTİ"
        kayit(
            etiket,
            "${SesAkisi.sn(gecen)} okundu · tahmin ${SesAkisi.sn(okunanTahminMs)} · " +
                "kaynak=$okumaKaynagi · öğrenilen ${"%.1f".format(tahminci.harfSn())} harf/sn"
        )
    }

    private fun dogalBitisIsiIptal() {
        dogalBitisIsi?.let { ui.removeCallbacks(it) }
        dogalBitisIsi = null
    }

    private fun bicim(v: Float): String = if (v < 0f) "-" else "%.2f".format(v)

    /** Çalışma kaydına bir satır. Kayıt kapalıysa hiçbir şey yapmaz. */
    private fun kayit(etiket: String, ayrinti: String) {
        if (!SesAkisi.kayitAcik) return
        SesAkisi.yaz(
            SesAkisi.saat(System.currentTimeMillis() % 86_400_000L) +
                "  " + etiket.padEnd(8) + " " + ayrinti
        )
    }

    /** Ana ekranda gösterilecek özet. */
    fun akisOzeti(): String {
        var o = sayac.ozet(tahminci.harfSn(), tahminci.olcumSayisi())
        o += " · sabit maliyet ${tahminci.tabanMs().toLong()} ms"
        if (aralikOlcer.sayi() >= SesAkisi.EN_AZ_ARALIK) {
            o += " · altyazı aralığı ortanca " + SesAkisi.sn(aralikOlcer.ortancaMs()) +
                ", bütçe " + SesAkisi.sn(aralikOlcer.butceMs())
        }
        // Servis durduktan sonra da okunabilsin.
        SesAkisi.sonOzet = o
        return o
    }

    /**
     * Cinsiyet kararı: ADIN ÖNCELİĞİ VAR.
     *
     * Altyazıda "JASON:" gibi kesin bir etiket varsa ses ölçümüne bakılmaz —
     * etiket ölçümden güvenilirdir. Ad yoksa ya da tanınmıyorsa, canlı ses
     * ölçümü (varsa) kullanılır. İkisi de yoksa BİLİNMİYOR döner ve
     * kullanıcının seçtiği varsayılan ses devreye girer.
     *
     * NOT: [algilanan] değerleri SesPerdeOlcer sabitlerinden gelir; ERKEK ve
     * KADIN her iki nesnede de aynı sayılara karşılık gelir.
     */
    private fun cinsiyetiSec(konusan: String?, algilanan: Int): Int {
        if (!cinsiyetAyrimi) return KonusanCinsiyeti.BILINMIYOR
        val isim = KonusanCinsiyeti.tahmin(konusan)
        if (isim != KonusanCinsiyeti.BILINMIYOR) return isim
        return if (algilanan == SesPerdeOlcer.ERKEK) KonusanCinsiyeti.ERKEK
        else if (algilanan == SesPerdeOlcer.KADIN) KonusanCinsiyeti.KADIN
        else KonusanCinsiyeti.BILINMIYOR
    }

    /**
     * Konuşanın cinsiyetine göre sesi ve perdeyi ayarlar.
     *
     * İKİ AYRI SES VARSA ses değiştirilir, perdeye dokunulmaz.
     * TEK SES VARSA (ya da ikisi için aynı ses seçilmişse) ayrım perdeyle
     * yapılır: erkek kalın, kadın ince. Cinsiyet bilinmiyorsa taban perde.
     */
    private fun sesiUygula(
        motor: TextToSpeech,
        cinsiyet: Int,
        konusan: String?,
        duyguPerde: Float = 1f,
        duyguHiz: Float = 1f,
    ) {
        // Konuşan adı hiç yoksa cinsiyet tahmini imkânsız: kullanıcının
        // seçtiği varsayılan sesle okunur.
        // Ad yoksa VE canlı ses ölçümü de bir şey söylemediyse varsayılan ses.
        // Ölçüm erkek/kadın dediyse aşağıdaki havuz yolu çalışsın.
        if (konusan.isNullOrBlank() && cinsiyet == KonusanCinsiyeti.BILINMIYOR &&
            varsayilanSesAdi.isNotBlank()
        ) {
            sesUygulaAdIle(motor, varsayilanSesAdi)
            uygulaPerde((ton * duyguPerde).coerceIn(0.5f, 2.0f), motor)
            uygulaHiz((hiz * duyguHiz).coerceIn(0.5f, 2.0f), motor)
            return
        }
        val karakterHavuzu = karakterHavuzu(cinsiyet, konusan)

        // 1) HAVUZDA EN AZ İKİ SES VAR: her karaktere ayrı GERÇEK ses.
        //    Perdeye hiç dokunulmaz; en doğal sonuç bu.
        if (karakterAyrimi && karakterHavuzu.size >= 2) {
            val sira = dagitici.yuva(konusan, "ses$cinsiyet", karakterHavuzu.size)
            val kayit = if (sira >= 0) karakterHavuzu[sira] else karakterHavuzu[0]
            sesUygulaAdIle(motor, kayit.ad)
            uygulaPerde((ton * duyguPerde).coerceIn(0.5f, 2.0f), motor)
            uygulaHiz((hiz * duyguHiz).coerceIn(0.5f, 2.0f), motor)
            return
        }

        // 2) Havuzda tek ses (ya da karakter ayrımı kapalı): o sesi kullan,
        //    ayrımı tona bırak.
        val tekSes = karakterHavuzu.firstOrNull()
        val secilen = if (tekSes != null) sesBul(tekSes.ad) ?: etkinSes(cinsiyet) else etkinSes(cinsiyet)
        if (secilen != null && secilen.name != uygulananSes) {
            try {
                motor.voice = secilen
                uygulananSes = secilen.name
            } catch (t: Throwable) {
                log("SESLI OKUMA: ses uygulanamadi (${t.javaClass.simpleName})")
            }
        }

        // ETKİN seslere bakılır, seçilen adlara değil: erkek için ses
        // seçilmiş ama kadın boş bırakılmışsa kadın da en iyi sese düşer;
        // o ses erkeğinkinden farklıysa ayrım zaten vardır.
        val ayriSesVar = etkinSes(KonusanCinsiyeti.ERKEK)?.name !=
            etkinSes(KonusanCinsiyeti.KADIN)?.name

        val kt = if (karakterAyrimi) dagitici.ton(konusan, cinsiyet, ayriSesVar)
        else KarakterSesi.varsayilan(cinsiyet, ayriSesVar)

        uygulaPerde((ton * kt.perde * duyguPerde).coerceIn(0.5f, 2.0f), motor)
        uygulaHiz((hiz * kt.hiz * duyguHiz).coerceIn(0.5f, 2.0f), motor)
    }

    /**
     * Bu cinsiyet için kullanılabilecek gerçek sesler.
     * Havuz ölçülmemişse ya da bu cinsiyette ses yoksa boş döner ve
     * eski (perdeyle ayırma) yola düşülür.
     */
    private fun karakterHavuzu(cinsiyet: Int, konusan: String?): List<SesHavuzu.Kayit> {
        if (havuz.isEmpty()) return emptyList()
        // ELLE İŞARETLEME ÖLÇÜMÜN ÜZERİNE YAZILIR.
        val havuzSon = SesHavuzu.elleUygula(havuz, cinsiyetElle)
        if (cinsiyet == KonusanCinsiyeti.ERKEK || cinsiyet == KonusanCinsiyeti.KADIN) {
            val hedef = if (cinsiyet == KonusanCinsiyeti.ERKEK) SesPerdeOlcer.ERKEK
            else SesPerdeOlcer.KADIN
            return SesHavuzu.havuz(havuzSon, hedef, mevcutAdlar(), internetSesi)
        }
        // ADI VAR AMA CİNSİYETİ BİLİNMİYOR ("Kratos" gibi): cinsiyeti
        // bilemesek de karakterleri birbirinden ayıralım, tüm havuzu kullan.
        if (!konusan.isNullOrBlank()) {
            return SesHavuzu.tumu(havuzSon, mevcutAdlar(), internetSesi)
        }
        // ADI HİÇ YOK (altyazıda konuşan öneki yok): dayanak sıfır.
        // Tek bir ses kullanılır; hangisi olduğunu kullanıcı seçer.
        return emptyList()
    }

    private fun mevcutAdlar(): Set<String> = sesler.map { it.name }.toSet()

    /**
     * Adı verilen sesi uygular. Ses artık yoksa (paket silinmişse) en iyi
     * sese düşer — sessizce bir önceki karakterin sesiyle okumak, yanlış
     * karakterin sesiyle konuşmak demekti.
     */
    /**
     * BELİRLİ BİR SESİ DİNLET (10.58)
     *
     * Ses cinsiyeti listesindeki "Dinle" düğmesi için. Cinsiyet ve
     * karakter dağıtımını atlar, doğrudan verilen sesi kullanır; duygu
     * ve tekrar süzgeci de devreye girmez, çünkü burada amaç sesin
     * kendisini duymak.
     */
    fun sesiDinle(ad: String, metin: String) {
        if (kapandi || !hazir) return
        val motor = tts ?: return
        try {
            dogalMotor?.sus()
            sesUygulaAdIle(motor, ad)
            uygulaPerde(ton.coerceIn(0.5f, 2.0f), motor)
            uygulaHiz(hiz.coerceIn(0.5f, 2.0f), motor)
            okunanId = "gl-dinle-" + System.nanoTime()
            okumaSuruyor = false
            motor.speak(metin, TextToSpeech.QUEUE_FLUSH, null, okunanId)
        } catch (t: Throwable) {
            log("SESLI OKUMA: dinletilemedi (${t.javaClass.simpleName})")
        }
    }

    private fun sesUygulaAdIle(motor: TextToSpeech, ad: String) {
        val v = sesBul(ad) ?: sesler.firstOrNull() ?: return
        if (v.name == uygulananSes) return
        try {
            motor.voice = v
            uygulananSes = v.name
        } catch (t: Throwable) {
            log("SESLI OKUMA: ses uygulanamadi (${t.javaClass.simpleName})")
        }
    }

    private fun uygulaPerde(hedef: Float, motor: TextToSpeech) {
        if (yaklasikEsit(hedef, uygulananTon)) return
        try {
            motor.setPitch(hedef)
            uygulananTon = hedef
        } catch (_: Throwable) {
        }
    }

    private fun uygulaHiz(hedef: Float, motor: TextToSpeech) {
        if (yaklasikEsit(hedef, uygulananHiz)) return
        try {
            motor.setSpeechRate(hedef)
            uygulananHiz = hedef
        } catch (_: Throwable) {
        }
    }

    /**
     * Bu cinsiyet için gerçekten kullanılacak ses.
     * Seçim yapılmamışsa ya da seçilen ses artık yoksa en iyi sese düşer.
     */
    private fun etkinSes(cinsiyet: Int): Voice? {
        val istenen = when (cinsiyet) {
            KonusanCinsiyeti.ERKEK -> erkekSesAdi
            KonusanCinsiyeti.KADIN -> kadinSesAdi
            else -> ""
        }
        return sesBul(istenen) ?: sesler.firstOrNull()
    }

    /** Perde zaten uygulanmışsa motora tekrar yazmayalım. */
    private fun yaklasikEsit(a: Float, b: Float): Boolean =
        (if (a > b) a - b else b - a) < 0.001f

    private fun sesBul(ad: String?): Voice? {
        if (ad.isNullOrBlank()) return null
        return sesler.firstOrNull { it.name == ad }
    }

    // ------------------------------------------------ otomatik ses tanıma

    /**
     * Telefondaki her Türkçe sesi sessizce dosyaya okutup perdesini ölçer
     * ve erkek/kadın olarak sınıflar.
     *
     * NEDEN: Android'in `Voice` sınıfı cinsiyet bildirmiyor, ses adından da
     * anlaşılmıyor. Ama sesin kendisi ölçülebiliyor (bkz. SesPerdeOlcer.kt).
     * Böylece kullanıcının tek tek dinleyip seçmesi gerekmiyor.
     *
     * Hoparlörden ses ÇIKMAZ: synthesizeToFile dosyaya yazar.
     * Ölçüm sırasında perde ve hız 1.0'a sabitlenir — kullanıcının ton
     * ayarı ölçümü kaydırmasın — sonra eski değerlere dönülür.
     *
     * [onBitti] ana iş parçacığında, ölçüm sırasına göre çağrılır.
     */
    fun seslerIncele(
        onIlerleme: ((Int, Int) -> Unit)? = null,
        onBitti: (List<SesOlcumu>) -> Unit,
    ) {
        val motor = tts
        if (!hazir || motor == null || sesler.isEmpty()) {
            ui.post { onBitti(emptyList()) }
            return
        }
        if (!olcumSuruyor.compareAndSet(false, true)) return

        // Ölçüm için tarafsız perde/hız.
        try {
            motor.setPitch(1.0f)
            motor.setSpeechRate(1.0f)
        } catch (_: Throwable) {
        }
        uygulananTon = -1f
        uygulananHiz = -1f
        uygulananSes = null

        val sonuclar = ArrayList<SesOlcumu>()
        olcSirayla(motor, 0, sonuclar, onIlerleme, onBitti)
    }

    private fun olcSirayla(
        motor: TextToSpeech,
        sira: Int,
        sonuclar: ArrayList<SesOlcumu>,
        onIlerleme: ((Int, Int) -> Unit)?,
        onBitti: (List<SesOlcumu>) -> Unit,
    ) {
        if (kapandi) {
            olcumBitir(onBitti, sonuclar)
            return
        }
        if (sira >= sesler.size) {
            olcumBitir(onBitti, sonuclar)
            return
        }
        val ses = sesler[sira]
        val bilgi = SesBilgi(ses.name, ses.quality, ses.isNetworkConnectionRequired)
        onIlerleme?.let { f -> ui.post { f(sira + 1, sesler.size) } }

        // İnternet isteyen sesler de ölçülür: kullanıcı "internet sesi"
        // seçeneğini açarsa bunlar kullanılacak ve o zaman cinsiyetleri
        // bilinmek zorunda. İnternet yoksa sentez başarısız olur ve ses
        // "ölçülemedi" olarak kaydedilir; zararsız.

        val dosya = File(app.cacheDir, "gl_ses_olcum.wav")
        try {
            dosya.delete()
        } catch (_: Throwable) {
        }

        // Geri çağrı ya da zaman aşımı: hangisi önce gelirse BİR kez ilerlenir.
        val ilerledi = AtomicBoolean(false)
        // Etiketli dönüş yerine açık koşul: geri çağrı ile zaman aşımı
        // yarıştığında yalnız ilki ilerletir.
        val devam = Runnable {
            if (ilerledi.compareAndSet(false, true)) {
                olcumAdimi(motor, sira, ses, bilgi, dosya, sonuclar, onIlerleme, onBitti)
            }
        }
        try {
            // 10.55: ARTIK AYRI DİNLEYİCİ KURULMUYOR. Dinleyici tektir;
            // burada kurulan, okuma izlemesini sessizce siliyordu.
            // Ortak dinleyici "gl-olcum-" önekini görünce bu işi çağırır.
            olcumGeriCagri = devam
            motor.voice = ses
            val sonuc = motor.synthesizeToFile(ORNEK_METIN, Bundle(), dosya, OLCUM_ONEKI + sira)
            if (sonuc != TextToSpeech.SUCCESS) {
                log("SESLI OKUMA: synthesizeToFile reddetti (${ses.name})")
                ui.post(devam)
                return
            }
        } catch (t: Throwable) {
            log("SESLI OKUMA: sentez kurulamadi (${t.javaClass.simpleName})")
            ui.post(devam)
            return
        }
        // Motor hiç cevap vermezse takılı kalmayalım.
        ui.postDelayed(devam, OLCUM_ZAMAN_ASIMI)
    }

    /**
     * Bir sesin ölçümünü tamamlar ve sıradakine geçer.
     * Hem sentez bittiğinde hem de zaman aşımında çağrılır; hangisi önce
     * gelirse (bkz. olcSirayla içindeki AtomicBoolean).
     */
    private fun olcumAdimi(
        motor: TextToSpeech,
        sira: Int,
        ses: Voice,
        bilgi: SesBilgi,
        dosya: File,
        sonuclar: ArrayList<SesOlcumu>,
        onIlerleme: ((Int, Int) -> Unit)?,
        onBitti: (List<SesOlcumu>) -> Unit,
    ) {
        val sonuc = try {
            SesPerdeOlcer.olc(dosya)
        } catch (t: Throwable) {
            log("SESLI OKUMA: olcum hatasi (${t.javaClass.simpleName})")
            SesPerdeOlcer.BOS
        }
        try {
            dosya.delete()
        } catch (_: Throwable) {
        }
        val o = SesOlcumu(bilgi, if (sonuc.olculdu) sonuc.hz else 0.0, sonuc.cinsiyet)
        log("SESLI OKUMA: olcum · ${ses.name} · ${o.aciklama}")
        sonuclar.add(o)
        ui.post { olcSirayla(motor, sira + 1, sonuclar, onIlerleme, onBitti) }
    }

    private fun olcumBitir(onBitti: (List<SesOlcumu>) -> Unit, sonuclar: List<SesOlcumu>) {
        olcumGeriCagri = null
        // 10.55: dinleyici NULL'A ÇEKİLMİYOR. Eskiden ölçüm bitince
        // dinleyici siliniyordu; artık okuma izlemesi de aynı
        // dinleyiciden geldiği için silmek onu da kapatırdı.
        tts?.let { dinleyiciKur(it) }
        // Kullanıcının ayarları bir sonraki okumada yeniden uygulanır.
        uygulananTon = -1f
        uygulananHiz = -1f
        uygulananSes = null
        olcumSuruyor.set(false)
        ui.post { onBitti(sonuclar) }
    }

    /** Okumayı anında keser. */
    fun sus() {
        if (okumaSuruyor) {
            val gecen = simdi() - okumaBaslangic
            sayac.replik(true, gecen, okunanTahminMs)
            kayit("SUSTURULDU", "${SesAkisi.sn(gecen)} okundu · tahmin ${SesAkisi.sn(okunanTahminMs)}")
            okumaSuruyor = false
            dogalBitisIsiIptal()
        }
        bekleyen = null
        sonOkunan = ""
        dogalMotor?.sus()
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    /** Motoru kapatır. Bundan sonra bu nesne kullanılmaz. */
    fun kapat() {
        // Kayıt kapanırken özet en sona yazılır; kullanıcı kaydı
        // kopyaladığında sayılar elinde olsun.
        if (SesAkisi.kayitAcik) SesAkisi.yaz(akisOzeti())
        kapandi = true
        hazir = false
        bekleyen = null
        dagitici.unut()
        dogalMotor?.kapat()
        dogalMotor = null
        val motor = tts
        tts = null
        try {
            motor?.stop()
            motor?.shutdown()
        } catch (_: Throwable) {
        }
    }

    companion object {

        private val TR = Locale("tr", "TR")

        /**
         * Ölçüm için okutulan cümle. Sesli harf bakımından zengin ve
         * yeterince uzun olmalı: perde ancak sesli çerçevelerde ölçülebiliyor.
         */
        const val ORNEK_METIN = "Buraya gel, kapıyı aç ve arabaya bin, hemen gidiyoruz."

        /** Motor cevap vermezse bu süre sonunda sıradaki sese geçilir (ms). */
        private const val OLCUM_ZAMAN_ASIMI = 6000L

        /** Ölçüm seslendirmelerinin kimlik öneki; dinleyici buna bakar. */
        const val OLCUM_ONEKI = "gl-olcum-"

        /** "James: Gel buraya." -> "Gel buraya." */
        private val KONUSAN =
            Regex("^\\p{Lu}[\\p{L}.'\\-]{1,19}(\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?\\s*:\\s+")

        private val SATIR_SONU = Regex("[\\r\\n]+")
        private val COK_BOSLUK = Regex("\\s{2,}")

        /** Okunmayacak satırlar: uyarı, durum ve okunacak harf içermeyenler. */
        fun okunurMu(metin: String?): Boolean {
            if (metin.isNullOrBlank()) return false
            val t = metin.trim()
            if (t.startsWith("⚠")) return false
            if (t.startsWith("GameLingo")) return false
            return temizle(t, false) != null
        }

        /**
         * Ekrandaki yazıyı sese uygun hale getirir: turkuaz noktayı ve fazla
         * boşlukları atar, [adAt] ise baştaki konuşan adını da atar.
         * Okunacak bir şey kalmazsa null.
         *
         * [adAt] NEDEN SEÇİME BAĞLI: "Dikkat: arkanda!" cümlesinin de başı
         * büyük harfli kelime + iki nokta. Ad atma her zaman açık olsa
         * "Dikkat" yutulurdu. Ad öneki yalnız "Konuşanı göster" ayarı açıkken
         * ekleniyor, bu yüzden ad atma da yalnız o ayar açıkken çalışır.
         */
        fun temizle(metin: String?, adAt: Boolean): String? {
            if (metin.isNullOrBlank()) return null
            var t = metin.trim()
            if (t.startsWith("⚠") || t.startsWith("GameLingo")) return null
            t = t.replace("●", " ")
            if (adAt) t = KONUSAN.replace(t, "")
            t = SATIR_SONU.replace(t, " ")
            t = COK_BOSLUK.replace(t, " ").trim()
            if (!t.any { it.isLetter() }) return null
            return t
        }

        /** Karşılaştırma için sade biçim: küçük harf, yalnız harf ve rakam. */
        fun sadeBicim(metin: String): String =
            metin.lowercase(TR).filter { it.isLetterOrDigit() }
    }
}
