import com.example.altyazi.SesAkisi

var gecti = 0
var kaldi = 0
fun kontrol(ad: String, k: Boolean, ek: String = "") {
    if (k) gecti++ else { kaldi++; println("  KALDI: $ad  $ek") }
}
fun esit(ad: String, b: Any?, g: Any?) = kontrol(ad, b == g, "beklenen=<$b> gercek=<$g>")

fun main() {
    println("== tahmin ==")
    val t1 = SesAkisi.tahmin("Kenton: Maskelerinizde iletisim sistemi var", 1f, 15.0, 250.0)
    kontrol("42 harf ~3 sn", t1 in 2600L..3800L, "$t1 ms")
    kontrol("bos metin 0", SesAkisi.tahmin("", 1f, 15.0, 250.0) == 0L)
    val t2 = SesAkisi.tahmin("Kenton: Maskelerinizde iletisim sistemi var", 2f, 15.0, 250.0)
    kontrol("iki kat hiz yarisi surer", t2 < t1, "$t2 < $t1")
    val t3 = SesAkisi.tahmin("Kenton: Maskelerinizde iletisim sistemi var", 0.5f, 15.0, 250.0)
    kontrol("yarim hiz iki kati surer", t3 > t1, "$t3 > $t1")
    // 10.56: noktalama eklentisi kaldirildi; ayni harf sayisi ayni sure
    val nokta = SesAkisi.tahmin("Gel. Gel. Gel.", 1f, 15.0, 250.0)
    val noktasiz = SesAkisi.tahmin("Gel  Gel  Gel ", 1f, 15.0, 250.0)
    esit("ayni harf sayisi ayni sure", nokta, noktasiz)
    kontrol("kisa replikte taban var", SesAkisi.tahmin("Ah", 1f, 15.0, 250.0) >= 250L)
    kontrol("taban buyudukce sure buyur",
        SesAkisi.tahmin("Gel buraya", 1f, 20.0, 800.0) > SesAkisi.tahmin("Gel buraya", 1f, 20.0, 200.0))
    kontrol("taban kirpilir", SesAkisi.tahmin("Gel", 1f, 20.0, 99999.0) <= 120_000L)
    kontrol("hiz kirpilir", SesAkisi.tahmin("Gel buraya hemen", 99f, 15.0, 250.0) > 0L)
    kontrol("harfSn kirpilir", SesAkisi.tahmin("Gel buraya hemen", 1f, 0.001, 250.0) > 0L)

    println("== tahminci ogrenme (iki parametreli) ==")
    val tc = SesAkisi.Tahminci()
    esit("basta taban harfSn", SesAkisi.TABAN_HARF_SN, tc.harfSn())
    esit("basta taban gecikme", SesAkisi.TABAN_GECIKME_MS, tc.tabanMs())
    esit("basta olcum yok", 0, tc.olcumSayisi())

    // Gercek model: ms = 800 + (harf/hiz) * 50  -> 20 harf/sn
    fun gercek(harf: Int, hiz: Float) = (800.0 + harf / hiz * 50.0).toLong()
    for (h in listOf(12, 20, 28, 35, 46, 54, 79)) {
        tc.ekle(h, gercek(h, 1.0f), 1.0f)
    }
    kontrol("harfSn ogrenildi ~20", kotlin.math.abs(tc.harfSn() - 20.0) < 0.6, tc.harfSn().toString())
    kontrol("taban ogrenildi ~800", kotlin.math.abs(tc.tabanMs() - 800.0) < 40.0, tc.tabanMs().toString())
    esit("7 olcum", 7, tc.olcumSayisi())

    // Farkli hizlardan gelen olcumler de ayni modeli vermeli
    val tc2 = SesAkisi.Tahminci()
    for ((h, z) in listOf(12 to 1.1f, 20 to 1.3f, 28 to 1.5f, 35 to 1.2f, 46 to 1.6f, 54 to 1.0f)) {
        tc2.ekle(h, gercek(h, z), z)
    }
    kontrol("hiz karisik olsa da harfSn ~20", kotlin.math.abs(tc2.harfSn() - 20.0) < 1.0, tc2.harfSn().toString())
    kontrol("hiz karisik olsa da taban ~800", kotlin.math.abs(tc2.tabanMs() - 800.0) < 80.0, tc2.tabanMs().toString())

    // KISA REPLIK ARTIK MODELI BOZMUYOR (10.55'in asil hatasi)
    val tc3 = SesAkisi.Tahminci()
    for (h in listOf(11, 12, 12, 16, 17, 20)) tc3.ekle(h, gercek(h, 1.0f), 1.0f)
    val uzunTahmin = tc3.tahminMs("x".repeat(46), 1.0f)
    val uzunGercek = gercek(46, 1.0f)
    kontrol("kisa olcumlerden sonra uzun replik tahmini saglam",
        kotlin.math.abs(uzunTahmin - uzunGercek) < 400L, "$uzunTahmin vs $uzunGercek")

    // bozuk olcumler alinmaz
    val tc4 = SesAkisi.Tahminci()
    tc4.ekle(2, 5000L, 1f); tc4.ekle(100, 50L, 1f); tc4.ekle(100, 90_000L, 1f); tc4.ekle(100, 5000L, 0f)
    esit("bozuk olcum alinmaz", 0, tc4.olcumSayisi())
    // pencere sinirli
    val tc5 = SesAkisi.Tahminci()
    repeat(60) { tc5.ekle(40, gercek(40, 1f), 1f) }
    esit("pencere siniri", SesAkisi.OLCUM_PENCERESI, tc5.olcumSayisi())
    tc5.temizle()
    esit("temizlenir", 0, tc5.olcumSayisi())
    // yetersiz olcumde taban
    val tc6 = SesAkisi.Tahminci()
    repeat(SesAkisi.EN_AZ_OLCUM - 1) { tc6.ekle(40, gercek(40, 1f), 1f) }
    esit("yetersiz olcum -> taban harfSn", SesAkisi.TABAN_HARF_SN, tc6.harfSn())
    // ayni noktada yigilan olcumler (egim hesaplanamaz) -> taban
    val tc7 = SesAkisi.Tahminci()
    repeat(8) { tc7.ekle(30, 2300L, 1f) }
    esit("yigilan olcum -> taban harfSn", SesAkisi.TABAN_HARF_SN, tc7.harfSn())

    println("== hizlanma carpani ==")
    esit("kesilme yok", 1f, SesAkisi.hizlanmaCarpani(0.0))
    esit("esik altinda hizlanma yok", 1f, SesAkisi.hizlanmaCarpani(0.20))
    kontrol("ortada ara deger",
        SesAkisi.hizlanmaCarpani(0.50) > 1f && SesAkisi.hizlanmaCarpani(0.50) < SesAkisi.EN_YUKSEK_CARPAN,
        SesAkisi.hizlanmaCarpani(0.50).toString())
    esit("ust sinir", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.hizlanmaCarpani(0.80))
    esit("tam kesilme ust sinir", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.hizlanmaCarpani(1.0))
    esit("eksi deger guvenli", 1f, SesAkisi.hizlanmaCarpani(-5.0))
    kontrol("artan monoton",
        SesAkisi.hizlanmaCarpani(0.3) < SesAkisi.hizlanmaCarpani(0.5) &&
            SesAkisi.hizlanmaCarpani(0.5) < SesAkisi.hizlanmaCarpani(0.7))

    println("== karar: bosta ==")
    val b = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.0)
    kontrol("bosta okur", b.oku && !b.kes, b.toString())
    esit("bosta carpan 1", 1f, b.hizCarpani)
    val b2 = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.9)
    kontrol("bosta ama geride: hizli okur",
        b2.oku && b2.hizCarpani == SesAkisi.EN_YUKSEK_CARPAN, b2.toString())

    println("== karar: KES modu ==")
    val k = SesAkisi.karar(SesAkisi.KES, true, 500L, 5000L, 0.9)
    kontrol("KES her zaman keser", k.oku && k.kes, k.toString())
    esit("KES modunda hizlanma yok", 1f, k.hizCarpani)
    kontrol("KES nedeni yuzde icerir", k.neden.contains("%"), k.neden)

    println("== karar: BITIR_ATLA modu ==")
    val ba1 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 4500L, 5000L, 0.5)
    kontrol("sonlardaysa bitir ve atla", !ba1.oku && !ba1.kes, ba1.toString())
    kontrol("atlama nedeni yazili", ba1.neden.contains("atlandı"), ba1.neden)
    val ba2 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 300L, 5000L, 0.5)
    kontrol("basindaysa kes", ba2.oku && ba2.kes, ba2.toString())
    val ba3 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 2750L, 5000L, 0.0)
    kontrol("tam esikte bitir", !ba3.oku, ba3.toString())
    val ba4 = SesAkisi.karar(SesAkisi.BITIR_ATLA, true, 100L, 0L, 0.0)
    kontrol("tahmin 0 ise bitmis sayilir", !ba4.oku, ba4.toString())

    println("== karar: HIZLAN modu ==")
    val h1 = SesAkisi.karar(SesAkisi.HIZLAN, true, 500L, 5000L, 0.9)
    kontrol("HIZLAN keser ve hizlanir",
        h1.oku && h1.kes && h1.hizCarpani == SesAkisi.EN_YUKSEK_CARPAN, h1.toString())
    val h2 = SesAkisi.karar(SesAkisi.HIZLAN, true, 500L, 5000L, 0.0)
    kontrol("kesilme yoksa hizlanmaz", h2.hizCarpani == 1f, h2.toString())

    println("== sayac ==")
    val s = SesAkisi.Sayac(4)
    esit("basta oran 0", 0.0, s.oran())
    s.replik(true, 1000L, 5000L)
    s.replik(true, 1000L, 5000L)
    s.replik(false, 5000L, 5000L)
    s.replik(false, 5000L, 5000L)
    esit("yarisi kesildi", 0.5, s.oran())
    // pencere 4: [T,T,F,F] + T -> ilk T dusur -> [T,F,F,T] = 0.5
    s.replik(true, 1000L, 5000L)
    esit("pencere kayiyor, oran ayni", 0.5, s.oran())
    s.replik(true, 1000L, 5000L)
    s.replik(true, 1000L, 5000L)
    esit("pencere dolunca yukselir", 0.75, s.oran())
    s.replik(true, 1000L, 5000L)
    esit("hepsi kesildi", 1.0, s.oran())
    val s2 = SesAkisi.Sayac()
    kontrol("bos ozet", s2.ozet(15.0, 0).contains("hiç replik okunmadı"), s2.ozet(15.0, 0))
    s2.replik(true, 1000L, 5000L)
    s2.replik(false, 4000L, 4000L)
    s2.atlandi()
    val oz = s2.ozet(18.5, 7)
    kontrol("ozet replik sayisi", oz.contains("2 replik"), oz)
    kontrol("ozet kesilen", oz.contains("1 kesildi"), oz)
    kontrol("ozet atlanan", oz.contains("1 atlandı"), oz)
    kontrol("ozet ogrenilen hiz", oz.contains("18.5") || oz.contains("18,5"), oz)
    s2.temizle()
    kontrol("temizlenir", s2.ozet(15.0, 0).contains("hiç replik"), s2.ozet(15.0, 0))

    println("== aralik olcer ==")
    val ao = SesAkisi.AralikOlcer()
    esit("basta olcum yok", 0, ao.sayi())
    esit("basta butce bilinmiyor", 0L, ao.butceMs())
    esit("basta ortanca yok", 0L, ao.ortancaMs())
    ao.ekle(2000L); ao.ekle(3000L); ao.ekle(1500L)
    esit("3 olcum butce vermez", 0L, ao.butceMs())
    ao.ekle(2500L)
    kontrol("4 olcumle butce gelir", ao.butceMs() > 0L, ao.butceMs().toString())
    // sirali: 1500, 2000, 2500, 3000 · %40 dilimi -> indeks (3*0.4)=1 -> 2000
    esit("butce %40 dilimi", 2000L, ao.butceMs())
    esit("ortanca", 2500L, ao.ortancaMs())
    kontrol("butce ortancadan kucuk ya da esit", ao.butceMs() <= ao.ortancaMs())
    val ao2 = SesAkisi.AralikOlcer()
    ao2.ekle(10L); ao2.ekle(99_000L); ao2.ekle(-5L)
    esit("asiri aralik alinmaz", 0, ao2.sayi())
    val ao3 = SesAkisi.AralikOlcer(5)
    repeat(20) { ao3.ekle(2000L) }
    esit("pencere siniri", 5, ao3.sayi())
    ao3.temizle()
    esit("temizlenir", 0, ao3.sayi())

    println("== ongorulu carpan ==")
    esit("butce bilinmiyorsa 1", 1f, SesAkisi.ongoruluCarpan(9000L, 0L))
    esit("tahmin yoksa 1", 1f, SesAkisi.ongoruluCarpan(0L, 2000L))
    esit("butceye sigiyorsa 1", 1f, SesAkisi.ongoruluCarpan(1800L, 2000L))
    esit("tam butce kadar ise 1", 1f, SesAkisi.ongoruluCarpan(2000L, 2000L))
    kontrol("butceyi asinca hizlanir",
        SesAkisi.ongoruluCarpan(2600L, 2000L) in 1.25f..1.35f,
        SesAkisi.ongoruluCarpan(2600L, 2000L).toString())
    esit("cok asinca ust sinir", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.ongoruluCarpan(9700L, 2000L))
    kontrol("artan monoton",
        SesAkisi.ongoruluCarpan(2200L, 2000L) < SesAkisi.ongoruluCarpan(3000L, 2000L))

    println("== birlesik carpan ==")
    // 10.58: ust sinir 1.25'e indi, 1.5 artik kirpilir
    esit("buyugu gecer", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.birlesikCarpan(1.5f, 1.2f))
    esit("buyugu gecer (ters)", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.birlesikCarpan(1.2f, 1.5f))
    esit("sinir altinda buyugu gecer", 1.2f, SesAkisi.birlesikCarpan(1.2f, 1.1f))
    esit("toplanmaz", SesAkisi.EN_YUKSEK_CARPAN, SesAkisi.birlesikCarpan(1.6f, 1.6f))
    esit("ikisi de 1 ise 1", 1f, SesAkisi.birlesikCarpan(1f, 1f))

    println("== karar: ongorulu hizlanma ==")
    // Kesilme hic olmamis ama replik butceyi asiyor: yine hizlanmali
    val ong = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.0,
        yeniTahminMs = 9700L, butceMs = 2000L)
    kontrol("uzun replik bastan hizlanir",
        ong.hizCarpani == SesAkisi.EN_YUKSEK_CARPAN, ong.toString())
    val ong2 = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.0,
        yeniTahminMs = 1500L, butceMs = 2000L)
    esit("kisa replik hizlanmaz", 1f, ong2.hizCarpani)
    // KES modunda ongorulu hizlanma da yok
    val ong3 = SesAkisi.karar(SesAkisi.KES, false, 0L, 0L, 0.9,
        yeniTahminMs = 9700L, butceMs = 2000L)
    esit("KES modunda hizlanma yok", 1f, ong3.hizCarpani)
    // eski imza (yeni parametreler olmadan) hala calisiyor
    val eski = SesAkisi.karar(SesAkisi.HIZLAN, false, 0L, 0L, 0.0)
    esit("varsayilan parametrelerle 1", 1f, eski.hizCarpani)

    println("== kayit ==")
    SesAkisi.temizle()
    SesAkisi.kayitAcik = false
    SesAkisi.yaz("gorunmez")
    esit("kapaliyken yazmaz", 0, SesAkisi.satirSayisi())
    SesAkisi.kayitAcik = true
    SesAkisi.yaz("bir")
    SesAkisi.yaz("iki")
    esit("acikken yazar", 2, SesAkisi.satirSayisi())
    esit("sirayla", listOf("bir", "iki"), SesAkisi.tumu())
    repeat(SesAkisi.KAYIT_SINIRI + 50) { SesAkisi.yaz("x$it") }
    esit("kayit siniri", SesAkisi.KAYIT_SINIRI, SesAkisi.satirSayisi())
    kontrol("bas kesilir, son kalir", SesAkisi.tumu().last() == "x${SesAkisi.KAYIT_SINIRI + 49}",
        SesAkisi.tumu().last())
    SesAkisi.temizle()
    esit("temizlenir", 0, SesAkisi.satirSayisi())
    SesAkisi.kayitAcik = false

    println("== bicimleme ==")
    esit("sn bicimi", "1.5 sn", SesAkisi.sn(1500L).replace(',', '.'))
    esit("saat bicimi", "01:02:03.004", SesAkisi.saat(3_723_004L))
    esit("sifir saat", "00:00:00.000", SesAkisi.saat(0L))

    println()
    println("GECTI: $gecti   KALDI: $kaldi")
    if (kaldi > 0) System.exit(1)
}
