package com.example.altyazi

/** YALNIZ DERLEME DENETIMI: MainActivity'nin kullandigi disa acik yuz. */
object CaptureService {
    @Volatile var running = false
    fun sesAkisOzeti(): String = "-"
    fun sesDogalDurumu(): String = "-"
}
