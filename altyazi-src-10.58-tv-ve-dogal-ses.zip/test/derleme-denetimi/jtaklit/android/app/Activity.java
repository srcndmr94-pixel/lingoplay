package android.app;
public class Activity extends android.content.Context {
    public <T extends android.view.View> T findViewById(int id) { return null; }
    public boolean isFinishing() { return false; }
    public void startActivity(android.content.Intent i) {}
    public android.content.res.Resources getResources() { return new android.content.res.Resources(); }
    public androidx.activity.OnBackPressedDispatcher getOnBackPressedDispatcher() {
        return new androidx.activity.OnBackPressedDispatcher();
    }
    public <I, O> androidx.activity.result.ActivityResultLauncher<I> registerForActivityResult(
            androidx.activity.result.contract.ActivityResultContract<I, O> contract,
            androidx.activity.result.ActivityResultCallback<O> callback) {
        return new androidx.activity.result.ActivityResultLauncher<I>();
    }
    public boolean isDestroyed() { return false; }
    public void requestPermissions(String[] permissions, int requestCode) {}
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {}
}
