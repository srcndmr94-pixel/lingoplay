package com.example.altyazi

import android.content.Context

/** YALNIZ DERLEME DENETIMI: TvMode'un Android'e bagli yuzu. */
object TvMode {
    fun isTvDevice(context: Context): Boolean = false
    fun externalDisplayConnected(context: Context): Boolean = false
}
