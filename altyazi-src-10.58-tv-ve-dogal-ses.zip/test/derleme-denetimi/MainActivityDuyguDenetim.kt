package com.example.altyazi

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

/**
 * SALT DERLEME DENETIMI: MainActivity'nin 10.54'te eklenen duygu, ozel
 * ayar ve ayar menusu fonksiyonlari -- GERCEK GOVDELERIYLE.
 */
class MainActivityDuyguDenetim : Activity() {

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var tvSesDurum: TextView
    private lateinit var cbDuygu: CheckBox
    private lateinit var boxDuygu: LinearLayout
    private lateinit var rgDuyguNot: RadioGroup
    private lateinit var cbDuyguUnlem: CheckBox
    private lateinit var cbDuyguCumle: CheckBox
    private lateinit var cbDuyguTr: CheckBox
    private lateinit var sbDuyguSiddet: SeekBar
    private lateinit var tvDuyguSiddet: TextView
    private lateinit var tvDuyguDurum: TextView
    private lateinit var rgSesAkis: RadioGroup
    private lateinit var cbSesKaydi: CheckBox
    private lateinit var tvSesAkisOzet: TextView
    private lateinit var tvDogalDurum: TextView
    private lateinit var cbSesAdsizAtla: CheckBox
    private lateinit var cbSesTekrarSuz: CheckBox
    private lateinit var boxSesCinsiyet: LinearLayout
    private lateinit var tvSesCinsiyetOzet: TextView
    private lateinit var cbYanSol: CheckBox
    private lateinit var cbYanSag: CheckBox
    private lateinit var cbMenuModu: CheckBox
    private var otomatikTaramaYapildi = false
    private lateinit var tvOzelDurum: TextView
    private lateinit var boxOzel: LinearLayout
    private val ozelYaziKutulari = ArrayList<Pair<OzelAyar.Satir, EditText>>()

    private var acikBolum = -1
    private var sesDeneme: SesliOku? = null
    private var duyguDeneSira = 0

    private val ayarKartIdleri: List<IntArray> = listOf(
        intArrayOf(R.id.secRegion),
        intArrayOf(R.id.secLook),
        intArrayOf(R.id.secContent, R.id.secAi),
        intArrayOf(R.id.secSes),
        intArrayOf(R.id.secDuygu),
        intArrayOf(),
        intArrayOf(R.id.secOzel),
        intArrayOf(R.id.secAdvanced),
    )

    private val ayarBasliklari = listOf(
        "Ekran alani", "Yazi ve gorunum", "Dil ve ceviri", "Sesli okuma",
        "Duygu ve unlemler", "Cihaz ve baglanti", "Ozel ayarlar", "Gelismis",
    )

    private val ayarSatirIdleri = intArrayOf(
        R.id.ayarSatir1, R.id.ayarSatir2, R.id.ayarSatir3, R.id.ayarSatir4,
        R.id.ayarSatir5, R.id.ayarSatir6, R.id.ayarSatir7, R.id.ayarSatir8,
    )

    private val ayarOzetIdleri = intArrayOf(
        R.id.ayarOzet1, R.id.ayarOzet2, R.id.ayarOzet3, R.id.ayarOzet4,
        R.id.ayarOzet5, R.id.ayarOzet6, R.id.ayarOzet7, R.id.ayarOzet8,
    )

    private val ozelTabloSec =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) ozelTabloyuAktar(uri)
        }

    private val SES_MIN = 50

    private lateinit var sbSesHiz: SeekBar
    private lateinit var sbSesTon: SeekBar
    private lateinit var cbSesCinsiyet: CheckBox
    private lateinit var cbSesKarakter: CheckBox
    private lateinit var cbSesInternet: CheckBox
    private lateinit var cbSesDogalGenAi: CheckBox

    private fun dpx(v: Int): Int = v * 3

    private fun sozlukPenceresi(a: String?, b: String?) {}

    private fun gecmisPenceresi() {}

    private fun yardimPenceresi() {}

    private fun sesEtiketleri() {}

    private fun sesleriTara() {}

    private fun onizlemeyiGuncelle() {}

    /** Gercek MainActivity'de ses motorunu acan yardimci; burada taklit. */
    private fun sesMotoru(sonra: (SesliOku) -> Unit) {
        sonra(SesliOku(this))
    }

    private fun duyguKur() {
        cbDuygu = findViewById(R.id.cbDuygu)
        boxDuygu = findViewById(R.id.boxDuygu)
        rgDuyguNot = findViewById(R.id.rgDuyguNot)
        cbDuyguUnlem = findViewById(R.id.cbDuyguUnlem)
        cbDuyguCumle = findViewById(R.id.cbDuyguCumle)
        cbDuyguTr = findViewById(R.id.cbDuyguTr)
        sbDuyguSiddet = findViewById(R.id.sbDuyguSiddet)
        tvDuyguSiddet = findViewById(R.id.tvDuyguSiddet)
        tvDuyguDurum = findViewById(R.id.tvDuyguDurum)

        cbDuygu.isChecked = prefs.duyguAcik
        boxDuygu.visibility = if (prefs.duyguAcik) View.VISIBLE else View.GONE
        cbDuygu.setOnCheckedChangeListener { _, acik ->
            prefs.duyguAcik = acik
            boxDuygu.visibility = if (acik) View.VISIBLE else View.GONE
            ayarOzetleriYaz()
        }

        findViewById<RadioButton>(
            when (prefs.duyguNotModu) {
                DuyguSesi.NOT_KISIK -> R.id.rbDuyguKisik
                DuyguSesi.NOT_CANLANDIR -> R.id.rbDuyguCanli
                else -> R.id.rbDuyguAtla
            }
        ).isChecked = true
        rgDuyguNot.setOnCheckedChangeListener { _, id ->
            prefs.duyguNotModu = when (id) {
                R.id.rbDuyguKisik -> DuyguSesi.NOT_KISIK
                R.id.rbDuyguCanli -> DuyguSesi.NOT_CANLANDIR
                else -> DuyguSesi.NOT_ATLA
            }
            ayarOzetleriYaz()
        }

        cbDuyguUnlem.isChecked = prefs.duyguUnlem
        cbDuyguUnlem.setOnCheckedChangeListener { _, v -> prefs.duyguUnlem = v }
        cbDuyguCumle.isChecked = prefs.duyguCumle
        cbDuyguCumle.setOnCheckedChangeListener { _, v -> prefs.duyguCumle = v }
        cbDuyguTr.isChecked = prefs.duyguTr
        cbDuyguTr.setOnCheckedChangeListener { _, v -> prefs.duyguTr = v }

        sbDuyguSiddet.progress = prefs.duyguSiddet
        duyguSiddetYaz(prefs.duyguSiddet)
        sbDuyguSiddet.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, deger: Int, kullanici: Boolean) {
                duyguSiddetYaz(deger)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}

            override fun onStopTrackingTouch(sb: SeekBar?) {
                prefs.duyguSiddet = sbDuyguSiddet.progress
                ayarOzetleriYaz()
            }
        })

        findViewById<TextView>(R.id.tvDuyguOrnek).text = DUYGU_ORNEKLERI
        findViewById<View>(R.id.btnDuyguDene).setOnClickListener { duyguyuDene() }
    }

    private fun duyguSiddetYaz(deger: Int) {
        tvDuyguSiddet.text = "Duygu şiddeti · %$deger" + when {
            deger <= 20 -> " (çok hafif)"
            deger >= 85 -> " (çok belirgin)"
            else -> ""
        }
    }

    private fun duyguyuDene() {
        prefs.duyguSiddet = sbDuyguSiddet.progress
        val ornek = DUYGU_DENEME[duyguDeneSira % DUYGU_DENEME.size]
        duyguDeneSira++
        val sonuc = DuyguSesi.hazirla(
            ornek,
            duyguAcik = cbDuygu.isChecked,
            notModu = prefs.duyguNotModu,
            unlemAcik = cbDuyguUnlem.isChecked,
            cumleAcik = cbDuyguCumle.isChecked,
            trAcik = cbDuyguTr.isChecked,
            siddet = sbDuyguSiddet.progress / 100f,
        )
        if (!sonuc.okunur) {
            tvDuyguDurum.text = "«$ornek» okunmadı · sahne notu atlanıyor"
            Toast.makeText(
                this,
                "«$ornek» okunmaz: sahne notu atlanıyor. Duymak için " +
                    "«Kısık sesle oku» ya da «Ünlem gibi canlandır» seçin.",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        // Durum yazısı DUYGU kartına yazılır: sesli okuma kartı o sırada
        // gizli olduğu için tvSesDurum'a yazmak kullanıcıya hiç görünmezdi.
        tvDuyguDurum.text = "«$ornek» → «${sonuc.metin}» · ${sonuc.duygu.ad} · " +
            "perde ${"%.2f".format(sonuc.perde)} · hız ${"%.2f".format(sonuc.hiz)}"
        sesMotoru { s ->
            duyguAyarlariniUygula(s)
            s.oku(ornek)
        }
    }

    private fun duyguAyarlariniUygula(s: SesliOku) {
        s.duyguAcik = cbDuygu.isChecked
        s.duyguNotModu = prefs.duyguNotModu
        s.duyguUnlem = cbDuyguUnlem.isChecked
        s.duyguCumle = cbDuyguCumle.isChecked
        s.duyguTr = cbDuyguTr.isChecked
        s.duyguSiddet = sbDuyguSiddet.progress / 100f
    }

    private fun ozelKur() {
        tvOzelDurum = findViewById(R.id.tvOzelDurum)
        boxOzel = findViewById(R.id.boxOzel)
        findViewById<View>(R.id.btnOzelAktar).setOnClickListener {
            try {
                ozelTabloSec.launch(arrayOf("*/*"))
            } catch (t: Throwable) {
                Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnOzelSablon).setOnClickListener {
            panoyaYaz(OzelAyar.sablon())
            Toast.makeText(this, "Örnek tablo panoya kopyalandı.", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnOzelSil).setOnClickListener {
            prefs.ozelTablo = ""
            ozelCiz()
            ayarOzetleriYaz()
            Toast.makeText(this, "Tablo silindi.", Toast.LENGTH_SHORT).show()
        }
        ozelCiz()
    }

    private fun panoyaYaz(metin: String) {
        try {
            val pano = getSystemService(Context.CLIPBOARD_SERVICE)
                as android.content.ClipboardManager
            pano.setPrimaryClip(android.content.ClipData.newPlainText("GameLingo", metin))
        } catch (_: Throwable) {
        }
    }

    private fun ozelTabloyuAktar(uri: Uri) {
        val ham = try {
            contentResolver.openInputStream(uri)?.use { akis ->
                akis.readBytes().toString(Charsets.UTF_8)
            }
        } catch (t: Throwable) {
            CrashLog.note(this, "ozel tablo okuma", t)
            null
        }
        if (ham.isNullOrBlank()) {
            Toast.makeText(this, "Dosya okunamadı ya da boş.", Toast.LENGTH_LONG).show()
            return
        }
        val satirlar = OzelAyar.coz(ham)
        if (satirlar.isEmpty()) {
            Toast.makeText(
                this,
                "Tabloda ayar bulunamadı. Sütunlar: Ad ; Tür ; Varsayılan ; Bölüm",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        prefs.ozelTablo = ham
        ozelCiz()
        ayarOzetleriYaz()
        Toast.makeText(this, "${satirlar.size} özel ayar aktarıldı.", Toast.LENGTH_SHORT).show()
    }

    private fun ozelLp(ustBosluk: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dpx(ustBosluk) }

    private fun ozelCiz() {
        boxOzel.removeAllViews()
        ozelYaziKutulari.clear()
        val satirlar = OzelAyar.coz(prefs.ozelTablo)
        tvOzelDurum.text = OzelAyar.ozet(satirlar)
        findViewById<View>(R.id.btnOzelSil).visibility =
            if (satirlar.isEmpty()) View.GONE else View.VISIBLE
        if (satirlar.isEmpty()) return
        for ((bolum, grup) in OzelAyar.bolumler(satirlar)) {
            boxOzel.addView(TextView(this).apply {
                text = bolum
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = ozelLp(16)
            })
            for (sat in grup) ozelKontrol(sat)
        }
    }

    private fun ozelKontrol(sat: OzelAyar.Satir) {
        when (sat.tur) {
            OzelAyar.T_ANAHTAR -> boxOzel.addView(CheckBox(this).apply {
                text = sat.ad
                isChecked = prefs.ozelDeger(sat.anahtar, if (sat.varsayilanAcik) "1" else "0") == "1"
                layoutParams = ozelLp(4)
                setOnCheckedChangeListener { _, v ->
                    prefs.ozelDegerYaz(sat.anahtar, if (v) "1" else "0")
                }
            })

            OzelAyar.T_KAYDIRAK -> {
                val etiket = TextView(this).apply { textSize = 13f; layoutParams = ozelLp(10) }
                val baslangic = prefs.ozelDeger(sat.anahtar, sat.varsayilanSayi.toString())
                    .toIntOrNull()?.coerceIn(0, 100) ?: 0
                etiket.text = sat.ad + " · %" + baslangic
                boxOzel.addView(etiket)
                boxOzel.addView(SeekBar(this).apply {
                    max = 100
                    progress = baslangic
                    layoutParams = ozelLp(0)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(sb: SeekBar?, deger: Int, kul: Boolean) {
                            etiket.text = sat.ad + " · %" + deger
                        }

                        override fun onStartTrackingTouch(sb: SeekBar?) {}

                        override fun onStopTrackingTouch(sb: SeekBar?) {
                            prefs.ozelDegerYaz(sat.anahtar, (sb?.progress ?: 0).toString())
                        }
                    })
                })
            }

            OzelAyar.T_SAYI, OzelAyar.T_YAZI -> {
                boxOzel.addView(TextView(this).apply {
                    text = sat.ad
                    textSize = 13f
                    layoutParams = ozelLp(10)
                })
                val kutu = EditText(this).apply {
                    setText(prefs.ozelDeger(sat.anahtar, sat.varsayilan))
                    if (sat.tur == OzelAyar.T_SAYI) {
                        inputType = android.text.InputType.TYPE_CLASS_NUMBER
                    }
                    layoutParams = ozelLp(0)
                    setOnFocusChangeListener { v, odak ->
                        if (!odak) prefs.ozelDegerYaz(sat.anahtar, (v as EditText).text.toString())
                    }
                }
                ozelYaziKutulari += sat to kutu
                boxOzel.addView(kutu)
            }

            else -> {
                val secenekler = if (sat.secenekler.isEmpty()) listOf(sat.varsayilan)
                else sat.secenekler
                boxOzel.addView(TextView(this).apply {
                    text = sat.ad
                    textSize = 13f
                    layoutParams = ozelLp(10)
                })
                boxOzel.addView(Spinner(this).apply {
                    adapter = ArrayAdapter(
                        this@MainActivityDuyguDenetim,
                        android.R.layout.simple_spinner_dropdown_item,
                        secenekler,
                    )
                    val kayitli = prefs.ozelDeger(sat.anahtar, sat.varsayilan)
                    setSelection(secenekler.indexOf(kayitli).coerceAtLeast(0))
                    layoutParams = ozelLp(0)
                    // Kuruluş sırasında tetiklenen ilk seçimi yazmıyoruz:
                    // kayıtlı değerin üstüne ilk seçeneği yazardı.
                    var kuruluyor = true
                    onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            ebeveyn: AdapterView<*>?,
                            gorunum: View?,
                            sira: Int,
                            kimlik: Long,
                        ) {
                            if (kuruluyor) {
                                kuruluyor = false
                                return
                            }
                            prefs.ozelDegerYaz(sat.anahtar, secenekler.getOrElse(sira) { "" })
                        }

                        override fun onNothingSelected(ebeveyn: AdapterView<*>?) {}
                    }
                })
            }
        }
    }

    private fun ayarMenusuKur() {
        for ((sira, id) in ayarSatirIdleri.withIndex()) {
            findViewById<View>(id)?.setOnClickListener { ayarBolumuAc(sira) }
        }
        findViewById<View>(R.id.btnAyarGeri)?.setOnClickListener { ayarListesineDon() }
        ayarListesineDon()
        onBackPressedDispatcher.addCallback(
            this,
            object : androidx.activity.OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (acikBolum >= 0) {
                        ayarListesineDon()
                        return
                    }
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            },
        )
    }

    private fun ayarBolumuAc(sira: Int) {
        if (sira < 0 || sira >= ayarKartIdleri.size) return
        val scroll = findViewById<ScrollView>(R.id.scroll)
        // Cihaz ve bağlantı: kendi kartı yok, ana ekrandaki mod kutusuna götürür.
        if (ayarKartIdleri[sira].isEmpty()) {
            val hedef = findViewById<View>(R.id.segMode) ?: return
            scroll?.post { scroll.smoothScrollTo(0, (hedef.top - dpx(8)).coerceAtLeast(0)) }
            return
        }
        acikBolum = sira
        prefs.ayarBolumu = sira
        findViewById<View>(R.id.ayarMenu)?.visibility = View.GONE
        findViewById<View>(R.id.ayarBaslikCubugu)?.visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvAyarBaslik)?.text = ayarBasliklari[sira]
        for ((n, idler) in ayarKartIdleri.withIndex()) {
            val gorunur = n == sira
            for (id in idler) {
                findViewById<View>(id)?.visibility = if (gorunur) View.VISIBLE else View.GONE
            }
        }
        val cubuk = findViewById<View>(R.id.ayarBaslikCubugu)
        if (scroll != null && cubuk != null) {
            scroll.post { scroll.smoothScrollTo(0, (cubuk.top - dpx(8)).coerceAtLeast(0)) }
        }
    }

    private fun ayarListesineDon() {
        if (::boxOzel.isInitialized) ozelYazilariKaydet()
        acikBolum = -1
        prefs.ayarBolumu = -1
        findViewById<View>(R.id.ayarMenu)?.visibility = View.VISIBLE
        findViewById<View>(R.id.ayarBaslikCubugu)?.visibility = View.GONE
        for (idler in ayarKartIdleri) {
            for (id in idler) findViewById<View>(id)?.visibility = View.GONE
        }
        ayarOzetleriYaz()
    }

    private fun ayarOzetleriYaz() {
        if (!::prefs.isInitialized) return
        val ozetler = try {
            listOf(
                "Altyazı %${prefs.topPct}–%${prefs.bottomPct}" +
                    (if (prefs.menuModu) " · MENÜ MODU açık"
                    else if (!prefs.menuTranslate) " · yan yazı kapalı"
                    else " · yan yazı: " + yanAlanAdlari()),
                "Boyut ${prefs.subtitleSize} · ${konumAdi(prefs.subtitlePos)}" +
                    (if (prefs.subtitleOutline) " · kenarlıklı" else ""),
                motorlarOzeti(),
                if (prefs.sesliOku) {
                    "Açık" + (if (prefs.sesDogalGenAi) " · doğal ses" else "") +
                        (if (prefs.sesKarakter) " · karakter ayrımı" else "")
                } else "Kapalı",
                if (prefs.duyguAcik) {
                    notModuAdi(prefs.duyguNotModu) + " · şiddet %${prefs.duyguSiddet}"
                } else "Kapalı",
                (if (prefs.tvMode) "TV modu" else "Telefon modu") +
                    (if (prefs.bridgeOn) " · köprü açık" else " · köprü kapalı"),
                OzelAyar.ozet(OzelAyar.coz(prefs.ozelTablo)),
                motorAdi(prefs.mode) +
                    (if (prefs.diagnostics) " · teşhis açık" else " · teşhis kapalı"),
            )
        } catch (_: Throwable) {
            return
        }
        for ((sira, id) in ayarOzetIdleri.withIndex()) {
            findViewById<TextView>(id)?.text = ozetler.getOrElse(sira) { "" }
        }
    }

    private fun konumAdi(deger: Int): String = when (deger) {
        1 -> "altyazıyı kapatır"
        2 -> "altyazının altında"
        3 -> "ekranın en altı"
        else -> "altyazının üstünde"
    }

    private fun notModuAdi(deger: Int): String = when (deger) {
        DuyguSesi.NOT_KISIK -> "sahne notu kısık"
        DuyguSesi.NOT_CANLANDIR -> "sahne notu canlandırılıyor"
        else -> "sahne notu atlanıyor"
    }

    private fun motorlarOzeti(): String {
        val acik = ArrayList<String>(4)
        if (prefs.googleCeviri) acik += "Google"
        if (prefs.deepLEnabled) acik += "DeepL"
        if (prefs.opusMtEnabled) acik += "OPUS"
        if (prefs.firefoxMotoru) acik += "Firefox"
        val liste = if (acik.isEmpty()) "motor seçilmedi" else acik.joinToString(" + ")
        return liste + " · " + bicimAdi(prefs.ceviriBicimi)
    }

    private fun bicimAdi(deger: Int): String = when (deger) {
        0 -> "hızlı"
        2 -> "doğru"
        else -> "dengeli"
    }

    private fun motorAdi(deger: Int): String = when (deger) {
        Prefs.MODE_AI -> "Yapay zekâ"
        Prefs.MODE_HYBRID -> "Hibrit"
        else -> "Anında"
    }

    private fun sesAyarlariniUygula(s: SesliOku) {
        prefs.sesHiz = sbSesHiz.progress + SES_MIN
        prefs.sesTon = sbSesTon.progress + SES_MIN
        s.hiz = prefs.sesHiz / 100f
        s.ton = prefs.sesTon / 100f
        s.adiAtla = prefs.showSpeaker
        s.cinsiyetAyrimi = cbSesCinsiyet.isChecked
        s.karakterAyrimi = cbSesKarakter.isChecked
        s.erkekSesAdi = prefs.sesErkekAdi
        s.kadinSesAdi = prefs.sesKadinAdi
        s.internetSesi = cbSesInternet.isChecked
        s.havuz = SesHavuzu.oku(prefs.sesHavuzu)
        s.varsayilanSesAdi = prefs.sesVarsayilanAdi
        s.dogalSesAcik = cbSesDogalGenAi.isChecked
        // Duygu kontrolleri henüz bağlanmamış olabilir (kuruluş sırası):
        // o durumda kayıtlı ayarlar kullanılır.
        s.akisModu = prefs.sesAkisModu
        if (::cbDuygu.isInitialized) {
            duyguAyarlariniUygula(s)
        } else {
            s.duyguAcik = prefs.duyguAcik
            s.duyguNotModu = prefs.duyguNotModu
            s.duyguUnlem = prefs.duyguUnlem
            s.duyguCumle = prefs.duyguCumle
            s.duyguTr = prefs.duyguTr
            s.duyguSiddet = prefs.duyguSiddet / 100f
        }
    }

    private fun baglaGezinti() {
        val scroll = findViewById<ScrollView>(R.id.scroll)
        fun git(id: Int) {
            val v = findViewById<View>(id) ?: return
            scroll.post { scroll.smoothScrollTo(0, (v.top - dpx(8)).coerceAtLeast(0)) }
        }
        // 10.54: kısayol kutuları artık ilgili ayar BÖLÜMÜNÜ açıyor; kartlar
        // liste görünümünde gizli olduğu için yalnız kaydırmak yetmiyordu.
        findViewById<View>(R.id.tileRegion).setOnClickListener {
            ayarBolumuAc(0)
        }
        findViewById<View>(R.id.tileAi).setOnClickListener {
            ayarBolumuAc(2)
        }
        findViewById<View>(R.id.tileLook).setOnClickListener {
            ayarBolumuAc(1)
        }
        findViewById<View>(R.id.tileDict).setOnClickListener { sozlukPenceresi(null, null) }
        findViewById<View>(R.id.navHome).setOnClickListener { scroll.post { scroll.smoothScrollTo(0, 0) } }
        findViewById<View>(R.id.navSettings).setOnClickListener {
            ayarListesineDon()
            git(R.id.secSettings)
        }
        findViewById<View>(R.id.navHistory).setOnClickListener { gecmisPenceresi() }
        findViewById<View>(R.id.navHelp).setOnClickListener { yardimPenceresi() }
        UserDict.apply(this)
    }

    private fun ozelYazilariKaydet() {
        for ((sat, kutu) in ozelYaziKutulari) {
            prefs.ozelDegerYaz(sat.anahtar, kutu.text.toString())
        }
    }

    private fun sesAkisiKur() {
        rgSesAkis = findViewById(R.id.rgSesAkis)
        cbSesKaydi = findViewById(R.id.cbSesKaydi)
        tvSesAkisOzet = findViewById(R.id.tvSesAkisOzet)

        findViewById<RadioButton>(
            when (prefs.sesAkisModu) {
                SesAkisi.KES -> R.id.rbAkisKes
                SesAkisi.BITIR_ATLA -> R.id.rbAkisBitir
                else -> R.id.rbAkisHizlan
            }
        ).isChecked = true
        rgSesAkis.setOnCheckedChangeListener { _, id ->
            prefs.sesAkisModu = when (id) {
                R.id.rbAkisKes -> SesAkisi.KES
                R.id.rbAkisBitir -> SesAkisi.BITIR_ATLA
                else -> SesAkisi.HIZLAN
            }
            // Çalışan servisin motoru da hemen öğrensin; yeniden
            // başlatmak gerekmesin.
            sesDeneme?.akisModu = prefs.sesAkisModu
            sesAkisOzetiYaz()
        }

        cbSesKaydi.isChecked = prefs.sesKaydi
        cbSesKaydi.setOnCheckedChangeListener { _, acik ->
            prefs.sesKaydi = acik
            SesAkisi.kayitAcik = acik
            if (acik) SesAkisi.temizle()
            sesAkisOzetiYaz()
        }

        findViewById<View>(R.id.btnSesKaydiKopyala).setOnClickListener { sesKaydiniKopyala() }
        findViewById<View>(R.id.btnSesKaydiTemizle).setOnClickListener {
            SesAkisi.temizle()
            sesAkisOzetiYaz()
            Toast.makeText(this, "Ses kaydı temizlendi.", Toast.LENGTH_SHORT).show()
        }
        sesAkisOzetiYaz()
    }

    private fun sesAkisOzetiYaz() {
        if (!::tvSesAkisOzet.isInitialized) return
        val satir = SesAkisi.satirSayisi()
        tvSesAkisOzet.text = if (!prefs.sesKaydi) {
            "Kayıt kapalı. " + CaptureService.sesAkisOzeti()
        } else {
            "Kayıt açık · $satir satır. " + CaptureService.sesAkisOzeti()
        }
    }

    private fun sesKaydiniKopyala() {
        val satirlar = SesAkisi.tumu()
        val ozet = CaptureService.sesAkisOzeti()
        if (satirlar.isEmpty()) {
            Toast.makeText(
                this,
                if (prefs.sesKaydi) "Kayıt boş. Sesli okumayı açıp bir sahne oynatın."
                else "Önce «Ses çalışma kaydı»nı açın.",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        val metin = StringBuilder()
        metin.append(ozet).append('\n')
        metin.append("mod=").append(
            when (prefs.sesAkisModu) {
                SesAkisi.KES -> "kes"
                SesAkisi.BITIR_ATLA -> "cümleyi bitir, atla"
                else -> "hızlanarak yetiş"
            }
        )
        metin.append(" · hız %").append(prefs.sesHiz)
        metin.append(" · ton %").append(prefs.sesTon)
        metin.append(" · doğal ses ").append(if (prefs.sesDogalGenAi) "açık" else "kapalı")
        metin.append(" · duygu ").append(if (prefs.duyguAcik) "açık %" + prefs.duyguSiddet else "kapalı")
        metin.append('\n').append("----\n")
        for (l in satirlar) metin.append(l).append('\n')
        metin.append("----\n").append(ozet).append('\n')
        panoyaYaz(metin.toString())
        Toast.makeText(this, "${satirlar.size} satır kopyalandı.", Toast.LENGTH_SHORT).show()
    }

    private fun dogallikKur() {
        tvDogalDurum = findViewById(R.id.tvDogalDurum)
        cbSesAdsizAtla = findViewById(R.id.cbSesAdsizAtla)
        cbSesTekrarSuz = findViewById(R.id.cbSesTekrarSuz)
        boxSesCinsiyet = findViewById(R.id.boxSesCinsiyet)
        tvSesCinsiyetOzet = findViewById(R.id.tvSesCinsiyetOzet)

        cbSesAdsizAtla.isChecked = prefs.sesAdsizAtla
        cbSesAdsizAtla.setOnCheckedChangeListener { _, v ->
            prefs.sesAdsizAtla = v
            sesDeneme?.adsizAtla = v
        }
        cbSesTekrarSuz.isChecked = prefs.sesTekrarSuz
        cbSesTekrarSuz.setOnCheckedChangeListener { _, v ->
            prefs.sesTekrarSuz = v
            sesDeneme?.tekrarSuz = v
        }

        findViewById<View>(R.id.btnSesDogalAyar).setOnClickListener { enDogalAyarlar() }
        dogalDurumYaz()
        sesCinsiyetleriniCiz()
        havuzBossaTara()
    }

    private fun enDogalAyarlar() {
        prefs.sesHiz = 100
        prefs.sesTon = 100
        prefs.duyguSiddet = 45
        sbSesHiz.progress = 100 - SES_MIN
        sbSesTon.progress = 100 - SES_MIN
        if (::sbDuyguSiddet.isInitialized) {
            sbDuyguSiddet.progress = 45
            duyguSiddetYaz(45)
        }
        sesDeneme?.let { sesAyarlariniUygula(it) }
        sesEtiketleri()
        ayarOzetleriYaz()
        Toast.makeText(this, "Hız %100 · ton %100 · duygu %45 yapıldı.", Toast.LENGTH_SHORT).show()
    }

    private fun dogalDurumYaz() {
        if (!::tvDogalDurum.isInitialized) return
        val durum = CaptureService.sesDogalDurumu()
        tvDogalDurum.text = if (!prefs.sesDogalGenAi) {
            "Doğal ses kapalı. Açılırsa cihazda destekleniyorsa kullanılır."
        } else {
            "Doğal ses motoru: $durum"
        }
    }

    private fun sesCinsiyetleriniCiz() {
        boxSesCinsiyet.removeAllViews()
        val kayitlar = SesHavuzu.oku(prefs.sesHavuzu)
        val elle = SesHavuzu.elleOku(prefs.sesCinsiyetElle).toMutableMap()
        tvSesCinsiyetOzet.text = SesHavuzu.elleOzet(kayitlar, elle)
        if (kayitlar.isEmpty()) return
        for (kayit in kayitlar) {
            boxSesCinsiyet.addView(sesCinsiyetSatiri(kayit, elle))
        }
    }

    private fun sesCinsiyetSatiri(
        kayit: SesHavuzu.Kayit,
        elle: MutableMap<String, Int>,
    ): View {
        val satir = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = ozelLp(10)
        }
        val etiket = TextView(this).apply {
            text = kisaSesAdi(kayit.ad) + "  " + kayit.hz.toInt() + " Hz"
            textSize = 12.5f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        satir.addView(etiket)
        val secili = elle[kayit.ad] ?: kayit.cinsiyet
        val erkek = cinsiyetDugmesi("Erkek", secili == SesPerdeOlcer.ERKEK)
        val kadin = cinsiyetDugmesi("Kadın", secili == SesPerdeOlcer.KADIN)
        val dene = TextView(this).apply {
            text = "Dinle"
            textSize = 12.5f
            setPadding(dpx(10), dpx(6), dpx(4), dpx(6))
            setTextColor(resources.getColor(R.color.lingo_primary, null))
            isClickable = true
            isFocusable = true
            setBackgroundResource(R.drawable.tv_odak)
            setOnClickListener { sesiDinle(kayit.ad) }
        }
        erkek.setOnClickListener {
            elle[kayit.ad] = SesPerdeOlcer.ERKEK
            prefs.sesCinsiyetElle = SesHavuzu.elleYaz(elle)
            sesDeneme?.cinsiyetElle = elle.toMap()
            sesCinsiyetleriniCiz()
        }
        kadin.setOnClickListener {
            elle[kayit.ad] = SesPerdeOlcer.KADIN
            prefs.sesCinsiyetElle = SesHavuzu.elleYaz(elle)
            sesDeneme?.cinsiyetElle = elle.toMap()
            sesCinsiyetleriniCiz()
        }
        satir.addView(erkek)
        satir.addView(kadin)
        satir.addView(dene)
        return satir
    }

    private fun cinsiyetDugmesi(yazi: String, secili: Boolean): TextView =
        TextView(this).apply {
            text = yazi
            textSize = 12.5f
            setPadding(dpx(10), dpx(6), dpx(10), dpx(6))
            setTextColor(
                if (secili) resources.getColor(R.color.lingo_on_primary, null)
                else resources.getColor(R.color.lingo_on_surface_variant, null)
            )
            setBackgroundResource(if (secili) R.drawable.bg_seg_on else R.drawable.tv_odak)
            isClickable = true
            isFocusable = true
        }

    private fun kisaSesAdi(ad: String): String {
        val p = ad.split('-')
        val kod = p.getOrNull(3) ?: ad
        val yer = if (ad.endsWith("network")) "ağ" else "cihaz"
        return "$kod · $yer"
    }

    private fun sesiDinle(ad: String) {
        sesMotoru { s -> s.sesiDinle(ad, SES_DENEME_METNI) }
    }

    private fun yanAlanlariKur() {
        cbYanSol = findViewById(R.id.cbYanSol)
        cbYanSag = findViewById(R.id.cbYanSag)
        cbMenuModu = findViewById(R.id.cbMenuModu)

        cbYanSol.isChecked = prefs.yanSolAcik
        cbYanSol.setOnCheckedChangeListener { _, v ->
            prefs.yanSolAcik = v
            yanAlanOzetleri()
            ayarOzetleriYaz()
        }
        cbYanSag.isChecked = prefs.yanSagAcik
        cbYanSag.setOnCheckedChangeListener { _, v ->
            prefs.yanSagAcik = v
            yanAlanOzetleri()
            ayarOzetleriYaz()
        }
        cbMenuModu.isChecked = prefs.menuModu
        cbMenuModu.setOnCheckedChangeListener { _, v ->
            prefs.menuModu = v
            ayarOzetleriYaz()
        }
        findViewById<View>(R.id.btnYanSol).setOnClickListener { alanSec(RegionActivity.ALAN_SOL) }
        findViewById<View>(R.id.btnYanSag).setOnClickListener { alanSec(RegionActivity.ALAN_SAG) }
        yanAlanOzetleri()
    }

    private fun alanSec(alan: String) {
        try {
            startActivity(
                Intent(this, RegionActivity::class.java)
                    .putExtra(RegionActivity.EK_ALAN, alan)
            )
        } catch (t: Throwable) {
            Toast.makeText(this, "Alan seçme ekranı açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun yanAlanOzetleri() {
        findViewById<TextView>(R.id.tvYanSol)?.text = "Sol: " + YanAlan.ozet(
            YanAlan.Kutu(prefs.yanSolAcik, prefs.yanSolLeft, prefs.yanSolTop, prefs.yanSolRight, prefs.yanSolBottom)
        )
        findViewById<TextView>(R.id.tvYanSag)?.text = "Sağ: " + YanAlan.ozet(
            YanAlan.Kutu(prefs.yanSagAcik, prefs.yanSagLeft, prefs.yanSagTop, prefs.yanSagRight, prefs.yanSagBottom)
        )
    }

    private fun havuzBossaTara() {
        if (otomatikTaramaYapildi) return
        if (prefs.sesHavuzu.isNotBlank()) return
        if (!prefs.sesliOku) return
        otomatikTaramaYapildi = true
        ui.postDelayed({
            try {
                if (prefs.sesHavuzu.isBlank()) sesleriTara()
            } catch (e: Throwable) {
                CrashLog.note(this, "otomatik ses taramasi", e)
            }
        }, 1200L)
    }

    private fun yanAlanAdlari(): String {
        val acik = ArrayList<String>(3)
        if (prefs.yanSolAcik) acik += "sol"
        if (prefs.yanSagAcik) acik += "sağ"
        if (prefs.menuAlanAcik) acik += "özel"
        return if (acik.isEmpty()) "üst bölge" else acik.joinToString(" + ")
    }

    private fun tvDuzeni() {
        if (!TvMode.isTvDevice(this)) return
        val kok = findViewById<View>(R.id.scroll) ?: return
        val dm = resources.displayMetrics
        val bosluk = TvYerlesim.overscanPx(dm.widthPixels, dm.heightPixels)
        kok.setPadding(bosluk, bosluk, bosluk, bosluk)
        kok.post {
            try {
                findViewById<View>(R.id.ayarSatir1)?.requestFocus()
            } catch (_: Throwable) {
            }
        }
    }

    companion object {
        private const val DUYGU_ORNEKLERI = "hmm -> himm"
        private val DUYGU_DENEME = listOf("Hmm, bir saniye.", "Ahaha!")
        private const val SES_DENEME_METNI = "Merhaba."
    }
}
