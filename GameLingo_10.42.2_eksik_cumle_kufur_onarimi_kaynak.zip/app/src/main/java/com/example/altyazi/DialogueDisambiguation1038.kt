package com.example.altyazi

/**
 * Conservative lexical disambiguation of unmistakable literal MT errors.
 * Not a translation model: only edits a problematic Turkish fragment when
 * both the English source and the literal output independently match.
 * Never alters the English OCR text or a model's already-natural result.
 */
object DialogueDisambiguation1038 {
    private val tagQuestion = Regex("""(?i)(?:[.!?]\s+|,\s*)right\?\s*$""")
    private val literalRight = Regex("""(?iu)\bsağ\s*\?$""")
    private val untranslatedNerd = Regex("""(?iu)\b(?:poindexter|pointexter)(?:['’]sın)?\b""")
    private val birdsBees = Regex("""(?iu)kuşlar\s+ve\s+arılar""")
    private val sororityLiteral = Regex("""(?iu)kardeşlik\s+kızı""")

    fun repair(source: String, translated: String): String {
        if (source.isBlank() || translated.isBlank()) return translated
        var result = translated
        if (tagQuestion.containsMatchIn(source)) {
            result = result.replace(literalRight, "değil mi?")
            result = result.replace(Regex("""(?iu)\.\s+değil mi\?$"""), ", değil mi?")
        }
        if (Regex("""(?i)\bpoindexter\b""").containsMatchIn(source)) {
            // A proper name is never replaced unless the source literally
            // identifies the slang noun poindexter.
            result = result.replace(untranslatedNerd) { m ->
                if (m.value.endsWith("sın", ignoreCase = true)) "ineksin" else "inek"
            }
        }
        if (Regex("""(?i)\bbirds\s+and\s+the\s+bees\b""").containsMatchIn(source)) {
            result = result.replace(birdsBees, "cinsellik")
        }
        if (Regex("""(?i)\bsorority\s+girl\b""").containsMatchIn(source)) {
            result = result.replace(sororityLiteral, "öğrenci topluluğundaki kız")
        }
        // "orders" in a command/request is "emirler", not purchase orders.
        // Both English context and the Turkish literal must match.
        if (Regex("""(?i)\b(?:what\s+are\s+your|await(?:ing)?\s+your)\s+orders\b""").containsMatchIn(source)) {
            result = result.replace(Regex("""(?iu)\bsiparişleriniz\b"""), "emirleriniz")
        }
        // Idiom is a life-or-death situation, not an emotional touching moment.
        if (Regex("""(?i)\btouch\s+and\s+go\b""").containsMatchIn(source)) {
            result = result.replace(Regex("""(?i)(?<!\p{L})(?:çok\s+)?dokunaklıydı(?!\p{L})"""), "durumu kritikti")
        }
        if (Regex("""(?i)\b(?:you|they|we)\s+are\s+avenged\b""").containsMatchIn(source)) {
            result = result.replace(Regex("""(?iu)(?<!\p{L})intikamınızı\s+aldınız(?!\p{L})""")) { m ->
                if (m.value.first().isUpperCase()) "İntikamınız alındı" else "intikamınız alındı"
            }
        }
        // 10.42: targeted repairs grounded in the actual live subtitles.
        // With an optional speaker label and trailing sound cue, "Mark?"
        // is a vocative. The literal Turkish noun "işaret" must not replace it.
        val addressedMark = Regex("""(?i)^\s*(?:\[[^]]+]\s*)?mark\?\s*(?:\[(?:shuddering|panting|sighs|groans|grunts)]\s*)?$""")
        if (addressedMark.matches(source) &&
            Regex("""(?iu)işaret\?""").containsMatchIn(result)) {
            result = result.replace(Regex("""(?iu)işaret\?"""), "Mark?")
        }
        // Never replace the entire translation here. A subtitle may contain
        // more than the idiom: "You guys are the best. Thank you." The old
        // whole-string assignment silently discarded the following sentence
        // (and any speaker label). Repair only the literal Turkish fragment.
        if (Regex("""(?i)\byou\s+guys\s+are\s+the\s+best\b""").containsMatchIn(source)) {
            result = result.replace(
                Regex("""(?iu)you['’]?dekiler\s+en\s+iyisidir\.?"""),
                "Siz harikasınız."
            )
        }
        if (Regex("""(?i)\bjust\s+spitballing\s+here\b""").containsMatchIn(source)) {
            val bad = Regex("""(?iu)burada\s+sadece\s+tükürük\s+topları""")
            val single = Regex("""(?iu)^ve\s+burada\s+sadece\s+tükürük\s+topları\.?$""")
            result = if (single.matches(result.trim())) {
                "Öylesine fikir yürütüyorum."
            } else result.replace(bad, "öylesine fikir yürütüyorum")
        }
        if (Regex("""(?i)\bbig\s+shoes\s+to\s+fill\b""").containsMatchIn(source)) {
            result = result.replace(
                Regex("""(?iu)doldurmam\s+gereken\s+büyük\s+bir\s+yer\s+var"""),
                "Benden öncekinin yerini doldurmalıyım"
            )
        }
        if (Regex("""(?i)\blook\s+regal\b""").containsMatchIn(source) &&
            Regex("""(?iu)(?:çok\s+)?güzel\s+görünüyorsun""").containsMatchIn(result)) {
            result = result.replace(Regex("""(?iu)(?:çok\s+)?güzel\s+görünüyorsun"""), "heybetli görünüyorsun")
        }
        return result
    }
}
