#!/usr/bin/env python3
"""Evaluate exact-match reference coverage; NOT a semantic quality score."""
import csv, sys, unicodedata
from collections import Counter

def norm(s):
    return ' '.join(unicodedata.normalize('NFC',s).casefold().split())

with open(sys.argv[1] if len(sys.argv)>1 else 'benchmark.csv', encoding='utf-8', newline='') as f:
    rows=list(csv.DictReader(f))
if len(sys.argv)>2:
    with open(sys.argv[2], encoding='utf-8', newline='') as f:
        outputs={r['id']:r['translation'] for r in csv.DictReader(f)}
else:
    outputs={r['id']:r['observed_10_24'] for r in rows}
by=Counter(); correct=Counter()
for r in rows:
    by[r['category']]+=1
    ok=norm(outputs.get(r['id'],''))==norm(r['reference_tr'])
    correct[r['category']]+=int(ok)
    print(f"{'PASS' if ok else 'FAIL'} {r['id']:>2} {r['category']}: {outputs.get(r['id'],'<missing>')}")
print(f"Exact reference matches: {sum(correct.values())}/{len(rows)}")
for k in sorted(by): print(f"  {k}: {correct[k]}/{by[k]}")
print('Note: exact match is strict and does not measure semantic equivalence.')
