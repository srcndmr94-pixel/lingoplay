# GameLingo Engine — ölçülebilir başlangıç

Bu paket bir çeviri modeli veya APK değildir. Kullanıcının 10.24 kayıtlarından alınan 15 somut regresyon örneği ve bağımsız karşılaştırma aracı içerir.

`python3 evaluate.py benchmark.csv` ile gözlenen 10.24 çevirilerini değerlendir.

Yeni motor çıktıları için `id,translation` başlıklı UTF-8 CSV oluştur ve `python3 evaluate.py benchmark.csv yeni_motor.csv` çalıştır.

**Sınırlar:** Referanslar tek doğru değildir. Exact-match puanı semantik kalite puanı değildir. OCR çıktısı ile gerçek altyazı farklıysa bunlar ayrıca doğrulanmalıdır. Model hızını ölçmek için Android cihazda zaman damgalı gerçek test gerekir.

**Kaynak kodu incelemesinden:** Var olan `LlmTranslate.kt` zaten Gemma E4B/E2B ve LiteRT-LM kullanıyor. 10.24 HIZLI modu bu modeli çeviride kullanmıyor. Dolayısıyla yeni bir çalışma zamanı eklemekten önce mevcut modelin kalite/gecikme karşılaştırmasını yapmak daha rasyonel.
