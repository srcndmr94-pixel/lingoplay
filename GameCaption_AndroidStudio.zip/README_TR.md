# Game Caption – Android Studio projesi

Bu paket, önceki çalışmadaki `CaptureService_fixed.kt` dosyasını temel alan Android Studio proje iskeletidir.

## Açma
1. ZIP'i çıkar.
2. Android Studio'da `GameCaption` klasörünü aç.
3. Gradle Sync işleminin bitmesini bekle.
4. Uygulamayı telefona yükle.

## İlk kullanım
1. Uygulamayı aç.
2. İsteğe bağlı olarak Gemini API anahtarını girip kaydet.
3. "Ekran üstü iznini ver" düğmesiyle diğer uygulamaların üzerinde gösterme iznini aç.
4. "Ekran çevirisini başlat" düğmesine basıp Android ekran yakalama iznini onayla.
5. Oyun veya video altyazıları ekranın altındaki çeviri katmanında gösterilir.

## İçerik
- `CaptureService.kt`: OCR, MediaProjection, ML Kit yerel çeviri, filtreleme ve altyazı katmanı.
- `AiTranslate.kt`: Gemini REST API çevirisi.
- `MainActivity.kt`: İzin ve API ayarı ekranı.
- `overlay_subtitle.xml`: Ekran üstü altyazı görünümü.

## Önemli
- Bu paket, mevcut düzeltilmiş CaptureService dosyasını ve eksik temel Android proje dosyalarını bir araya getiren başlangıç sürümüdür.
- Android Studio/Gradle derlemesi ve gerçek cihaz testi bu ortamda yapılmadı. İlk açılışta Gradle/SDK uyumluluğu için hata çıkarsa hata çıktısına göre düzeltmek gerekir.
- Gemini API anahtarı uygulama tercihlerinde cihazda saklanır; paylaşmayın.
- Ekran yakalama, Android'in sistem onayına bağlıdır. Bazı oyunlar DRM/güvenlik nedeniyle görüntü yakalamayı engelleyebilir.
