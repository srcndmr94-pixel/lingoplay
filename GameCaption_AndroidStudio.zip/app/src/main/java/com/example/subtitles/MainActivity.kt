package com.example.subtitles

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager

class MainActivity : AppCompatActivity() {
    private lateinit var apiKey: EditText
    private lateinit var modelName: EditText
    private val captureRequestCode = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiKey = findViewById(R.id.apiKey)
        modelName = findViewById(R.id.modelName)
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        apiKey.setText(prefs.getString("gemini_api_key", ""))
        modelName.setText(prefs.getString("gemini_model_name", "gemini-flash-latest"))

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            prefs.edit()
                .putString("gemini_api_key", apiKey.text.toString().trim())
                .putString("gemini_model_name", modelName.text.toString().trim().ifBlank { "gemini-flash-latest" })
                .apply()
            Toast.makeText(this, "Ayarlar kaydedildi", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.overlayButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "Ekran üstü izni zaten açık", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Önce ekran üstü iznini ver", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra("RESULT_CODE", resultCode)
                putExtra("DATA", data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Game Caption başlatıldı", Toast.LENGTH_SHORT).show()
        }
    }
}
