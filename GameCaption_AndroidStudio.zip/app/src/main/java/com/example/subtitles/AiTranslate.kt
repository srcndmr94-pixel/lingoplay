package com.example.subtitles

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object AiTranslate {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun translateWithGemini(
        text: String,
        apiKey: String,
        modelName: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(apiKey.isNotBlank()) { "API_KEY_MISSING" }
            val model = modelName.trim().ifBlank { "gemini-flash-latest" }
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val prompt = "Translate the following game dialogue into natural Turkish. " +
                "Return only the translation, preserving meaning and tone:\n\n$text"
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put("text", prompt))
                )))
                .put("generationConfig", JSONObject().put("temperature", 0.2))
                .toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder().url(url).post(body).build()
            client.newCall(request).execute().use { response ->
                val responseText = response.body?.string().orEmpty()
                if (!response.isSuccessful) throw IOException("${response.code}: $responseText")
                val json = JSONObject(responseText)
                val candidates = json.optJSONArray("candidates")
                    ?: throw IOException("EMPTY_RESPONSE")
                val parts = candidates.optJSONObject(0)?.optJSONObject("content")
                    ?.optJSONArray("parts") ?: throw IOException("EMPTY_RESPONSE")
                val translated = buildString {
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i)
                        if (part != null) append(part.optString("text"))
                    }
                }.trim()
                if (translated.isBlank()) throw IOException("EMPTY_RESPONSE")
                translated
            }
        }
    }
}
