package com.example.altyazi

/** Kaynak İngilizceyle birebir doğrulanan replikler; diğerlerine dokunmaz. */
object SourceAwareDialogueFix {
    private fun key(s: String): String = s.trim()
        .replace('’', '\'')
        .replace(Regex("\\s+"), " ")
        .trimEnd('.', '!', '?', ' ')
        .lowercase(java.util.Locale.ROOT)

    private val known = mapOf(
        "we're not that late" to "O kadar da geç kalmadık.",
        "were not that late" to "O kadar da geç kalmadık.",
        "brian's doing us a favor, you know? we need this intro, lu" to
            "Brian bize iyilik yapıyor, biliyorsun. Lu, bizi tanıştırmasına ihtiyacımız var.",
        "you know, we're in some deep fucking shit" to "Biliyorsun, fena hâlde boka battık.",
        "look, he could sell us out. or put a bullet through our heads" to
            "Bak, bizi ele verebilir. Ya da kafamıza kurşun sıkabilir.",
        "what you think i needed a lift for" to "Sence beni neden arabayla almanı istedim?",
        "yeah, go. like, right fucking now" to "Evet, git. Hem de hemen, amına koyayım.",
        "he wants it on the quiet. he only wants one of you" to
            "Bu işin gizli kalmasını istiyor. Sadece birinizi istiyor.",
        "nice. on my way" to "Güzel. Yoldayım.",
        "alright, so how you wanna play it" to "Peki, nasıl hareket edeceğiz?",
        "this is so fucked" to "Bu iş fena sıçtı.",
        "and i fucking jumped" to "Ben de atladım, amına koyayım."
    )
    fun correct(source: String): String? = known[key(source)]
}
