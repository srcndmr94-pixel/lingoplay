import com.example.altyazi.SourceAwareDialogueFix
fun main() {
    check(SourceAwareDialogueFix.correct("Were not that late.") == "O kadar da geç kalmadık.")
    check(SourceAwareDialogueFix.correct("We're not that late.") == "O kadar da geç kalmadık.")
    check(SourceAwareDialogueFix.correct("You know, we're in some deep fucking shit.") == "Biliyorsun, fena hâlde boka battık.")
    check(SourceAwareDialogueFix.correct("Nice. On my way.") == "Güzel. Yoldayım.")
    check(SourceAwareDialogueFix.correct("He wants it on the quiet. He only wants one of you.")?.contains("gizli") == true)
    check(SourceAwareDialogueFix.correct("Unrelated sentence.") == null)
    println("6/6 PASS")
}
