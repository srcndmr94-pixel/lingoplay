package com.example.altyazi

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * SESLİ OKUMA (deneme) — 10.43
 *
 * Ekrana çıkan Türkçe çeviriyi telefonun kendi Türkçe konuşma motoruyla okur.
 * Ücretsiz, anahtarsız, kota yok: Android'in içindeki TTS motoru kullanılıyor.
 *
 * BU DUBLAJ DEĞİL. Karakterlerin sesi klonlanmıyor; tek bir sistem sesi
 * çeviriyi okuyor. Ses klonlama (her karakterin kendi sesiyle Türkçe
 * konuşması) telefonda gerçek zamanlı çalışmıyor.
 *
 * Tasarım kararları:
 *  - BİRİKME YOK: yeni replik gelince okunmakta olan eski replik kesilir
 *    (QUEUE_FLUSH). Ses, oyunun gerisinde kalan bir kuyruğa dönüşmez.
 *  - AYNI YAZI İKİ KEZ OKUNMAZ: taslak okunduktan sonra yapay zekâ aynı
 *    cümleyi döndürürse tekrar okunmaz.
 *  - Motor hazır olmadan gelen replik bekletilir; yalnız EN SON replik
 *    okunur, kuyruk tutulmaz.
 *  - Konuşan adı ("James: ...") okunmaz; "James iki nokta" demesin.
 */
class SesliOku(context: Context, private val log: (String) -> Unit = {}) {

    private val app = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var hazir = false
    @Volatile private var kapandi = false

    /** En son okunan yazının sade hali; aynısı tekrar okunmasın. */
    @Volatile private var sonOkunan = ""

    /** Motor açılırken gelen replik; yalnız en sonu saklanır. */
    @Volatile private var bekleyen: String? = null

    /** Konuşma hızı, 0.5 - 2.0. Ayarlardaki kaydırıcıdan gelir. */
    @Volatile
    var hiz: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            try {
                tts?.setSpeechRate(field)
            } catch (_: Throwable) {
            }
        }

    /** Ses tonu, 0.5 - 2.0. Küçük = kalın, büyük = ince. */
    @Volatile
    var ton: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            try {
                tts?.setPitch(field)
            } catch (_: Throwable) {
            }
        }

    /**
     * Baştaki konuşan adı ("James: ...") atılsın mı?
     * CaptureService bunu prefs.showSpeaker'dan geçirir.
     */
    @Volatile
    var adiAtla: Boolean = true

    /**
     * Motoru açar. [onDurum] en çok bir kez, ana iş parçacığında çağrılır:
     * (çalışıyor mu, kullanıcıya gösterilecek açıklama).
     * Açılış 100-700 ms sürer; bu arada gelen replikler bekletilir.
     */
    fun baslat(onDurum: ((Boolean, String) -> Unit)? = null) {
        if (tts != null || kapandi) return
        try {
            tts = TextToSpeech(app, TextToSpeech.OnInitListener { status ->
                motorAcildi(status, onDurum)
            })
        } catch (t: Throwable) {
            log("SESLI OKUMA: motor kurulamadi (${t.javaClass.simpleName}: ${t.message})")
            bildir(onDurum, false, "Konuşma motoru başlatılamadı.")
        }
    }

    /** TextToSpeech açılış sonucu. Etiketli dönüş yok: okunması kolay olsun. */
    private fun motorAcildi(status: Int, onDurum: ((Boolean, String) -> Unit)?) {
        if (kapandi) return
        if (status != TextToSpeech.SUCCESS) {
            log("SESLI OKUMA: motor acilamadi (status=$status)")
            bildir(onDurum, false, "Telefonda çalışan bir konuşma motoru bulunamadı.")
            return
        }
        val motor = tts
        if (motor == null) {
            log("SESLI OKUMA: motor acilirken kapatildi")
            return
        }
        val sonuc = try {
            motor.setLanguage(Locale("tr", "TR"))
        } catch (t: Throwable) {
            log("SESLI OKUMA: dil ayarlanamadi (${t.javaClass.simpleName})")
            TextToSpeech.LANG_NOT_SUPPORTED
        }
        val turkceVar = sonuc == TextToSpeech.LANG_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
        if (!turkceVar) {
            log("SESLI OKUMA: Turkce ses yok (sonuc=$sonuc)")
            bildir(
                onDurum, false,
                "Türkçe ses paketi yüklü değil. Telefon Ayarları ▸ Erişilebilirlik ▸ " +
                    "Metin okuma bölümünden Türkçe sesi indirin."
            )
            return
        }
        try {
            motor.setSpeechRate(hiz)
            motor.setPitch(ton)
        } catch (_: Throwable) {
        }
        hazir = true
        log("SESLI OKUMA: hazir (Turkce)")
        bildir(onDurum, true, "Türkçe ses hazır.")
        // Motor açılırken gelen son replik varsa şimdi okunur.
        val sira = bekleyen
        bekleyen = null
        if (sira != null) oku(sira)
    }

    private fun bildir(onDurum: ((Boolean, String) -> Unit)?, ok: Boolean, mesaj: String) {
        if (onDurum == null) return
        ui.post { onDurum(ok, mesaj) }
    }

    /**
     * Çeviriyi okur. Okunmakta olan replik varsa KESİLİR: ekranda ne varsa
     * kulakta da o olsun, ses oyunun gerisine düşmesin.
     */
    fun oku(metin: String?) {
        if (kapandi) return
        val temiz = temizle(metin, adiAtla) ?: return
        if (!hazir) {
            // Motor henüz açılmadı: yalnız en son replik saklanır.
            bekleyen = temiz
            return
        }
        val sade = sadeBicim(temiz)
        if (sade.isEmpty()) return
        if (sade == sonOkunan) return   // taslak ile düzeltilmiş aynı çıktı
        sonOkunan = sade
        val motor = tts ?: return
        try {
            motor.speak(temiz, TextToSpeech.QUEUE_FLUSH, null, "gl-" + System.nanoTime())
        } catch (t: Throwable) {
            log("SESLI OKUMA: okunamadi (${t.javaClass.simpleName})")
        }
    }

    /** Okumayı anında keser (ekran temizlendi, çeviri durdu). */
    fun sus() {
        bekleyen = null
        sonOkunan = ""
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    /** Motoru kapatır. Bundan sonra bu nesne kullanılmaz. */
    fun kapat() {
        kapandi = true
        hazir = false
        bekleyen = null
        val motor = tts
        tts = null
        try {
            motor?.stop()
            motor?.shutdown()
        } catch (_: Throwable) {
        }
    }

    companion object {

        /** "James: Gel buraya." -> "Gel buraya." Konuşan adı okunmaz. */
        private val KONUSAN =
            Regex("^\\p{Lu}[\\p{L}.'\\-]{1,19}(\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?\\s*:\\s+")

        private val SATIR_SONU = Regex("[\\r\\n]+")
        private val COK_BOSLUK = Regex("\\s{2,}")

        /** Okunmayacak satırlar: uyarı, durum ve okunacak harf içermeyenler. */
        fun okunurMu(metin: String?): Boolean {
            if (metin.isNullOrBlank()) return false
            val t = metin.trim()
            if (t.startsWith("⚠")) return false
            if (t.startsWith("GameLingo")) return false
            return temizle(t, false) != null
        }

        /**
         * Ekrandaki yazıyı sese uygun hale getirir: turkuaz noktayı ve fazla
         * boşlukları atar, [adAt] ise baştaki konuşan adını da atar.
         * Okunacak bir şey kalmazsa null.
         *
         * [adAt] NEDEN SEÇİME BAĞLI: "Dikkat: arkanda!" cümlesinin de başı
         * büyük harfli kelime + iki nokta. Ad atma her zaman açık olsa
         * "Dikkat" yutulurdu. Ad öneki yalnız "Konuşanı göster" ayarı açıkken
         * ekleniyor (CaptureService: "$ad: $kalan"), bu yüzden ad atma da
         * yalnız o ayar açıkken çalışır.
         */
        fun temizle(metin: String?, adAt: Boolean): String? {
            if (metin.isNullOrBlank()) return null
            var t = metin.trim()
            if (t.startsWith("⚠") || t.startsWith("GameLingo")) return null
            t = t.replace("●", " ")
            if (adAt) t = KONUSAN.replace(t, "")
            t = SATIR_SONU.replace(t, " ")
            t = COK_BOSLUK.replace(t, " ").trim()
            // En az bir harf olsun: "...", "—", "?!" gibi satırlar okunmaz.
            if (!t.any { it.isLetter() }) return null
            return t
        }

        /** Karşılaştırma için sade biçim: küçük harf, yalnız harf ve rakam. */
        fun sadeBicim(metin: String): String =
            metin.lowercase(Locale("tr", "TR")).filter { it.isLetterOrDigit() }
    }
}
