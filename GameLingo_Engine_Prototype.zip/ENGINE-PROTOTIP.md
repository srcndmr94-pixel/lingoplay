# GameLingo Engine — ilk prototip
GameLingoEngineCore.kt yeni motorun aday seçim katmanıdır. Henüz mevcut uygulama akışına bağlanmadı ve bağımsız çeviri modeli değildir. Çevrimdışı model adaylarının kıyaslanması ve entegrasyonu sonraki aşamadır.
Kontrol: kotlinc GameLingoEngineCore.kt GameLingoEngineCoreTest.kt -include-runtime -d engine.jar && java -jar engine.jar
4/4 JVM kontrolü geçti. Android APK ve cihaz testi yapılmadı.
