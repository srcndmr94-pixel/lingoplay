package com.example.altyazi

/**
 * OCR kaynaklı, yüksek güvenli metin düzeltmeleri ve ilk kare güven denetimi.
 * Dil modeli değildir; cümleyi yeniden yazmaz, özel isimleri tahmin etmez.
 * GameTranslator'ın kararlı okuma yaklaşımının Android'e uyarlanmış küçük kısmı.
 */
object SubtitlePreparation {
    private val repairs = listOf(
        // Örnekleri gerçek test loglarından alındı; dar bağlam dışına uygulanmaz.
        Regex("(?i)\\bmost hand some\\b") to "most handsome",
        Regex("(?i)\\bmnonths\\b") to "months",
        Regex("(?i)\\bmomn\\b") to "mom",
        Regex("(?i)\\bhave never been mnore\\b") to "have never been more",
        Regex("(?i)\\bit is timne we were at war\\b") to "it is time we were at war",
        Regex("^H don't know\\b") to "I don't know",
        Regex("(?i)\\btw\\s+O-week\\b") to "two-week",
        Regex("(?i)\\bwara million\\b") to "war a million",
        Regex("(?i)\\bthere'sa\\b") to "there's a",
        Regex("(?i)\\bain['’]?t\\b") to "ain't",
        // Yalnız ayırt edici bağlamda OCR harf/boşluk kayıpları.
        Regex("(?i)\\bwhat,\\s*didl\\s+leave\\b") to "What, did I leave",
        Regex("(?i)^wet,\\s+that sounds like a challenge\\b") to "Well, that sounds like a challenge",
        Regex("(?i)\\b(suit)\\s+Al(?=])") to "suit AI",
        // 10.31: only high-confidence OCR repairs supported by actual logs.
        Regex("(?i)\\bmnom\\b") to "mom",
        Regex("(?i)\\bwhen you were born, your mnom\\b") to "When you were born, your mom",
        Regex("(?i)\\b(?<=\\[)all gruntingl$") to "all grunting]",
        Regex("(?i)\\b(?<=\\[)oliver gruntingl$") to "Oliver grunting]",
        Regex("(?i)\\b(?<=\\[)alien gruntingl$") to "Alien grunting]",
        Regex("(?i)\\bit always find my way back to you\\b") to "I always find my way back to you",
        Regex("(?i)\\byou take the left,\\s*t[iIl1]l take the right\\b") to "You take the left, I'll take the right",
        Regex("(?i)\\bshe's stronger than she look\\s+s\\b") to "She's stronger than she looks"
    )

    fun repair(text: String): String {
        var current = text
        for ((pattern, replacement) in repairs) {
            current = pattern.replace(current) { match ->
                if (match.value.firstOrNull()?.isUpperCase() == true) {
                    replacement.replaceFirstChar { it.uppercase() }
                } else replacement
            }
        }
        return current
    }

    private val safeShortWords = setOf(
        "a", "i", "o", "an", "am", "as", "at", "be", "by", "do", "go", "ha",
        "he", "hi", "if", "in", "is", "it", "me", "mr", "ms", "my", "no",
        "of", "oh", "ok", "on", "or", "so", "to", "tv", "uh", "um", "up",
        "us", "we", "ya", "ye", "ai", "dr", "st", "id", "vs"
    )
    private val words = Regex("[\\p{L}]+(?:['’][\\p{L}]+)?")
    private val suspiciousChars = Regex("[|#@%]|[\\p{L}]\\d[\\p{L}]|\\d[\\p{L}]\\d")

    /** Şüpheli OCR: ilk karede acele etmeyip ikinci, aynı okumayı bekle. */
    fun confidentFirstRead(text: String): Boolean {
        if (text.isBlank()) return false
        // Sahne/ses etiketlerini gereksiz yere yavaşlatma.
        if (text.trim().matches(Regex("^\\[[^]\\n]+]$"))) return true
        if (suspiciousChars.containsMatchIn(text)) return false
        val tokens = words.findAll(text).map { it.value }.toList()
        if (tokens.isEmpty()) return false
        return tokens.none { word ->
            word.length <= 2 && word.lowercase() !in safeShortWords
        }
    }
}

/**
 * Yalnız Google yolunda güvenli anlamsal normalleştirme.
 * Cümle sonundaki ", too" çoğu zaman "ben de" anlamındadır;
 * "too much/too late" hiçbir zaman değiştirilmez.
 */
object GoogleSourcePreparation {
    private val finalToo = Regex("(?i),\\s*too([.!?…]*)$")

    fun prepare(text: String): String = finalToo.replace(text) { match ->
        " as well" + match.groupValues[1]
    }
}
