package com.example.altyazi

/** Translation engine policy independent of any network or Android API.
 * It does not generate translations: it ranks outputs from installed engines.
 */
object GameLingoEngineCore {
    data class Candidate(val engine: String, val text: String, val latencyMs: Long)
    data class Decision(val selected: Candidate?, val rejected: Map<String, String>)

    private val sourceNegation = Regex("\\b(?:not|never|no|don't|doesn't|didn't|can't|cannot|won't|isn't|aren't|wasn't|weren't|shouldn't)\\b", RegexOption.IGNORE_CASE)
    private val targetNegation = Regex("\\b(?:değil|yok|hayır|asla|hiç|olmaz|olmadı|olmayacak|istemiyor|yapma|yapmadı)\\b|\\p{L}+(?:mıyor|miyor|muyor|müyor|madı|medi|mayacak|meyecek)", RegexOption.IGNORE_CASE)
    private val profanity = Regex("\\b(?:fuck|fucking|fucked|shit|bullshit|motherfucker)\\b", RegexOption.IGNORE_CASE)
    private val turkishProfanity = Regex("(?:siktir|sik|bok|amına|lanet|kahrol)", RegexOption.IGNORE_CASE)
    private val leftovers = Regex("\\b(?:the|with|would|should|your|they|we're|gonna|shouldn)\\b", RegexOption.IGNORE_CASE)

    fun select(source: String, candidates: List<Candidate>): Decision {
        val rejected = linkedMapOf<String, String>()
        val scored = candidates.mapNotNull { c ->
            val t = c.text.trim()
            val reason = when {
                t.isEmpty() || t.equals(source.trim(), true) -> "empty-or-untranslated"
                leftovers.findAll(t).count() >= 2 -> "english-residue"
                sourceNegation.containsMatchIn(source) && !targetNegation.containsMatchIn(t) -> "possible-lost-negation"
                else -> null
            }
            if (reason != null) { rejected[c.engine] = reason; null }
            else {
                var score = 100
                if (profanity.containsMatchIn(source) && !turkishProfanity.containsMatchIn(t)) score -= 35
                if (t.length > source.length * 3 + 50) score -= 25
                if (c.latencyMs > 1000) score -= 10
                c to score
            }
        }
        return Decision(scored.maxByOrNull { it.second }?.first, rejected)
    }
}
