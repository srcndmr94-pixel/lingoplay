import com.example.altyazi.GameLingoEngineCore
fun main() {
    val e = GameLingoEngineCore
    fun c(id: String, t: String) = GameLingoEngineCore.Candidate(id,t,100)
    check(e.select("I don't know", listOf(c("bad","Biliyorum"),c("good","Bilmiyorum"))).selected?.engine == "good")
    check(e.select("And I fucking jumped", listOf(c("bad","Ve atladım"),c("good","Ben de atladım, siktir!"))).selected?.engine == "good")
    check(e.select("Hello", listOf(c("bad",""))).selected == null)
    check(e.select("We should go", listOf(c("bad","we're gonna go"),c("good","Gitmeliyiz"))).selected?.engine == "good")
    println("4 engine policy checks passed")
}
