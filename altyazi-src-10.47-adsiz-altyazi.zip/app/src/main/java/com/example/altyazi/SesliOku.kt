package com.example.altyazi

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.Locale

/**
 * SESLİ OKUMA — 10.43'te eklendi, 10.44'te ses seçimi geldi.
 *
 * Ekrana çıkan Türkçe çeviriyi telefonun Türkçe konuşma motoruyla okur.
 * Ücretsiz, anahtarsız, kota yok.
 *
 * BU DUBLAJ DEĞİL. Karakterlerin gerçek sesi klonlanmıyor; telefonda yüklü
 * Türkçe seslerden biri okuyor.
 *
 * 10.44 — ERKEK/KADIN AYRIMI:
 * Altyazıdaki konuşan adına bakıp ([KonusanCinsiyeti]) erkek ya da kadın
 * sesini seçer. Android'in `Voice` sınıfı cinsiyet bildirmediği için hangi
 * sesin erkek hangisinin kadın olduğunu kullanıcı ayarlardan DİNLEYEREK
 * seçer; burada yalnız seçilen ses uygulanır.
 *
 * Telefonda tek Türkçe ses varsa ayrım perdeyle yapılır: erkek biraz kalın,
 * kadın biraz ince. Klonlama değil ama iki karakter karışmaz.
 *
 * Tasarım kararları (10.43'ten):
 *  - BİRİKME YOK: yeni replik gelince okunan kesilir (QUEUE_FLUSH).
 *  - AYNI YAZI İKİ KEZ OKUNMAZ.
 *  - Motor hazır olmadan gelen replik bekletilir; yalnız en sonu okunur.
 */
class SesliOku(context: Context, private val log: (String) -> Unit = {}) {

    /** Ayarlarda listelenen bir Türkçe ses. */
    data class SesBilgi(
        val ad: String,
        val kalite: Int,
        val agGerekir: Boolean,
    ) {
        /** Kullanıcıya gösterilen satır. */
        val etiket: String
            get() {
                val k = when {
                    kalite >= 500 -> "çok yüksek kalite"
                    kalite >= 400 -> "yüksek kalite"
                    kalite >= 300 -> "orta kalite"
                    else -> "düşük kalite"
                }
                return if (agGerekir) "$ad · $k · internet ister" else "$ad · $k"
            }
    }

    /** Bir sesin ölçüm sonucu. */
    data class SesOlcumu(
        val ses: SesBilgi,
        val hz: Double,
        val cinsiyet: Int,
    ) {
        val olculdu: Boolean get() = hz > 0.0
        val aciklama: String
            get() = when {
                !olculdu -> "ölçülemedi"
                cinsiyet == SesPerdeOlcer.ERKEK -> "erkek · ${hz.toInt()} Hz"
                cinsiyet == SesPerdeOlcer.KADIN -> "kadın · ${hz.toInt()} Hz"
                else -> "belirsiz · ${hz.toInt()} Hz"
            }
    }

    private val app = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var hazir = false
    @Volatile private var kapandi = false

    /** Telefonda bulunan Türkçe sesler, kaliteden düşüğe sıralı. */
    @Volatile private var sesler: List<Voice> = emptyList()

    /** Şu an motora uygulanmış ses adı; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananSes: String? = null

    /** Şu an uygulanmış perde; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananTon: Float = -1f

    /** Şu an uygulanmış konuşma hızı; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananHiz: Float = -1f

    /** Karakter adlarını tonlara dağıtır (bkz. KarakterSesi.kt). */
    private val dagitici = KarakterSesi.Dagitici()

    /** Ölçüm sürerken ikinci bir tarama başlatılmasın. */
    private val olcumSuruyor = AtomicBoolean(false)

    /** En son okunan yazının sade hali; aynısı tekrar okunmasın. */
    @Volatile private var sonOkunan = ""

    /** Motor açılırken gelen replik ve konuşanı; yalnız en sonu saklanır. */
    @Volatile private var bekleyen: Pair<String, String?>? = null

    /** Taban konuşma hızı, 0.5 - 2.0. Karakter tonu bunun üstüne biner. */
    @Volatile
    var hiz: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            uygulananHiz = -1f   // bir sonraki okumada yeniden uygulansın
        }

    /** Taban ses tonu, 0.5 - 2.0. Cinsiyet ayrımı bunun üstüne eklenir. */
    @Volatile
    var ton: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            uygulananTon = -1f   // bir sonraki okumada yeniden uygulansın
        }

    /** Baştaki konuşan adı okunmasın mı? (prefs.showSpeaker) */
    @Volatile
    var adiAtla: Boolean = true

    /** Erkek/kadın ayrımı yapılsın mı? */
    @Volatile
    var cinsiyetAyrimi: Boolean = true

    /**
     * Her karaktere ayrı ton verilsin mi?
     *
     * Kapalıyken tüm erkekler tek tonla, tüm kadınlar tek tonla okunur
     * (10.44 davranışı). Açıkken iki erkek karşılıklı konuşsa bile
     * birbirinden ayrılır.
     */
    @Volatile
    var karakterAyrimi: Boolean = true

    /** Ayarlardan seçilen erkek sesinin adı; boşsa en iyi ses kullanılır. */
    @Volatile
    var erkekSesAdi: String = ""

    /** Ayarlardan seçilen kadın sesinin adı; boşsa en iyi ses kullanılır. */
    @Volatile
    var kadinSesAdi: String = ""

    /**
     * KONUŞAN ADI YOKKEN kullanılacak ses.
     *
     * NEDEN GEREKLİ: birçok film/dizi altyazısında ve bazı oyunlarda replikler
     * "JASON: ..." gibi bir önek taşımaz. O zaman uygulamanın cinsiyeti
     * anlayacak HİÇBİR dayanağı kalmaz. Böyle içerikte her replik bu sesle
     * okunur; kullanıcı hangi sesi istediğini ayarlardan seçer.
     *
     * Boş bırakılırsa en iyi kaliteli ses kullanılır — ki bu, 19 sesin 15'i
     * ince olan bir telefonda her şeyin kadın sesiyle okunması demekti.
     */
    @Volatile
    var varsayilanSesAdi: String = ""

    /**
     * Ölçülmüş ses havuzu (bkz. SesHavuzu.kt). Doluysa her karaktere AYRI
     * GERÇEK SES verilir; perdeyle oynanmaz. Telefonda 15 Türkçe ses varken
     * iki erkeği perde farkıyla ayırmak yerine iki ayrı ses vermek çok daha
     * doğal duyuluyor.
     */
    @Volatile
    var havuz: List<SesHavuzu.Kayit> = emptyList()

    /**
     * İnternet isteyen sesler kullanılsın mı?
     *
     * Google'ın "-network" Türkçe sesleri sunucuda üretiliyor ve yerel
     * seslerden belirgin şekilde daha doğal. Bedeli: internet gerekir ve
     * replik başına birkaç yüz milisaniye gecikme ekler.
     */
    @Volatile
    var internetSesi: Boolean = false

    /**
     * Motoru açar. [onDurum] en çok bir kez, ana iş parçacığında çağrılır:
     * (çalışıyor mu, kullanıcıya gösterilecek açıklama).
     */
    fun baslat(onDurum: ((Boolean, String) -> Unit)? = null) {
        if (tts != null || kapandi) return
        try {
            tts = TextToSpeech(app, TextToSpeech.OnInitListener { status ->
                motorAcildi(status, onDurum)
            })
        } catch (t: Throwable) {
            log("SESLI OKUMA: motor kurulamadi (${t.javaClass.simpleName}: ${t.message})")
            bildir(onDurum, false, "Konuşma motoru başlatılamadı.")
        }
    }

    private fun motorAcildi(status: Int, onDurum: ((Boolean, String) -> Unit)?) {
        if (kapandi) return
        if (status != TextToSpeech.SUCCESS) {
            log("SESLI OKUMA: motor acilamadi (status=$status)")
            bildir(onDurum, false, "Telefonda çalışan bir konuşma motoru bulunamadı.")
            return
        }
        val motor = tts
        if (motor == null) {
            log("SESLI OKUMA: motor acilirken kapatildi")
            return
        }
        val sonuc = try {
            motor.setLanguage(TR)
        } catch (t: Throwable) {
            log("SESLI OKUMA: dil ayarlanamadi (${t.javaClass.simpleName})")
            TextToSpeech.LANG_NOT_SUPPORTED
        }
        val turkceVar = sonuc == TextToSpeech.LANG_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
        if (!turkceVar) {
            log("SESLI OKUMA: Turkce ses yok (sonuc=$sonuc)")
            bildir(
                onDurum, false,
                "Türkçe ses paketi yüklü değil. Telefon Ayarları ▸ Erişilebilirlik ▸ " +
                    "Metin okuma bölümünden Türkçe sesi indirin."
            )
            return
        }
        sesleriTopla(motor)
        uygulananSes = null
        uygulananTon = -1f
        uygulananHiz = -1f
        hazir = true
        log("SESLI OKUMA: hazir · ${sesler.size} Turkce ses")
        bildir(onDurum, true, durumYazisi())
        val sira = bekleyen
        bekleyen = null
        if (sira != null) oku(sira.first, sira.second)
    }

    /**
     * Telefondaki Türkçe sesleri toplar, kaliteden düşüğe sıralar.
     * İnternet isteyen sesler listeye girer ama sona konur: uygulamanın
     * amacı internetsiz çalışmak.
     */
    private fun sesleriTopla(motor: TextToSpeech) {
        sesler = try {
            val hepsi = motor.voices ?: emptySet<Voice>()
            hepsi.filter { v ->
                try {
                    v.locale != null && v.locale.language.equals("tr", ignoreCase = true)
                } catch (_: Throwable) {
                    false
                }
            }.sortedWith(
                compareBy<Voice> { if (it.isNetworkConnectionRequired) 1 else 0 }
                    .thenByDescending { it.quality }
                    .thenBy { it.name }
            )
        } catch (t: Throwable) {
            log("SESLI OKUMA: ses listesi alinamadi (${t.javaClass.simpleName})")
            emptyList()
        }
        for (v in sesler) log("SESLI OKUMA: ses · ${v.name} · kalite=${v.quality} · ag=${v.isNetworkConnectionRequired}")
    }

    private fun durumYazisi(): String {
        if (sesler.isEmpty()) return "Türkçe ses hazır (motor ayrı ses listesi vermiyor)."
        val enIyi = sesler.first()
        val kalite = if (enIyi.quality >= 400) "yüksek kaliteli" else "standart"
        return "${sesler.size} Türkçe ses bulundu; en iyisi $kalite."
    }

    /** Ayarlar ekranı için: bulunan Türkçe sesler. */
    fun bulunanSesler(): List<SesBilgi> = sesler.map {
        SesBilgi(it.name, it.quality, it.isNetworkConnectionRequired)
    }

    fun hazirMi(): Boolean = hazir

    private fun bildir(onDurum: ((Boolean, String) -> Unit)?, ok: Boolean, mesaj: String) {
        if (onDurum == null) return
        ui.post { onDurum(ok, mesaj) }
    }

    /**
     * Çeviriyi okur. Okunmakta olan replik KESİLİR.
     * [konusan] altyazıdaki konuşan adı; ses seçimi buna göre yapılır.
     */
    fun oku(metin: String?, konusan: String? = null) {
        if (kapandi) return
        val temiz = temizle(metin, adiAtla) ?: return
        if (!hazir) {
            bekleyen = temiz to konusan
            return
        }
        val sade = sadeBicim(temiz)
        if (sade.isEmpty()) return
        if (sade == sonOkunan) return
        sonOkunan = sade
        val motor = tts ?: return

        val cinsiyet = if (cinsiyetAyrimi) KonusanCinsiyeti.tahmin(konusan)
        else KonusanCinsiyeti.BILINMIYOR
        sesiUygula(motor, cinsiyet, konusan)

        try {
            motor.speak(temiz, TextToSpeech.QUEUE_FLUSH, null, "gl-" + System.nanoTime())
        } catch (t: Throwable) {
            log("SESLI OKUMA: okunamadi (${t.javaClass.simpleName})")
        }
    }

    /**
     * Konuşanın cinsiyetine göre sesi ve perdeyi ayarlar.
     *
     * İKİ AYRI SES VARSA ses değiştirilir, perdeye dokunulmaz.
     * TEK SES VARSA (ya da ikisi için aynı ses seçilmişse) ayrım perdeyle
     * yapılır: erkek kalın, kadın ince. Cinsiyet bilinmiyorsa taban perde.
     */
    private fun sesiUygula(motor: TextToSpeech, cinsiyet: Int, konusan: String?) {
        // Konuşan adı hiç yoksa cinsiyet tahmini imkânsız: kullanıcının
        // seçtiği varsayılan sesle okunur.
        if (konusan.isNullOrBlank() && varsayilanSesAdi.isNotBlank()) {
            sesUygulaAdIle(motor, varsayilanSesAdi)
            uygulaPerde(ton.coerceIn(0.5f, 2.0f), motor)
            uygulaHiz(hiz.coerceIn(0.5f, 2.0f), motor)
            return
        }
        val karakterHavuzu = karakterHavuzu(cinsiyet, konusan)

        // 1) HAVUZDA EN AZ İKİ SES VAR: her karaktere ayrı GERÇEK ses.
        //    Perdeye hiç dokunulmaz; en doğal sonuç bu.
        if (karakterAyrimi && karakterHavuzu.size >= 2) {
            val sira = dagitici.yuva(konusan, "ses$cinsiyet", karakterHavuzu.size)
            val kayit = if (sira >= 0) karakterHavuzu[sira] else karakterHavuzu[0]
            sesUygulaAdIle(motor, kayit.ad)
            uygulaPerde(ton.coerceIn(0.5f, 2.0f), motor)
            uygulaHiz(hiz.coerceIn(0.5f, 2.0f), motor)
            return
        }

        // 2) Havuzda tek ses (ya da karakter ayrımı kapalı): o sesi kullan,
        //    ayrımı tona bırak.
        val tekSes = karakterHavuzu.firstOrNull()
        val secilen = if (tekSes != null) sesBul(tekSes.ad) ?: etkinSes(cinsiyet) else etkinSes(cinsiyet)
        if (secilen != null && secilen.name != uygulananSes) {
            try {
                motor.voice = secilen
                uygulananSes = secilen.name
            } catch (t: Throwable) {
                log("SESLI OKUMA: ses uygulanamadi (${t.javaClass.simpleName})")
            }
        }

        // ETKİN seslere bakılır, seçilen adlara değil: erkek için ses
        // seçilmiş ama kadın boş bırakılmışsa kadın da en iyi sese düşer;
        // o ses erkeğinkinden farklıysa ayrım zaten vardır.
        val ayriSesVar = etkinSes(KonusanCinsiyeti.ERKEK)?.name !=
            etkinSes(KonusanCinsiyeti.KADIN)?.name

        val kt = if (karakterAyrimi) dagitici.ton(konusan, cinsiyet, ayriSesVar)
        else KarakterSesi.varsayilan(cinsiyet, ayriSesVar)

        uygulaPerde((ton * kt.perde).coerceIn(0.5f, 2.0f), motor)
        uygulaHiz((hiz * kt.hiz).coerceIn(0.5f, 2.0f), motor)
    }

    /**
     * Bu cinsiyet için kullanılabilecek gerçek sesler.
     * Havuz ölçülmemişse ya da bu cinsiyette ses yoksa boş döner ve
     * eski (perdeyle ayırma) yola düşülür.
     */
    private fun karakterHavuzu(cinsiyet: Int, konusan: String?): List<SesHavuzu.Kayit> {
        if (havuz.isEmpty()) return emptyList()
        if (cinsiyet == KonusanCinsiyeti.ERKEK || cinsiyet == KonusanCinsiyeti.KADIN) {
            val hedef = if (cinsiyet == KonusanCinsiyeti.ERKEK) SesPerdeOlcer.ERKEK
            else SesPerdeOlcer.KADIN
            return SesHavuzu.havuz(havuz, hedef, mevcutAdlar(), internetSesi)
        }
        // ADI VAR AMA CİNSİYETİ BİLİNMİYOR ("Kratos" gibi): cinsiyeti
        // bilemesek de karakterleri birbirinden ayıralım, tüm havuzu kullan.
        if (!konusan.isNullOrBlank()) {
            return SesHavuzu.tumu(havuz, mevcutAdlar(), internetSesi)
        }
        // ADI HİÇ YOK (altyazıda konuşan öneki yok): dayanak sıfır.
        // Tek bir ses kullanılır; hangisi olduğunu kullanıcı seçer.
        return emptyList()
    }

    private fun mevcutAdlar(): Set<String> = sesler.map { it.name }.toSet()

    private fun sesUygulaAdIle(motor: TextToSpeech, ad: String) {
        if (ad == uygulananSes) return
        val v = sesBul(ad) ?: return
        try {
            motor.voice = v
            uygulananSes = ad
        } catch (t: Throwable) {
            log("SESLI OKUMA: ses uygulanamadi (${t.javaClass.simpleName})")
        }
    }

    private fun uygulaPerde(hedef: Float, motor: TextToSpeech) {
        if (yaklasikEsit(hedef, uygulananTon)) return
        try {
            motor.setPitch(hedef)
            uygulananTon = hedef
        } catch (_: Throwable) {
        }
    }

    private fun uygulaHiz(hedef: Float, motor: TextToSpeech) {
        if (yaklasikEsit(hedef, uygulananHiz)) return
        try {
            motor.setSpeechRate(hedef)
            uygulananHiz = hedef
        } catch (_: Throwable) {
        }
    }

    /**
     * Bu cinsiyet için gerçekten kullanılacak ses.
     * Seçim yapılmamışsa ya da seçilen ses artık yoksa en iyi sese düşer.
     */
    private fun etkinSes(cinsiyet: Int): Voice? {
        val istenen = when (cinsiyet) {
            KonusanCinsiyeti.ERKEK -> erkekSesAdi
            KonusanCinsiyeti.KADIN -> kadinSesAdi
            else -> ""
        }
        return sesBul(istenen) ?: sesler.firstOrNull()
    }

    /** Perde zaten uygulanmışsa motora tekrar yazmayalım. */
    private fun yaklasikEsit(a: Float, b: Float): Boolean =
        (if (a > b) a - b else b - a) < 0.001f

    private fun sesBul(ad: String?): Voice? {
        if (ad.isNullOrBlank()) return null
        return sesler.firstOrNull { it.name == ad }
    }

    // ------------------------------------------------ otomatik ses tanıma

    /**
     * Telefondaki her Türkçe sesi sessizce dosyaya okutup perdesini ölçer
     * ve erkek/kadın olarak sınıflar.
     *
     * NEDEN: Android'in `Voice` sınıfı cinsiyet bildirmiyor, ses adından da
     * anlaşılmıyor. Ama sesin kendisi ölçülebiliyor (bkz. SesPerdeOlcer.kt).
     * Böylece kullanıcının tek tek dinleyip seçmesi gerekmiyor.
     *
     * Hoparlörden ses ÇIKMAZ: synthesizeToFile dosyaya yazar.
     * Ölçüm sırasında perde ve hız 1.0'a sabitlenir — kullanıcının ton
     * ayarı ölçümü kaydırmasın — sonra eski değerlere dönülür.
     *
     * [onBitti] ana iş parçacığında, ölçüm sırasına göre çağrılır.
     */
    fun seslerIncele(
        onIlerleme: ((Int, Int) -> Unit)? = null,
        onBitti: (List<SesOlcumu>) -> Unit,
    ) {
        val motor = tts
        if (!hazir || motor == null || sesler.isEmpty()) {
            ui.post { onBitti(emptyList()) }
            return
        }
        if (!olcumSuruyor.compareAndSet(false, true)) return

        // Ölçüm için tarafsız perde/hız.
        try {
            motor.setPitch(1.0f)
            motor.setSpeechRate(1.0f)
        } catch (_: Throwable) {
        }
        uygulananTon = -1f
        uygulananHiz = -1f
        uygulananSes = null

        val sonuclar = ArrayList<SesOlcumu>()
        olcSirayla(motor, 0, sonuclar, onIlerleme, onBitti)
    }

    private fun olcSirayla(
        motor: TextToSpeech,
        sira: Int,
        sonuclar: ArrayList<SesOlcumu>,
        onIlerleme: ((Int, Int) -> Unit)?,
        onBitti: (List<SesOlcumu>) -> Unit,
    ) {
        if (kapandi) {
            olcumBitir(onBitti, sonuclar)
            return
        }
        if (sira >= sesler.size) {
            olcumBitir(onBitti, sonuclar)
            return
        }
        val ses = sesler[sira]
        val bilgi = SesBilgi(ses.name, ses.quality, ses.isNetworkConnectionRequired)
        onIlerleme?.let { f -> ui.post { f(sira + 1, sesler.size) } }

        // İnternet isteyen sesler de ölçülür: kullanıcı "internet sesi"
        // seçeneğini açarsa bunlar kullanılacak ve o zaman cinsiyetleri
        // bilinmek zorunda. İnternet yoksa sentez başarısız olur ve ses
        // "ölçülemedi" olarak kaydedilir; zararsız.

        val dosya = File(app.cacheDir, "gl_ses_olcum.wav")
        try {
            dosya.delete()
        } catch (_: Throwable) {
        }

        // Geri çağrı ya da zaman aşımı: hangisi önce gelirse BİR kez ilerlenir.
        val ilerledi = AtomicBoolean(false)
        val devam = Runnable {
            if (!ilerledi.compareAndSet(false, true)) return@Runnable
            val sonuc = try {
                SesPerdeOlcer.olc(dosya)
            } catch (t: Throwable) {
                log("SESLI OKUMA: olcum hatasi (${t.javaClass.simpleName})")
                SesPerdeOlcer.BOS
            }
            try {
                dosya.delete()
            } catch (_: Throwable) {
            }
            val o = SesOlcumu(bilgi, if (sonuc.olculdu) sonuc.hz else 0.0, sonuc.cinsiyet)
            log("SESLI OKUMA: olcum · ${ses.name} · ${o.aciklama}")
            sonuclar.add(o)
            ui.post { olcSirayla(motor, sira + 1, sonuclar, onIlerleme, onBitti) }
        }

        try {
            motor.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    ui.post(devam)
                }

                @Deprecated("eski imza; yenisi aşağıda")
                override fun onError(id: String?) {
                    ui.post(devam)
                }

                override fun onError(id: String?, kod: Int) {
                    log("SESLI OKUMA: sentez hatasi kod=$kod")
                    ui.post(devam)
                }
            })
            motor.voice = ses
            val sonuc = motor.synthesizeToFile(ORNEK_METIN, Bundle(), dosya, "gl-olcum-$sira")
            if (sonuc != TextToSpeech.SUCCESS) {
                log("SESLI OKUMA: synthesizeToFile reddetti (${ses.name})")
                ui.post(devam)
                return
            }
        } catch (t: Throwable) {
            log("SESLI OKUMA: sentez kurulamadi (${t.javaClass.simpleName})")
            ui.post(devam)
            return
        }
        // Motor hiç cevap vermezse takılı kalmayalım.
        ui.postDelayed(devam, OLCUM_ZAMAN_ASIMI)
    }

    private fun olcumBitir(onBitti: (List<SesOlcumu>) -> Unit, sonuclar: List<SesOlcumu>) {
        try {
            tts?.setOnUtteranceProgressListener(null)
        } catch (_: Throwable) {
        }
        // Kullanıcının ayarları bir sonraki okumada yeniden uygulanır.
        uygulananTon = -1f
        uygulananHiz = -1f
        uygulananSes = null
        olcumSuruyor.set(false)
        ui.post { onBitti(sonuclar) }
    }

    /** Okumayı anında keser. */
    fun sus() {
        bekleyen = null
        sonOkunan = ""
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    /** Motoru kapatır. Bundan sonra bu nesne kullanılmaz. */
    fun kapat() {
        kapandi = true
        hazir = false
        bekleyen = null
        dagitici.unut()
        val motor = tts
        tts = null
        try {
            motor?.stop()
            motor?.shutdown()
        } catch (_: Throwable) {
        }
    }

    companion object {

        private val TR = Locale("tr", "TR")

        /**
         * Ölçüm için okutulan cümle. Sesli harf bakımından zengin ve
         * yeterince uzun olmalı: perde ancak sesli çerçevelerde ölçülebiliyor.
         */
        const val ORNEK_METIN = "Buraya gel, kapıyı aç ve arabaya bin, hemen gidiyoruz."

        /** Motor cevap vermezse bu süre sonunda sıradaki sese geçilir (ms). */
        private const val OLCUM_ZAMAN_ASIMI = 6000L

        /** "James: Gel buraya." -> "Gel buraya." */
        private val KONUSAN =
            Regex("^\\p{Lu}[\\p{L}.'\\-]{1,19}(\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?\\s*:\\s+")

        private val SATIR_SONU = Regex("[\\r\\n]+")
        private val COK_BOSLUK = Regex("\\s{2,}")

        /** Okunmayacak satırlar: uyarı, durum ve okunacak harf içermeyenler. */
        fun okunurMu(metin: String?): Boolean {
            if (metin.isNullOrBlank()) return false
            val t = metin.trim()
            if (t.startsWith("⚠")) return false
            if (t.startsWith("GameLingo")) return false
            return temizle(t, false) != null
        }

        /**
         * Ekrandaki yazıyı sese uygun hale getirir: turkuaz noktayı ve fazla
         * boşlukları atar, [adAt] ise baştaki konuşan adını da atar.
         * Okunacak bir şey kalmazsa null.
         *
         * [adAt] NEDEN SEÇİME BAĞLI: "Dikkat: arkanda!" cümlesinin de başı
         * büyük harfli kelime + iki nokta. Ad atma her zaman açık olsa
         * "Dikkat" yutulurdu. Ad öneki yalnız "Konuşanı göster" ayarı açıkken
         * ekleniyor, bu yüzden ad atma da yalnız o ayar açıkken çalışır.
         */
        fun temizle(metin: String?, adAt: Boolean): String? {
            if (metin.isNullOrBlank()) return null
            var t = metin.trim()
            if (t.startsWith("⚠") || t.startsWith("GameLingo")) return null
            t = t.replace("●", " ")
            if (adAt) t = KONUSAN.replace(t, "")
            t = SATIR_SONU.replace(t, " ")
            t = COK_BOSLUK.replace(t, " ").trim()
            if (!t.any { it.isLetter() }) return null
            return t
        }

        /** Karşılaştırma için sade biçim: küçük harf, yalnız harf ve rakam. */
        fun sadeBicim(metin: String): String =
            metin.lowercase(TR).filter { it.isLetterOrDigit() }
    }
}
