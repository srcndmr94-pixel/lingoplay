# GameLingo 200 — Genel çeviri kalitesi ve canlı altyazı iyileştirmeleri

Tarih: 16 Kasım 2026
Temel sürüm: 10.42.7-realtime-stable-rc5 (versionCode 199)
Yeni kaynak: 10.42.7-natural-realtime-rc6 (versionCode 200)
Durum: Kaynak adayı. Android APK ve Pixel 9 Pro uçtan uca testi henüz yapılmadı.

## Kaynağı anlamak

16 Kasım gerçek cihaz kaydında 199 sürümü, önceki sürümden daha az replik kaçırdı ve pek çok yanıt 300–500 ms çeviri süresinde üretildi. Ama ML Kit hızlı yedek çıktıları bazı anlamları bozdu; ilk yayınlanan sonucun sabitlenmesi DeepL'in daha iyi geç sonucunun ekrana gelmesini engelledi. Örnek: “They talk about us like we're not there.” → “Orada olmadığımız gibi bizim için konuşurlar.” (anlam yanlış). Genel çözüm video repliği ezberlemek değil, güvenilir sonuç ve hız arasında korumalı seçim yapmak.

Karşılaştırma, 11 örnek için *model yanıtı* gecikmelerini ölçer; OCR gecikmesi dahil değildir. Google 187 ms, DeepL API 303 ms, ML Kit 43 ms, OPUS-MT 148 ms, E4B 3224 ms ortanca; başarı sayısı 11/11 olmak çevirilerin doğru olduğu anlamına gelmez. DeepL doğal ifadelerde güçlü, OPUS daha hızlı ancak deyimlerde yanılabilir; ML Kit anlamı ters çevirebilir. Bu örneklem çok küçük olduğundan genellenmiş başarı oranı değildir.

## Kaynağa uygulanan genel düzeltmeler

1. `RealtimeCaptionPolicy199.kt`: hızlı yedek hazır olsa bile güçlü motor için ek 125 ms *kısa zaman penceresi* tanınır. İnternete ikinci istek yapılmaz; mevcut 420 ms yerel başlama ve 550 ms yerel zaman sınırı korunur. Bu, bazı sahnelerde yerel yedek yerine daha doğal ana sonucun kazanmasına yardımcı olabilir; gerçek cihaz gecikmesi artabilir ve test edilmedi.
2. `CaptureService.kt`: yerel yedek, yüksek güvenli `TranslationQualityGate` uyarıları dahil herhangi bir sorun saptandığında yayınlanmaz; `LocalCaptionQuality200` bozuk parantez ve çevrilmemiş İngilizce ses etiketlerini reddeder. DeepL/OPUS/Google motor akışı ve kaybolan replikleri önleyen nesil kontrolü değişmedi.
3. `SoundTags` (OfflineFix.kt): oyun/diziye özel replikler *değil*, genel kapalı altyazı SES sözcükleri ve birleşik ses ifadeleri eklenmiştir. Örnekler: `tires squeal`, `exclaims`, `clangs`, `both groaning`, `brakes screeching`, `horn honking`, `footsteps thudding`. Sesin öznesi ve fiili düşürülmez.
4. `OcrSoundCue200.kt`: yalnız yüksek güvenli ses etiketi biçim bozulmalarını onarır; `I shouting - [Phase Three snarlingl` → `[shouting] - [Phase Three snarling]`, ` - Name shouts]` → ` - [Name shouts]`. Genel konuşma cümleleri değiştirilmez.
5. Kullanıcı sözlüğü, üç satır bağlam, altyazının alt konumu ve Gemini'siz canlı motor sırası korunmuştur. Bu sürümde belirli film ya da oyuna özel *tam cümle ezberleme* eklenmedi.

## Çalıştırılan kontroller

- `python run_all_61.py`: **61/61 PASS, 0 FAIL, 0 TIMEOUT**.
- Gerçek Kotlin `RealtimeCaptionPolicy199` + `OcrSoundCue200` ile `NaturalRealtime200Test.kt`: **11/11 PASS**.
- Gerçek `SoundTags` üretim nesnesi `OfflineFix.kt` içinden ayrıştırılıp `SoundTags200Test.kt` ile kotlinc/JVM'de çalıştırıldı: **10/10 PASS**.
- `python tests/test_natural_realtime_200.py`: **9/9 PASS** (üretim bağlantı/statik kontroller).
- Bu testler önceki model karşılaştırmasını cihazda yeniden çalıştırmaz; sonuçların semantik doğruluğunu tüm metinlerde garanti etmez.

## Açık riskler

- Android SDK/Gradle ile tam APK derlemesi burada yapılmadı. Pixel 9 Pro Android 17 üzerinde OCR, çeviri gecikmesi, bellek, pil ve ısınma doğrulanmadı.
- 125 ms kalite penceresi, yedekten sonuç alındığında ek gecikme yaratabilir. Güçlü motor geç yanıt verirse görüntülenen ilk geçerli çıktı yine yerel olabilir; yüzde yüz doğal çeviri iddiası yok.
- `SoundTags` genel ses ipuçlarını iyileştirir fakat yarım ses etiketlerinin her varyantı tanınmaz. Bozuk OCR anlamı bütünüyle kurtarılamaz.
- `app/debug.keystore` önceki geliştirme imzasını korumak için pakette hâlâ var. GÜVENLİK: Bu ZIP herkese açık GitHub deposuna yüklenmemeli. Özel depoda derlenmelidir. Debug anahtarı üretim dağıtımı için güvenli değildir.
- GitHub Actions eski/bozuk ZIP'i seçebilir. `Kaynak:` kaydında 200 ZIP'inin seçildiğini ve `unzip -t` testini doğrulayın.

## Önerilen cihaz kabulü

1. Daha önce sorunlu replikleri yeniden açıp `YAZILAN · hızlı yerel yedek` oranını ve çeviri doğallığını karşılaştırın.
2. İsim içeren, ses etiketi içeren ve çok hızlı iki satır art arda gelen sahneleri deneyin. Uygulama eski satırı yeni satırın yerine koymamalı.
3. Test çıktılarını yalnız başarılı/başarısız değil, OCR+çeviri toplam süresi ve yanlış anlamlı çeviri örnekleriyle değerlendirin.
