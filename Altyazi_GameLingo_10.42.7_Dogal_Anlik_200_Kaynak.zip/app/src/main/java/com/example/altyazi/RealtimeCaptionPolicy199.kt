package com.example.altyazi

/** Gerçek oyuna/filme özgü içerik taşımayan canlı gecikme politikası. */
object RealtimeCaptionPolicy199 {
    const val HEDGE_AFTER_MS = 420L
    const val LOCAL_TIMEOUT_MS = 550L
    // Yerel sonucun hemen arkasından gelebilecek DeepL/OPUS için kısa kalite önceliği.
    // Bu yeni bir ağ çağrısı değil; hızlı replikler için üst sınırla bağlı.
    const val PRIMARY_GRACE_MS = 125L

    fun needsLocalHedge(balanced: Boolean, strongAvailable: Boolean, source: String): Boolean =
        balanced && strongAvailable && source.any(Char::isLetter) &&
            !Regex("""^\[[^]]{1,80}]$""").matches(source.trim())
}

/** Her replikte ilk güvenilir sonucu yayınla; geç sonucu ekranı değiştirmeden sakla. */
class StableCaptionGate199 {
    private var publishedId = Long.MIN_VALUE

    @Synchronized fun firstValidated(id: Long, isCurrent: (Long) -> Boolean): Boolean {
        if (id <= 0L || !isCurrent(id) || publishedId == id) return false
        publishedId = id
        return true
    }
}

/** Yerel hızlı yedek yalnız sağlam görünen Türkçe çıktıları ekrana verebilir. */
object LocalCaptionQuality200 {
    private val leftoverSoundEnglish = Regex("""\b(?:gruntingl|shoutingl|snarlingl|grunting|groaning|shouts|screechingl)\b""", RegexOption.IGNORE_CASE)
    fun safe(source: String, translation: String): Boolean {
        val t = translation.trim()
        if (t.isBlank() || t == source.trim()) return false
        if (source.count { it == '[' } != source.count { it == ']' }) return false
        if (t.count { it == '[' } != t.count { it == ']' }) return false
        if (leftoverSoundEnglish.containsMatchIn(t)) return false
        return true
    }
}
