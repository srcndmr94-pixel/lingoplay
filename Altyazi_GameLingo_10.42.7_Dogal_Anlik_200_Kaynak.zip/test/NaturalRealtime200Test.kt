package com.example.altyazi

fun main() {
    var total = 0
    fun verify(ok: Boolean, desc: String) { check(ok) { desc }; total++ }
    verify(OcrSoundCue200.repair("Let him go! - Brandyworth shouts]") == "Let him go! - [Brandyworth shouts]", "missing opening bracket")
    verify(OcrSoundCue200.repair("I shouting - [Phase Three snarlingl") == "[shouting] - [Phase Three snarling]", "two OCR errors")
    verify(OcrSoundCue200.repair("I am shouting at you.") == "I am shouting at you.", "spoken dialogue unchanged")
    verify(OcrSoundCue200.repair("I shout. I am happy.") == "I shout. I am happy.", "no dialogue alteration")
    verify(OcrSoundCue200.repair("[Eve groaning]") == "[Eve groaning]", "valid cue unchanged")
    verify(LocalCaptionQuality200.safe("Hello", "Merhaba"), "valid local fallback")
    verify(!LocalCaptionQuality200.safe("[shouting]", "[bağırıyor"), "unclosed translated bracket")
    verify(!LocalCaptionQuality200.safe("[snarling", "hırlıyor"), "bad source bracket")
    verify(!LocalCaptionQuality200.safe("[Phase Three grunting]", "[Phase Three grunting]"), "untranslated sound")
    verify(RealtimeCaptionPolicy199.PRIMARY_GRACE_MS in 80L..200L, "primary grace stays short")
    verify(RealtimeCaptionPolicy199.LOCAL_TIMEOUT_MS == 550L, "local fallback bound preserved")
    println("NATURAL REALTIME 200: $total/$total PASS")
}
