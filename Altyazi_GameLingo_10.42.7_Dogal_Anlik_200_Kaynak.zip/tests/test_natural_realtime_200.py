from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root/'app/src/main/java/com/example/altyazi/CaptureService.kt').read_text()
phrases = (root/'app/src/main/java/com/example/altyazi/OfflineFix.kt').read_text()
policy = (root/'app/src/main/java/com/example/altyazi/RealtimeCaptionPolicy199.kt').read_text()
build = (root/'app/build.gradle.kts').read_text()
checks = {
    'version 200': 'versionCode = 200' in build,
    'sound OCR repair wired': 'dialogueContext.repair(OcrSoundCue200.repair(text))' in source,
    'primary wait bounded': 'delay(RealtimeCaptionPolicy199.PRIMARY_GRACE_MS)' in source,
    'fallback guard wired': '!LocalCaptionQuality200.safe(source, translated)' in source,
    'sound tag general forms': all(('"'+s+'" to ') in phrases for s in ('both groaning','tires squeal','exclaims','horn honking','footsteps thudding')),
    'initial hedge remains 420ms': 'HEDGE_AFTER_MS = 420L' in policy,
    'engine order retained': 'remote ?: (if (prefs.opusMtEnabled' in source,
    'overlay unchanged': 'screenHeight - dp(110)' in source,
    'preserve stale guard': 'subtitleGeneration.isCurrent(runId)' in source,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
print(f'NATURAL REALTIME 200: {sum(checks.values())}/{len(checks)} PASS')
