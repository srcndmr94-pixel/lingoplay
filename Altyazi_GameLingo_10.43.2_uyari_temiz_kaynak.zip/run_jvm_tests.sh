#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
K=$(command -v kotlinc)
LIB=/root/.sdkman/candidates/kotlin/current/lib
COR=$LIB/kotlinx-coroutines-core-jvm.jar
B=app/src/main/java/com/example/altyazi
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
"$K" test/jvm/{OfflineFixJvm.kt,SozlukJvmStub.kt} "$B"/{Phrases.kt,SourceAwareDialogueFix.kt,Slang.kt,ProperNameSequence1039.kt,LiveSubtitleQuality10425.kt,MeaningSafety.kt,TranslationQualityGate.kt,SubtitlePreparation.kt,DialogueContextRepair.kt,DeepLRequestPolicy.kt,DeepLPolicy.kt,SubtitleHoldPolicy.kt} -cp "$COR" -d "$TMP/core.jar"
TEST_FILES=(test/{RealLog10431Test,SourceFlow10429Test,SpeakerContext10428Test,ContextQuality1022Test,ContextQuality1021Test,ThreeLineContext1032Test,DialogueContextTest,MeaningSafety1033Test,DeepLPolicy10424Test,SoundTags1038Test,LiveSpan10430Test}.kt test/jvm/{JoinedLive10431Test,OfflineFixSpan10430Test,StrongOnly10432Test,SubtitleHold10432Test}.kt)
"$K" "${TEST_FILES[@]}" -cp "$TMP/core.jar:$COR" -d "$TMP/tests.jar" 2>"$TMP/compile.err" || { cat "$TMP/compile.err"; exit 1; }
passed=0; failed=0
for file in "${TEST_FILES[@]}"; do
    base=$(basename "${file%.kt}")
    package="com.example.altyazi."
    if [ "$base" = "ThreeLineContext1032Test" ] || [ "$base" = "MeaningSafety1033Test" ]; then package=""; fi
    if java -cp "$TMP/tests.jar:$TMP/core.jar:$COR:$LIB/kotlin-stdlib.jar" "${package}${base}Kt" > "$TMP/$base.out" 2>&1; then
        echo "PASS $base: $(tail -1 "$TMP/$base.out" | cut -c 1-125)"; passed=$((passed+1))
    else
        echo "FAIL $base"; tail -12 "$TMP/$base.out" || true; failed=$((failed+1))
    fi
done
printf 'JVM groups: %s passed, %s failed\n' "$passed" "$failed"
[ "$failed" -eq 0 ]
