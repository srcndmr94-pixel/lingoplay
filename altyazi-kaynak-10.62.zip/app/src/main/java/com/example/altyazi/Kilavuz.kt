package com.example.altyazi

/**
 * 10.59 — UYGULAMA İÇİ KULLANIM KILAVUZU (telefon).
 *
 * Uygulamanın içinden okunur: Yardım ▸ bölüm listesi ▸ bölüm metni.
 * Android'e hiç bağlı değil, bu yüzden testten geçirilebiliyor
 * (bkz. test/derleme-denetimi/KilavuzTest.kt).
 *
 * KURAL: buradaki her düğme/bölüm adı arayüzde GERÇEKTEN yazdığı gibi
 * olmalı. Kılavuzda "Ses ayarları" yazıp ekranda "Sesli okuma" görmek
 * kılavuzu işe yaramaz hâle getirir; testler bunu denetliyor.
 */
object Kilavuz {

    const val BASLIK = "Kullanım kılavuzu"

    /** Bir bölüm: listede görünen başlık ve açılınca okunan metin. */
    data class Bolum(val baslik: String, val metin: String) {
        /** Listede başlığın yanında görünen kısa özet (ilk satır). */
        val ilkSatir: String get() = metin.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: ""
    }

    val TELEFON: List<Bolum> = listOf(
        Bolum(
            "1 · Beş adımda başla",
            """
İlk kez kuranlar için en kısa yol.

1. Ana sayfada "Ne izliyorsunuz" bölümüne türü seç, adını yaz (örn. Oyun · Red Dead Redemption 2). Çeviri belirgin biçimde isabetli olur.
2. "Yapay zekâ" kartından modeli bir kez indir. Wi-Fi'da yap; bir daha istemez.
3. ÇEVİRİYİ BAŞLAT'a bas.
4. Android "Ekran kaydı başlatılsın mı?" diye sorar — "Şimdi başlat" de. Bu izin olmadan uygulama ekranı okuyamaz.
5. Ana tuşla oyuna/diziye geç. Türkçe altyazı görüntünün üstünde çıkar.

Durdurmak için GameLingo'ya dön, aynı düğmeye bas (artık "Durduruldu" yazar).

İlk denemede hiç yazı çıkmazsa 10. bölüme (Sorun giderme) bak; çoğu zaman tek sebebi altyazı bölgesidir.
            """.trim(),
        ),
        Bolum(
            "2 · Ne izlediğini yazmak",
            """
Bu alan çevirinin kalitesini en çok değiştiren yerdir.

Tür + ad yazıldığında uygulama kelimenin oyundaki anlamını seçer: bir savaş oyununda "Fire!" → "Ateş!", bir yemek programında "Fire!" → "Ocağa ver!".

• Tür: Oyun, Film, Dizi, Belgesel gibi seçeneklerden biri.
• Ad: oyunun ya da dizinin adı. Türkçe yazmaya çalışma, orijinal adı yaz.
• Yarıda değiştirebilirsin; yeni satırlardan itibaren geçerli olur.

Boş bırakırsan çeviri yine çalışır, yalnız deyimlerde ve argoda daha çok hata yapar.
            """.trim(),
        ),
        Bolum(
            "3 · Altyazı bölgesi (en sık gereken ayar)",
            """
Uygulama ekranın her yerini okumaz; okuduğu şeride "altyazı bölgesi" denir. Yanlış yerdeyse ya hiç yazı çıkmaz ya da can/para göstergesi çevrilir.

Ayarlar ▸ Ekran alanı:
• HIZLI KONUM: "Alt bölge" çoğu oyuna ve diziye uyar. "Üst bölge" bazı Japon yapımlarında işe yarar. "Tam ekran" her yazıyı okur — en yavaş olanı ve menü yazılarını da altyazı sanır.
• Üst sınır / Alt sınır: şeridi elle daraltıp genişletir. Yüzde olarak ekranın tepesinden ölçülür. YouTube için yaklaşık %72 – %95 iyi sonuç verir.
• "Alanı ekranda seç": görüntünün üstünde parmakla kutu çizersin. En kesin yöntem budur.

YAN YAZILAR (menü, görev, tuş yazıları, oyun içi telefon mesajları)
• "Menü, görev ve tuş yazılarını da çevir" açıldığında şerit dışındaki yazılar da okunur.
• 10.58'den beri sol ve sağ için AYRI kutu seçilebiliyor: "Sol alanı kullan" / "Sağ alanı kullan". Daha önce tek kutu ikisini birlikte kapsamak zorundaydı ve aradaki boş ekranı da tarıyordu; artık taramıyor, bu yüzden daha hızlı.

MENÜ MODU
Oyun menüsüne girdiğinde "Menü modu · tüm ekranı tara"yı aç: alan sınırı kalkar, ekrandaki her yazı bulunduğu yerde çevrilir — "Settings" yazan yerde "Ayarlar" görünür. Oyuna dönünce kapat; tüm ekranı taramak yavaştır.
            """.trim(),
        ),
        Bolum(
            "4 · Çeviri biçimi ve motorlar",
            """
Ayarlar ▸ Dil ve çeviri. Dördü arasındaki fark hız ile doğruluk takasıdır.

• Hızlı — yapay zekâ yok. Altyazı anında çıkar, sonradan değişmez. Çok hızlı atışmalarda en rahat okunanı.
• Dengeli (önerilen) — seçili motor öncelikli, şüpheli sonuçta yedek motor denenir.
• Doğru önce (deneysel) — E4B modeli; 3 saniyeden fazla gecikebilir, canlı oyun için önerilmez.
• Doğruluk öncelikli — önce gri taslak çıkar, yapay zekâ bitince doğrusu yerine geçer ve hafızaya girer.

İki yardımcı anahtar:
• "Önce doğru çeviriyi bekle": satır tek seferde doğru çıkar, yazı taslaktan düzeltilmişe geçmez. Bedeli 1-2 saniye gecikme.
• "Hızlı konuşmada önceki satır üstte kalsın": yeni replik eskisini silmez, küçülüp solgunlaşarak üstte 1,5 saniye daha durur.

HAZIR ÇEVİRİ PAKETİ (en hızlısı)
"Hazır çeviri paketi kullan" açıkken satır, hiçbir motora sorulmadan önce pakette aranır. Bulunursa anında ekrana gelir — internet, bekleme, kota yok. Uygulamayla GTA VI paketi geliyor (40.718 satır). Pakette olmayan satır aşağıdaki normal sırayla çevrilir, yani paket hiçbir şeyi yavaşlatmaz.
"Oyun paketlerini indir / güncelle" düğmesi sunucudan ücretsiz paketleri çeker: GTA VI (707 bin satır), GTA V, Elden Ring, Mafia ve diğerleri. Hesap gerekmez, haftada bir kendiliğinden bakılır. İnen her paket SHA-256 ile doğrulanır; bozuk ya da yarım dosya hiç yüklenmez.
Kendi paketini telefonun GameLingo klasöründeki "paketler" dizinine koyabilirsin (.json ya da .json.gz). Yanlış bir hazır çeviri görürsen kutuyu kapat.

MOTORLAR
• Google Çeviri: anahtarsız, kotasız, internet gerekir.
• OPUS-MT (yerel): internetsiz çalışır; modeli ZIP olarak bir kez yüklersin.
• Firefox çeviri modeli: internetsiz, ücretsiz; Offline Translator uygulaması gerekir.
• DeepL: isteğe bağlı, API anahtarı ister ve ücret doğurabilir. İstemiyorsan hiç açma — diğerlerinin hepsi ücretsizdir.
            """.trim(),
        ),
        Bolum(
            "5 · Görünüm",
            """
Ayarlar ▸ Yazı ve görünüm. Örnek satır ("Işığı söndür, çabuk!") değişiklikleri anında gösterir.

• Yazı rengi: beyaz, sarı, yeşil, turkuaz. Sarı koyu sahnelerde en okunur olanı.
• Arka plan: yarı saydam (önerilen), tam dolu, yok. "Yok" seçilince oyunun aydınlık sahnelerinde yazı kaybolabilir — o zaman "Yazıya koyu kenarlık ekle"yi aç.
• Konum: şeridin üstünde (İngilizce de görünür), şeridin üstünü kapat (İngilizceyi örter), İngilizcenin hemen altında, ekranın en altı.
• Yazı boyutu: TV'ye yansıtıyorsan büyüt; telefon elde tutulurken küçük boy daha az yer kaplar.
            """.trim(),
        ),
        Bolum(
            "6 · Sesli okuma",
            """
Ayarlar ▸ Sesli okuma. "Çeviriyi sesli oku" açıldığında telefonun Türkçe konuşma motoru altyazıyı okur. İnternet ve anahtar gerekmez.

Dublaj DEĞİLDİR: karakter sesleri klonlanmaz. Yapılan şey, konuşana göre ses ve ton seçmektir.

ERKEK / KADIN
"Erkek ve kadın seslerini ayır" altyazıdaki konuşan adına bakar. Android ses motorları cinsiyet bildirmediği için uygulama sesleri sessizce ölçüp atamayı kendisi yapar.
→ İlk kurulumda bir kez "Sesleri tara ve kendiliğinden ata"ya bas.
→ Ölçüm yanlış atadıysa "Ses cinsiyetleri" listesinden Dinle'ye bas, duyduğunu işaretle. İşaret ölçümün üstüne yazılır ve bir daha şaşmaz.
Telefonda tek Türkçe ses varsa ayrım perdeyle yapılır: erkek kalın, kadın ince.

SES ALTYAZIYA YETİŞEMEZSE
Hızlı atışmalarda altyazı 1-2 saniyede değişir, bir replik ise ortalama 2,2 saniye sürer. Üç davranıştan birini seç:
• Cümleyi bitir ve hızlan (varsayılan) — bölünen replik %14, duyulmayan %21.
• Yalnız hızlan — bölünen %39, duyulmayan yok.
• Kes ve yeni repliğe geç — bölünen %43, duyulmayan yok.
Oranlar senin 19 Kasım kaydının (28 replik) benzetiminden geliyor.

SES ROBOTİK DUYULUYORSA
"En doğal ayarlara dön"e bas: hız ve ton %100'e, duygu şiddeti %45'e çekilir. Çarpanlar üst üste bindiğinde (taban + duygu + yetişme) ses sentetik duyulur — asıl sebep çoğunlukla budur.

GEREKSİZ OKUMALARI KESMEK
• "Konuşan adı olmayan satırları okuma": radyo istasyonu adları, menü ve reklam yazıları okunmaz.
• "Aynı satırı bir kez oku": ekran okuma aynı iletiyi birkaç biçimde yakalayabiliyor; sözcük köklerine bakıp tekrarı atlar.

DOĞAL TÜRKÇE SES
"Doğal Türkçe ses (cihaz içi)" destekli cihazlarda belirgin biçimde daha doğal konuşur; model ilk kullanımda iner, APK'yı büyütmez. Desteklenmeyen cihazda sessizce Android sesine düşer — hangisinin çaldığını Sesli okuma ekranındaki durum satırı yazar. TV'de kapalıdır (TV'lerde gereken altyapı yok).
Hız ve ton ayarı doğal seste değil, yalnız Android sesinde geçerlidir.
            """.trim(),
        ),
        Bolum(
            "7 · Duygu ve ünlemler",
            """
Ayarlar ▸ Duygu ve ünlemler. Yalnız SESİ etkiler; ekrandaki yazı değişmez.

Eskiden "hmm", "ahaha", "ahhhh" harf harf okunuyordu. Artık tanınır ve kendi tonuyla seslendirilir:
hmm → hımm (düşünme) · ahaha → ha ha ha (gülme) · ahhhh → ahh (acı, yavaş) · hık → hıh hıh (ağlama) · oh (şaşırma)

• Sahne notları ([gülüyor], (ağlıyor), *iç çeker*) için üç seçenek var: hiç okumama, kısık sesle okuma, ya da gülme/ağlama tonuyla canlandırma.
• "Noktalamadan duygu çıkar": KOŞ! bağırma · Ne?! panik · Gidiyorum… üzgün.
• "İngilizce ünlemleri Türkçeleştir": ugh → ahh · ouch → ah · oops → eyvah.
• "Duygu şiddeti" ne kadar abartılacağını belirler. %45 doğal duyulan değerdir; yükselttikçe tiyatro gibi olur.

"Duyguyu dene"ye basarak hepsini sırayla dinleyebilirsin.
            """.trim(),
        ),
        Bolum(
            "8 · Yanlış çeviriyi düzeltmek",
            """
Bir satır yanlış çevrildiyse kalıcı olarak düzeltebilirsin.

1. Alttaki "Geçmiş" sekmesine git.
2. Yanlış çevrilen satırı seç.
3. Doğrusunu yaz ve kaydet.

O cümle bir daha hep senin yazdığın gibi çevrilir — internete de bağlı değildir. Kendi düzeltmelerin Ayarlar ▸ "Sözlüğüm" bölümünde toplanır; oradan silebilir ya da değiştirebilirsin.

Karakter adları, yer adları ve oyuna özgü terimler için en çok işe yarayan yöntem budur.
            """.trim(),
        ),
        Bolum(
            "9 · TV ve bilgisayarda kullanmak",
            """
Üç ayrı yol var; hangisini kullandığına göre kurulum değişir.

A) TV'ye GameLingo TV kurmak
TV'nin kendisine kurulan ayrı bir APK (GameLingo TV). TV'de çalışan oyunları ve YouTube'u çevirir. Ayrıntılı kurulum için bu kılavuzun "TV kılavuzu" düğmesine bas.

B) Telefonu USB-C → HDMI ile TV'ye bağlamak
Telefon çevirir, TV yalnız gösterir. "DP Alt Mode / video çıkışı" yazan bir adaptör gerekir. Ana sayfanın üstünden "TV"yi seç: yazı yaklaşık 1,5 kat büyür ve kutu TV kenarlarındaki kesilme payından uzak durur.

C) TV ya da bilgisayara telefonun yapay zekâsını vermek
TV'nin ve bilgisayarın çevirisi kabadır. Telefondaki yapay zekâ onlara doğru çeviriyi sağlayabilir:
1. Telefonda "Telefondaki yapay zekâ" bölümünde "TV ve bilgisayara çeviri sağla"ya bas. Ekranda 4 haneli kod çıkar.
2. TV'de "Telefonun yapay zekâsını kullan"a bas, kodu yaz, Eşleş de.
3. İkisi aynı Wi-Fi'da olmalı. Telefonu şarja takıp bırakabilirsin; ekran kapalıyken de çalışır.
Önce gri taslak çıkar, 2-4 saniye sonra telefondan gelen doğru çeviri yerine geçer. Telefon kapanırsa TV kendi çevirisine döner.

NE ÇEVRİLEMEZ
Netflix, Disney+, Prime Video ve HBO Max kopya koruması kullanır; ekran görüntüsü siyah gelir, hiçbir yolla çevrilemez. TV'nin HDMI girişindeki görüntü (PS5, konsol, uydu) de yakalanamaz — PS5'i Chiaki/Pylux gibi bir uygulamayla TV'de açarsan çalışır.
            """.trim(),
        ),
        Bolum(
            "10 · Sorun giderme",
            """
HİÇ ALTYAZI ÇIKMIYOR
1. Çeviri gerçekten başladı mı? Düğmede "Durduruldu" yazıyorsa başlamamış.
2. Ekran kaydı iznini verdin mi? Verilmediyse hiçbir şey okunamaz.
3. Altyazı bölgesi doğru yerde mi? Ayarlar ▸ Ekran alanı ▸ "Alanı ekranda seç" ile kutuyu altyazının üstüne çiz. Sebebin çoğu budur.
4. "Kurulumu kontrol et"e bas; eksik izin varsa söyler.

GÖRÜNTÜ SİYAH / YANLIŞ YER ÇEVRİLİYOR
Ayarlar ▸ Gelişmiş ▸ "Ne görüyor? (ekran önizlemesi)". Son yakalanan kareyi gösterir. Turkuaz çerçeve okunan bölgedir.
• Videonun yerinde siyah görüyorsan o uygulama ekran kaydını engelliyor (Netflix vb.) — yapılacak bir şey yok.
• Altyazı çerçevenin dışındaysa bölgeyi düzelt.

SES ÇIKMIYOR
• "Çeviriyi sesli oku" açık mı?
• Telefonun medya sesi açık mı? (Zil sesi değil, medya.)
• Telefonda Türkçe konuşma motoru kurulu mu? Android Ayarlar ▸ Erişilebilirlik ▸ Metin okuma.
• "Konuşan adı olmayan satırları okuma" açıksa, konuşan adı taşımayan altyazılar bilerek okunmaz. Çoğu film altyazısında ad yoktur — bu ayarı kapat.

ÇEVİRİ GEÇ GELİYOR
Ana sayfadaki Okuma / Çeviri / Gecikme sayıları son satırın gerçek ölçümüdür. Gecikme yüksekse: "Hızlı" biçime geç, "Yapay zekâ her satırda çalışsın"ı kapat, menü modunu kapat, altyazı bölgesini daralt.

SORUNU BANA BİLDİRMEK
Ayarlar ▸ Gelişmiş ▸ "Tanılama"yı aç, sonra oyuna dön ve TEK bir sahne oyna. Dönüp "Çalışma kaydını kopyala"ya bas, metni bana gönder. Sesle ilgiliyse Sesli okuma ekranındaki "Ses çalışma kaydı"nı da aç ve "Ses kaydını kopyala"yı gönder. Bu iki kayıt olmadan sebebi tahmin etmek zorunda kalıyorum.
            """.trim(),
        ),
        Bolum(
            "11 · Kayıtlar ve günlükler",
            """
Üç ayrı kayıt var; hangisini isteyeceğim soruna göre değişir.

• Çalışma kaydı (Ayarlar ▸ Gelişmiş) — okuma, çeviri, hangi motorun çalıştığı, süreler. Çeviri sorunları için bu.
• Ses çalışma kaydı (Ayarlar ▸ Sesli okuma) — her repliğin gelişi, konuşanı, seçilen sesi, duygusu, gerçek süresi, kesilip kesilmediği. Ses sorunları için bu. Açık bırakmak okuma süresi tahminini de iyileştirir, çünkü süre bu ölçümlerden öğrenilir.
• Son hata (Ayarlar ▸ Gelişmiş ▸ "Son hatayı kopyala") — uygulama çöktüyse ya da bir motor patladıysa sebebi burada yazar.

Her birinin yanında "kopyala" ve "temizle" düğmesi var. Yeni bir sorunu incelerken önce temizle, sonra sorunu tekrar ettir, sonra kopyala — karışmamış kayıt çok daha işe yarar.

Özel ayarlar: Ayarlar ▸ Özel ayarlar bölümünden dört sütunlu bir tablo (Ad · Tür · Varsayılan · Bölüm) içe aktarabilirsin; "Örnek tablo şablonunu panoya kopyala" ile şablonu alıp doldurman yeterli.
            """.trim(),
        ),
    )

    /** Listede gösterilecek başlıklar. */
    fun basliklar(bolumler: List<Bolum> = TELEFON): List<String> = bolumler.map { it.baslik }

    /** "Tümünü kopyala" için tek parça metin. */
    fun tumMetin(bolumler: List<Bolum> = TELEFON): String =
        bolumler.joinToString("\n\n\n") { "${it.baslik}\n${"-".repeat(it.baslik.length)}\n${it.metin}" }

    /**
     * Basit arama: sorudaki sözcüklerin geçtiği bölümlerin sıraları,
     * en çok eşleşen başta. Türkçe büyük/küçük harf için iki yerelde dener.
     */
    fun ara(soru: String, bolumler: List<Bolum> = TELEFON): List<Int> {
        val sozcukler = ayir(soru)
        if (sozcukler.isEmpty()) return emptyList()
        val puanlar = bolumler.mapIndexed { sira, b ->
            val ham = b.baslik + "\n" + b.metin
            // Türkçe I/İ yüzünden tek yerel yetmiyor: "LINGO" Türkçe yerelde
            // "lıngo" olurken gövdedeki "Lingo" "lingo" kalıyor ve eşleşme
            // kaçıyor. İki yerelin ikisinde de arıyoruz.
            val govdeler = listOf(kucukTr(ham), kucukKok(ham))
            sira to sozcukler.count { s -> govdeler.any { it.contains(s) } }
        }
        return puanlar.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
    }

    private fun ayir(soru: String): List<String> =
        (kucukTr(soru) + "\n" + kucukKok(soru))
            .split(Regex("[^\\p{L}0-9]+")).filter { it.length >= 3 }.distinct()

    private fun kucukTr(s: String): String = s.lowercase(java.util.Locale.forLanguageTag("tr-TR"))

    private fun kucukKok(s: String): String = s.lowercase(java.util.Locale.ROOT)
}
