package com.example.altyazi

import java.util.Locale

/**
 * High-confidence, source-guided repairs for short game dialogue.
 * No network, no tokens. Never fabricates missing words for OCR fragments.
 * Only corrects known grammatical patterns and context-dependent short replies.
 */
object ContextualDialogue {
    private fun norm(s: String): String = s.trim().replace(Regex("\\s+"), " ")
        .lowercase(Locale.ROOT).trim('.', '!', '?', ' ', '…')

    fun repair(source: String, translated: String, previous: String? = null): String {
        val s = norm(source)
        val prev = norm(previous.orEmpty())
        val t = translated.trim()
        if (t.isEmpty()) return t

        // Spoken interjections: preserve meaning, not English literal meaning.
        if (s == "i'm looking hot" || s == "i'm looking hot. oh, yeah")
            return if (s.endsWith("oh, yeah")) "Çok çekici görünüyorum. İşte bu!" else "Çok çekici görünüyorum."
        if (s == "i'm looking big. i'm looking mean") return "İri yarı ve sert görünüyorum."
        if (s == "free demons") return "İblisleri özgür bırak."
        if (s == "defeat volcanikka. free demons") return "Volcanikka'yı yen. İblisleri özgür bırak."
        if (s == "demons not torture vile, all die") return "İblisler Vile'a işkence etmezse herkes ölür."
        if (s == "can't go to war without me") return "Bensiz savaşa gidemezsiniz."
        if (s == "must" && prev.contains("without me")) return "Gitmek zorundayız."
        if (s == "you do" && (prev.contains("i don't know") || prev.contains("don't know"))) return "Biliyorsun."
        if (s == "i do what" && prev == "you do") return "Neyi biliyorum?"
        if (s == "strongest among us") return "Aramızdaki en güçlü kişi sensin."
        if (s == "she falls, they follow") return "O düşerse diğerleri de düşer!"
        if (s == "i'll clear a path, then it's all you guys") return "Ben yolu açacağım, gerisi sizde."
        if (s == "no. save strength") return "Hayır. Gücünü sakla."
        if (s == "vile almost restored") return "Vile neredeyse eski gücüne kavuştu."
        if (s == "ah. a new play thing to dismember") return "Ah, parçalayacak yeni bir oyuncak."
        if (s == "oh, poor damien") return "Ah, zavallı Damien."
        if (s == "kick hideous bitch's ass") return "O iğrenç kaltağın ağzını burnunu dağıt!"
        // Only correct the greeting when the original has no insult.
        if (Regex("^yo(?:o+)?[,! ]", RegexOption.IGNORE_CASE).containsMatchIn(source) &&
            !Regex("\\b(fuck|motherfucker|bitch|asshole)\\b", RegexOption.IGNORE_CASE).containsMatchIn(source)) {
            return t.replace(Regex("^(?:Lan|Ulan)[,! ]+", RegexOption.IGNORE_CASE), "Hey, ")
        }
        return t
    }
}
