import com.example.altyazi.ContextualDialogue

fun main() {
    val tests = listOf(
        Triple("You do.", "Siz yapıyorsunuz.", "I don't know."),
        Triple("I do what?", "Ne yapacağım?", "You do."),
        Triple("Free demons.", "Özgür şeytanlar.", "Defeat Volcanikka."),
        Triple("Yo, Ray!", "Lan, Ray!", "Hello."),
        Triple("Must.", "Mutlak.", "Can't go to war without me.")
    )
    for ((source, translated, previous) in tests) {
        val result = ContextualDialogue.repair(source, translated, previous)
        check(result != translated) { "Not repaired: $source" }
        println("$source => $result")
    }
    check(ContextualDialogue.repair("Must.", "Mutlak.", "No.") == "Mutlak.")
    println("6 checks passed")
}
