# GameLingo 10.15 – Diyalog kalitesi düzeltmeleri

- `AiGuard.kt`: `Yo` seslenmesini zorunlu olarak `Lan` yapan kural `Hey` olarak değiştirildi. Kaynakta ayrıca küfür varsa mevcut küfür korunur.
- `ContextualDialogue.kt`: hızlı çeviri sonrasında kaynak metne ve mevcutsa önceki altyazıya bakarak yüksek güvenli anlam onarımları yapan tokensız katman eklendi. Kısa eksiltili cümleler ve birkaç yaygın oyun ifadesi hedeflendi.
- `CaptureService.kt`: bu katman hem kesin replik hem hızlı çeviri çıktısına bağlandı.
- `app/build.gradle.kts`: sürüm 10.15, versionCode 149.
- `test/ContextualDialogueSmoke.kt`: 6 kontrol içeren Kotlin duman testi.

## Doğrulama
`kotlinc` ile ContextualDialogue + test dosyası derlendi ve 6 kontrol geçti.

## Sınırlar
Bu bir genel amaçlı bağlamsal makine çevirisi modeli değildir. Örneklerdeki sınırlı hata sınıflarını ve kaynak metne göre onarımları düzeltir. Ekran döndürme/yakalama, tüm oyunlarda bağlam, OCR birleştirme, Google 429 ve Android APK derlemesi bu pakette doğrulanmadı. Gradle wrapper kaynak arşivinde bulunmuyor. Gerçek cihaz testi gereklidir.
