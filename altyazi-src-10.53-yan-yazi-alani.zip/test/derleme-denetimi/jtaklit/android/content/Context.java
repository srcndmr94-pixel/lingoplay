package android.content;
import java.io.File;
public class Context {
    public static final int MODE_PRIVATE = 0;
    public Context getApplicationContext() { return this; }
    public File getCacheDir() { return new File("/tmp"); }
    public SharedPreferences getSharedPreferences(String name, int mode) { return null; }
    public int checkSelfPermission(String perm) { return 0; }
}
