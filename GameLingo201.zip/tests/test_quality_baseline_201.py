from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/com/example/altyazi/CaptureService.kt').read_text()
base=source.replace('dialogueContext.repair(OcrSoundCue200.repair(text))', 'dialogueContext.repair(text)')
assert source.count('dialogueContext.repair(OcrSoundCue200.repair(text))') == 1
assert 'delay(RealtimeCaptionPolicy199.PRIMARY_GRACE_MS)' not in source
assert 'LocalCaptionQuality200' not in source
assert 'HEDGE_AFTER_MS = 420L' in (root/'app/src/main/java/com/example/altyazi/RealtimeCaptionPolicy199.kt').read_text()
assert 'LOCAL_TIMEOUT_MS = 550L' in (root/'app/src/main/java/com/example/altyazi/RealtimeCaptionPolicy199.kt').read_text()
assert 'versionCode = 201' in (root/'app/build.gradle.kts').read_text()
assert 'remote ?: (if (prefs.opusMtEnabled' in source
assert 'subtitleGeneration.isCurrent(runId)' in source
assert 'screenHeight - dp(110)' in source
assert 'delay(RealtimeCaptionPolicy199.PRIMARY_GRACE_MS)' not in source
assert 'TranslationQualityGate.mustReject(TranslationQualityGate.check(body, translated))' in source
assert 'val modelFirst = NaturalTranslationPolicy10427.modelFirst(' in source
# Exact byte-for-byte freeze of the 199 translation engine except the single OCR sound-cue hook.
manifest=__import__('json').loads((root/'tests/quality_baseline_199_sha256.json').read_text())
for path, expected in manifest.items():
    content=(root/path).read_bytes()
    if path.endswith('/CaptureService.kt'):
        content=content.replace(b'dialogueContext.repair(OcrSoundCue200.repair(text))',b'dialogueContext.repair(text)')
    assert hashlib.sha256(content).hexdigest()==expected, f'Unreviewed translation regression in {path}'
assert (root/'app/src/main/java/com/example/altyazi/OfflineFix.kt').read_text().count('"both groaning" to "ikisi de inliyor"')==1
print(f'PASS: {len(manifest)} core files match 199 byte-for-byte (except approved sound-cue hook)')
print('PASS: 201 uses original 199 translation flow without 200 timing/quality changes')
