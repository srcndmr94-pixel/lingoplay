package com.example.altyazi

/** Gerçek oyuna/filme özgü içerik taşımayan canlı gecikme politikası. */
object RealtimeCaptionPolicy199 {
    const val HEDGE_AFTER_MS = 420L
    const val LOCAL_TIMEOUT_MS = 550L

    fun needsLocalHedge(balanced: Boolean, strongAvailable: Boolean, source: String): Boolean =
        balanced && strongAvailable && source.any(Char::isLetter) &&
            !Regex("""^\[[^]]{1,80}]$""").matches(source.trim())
}

/** Her replikte ilk güvenilir sonucu yayınla; geç sonucu ekranı değiştirmeden sakla. */
class StableCaptionGate199 {
    private var publishedId = Long.MIN_VALUE

    @Synchronized fun firstValidated(id: Long, isCurrent: (Long) -> Boolean): Boolean {
        if (id <= 0L || !isCurrent(id) || publishedId == id) return false
        publishedId = id
        return true
    }
}
