package com.example.altyazi

import java.util.Locale

/**
 * KARAKTER SESLERİ — 10.45
 *
 * Sorun: erkek/kadın ayrımı tek başına yetmiyor. İki erkek karşılıklı
 * konuşunca ikisi de aynı sesle çıkıyor ve kim konuşuyor anlaşılmıyor.
 *
 * Çözüm: her cinsiyet için DÖRT ton var. Perde ve konuşma hızı birlikte
 * değişiyor — derin ton aynı zamanda yavaş, ince ton aynı zamanda hızlı.
 * Kulak bunu yaş farkı olarak duyuyor: derin+yavaş yaşlı, ince+hızlı genç.
 *
 * DÜRÜST SINIR: uygulama kimin yaşlı olduğunu BİLMİYOR. İsimden yaş
 * çıkmaz. Yaptığı şey karakterleri birbirinden ayırmak; "bu karakter
 * yaşlı" iddiası değil. Tonlar yalnız ayırt edici olsun diye bu aralıkta.
 *
 * Seslerin kendisi değişmiyor: kullanıcı ayarlardan erkek ve kadın sesini
 * seçiyor, buradaki tonlar o seçilen sesin üstüne biniyor. Böylece
 * kullanıcının seçimi korunuyor.
 */
object KarakterSesi {

    /**
     * Bir karakter tonu. [perde] ve [hiz], kullanıcının taban ayarlarıyla
     * ÇARPILIR; yani kullanıcı tonu kalınlaştırırsa hepsi kalınlaşır.
     */
    data class Ton(
        val perde: Float,
        val hiz: Float,
        val etiket: String,
        /**
         * Adsız replikte ve karakter ayrımı kapalıyken kullanılan ton.
         * Her havuzda tam bir tane işaretli. Sıra numarasıyla seçmek
         * yanıltıcıydı: "1" erkek havuzunda "olgun"a denk geliyordu.
         */
        val varsayilan: Boolean = false,
    )

    /** Erkek tonları: derinden inceye, yavaştan hızlıya. */
    private val ERKEK = listOf(
        Ton(0.72f, 0.90f, "derin ve ağır"),
        Ton(0.82f, 0.97f, "olgun"),
        Ton(0.90f, 1.00f, "normal", varsayilan = true),
        Ton(0.98f, 1.06f, "genç"),
    )

    /** Kadın tonları. */
    private val KADIN = listOf(
        Ton(1.02f, 0.92f, "olgun ve ağır"),
        Ton(1.12f, 0.99f, "olgun"),
        Ton(1.22f, 1.03f, "normal", varsayilan = true),
        Ton(1.32f, 1.08f, "genç"),
    )

    /**
     * Cinsiyeti bilinmeyen karakterler. Taban sesin çevresinde dar bir
     * aralık: yanlış cinsiyette okuyormuş gibi durmasın, ama iki bilinmeyen
     * karakter yine de ayrışsın.
     */
    private val NOTR = listOf(
        Ton(0.88f, 0.97f, "kalın"),
        Ton(0.96f, 1.00f, "normal", varsayilan = true),
        Ton(1.06f, 1.02f, "ince"),
        Ton(1.14f, 1.05f, "daha ince"),
    )

    /**
     * Kullanılacak ton havuzu.
     *
     * [notr] = erkek ve kadın için GERÇEKTEN farklı iki ses seçilebilmiş
     * demektir; cinsiyeti sesin kendisi taşıdığı için perdeye yüklenmeye
     * gerek yok ve dar nötr havuz kullanılır. Yalnız tek ses varsa geniş
     * cinsiyet havuzları devreye girer: perde hem cinsiyeti hem karakteri
     * ayırmak zorundadır.
     */
    fun havuz(cinsiyet: Int, notr: Boolean = false): List<Ton> = when {
        notr -> NOTR
        cinsiyet == KonusanCinsiyeti.ERKEK -> ERKEK
        cinsiyet == KonusanCinsiyeti.KADIN -> KADIN
        else -> NOTR
    }

    /**
     * Karakter adlarını tonlara dağıtır.
     *
     * KALICI: bir ad hangi tonu aldıysa oturum boyunca onu kullanır.
     * Tercih edilen yuva adın özüt değerinden (hash) bulunur, böylece aynı
     * karakter çoğu oturumda aynı tonla konuşur. O yuva BAŞKA bir ada
     * verilmişse bir sonraki boş yuvaya kayar: aynı sahnedeki iki karakter
     * asla aynı tonu paylaşmaz (havuz dolana kadar).
     */
    class Dagitici {

        /** "grup|ad" -> yuva sırası. */
        private val atanan = HashMap<String, Int>()

        /** "grup|sıra" -> ad. Yuvanın kimde olduğunu tutar. */
        private val yuvalar = HashMap<String, String>()

        /**
         * Bu ad için [grup] içinde bir yuva numarası (0 .. havuzBoyu-1).
         * Ad yoksa ya da havuz boşsa -1.
         *
         * KALICI: bir ad hangi yuvayı aldıysa oturum boyunca onu kullanır.
         * Tercih edilen yuva adın özüt değerinden bulunur, böylece aynı
         * karakter çoğu oturumda aynı yuvayı alır. O yuva başka bir ada
         * verilmişse ileri doğru kayılır: aynı sahnedeki iki karakter asla
         * aynı yuvayı paylaşmaz (havuz dolana kadar).
         *
         * [grup] ton ve ses dağıtımını ayırmak için: "ton1", "ses2" gibi.
         */
        fun yuva(ad: String?, grup: String, havuzBoyu: Int): Int {
            if (havuzBoyu <= 0) return -1
            val anahtar = KarakterSesi.adAnahtari(ad) ?: return -1
            val tam = "$grup|$anahtar"
            atanan[tam]?.let { return if (it < havuzBoyu) it else it % havuzBoyu }

            val tercih = Math.floorMod(anahtar.hashCode(), havuzBoyu)
            var sira = tercih
            for (i in 0 until havuzBoyu) {
                val aday = (tercih + i) % havuzBoyu
                if (yuvalar["$grup|$aday"] == null) {
                    sira = aday
                    break
                }
            }
            yuvalar["$grup|$sira"] = anahtar
            atanan[tam] = sira
            return sira
        }

        /** Bu ad için ton. Ad yoksa havuzun varsayılan tonu döner. */
        fun ton(ad: String?, cinsiyet: Int, notr: Boolean = false): Ton {
            val h = KarakterSesi.havuz(cinsiyet, notr)
            val sira = yuva(ad, "ton$cinsiyet", h.size)
            return if (sira < 0) KarakterSesi.varsayilan(cinsiyet, notr) else h[sira]
        }

        /** Bu ada atanmış ton sırası (test ve kayıt için). */
        fun sira(ad: String?, cinsiyet: Int): Int {
            val anahtar = KarakterSesi.adAnahtari(ad)
                ?: return KarakterSesi.varsayilanSira(cinsiyet)
            return atanan["ton$cinsiyet|$anahtar"] ?: KarakterSesi.varsayilanSira(cinsiyet)
        }

        /** Kaç karaktere ton verilmiş. */
        fun karakterSayisi(): Int = atanan.size

        /** Çeviri durunca unutulur; yeni oyunda dağıtım baştan yapılır. */
        fun unut() {
            atanan.clear()
            yuvalar.clear()
        }
    }

    /** Bu havuzun varsayılan tonu: adsız replikte ve karakter ayrımı kapalıyken. */
    fun varsayilan(cinsiyet: Int, notr: Boolean = false): Ton {
        val h = havuz(cinsiyet, notr)
        return h.firstOrNull { it.varsayilan } ?: h[h.size / 2]
    }

    /** Varsayılan tonun havuzdaki sırası. */
    fun varsayilanSira(cinsiyet: Int, notr: Boolean = false): Int {
        val h = havuz(cinsiyet, notr)
        val i = h.indexOfFirst { it.varsayilan }
        return if (i < 0) h.size / 2 else i
    }

    /**
     * Adı karşılaştırılabilir hale getirir: "JASON", "Jason" ve "jason"
     * aynı karakter sayılsın. Türkçe küçültme tuzağı için iki yerelden
     * ROOT seçildi; burada eşleşme değil yalnız teklik önemli.
     */
    fun adAnahtari(ad: String?): String? {
        if (ad.isNullOrBlank()) return null
        val t = ad.trim().trim('.', ',', '!', '?', '"', '\'')
            .substringBefore(' ')
            .lowercase(Locale.ROOT)
        return if (t.isEmpty()) null else t
    }
}
