import java.util.*;

/**
 * YIN perde ölçümü + GERÇEKÇİ sentetik konuşma (formantlı).
 *
 * Önceki test harnessi fazla kolaydı: 1/h genlikli saf harmonik yığını
 * üretiyordu ve periyodun yarısında güçlü tepe oluşmuyordu. Gerçek konuşmada
 * formantlar belirli harmonikleri yükseltir; oktav hatası orada doğar.
 * Bu harness formant süzgeci uyguluyor.
 */
public class YinTest {

    static final int BELIRSIZ=0, ERKEK=1, KADIN=2;
    static final double ERKEK_SINIRI=155.0, KADIN_SINIRI=175.0;
    static final double EN_DUSUK_HZ=70.0, EN_YUKSEK_HZ=320.0;
    static final double YIN_ESIK=0.15;
    static final int EN_AZ_SESLI_CERCEVE=8;

    static class Sonuc {
        final double hz; final int sesli, cinsiyet;
        Sonuc(double h,int s,int c){hz=h;sesli=s;cinsiyet=c;}
        boolean olculdu(){ return hz>0 && sesli>=EN_AZ_SESLI_CERCEVE; }
        public String toString(){
            if(!olculdu()) return "ölçülemedi";
            return (cinsiyet==ERKEK?"erkek":cinsiyet==KADIN?"kadın":"belirsiz")+" ("+(int)hz+" Hz)";
        }
    }
    static final Sonuc BOS=new Sonuc(0,0,BELIRSIZ);

    static Sonuc olc(float[] x,int sr){
        if(sr<=0 || x.length<sr/10) return BOS;
        int cerceve=Math.max(512,(int)(sr*0.045));
        int adim=Math.max(64,(int)(sr*0.010));
        int enKisa=Math.max(2,(int)(sr/EN_YUKSEK_HZ));
        int enUzun=Math.min(cerceve/2-1,(int)(sr/EN_DUSUK_HZ));
        if(enUzun<=enKisa) return BOS;
        ArrayList<Double> bulunan=new ArrayList<>();
        for(int bas=0; bas+cerceve<=x.length; bas+=adim){
            double f0=yin(x,bas,cerceve,enKisa,enUzun,sr);
            if(f0>0) bulunan.add(f0);
        }
        if(bulunan.size()<EN_AZ_SESLI_CERCEVE) return new Sonuc(0,bulunan.size(),BELIRSIZ);
        Collections.sort(bulunan);
        int n=bulunan.size();
        double med = n%2==1?bulunan.get(n/2):(bulunan.get(n/2-1)+bulunan.get(n/2))/2.0;
        int c = med<ERKEK_SINIRI?ERKEK : med>KADIN_SINIRI?KADIN : BELIRSIZ;
        return new Sonuc(med,n,c);
    }

    /** YIN: fark işlevi + birikimli ortalama normalleştirme + mutlak eşik. */
    static double yin(float[] x,int bas,int uzunluk,int enKisa,int enUzun,int sr){
        int W = uzunluk/2;
        double[] d=new double[enUzun+1];
        double enerji=0;
        for(int j=0;j<W;j++) enerji += x[bas+j]*x[bas+j];
        if (enerji < 1e-7) return 0;
        for(int tau=1;tau<=enUzun;tau++){
            double t=0;
            for(int j=0;j<W;j++){ double f=x[bas+j]-x[bas+j+tau]; t+=f*f; }
            d[tau]=t;
        }
        double[] dn=new double[enUzun+1];
        dn[0]=1.0; double kosu=0;
        for(int tau=1;tau<=enUzun;tau++){
            kosu+=d[tau];
            dn[tau] = kosu==0 ? 1.0 : d[tau]*tau/kosu;
        }
        int tau=-1;
        for(int t=enKisa;t<=enUzun;t++){
            if(dn[t]<YIN_ESIK){
                // Yerel en dusuge in
                while(t+1<=enUzun && dn[t+1]<dn[t]) t++;
                tau=t; break;
            }
        }
        if(tau<0){
            double enAz=Double.MAX_VALUE; int yer=-1;
            for(int t=enKisa;t<=enUzun;t++) if(dn[t]<enAz){ enAz=dn[t]; yer=t; }
            if(yer<0 || enAz>0.45) return 0;   // periyodik degil
            tau=yer;
        }
        // Parabolik ince ayar
        double iyi=tau;
        if(tau>enKisa && tau<enUzun){
            double a=dn[tau-1], b=dn[tau], c=dn[tau+1];
            double payda=2*(2*b-a-c);
            if(Math.abs(payda)>1e-12) iyi = tau + (c-a)/payda;
        }
        if(iyi<=0) return 0;
        return sr/iyi;
    }

    // ------------------------------------------ gercekci konusma uretimi

    /** Iki kutuplu rezonator (formant). */
    static float[] formant(float[] x,int sr,double f,double bw){
        double r=Math.exp(-Math.PI*bw/sr);
        double c=2*r*Math.cos(2*Math.PI*f/sr);
        float[] y=new float[x.length];
        double y1=0,y2=0;
        for(int i=0;i<x.length;i++){
            double v=x[i]+c*y1-r*r*y2;
            y[i]=(float)v; y2=y1; y1=v;
        }
        return y;
    }

    /** Glottal darbe dizisi + formant suzgeci: gercek konusmaya benzer. */
    static float[] ses(double f0,int sr,double saniye,double[] formantlar,double gurultu,long tohum){
        Random r=new Random(tohum);
        int n=(int)(sr*saniye);
        float[] darbe=new float[n];
        double periyot=sr/f0, sonraki=0;
        for(int i=0;i<n;i++){
            if(i>=sonraki){ darbe[i]=1f; sonraki+=periyot; }
            darbe[i]+= (float)((r.nextDouble()*2-1)*gurultu);
        }
        float[] y=darbe;
        for(double f:formantlar) y=formant(y,sr,f,90);
        // normalle
        float en=0; for(float v:y) en=Math.max(en,Math.abs(v));
        if(en>0) for(int i=0;i<y.length;i++) y[i]=y[i]/en*0.7f;
        return y;
    }

    static final double[] ERKEK_FORMANT = {500, 1500, 2500};
    static final double[] KADIN_FORMANT = {650, 1900, 2900};

    static int gecti=0,kaldi=0;
    static void olcumTesti(String ad,double f0,int sr,double[] fmt,double gurultu,int bekC){
        float[] x=ses(f0,sr,1.2,fmt,gurultu,(long)(f0*131));
        Sonuc s=olc(x,sr);
        double sapma = s.hz>0 ? Math.abs(s.hz-f0)/f0*100 : 999;
        boolean ok = s.olculdu() && sapma<6.0 && s.cinsiyet==bekC;
        if(ok){gecti++;System.out.printf("  OK   %-28s olculen=%6.1f Hz  gercek=%3.0f  sapma=%%%.1f%n",ad,s.hz,f0,sapma);}
        else{kaldi++;System.out.printf("  HATA %-28s olculen=%6.1f Hz  gercek=%3.0f  -> %s%n",ad,s.hz,f0,s);}
    }
    static void dogru(String ad,boolean k,String ek){
        if(k){gecti++;System.out.println("  OK   "+ad+(ek.isEmpty()?"":"  "+ek));}
        else{kaldi++;System.out.println("  HATA "+ad+"  "+ek);}
    }


    // ---------------------------------------------------- WAV yaz / oku

    static void wavYaz(java.io.File f,float[] x,int sr,int kanal) throws java.io.IOException {
        int veriBoyu=x.length*2*kanal;
        try (java.io.DataOutputStream o=new java.io.DataOutputStream(
                new java.io.BufferedOutputStream(new java.io.FileOutputStream(f)))) {
            o.writeBytes("RIFF"); leInt(o,36+veriBoyu); o.writeBytes("WAVE");
            o.writeBytes("fmt "); leInt(o,16); leShort(o,1); leShort(o,kanal);
            leInt(o,sr); leInt(o,sr*kanal*2); leShort(o,kanal*2); leShort(o,16);
            o.writeBytes("data"); leInt(o,veriBoyu);
            for(float v:x){
                int t=(int)Math.max(-32768,Math.min(32767,Math.round(v*32767)));
                for(int k=0;k<kanal;k++) leShort(o,t);
            }
        }
    }
    static void leInt(java.io.DataOutputStream o,int v) throws java.io.IOException {
        o.write(v&0xFF); o.write((v>>8)&0xFF); o.write((v>>16)&0xFF); o.write((v>>24)&0xFF);
    }
    static void leShort(java.io.DataOutputStream o,int v) throws java.io.IOException {
        o.write(v&0xFF); o.write((v>>8)&0xFF);
    }
    static class Ses { float[] ornekler; int sr; }
    static Ses wavOku(java.io.File dosya) throws java.io.IOException {
        if(!dosya.isFile()||dosya.length()<44) return null;
        try (java.io.RandomAccessFile f=new java.io.RandomAccessFile(dosya,"r")) {
            byte[] bas=new byte[12]; f.readFully(bas);
            if(!new String(bas,0,4,"US-ASCII").equals("RIFF")) return null;
            if(!new String(bas,8,4,"US-ASCII").equals("WAVE")) return null;
            int sr=0,kanal=1,bit=16; byte[] veri=null;
            while(f.getFilePointer()+8<=f.length()){
                byte[] b=new byte[8]; f.readFully(b);
                String ad=new String(b,0,4,"US-ASCII"); int boy=leiInt(b,4);
                if(boy<0) return null;
                if(ad.equals("fmt ")){ byte[] fmt=new byte[boy]; f.readFully(fmt);
                    kanal=leiShort(fmt,2); sr=leiInt(fmt,4); bit=leiShort(fmt,14); }
                else if(ad.equals("data")){
                    int kalan=(int)(f.length()-f.getFilePointer());
                    int ok=(boy>0&&boy<=kalan)?boy:kalan;
                    if(ok<=0) return null;
                    veri=new byte[ok]; f.readFully(veri);
                } else f.seek(f.getFilePointer()+boy+(boy&1));
                if(veri!=null) break;
            }
            if(veri==null||sr<=0||kanal<=0||bit!=16) return null;
            int cf=(veri.length/2)/kanal; if(cf<=0) return null;
            float[] out=new float[cf]; int o=0;
            for(int c=0;c<cf;c++){ int t=0;
                for(int k=0;k<kanal;k++){ int lo=veri[o]&0xFF,hi=veri[o+1]; t+=(hi<<8)|lo; o+=2; }
                out[c]=((float)t/kanal)/32768f; }
            Ses s=new Ses(); s.ornekler=out; s.sr=sr; return s;
        }
    }
    static int leiInt(byte[] b,int i){ return (b[i]&0xFF)|((b[i+1]&0xFF)<<8)|((b[i+2]&0xFF)<<16)|((b[i+3]&0xFF)<<24); }
    static int leiShort(byte[] b,int i){ return (b[i]&0xFF)|((b[i+1]&0xFF)<<8); }

    // ------------------------- ESKI ALGORITMA (yalniz regresyon kaniti icin)

    /**
     * 10.46'da gonderilen hatali yontem: en yuksek tepenin %85'ine ulasan
     * ILK tepe. Bu testlerde COKMESI BEKLENIR; buradaki amaci, YIN'e donus
     * yapilirsa hatanin yeniden girmedigini gostermek.
     */
    static double eskiYontem(float[] x,int bas,int uzunluk,int enKisa,int enUzun,int sr){
        double ort=0; for(int i=0;i<uzunluk;i++) ort+=x[bas+i]; ort/=uzunluk;
        double sifir=0; for(int i=0;i<uzunluk;i++){ double d=x[bas+i]-ort; sifir+=d*d; }
        if(sifir<1e-6) return 0;
        double[] r=new double[enUzun+2]; double enYuksek=0;
        for(int g=enKisa;g<=enUzun;g++){
            double t=0; int son=uzunluk-g;
            for(int i=0;i<son;i++) t+=(x[bas+i]-ort)*(x[bas+i+g]-ort);
            r[g]=t/sifir; if(r[g]>enYuksek) enYuksek=r[g];
        }
        if(enYuksek<0.30) return 0;
        for(int g=enKisa+1;g<enUzun;g++)
            if(r[g]>=r[g-1]&&r[g]>=r[g+1]&&r[g]>=0.85*enYuksek) return (double)sr/g;
        return 0;
    }

    static double eskiOlc(float[] x,int sr){
        int cerceve=Math.max(256,(int)(sr*0.040));
        int adim=Math.max(64,(int)(sr*0.010));
        int enKisa=Math.max(2,(int)(sr/EN_YUKSEK_HZ));
        int enUzun=Math.min(cerceve-1,(int)(sr/EN_DUSUK_HZ));
        ArrayList<Double> b=new ArrayList<>();
        for(int bas=0;bas+cerceve<=x.length;bas+=adim){
            double f=eskiYontem(x,bas,cerceve,enKisa,enUzun,sr);
            if(f>0) b.add(f);
        }
        if(b.size()<EN_AZ_SESLI_CERCEVE) return 0;
        Collections.sort(b); int n=b.size();
        return n%2==1?b.get(n/2):(b.get(n/2-1)+b.get(n/2))/2.0;
    }

    public static void main(String[] a) throws Exception {
        System.out.println("== A) ERKEK sesleri (formantli, gercekci) ==");
        olcumTesti("erkek  85 Hz", 85,22050,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("erkek 100 Hz",100,22050,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("erkek 110 Hz",110,22050,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("erkek 120 Hz",120,22050,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("erkek 135 Hz",135,22050,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("erkek 150 Hz",150,22050,ERKEK_FORMANT,0.01,ERKEK);

        System.out.println("== B) KADIN sesleri ==");
        olcumTesti("kadin 185 Hz",185,22050,KADIN_FORMANT,0.01,KADIN);
        olcumTesti("kadin 200 Hz",200,22050,KADIN_FORMANT,0.01,KADIN);
        olcumTesti("kadin 220 Hz",220,22050,KADIN_FORMANT,0.01,KADIN);
        olcumTesti("kadin 240 Hz",240,22050,KADIN_FORMANT,0.01,KADIN);
        olcumTesti("kadin 260 Hz",260,22050,KADIN_FORMANT,0.01,KADIN);

        System.out.println("== C) OKTAV HATASI: erkek sesi kadin okunmamali ==");
        for(double f0: new double[]{95,110,120,130,145}){
            float[] x=ses(f0,22050,1.2,ERKEK_FORMANT,0.02,(long)f0);
            Sonuc s=olc(x,22050);
            boolean ciftKat = s.hz>f0*1.7 && s.hz<f0*2.3;
            boolean yariKat = s.hz>f0*0.4 && s.hz<f0*0.6;
            dogru(String.format(Locale.ROOT,"%.0f Hz oktav kaymasi yok",f0),
                  !ciftKat && !yariKat, s.toString());
        }

        System.out.println("== D) Farkli ornekleme hizlari ==");
        olcumTesti("erkek 120 @16k",120,16000,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("erkek 120 @24k",120,24000,ERKEK_FORMANT,0.01,ERKEK);
        olcumTesti("kadin 210 @44.1k",210,44100,KADIN_FORMANT,0.01,KADIN);

        System.out.println("== E) Gurultu altinda ==");
        olcumTesti("erkek 115 + gurultu",115,22050,ERKEK_FORMANT,0.10,ERKEK);
        olcumTesti("kadin 225 + gurultu",225,22050,KADIN_FORMANT,0.10,KADIN);

        System.out.println("== F) Olculemeyenler ==");
        dogru("sessizlik", !olc(new float[22050],22050).olculdu(), "");
        float[] beyaz=new float[22050]; Random r=new Random(5);
        for(int i=0;i<beyaz.length;i++) beyaz[i]=(float)((r.nextDouble()*2-1)*0.3);
        Sonuc bs=olc(beyaz,22050);
        dogru("saf gurultu", bs.cinsiyet==BELIRSIZ || !bs.olculdu(), bs.toString());
        dogru("bos dizi", !olc(new float[0],22050).olculdu(), "");

        System.out.println("== G) WAV yaz/oku dongusu ==");
        java.io.File tek=java.io.File.createTempFile("ses_tek",".wav");
        wavYaz(tek, ses(125,22050,1.2,ERKEK_FORMANT,0.01,77), 22050, 1);
        Ses o1=wavOku(tek);
        dogru("tek kanal okundu", o1!=null && o1.sr==22050, o1==null?"null":o1.sr+" Hz");
        Sonuc w1=olc(o1.ornekler,o1.sr);
        dogru("dosyadan 125 Hz erkek", w1.olculdu() && Math.abs(w1.hz-125)/125<0.06 && w1.cinsiyet==ERKEK, w1.toString());

        java.io.File cift=java.io.File.createTempFile("ses_cift",".wav");
        wavYaz(cift, ses(215,22050,1.2,KADIN_FORMANT,0.01,78), 22050, 2);
        Ses o2=wavOku(cift);
        Sonuc w2=olc(o2.ornekler,o2.sr);
        dogru("stereo 215 Hz kadin", w2.olculdu() && w2.cinsiyet==KADIN, w2.toString());

        java.io.File bozuk=java.io.File.createTempFile("bozuk",".wav");
        try(java.io.FileOutputStream fo=new java.io.FileOutputStream(bozuk)){
            fo.write("DEGILWAVEDOSYASI123456789012345678901234567890".getBytes("US-ASCII"));
        }
        dogru("bozuk dosya null", wavOku(bozuk)==null, "");
        tek.delete(); cift.delete(); bozuk.delete();

        System.out.println("== H) Iki yontem de bu sinyallerde DOGRU olcuyor ==");
        // ONEMLI NOT: 10.46'da "olcum oktav kaydiriyor" diye tanilamistim;
        // yanlisti. Eski otokorelasyon yontemi de bu formantli sinyallerde
        // dogru olcuyor. Gercek sorun olcumde degil, konusan adi olmayan
        // altyazilarda cinsiyetin HIC bilinememesindeydi (bkz. YonlendirmeTest).
        // YIN yine de korunuyor: iki oktav hatasina karsi da dayanikli.
        for(double f0: new double[]{95,110,120,130,145}){
            float[] x=ses(f0,22050,1.2,ERKEK_FORMANT,0.02,(long)f0);
            double eski=eskiOlc(x,22050);
            double yeni2=olc(x,22050).hz;
            dogru(String.format(Locale.ROOT,"%.0f Hz: eski=%.0f yeni=%.0f",f0,eski,yeni2),
                  Math.abs(yeni2-f0)/f0<0.06, "");
        }

        System.out.println("\nGecti: "+gecti+" · Kaldi: "+kaldi);
        if(kaldi>0) System.exit(1);
    }
}
