import java.util.*;

/**
 * SesliOku.sesiUygula() YÖNLENDİRMESİ.
 *
 * 10.46'da kullanıcının videosunda HER replik kadın sesiyle okundu. Sebep:
 * altyazıda "JASON:" gibi konuşan öneki yoktu, cinsiyet bilinemedi ve kod
 * listenin ilk sesine düşüyordu — 19 sesin 15'i ince olduğu için hep kadın.
 * Bu test o yolu kilitler.
 */
public class YonlendirmeTest {

    static final int BELIRSIZ=0, ERKEK=1, KADIN=2;

    static class Kayit {
        final String ad; final double hz; final int cinsiyet; final boolean ag;
        Kayit(String a,double h,int c,boolean g){ad=a;hz=h;cinsiyet=c;ag=g;}
        public String toString(){ return ad; }
    }

    // --- Telefondaki gercek duruma benzer: cogu ses ince
    static final List<Kayit> HAVUZ = Arrays.asList(
        new Kayit("ince1",240,KADIN,false), new Kayit("ince2",232,KADIN,false),
        new Kayit("ince3",228,KADIN,false), new Kayit("ince4",221,KADIN,false),
        new Kayit("kalin1",112,ERKEK,false), new Kayit("kalin2",128,ERKEK,false),
        new Kayit("orta1",165,BELIRSIZ,false));
    static Set<String> MEVCUT = new HashSet<>(Arrays.asList(
        "ince1","ince2","ince3","ince4","kalin1","kalin2","orta1"));
    /** Kalite sirasina gore ilk ses (eski kodun dustugu yer): ince bir ses. */
    static final String EN_IYI_SES = "ince1";

    static List<Kayit> havuz(int c){
        List<Kayit> u=new ArrayList<>();
        for(Kayit k:HAVUZ) if(k.cinsiyet==c && MEVCUT.contains(k.ad)) u.add(k);
        if(c==KADIN) u.sort((a,b)->Double.compare(b.hz,a.hz)); else u.sort((a,b)->Double.compare(a.hz,b.hz));
        return u;
    }
    static List<Kayit> tumu(){
        List<Kayit> u=new ArrayList<>();
        for(Kayit k:HAVUZ) if(MEVCUT.contains(k.ad) && k.hz>0) u.add(k);
        u.sort((a,b)->Double.compare(a.hz,b.hz));
        return u;
    }

    static class Dagitici {
        final Map<String,Integer> atanan=new HashMap<>();
        final Map<String,String> yuvalar=new HashMap<>();
        int yuva(String ad,String grup,int boy){
            if(boy<=0) return -1;
            if(ad==null||ad.trim().isEmpty()) return -1;
            String a=ad.trim().toLowerCase(Locale.ROOT);
            if(a.contains(" ")) a=a.substring(0,a.indexOf(' '));
            String tam=grup+"|"+a;
            Integer v=atanan.get(tam); if(v!=null) return v<boy?v:v%boy;
            int tercih=Math.floorMod(a.hashCode(),boy); int sira=tercih;
            for(int i=0;i<boy;i++){ int aday=(tercih+i)%boy;
                if(yuvalar.get(grup+"|"+aday)==null){ sira=aday; break; } }
            yuvalar.put(grup+"|"+sira,a); atanan.put(tam,sira); return sira;
        }
    }

    static String varsayilanSesAdi = "kalin1";
    static Dagitici d = new Dagitici();

    /** sesiUygula() yonlendirmesi: hangi ses kullanilir? */
    static String sesSec(String konusan,int cinsiyet){
        if((konusan==null||konusan.trim().isEmpty()) && !varsayilanSesAdi.isEmpty())
            return varsayilanSesAdi;
        List<Kayit> h;
        if(cinsiyet==ERKEK||cinsiyet==KADIN) h=havuz(cinsiyet);
        else if(konusan!=null && !konusan.trim().isEmpty()) h=tumu();
        else h=new ArrayList<>();
        if(h.size()>=2){ int y=d.yuva(konusan,"ses"+cinsiyet,h.size()); return h.get(y>=0?y:0).ad; }
        if(h.size()==1) return h.get(0).ad;
        return EN_IYI_SES;   // eski yol: son care
    }

    static int gecti=0,kaldi=0;
    static void esit(String ad,String bek,String gel){
        if(bek.equals(gel)){gecti++;System.out.println("  OK   "+ad+"  -> "+gel);}
        else{kaldi++;System.out.println("  HATA "+ad+"  beklenen=["+bek+"] gelen=["+gel+"]");}
    }
    static void dogru(String ad,boolean k,String ek){
        if(k){gecti++;System.out.println("  OK   "+ad+(ek.isEmpty()?"":"  "+ek));}
        else{kaldi++;System.out.println("  HATA "+ad+"  "+ek);}
    }

    public static void main(String[] a){
        System.out.println("== A) ASIL HATA: konusan adi YOK ==");
        d=new Dagitici(); varsayilanSesAdi="kalin1";
        esit("adsiz replik varsayilan sesle", "kalin1", sesSec(null,BELIRSIZ));
        esit("bos ad da ayni", "kalin1", sesSec("  ",BELIRSIZ));
        dogru("listenin ilk (ince) sesine DUSMUYOR", !sesSec(null,BELIRSIZ).equals(EN_IYI_SES),
              "ilk ses="+EN_IYI_SES);

        System.out.println("== B) Varsayilan ses degistirilince ==");
        varsayilanSesAdi="ince2";
        esit("kullanicinin secimi", "ince2", sesSec(null,BELIRSIZ));
        varsayilanSesAdi="kalin1";

        System.out.println("== C) Adi var, cinsiyeti BILINIYOR ==");
        d=new Dagitici();
        String e1=sesSec("James",ERKEK), e2=sesSec("Arthur",ERKEK);
        dogru("iki erkek ayri ses", !e1.equals(e2), e1+" / "+e2);
        dogru("ikisi de kalin havuzdan", e1.startsWith("kalin")&&e2.startsWith("kalin"), e1+" / "+e2);
        String k1=sesSec("Lucia",KADIN), k2=sesSec("Martha",KADIN);
        dogru("iki kadin ayri ses", !k1.equals(k2), k1+" / "+k2);
        dogru("ikisi de ince havuzdan", k1.startsWith("ince")&&k2.startsWith("ince"), k1+" / "+k2);

        System.out.println("== D) Adi var ama cinsiyeti BILINMIYOR (Kratos) ==");
        d=new Dagitici();
        String b1=sesSec("Kratos",BELIRSIZ), b2=sesSec("Zagreus",BELIRSIZ);
        dogru("iki bilinmeyen karakter yine de ayrisir", !b1.equals(b2), b1+" / "+b2);
        dogru("varsayilan sese sabitlenmiyor",
              !(b1.equals("kalin1") && b2.equals("kalin1")), b1+" / "+b2);

        System.out.println("== E) Ayni karakter hep ayni ses ==");
        d=new Dagitici();
        String x1=sesSec("James",ERKEK), x2=sesSec("James",ERKEK), x3=sesSec("JAMES",ERKEK);
        dogru("James sabit", x1.equals(x2)&&x2.equals(x3), x1);

        System.out.println("== F) Varsayilan ses bos birakilirsa eski yola duser ==");
        varsayilanSesAdi="";
        esit("son care en iyi ses", EN_IYI_SES, sesSec(null,BELIRSIZ));
        varsayilanSesAdi="kalin1";

        System.out.println("== G) Adsiz replik cinsiyet tahmininden ETKILENMEZ ==");
        esit("cinsiyet ERKEK gelse bile ad yoksa varsayilan", "kalin1", sesSec(null,ERKEK));
        esit("cinsiyet KADIN gelse bile", "kalin1", sesSec(null,KADIN));

        System.out.println("\nGecti: "+gecti+" · Kaldi: "+kaldi);
        if(kaldi>0) System.exit(1);
    }
}
