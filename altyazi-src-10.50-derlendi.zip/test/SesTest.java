import java.util.Locale;
import java.util.regex.Pattern;

/** SesliOku.kt içindeki saf mantığın birebir karşılığı; davranışı burada ölçüyoruz. */
public class SesTest {

    static final Pattern KONUSAN =
        Pattern.compile("^\\p{Lu}[\\p{L}.'\\-]{1,19}(\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?\\s*:\\s+");

    static String temizle(String metin, boolean adAt) {
        if (metin == null || metin.trim().isEmpty()) return null;
        String t = metin.trim();
        if (t.startsWith("⚠") || t.startsWith("GameLingo")) return null;
        t = t.replace("●", " ");
        if (adAt) t = KONUSAN.matcher(t).replaceAll("");
        t = t.replaceAll("[\\r\\n]+", " ");
        t = t.replaceAll("\\s{2,}", " ").trim();
        boolean harf = false;
        for (char c : t.toCharArray()) if (Character.isLetter(c)) { harf = true; break; }
        if (!harf) return null;
        return t;
    }

    static String temizleAd(String m) { return temizle(m, true); }

    static boolean okunurMu(String m) {
        if (m == null || m.trim().isEmpty()) return false;
        String t = m.trim();
        if (t.startsWith("⚠")) return false;
        if (t.startsWith("GameLingo")) return false;
        return temizle(t, false) != null;
    }

    static String sade(String m) {
        String low = m.toLowerCase(new Locale("tr", "TR"));
        StringBuilder sb = new StringBuilder();
        for (char c : low.toCharArray()) if (Character.isLetterOrDigit(c)) sb.append(c);
        return sb.toString();
    }

    static int gecti = 0, kaldi = 0;

    static void esit(String ad, Object beklenen, Object gercek) {
        boolean ok = (beklenen == null) ? gercek == null : beklenen.equals(gercek);
        if (ok) { gecti++; System.out.println("  OK   " + ad); }
        else { kaldi++; System.out.println("  HATA " + ad + "\n        beklenen: [" + beklenen + "]\n        gelen   : [" + gercek + "]"); }
    }

    public static void main(String[] a) {
        System.out.println("== temizle: konusan adi atilmali ==");
        esit("James", "Gel buraya.", temizleAd("James: Gel buraya."));
        esit("iki kelimeli ad", "Hemen gidiyoruz.", temizleAd("John Marston: Hemen gidiyoruz."));
        esit("turkce ad", "Kapiyi ac.", temizleAd("İsmail: Kapiyi ac."));
        esit("bosluksuz iki nokta", "Tamam.", temizleAd("LUCIA: Tamam."));

        System.out.println("== temizle: cumle icindeki iki nokta KORUNMALI ==");
        esit("cumle ortasi", "Sana bir sey diyecegim: kac.", temizleAd("Sana bir sey diyecegim: kac."));
        esit("saat", "Saat 10:30'da buradayim.", temizleAd("Saat 10:30'da buradayim."));

        System.out.println("== temizle: isaret ve bosluk ==");
        esit("turkuaz nokta", "Isigi sondur, cabuk!", temizleAd("Isigi sondur, cabuk!  ●"));
        esit("satir sonu", "Bir seyler duydum ama emin degilim.", temizleAd("Bir seyler duydum\nama emin degilim."));
        esit("cok bosluk", "Ne oluyor lan", temizleAd("Ne    oluyor   lan"));

        System.out.println("== okunmayacaklar ==");
        esit("uyari", null, temizleAd("⚠ Ekranda yazi okunamiyor. Altyazi bolgesini kontrol edin."));
        esit("durum", null, temizleAd("GameLingo calisiyor…"));
        esit("bos", null, temizleAd("   "));
        esit("null", null, temizleAd(null));
        esit("yalniz noktalama", null, temizleAd("...!?"));
        esit("yalniz tire", null, temizleAd("—"));
        esit("okunurMu uyari", false, okunurMu("⚠ hata"));
        esit("okunurMu normal", true, okunurMu("Hadi gidelim."));
        esit("okunurMu sadece ad", true, okunurMu("Raymond, Raymond."));

        System.out.println("== ad atma KAPALI iken cumle bozulmamali ==");
        esit("Dikkat kapali", "Dikkat: arkanda!", temizle("Dikkat: arkanda!", false));
        esit("Dikkat acik (ad sanilir)", "arkanda!", temizle("Dikkat: arkanda!", true));
        esit("James kapali korunur", "James: Gel buraya.", temizle("James: Gel buraya.", false));

        System.out.println("== tekrar okumayi engelleme (sade bicim) ==");
        esit("ayni cumle noktalama farki", sade("Tam iceride."), sade("Tam iceride!"));
        esit("bosluk farki", sade("Evet ."), sade("Evet."));
        esit("farkli cumle ayri", false, sade("Evet.").equals(sade("Hayir.")));
        esit("ad atildiktan sonra ayni", sade(temizleAd("James: Gel buraya.")), sade(temizleAd("Gel buraya.")));

        System.out.println("\nGecti: " + gecti + " · Kaldi: " + kaldi);
        if (kaldi > 0) System.exit(1);
    }
}
