package android.app;
public class Activity extends android.content.Context {
    public <T extends android.view.View> T findViewById(int id) { return null; }
    public boolean isFinishing() { return false; }
    public boolean isDestroyed() { return false; }
}
