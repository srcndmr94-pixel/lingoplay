package android.view;
public class View {
    public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;
    public void setVisibility(int v) {}
    public int getVisibility() { return 0; }
    public void setOnClickListener(OnClickListener l) {}
    public interface OnClickListener { void onClick(View v); }
}
