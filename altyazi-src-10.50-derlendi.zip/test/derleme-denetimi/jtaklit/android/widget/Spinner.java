package android.widget;
public class Spinner extends AdapterView<SpinnerAdapter> {
    public void setAdapter(SpinnerAdapter a) {}
    public SpinnerAdapter getAdapter() { return null; }
}
