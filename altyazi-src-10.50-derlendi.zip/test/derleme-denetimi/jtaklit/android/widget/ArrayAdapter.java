package android.widget;
import java.util.List;
public class ArrayAdapter<T> implements ListAdapter, SpinnerAdapter {
    public ArrayAdapter(android.content.Context c, int resource, List<T> objects) {}
}
