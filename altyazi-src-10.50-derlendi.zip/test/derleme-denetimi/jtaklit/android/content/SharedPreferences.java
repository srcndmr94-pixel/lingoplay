package android.content;
import java.util.Set;
public interface SharedPreferences {
    String getString(String key, String def);
    int getInt(String key, int def);
    boolean getBoolean(String key, boolean def);
    boolean contains(String key);
    Editor edit();
    interface Editor {
        Editor putString(String k, String v);
        Editor putInt(String k, int v);
        Editor putBoolean(String k, boolean v);
        void apply();
    }
}
