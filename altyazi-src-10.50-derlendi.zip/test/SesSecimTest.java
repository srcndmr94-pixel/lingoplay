import java.util.*;

/**
 * SesliOku'daki SES SEÇİMİ mantığı (etkinSes / ayriSesVar).
 * Perde ve hız artık KarakterSesi'nden geliyor; onu KarakterTest ölçüyor.
 */
public class SesSecimTest {

    static final int BILINMIYOR = 0, ERKEK = 1, KADIN = 2;

    List<String> sesler = new ArrayList<>();   // kaliteden düşüğe
    String erkekSesAdi = "", kadinSesAdi = "";
    boolean cinsiyetAyrimi = true;

    String sesBul(String ad) {
        if (ad == null || ad.isEmpty()) return null;
        for (String s : sesler) if (s.equals(ad)) return s;
        return null;
    }

    String etkinSes(int cinsiyet) {
        String istenen = cinsiyet == ERKEK ? erkekSesAdi : cinsiyet == KADIN ? kadinSesAdi : "";
        String b = sesBul(istenen);
        if (b != null) return b;
        return sesler.isEmpty() ? null : sesler.get(0);
    }

    /** Erkek ve kadın için gerçekten farklı ses kullanılabiliyor mu? */
    boolean ayriSesVar() {
        String e = etkinSes(ERKEK), k = etkinSes(KADIN);
        return !(e == null ? k == null : e.equals(k));
    }

    String okunanSes(int cinsiyetHam) {
        int c = cinsiyetAyrimi ? cinsiyetHam : BILINMIYOR;
        return String.valueOf(etkinSes(c));
    }

    static int gecti = 0, kaldi = 0;
    static void esit(String ad, Object bek, Object gel) {
        if (bek.equals(gel)) { gecti++; System.out.println("  OK   " + ad); }
        else { kaldi++; System.out.println("  HATA " + ad + "  beklenen=[" + bek + "] gelen=[" + gel + "]"); }
    }

    public static void main(String[] a) {
        System.out.println("== A) Iki ayri ses secili ==");
        SesSecimTest t = new SesSecimTest();
        t.sesler = Arrays.asList("tr-A", "tr-B");
        t.erkekSesAdi = "tr-A"; t.kadinSesAdi = "tr-B";
        esit("erkek -> tr-A", "tr-A", t.okunanSes(ERKEK));
        esit("kadin -> tr-B", "tr-B", t.okunanSes(KADIN));
        esit("bilinmiyor -> en iyi ses", "tr-A", t.okunanSes(BILINMIYOR));
        esit("ayri ses VAR", true, t.ayriSesVar());

        System.out.println("== B) Telefonda tek ses ==");
        t = new SesSecimTest();
        t.sesler = Arrays.asList("tr-A");
        esit("erkek -> tr-A", "tr-A", t.okunanSes(ERKEK));
        esit("kadin -> tr-A", "tr-A", t.okunanSes(KADIN));
        esit("ayri ses YOK (perde devreye girecek)", false, t.ayriSesVar());

        System.out.println("== C) Iki sese de AYNI ses secilmis ==");
        t = new SesSecimTest();
        t.sesler = Arrays.asList("tr-A", "tr-B");
        t.erkekSesAdi = "tr-B"; t.kadinSesAdi = "tr-B";
        esit("ikisi de tr-B", "tr-B", t.okunanSes(ERKEK));
        esit("ayri ses YOK", false, t.ayriSesVar());

        System.out.println("== D) Yalniz erkek secili, kadin bos ==");
        t = new SesSecimTest();
        t.sesler = Arrays.asList("tr-A", "tr-B");
        t.erkekSesAdi = "tr-B";
        esit("erkek -> tr-B", "tr-B", t.okunanSes(ERKEK));
        esit("kadin -> en iyi ses tr-A", "tr-A", t.okunanSes(KADIN));
        esit("ayri ses VAR (perde bozulmaz)", true, t.ayriSesVar());

        System.out.println("== E) Secili ses artik yok (paket silinmis) ==");
        t = new SesSecimTest();
        t.sesler = Arrays.asList("tr-A");
        t.erkekSesAdi = "tr-SILINMIS"; t.kadinSesAdi = "tr-YOK";
        esit("erkek yedege duser", "tr-A", t.okunanSes(ERKEK));
        esit("kadin yedege duser", "tr-A", t.okunanSes(KADIN));
        esit("ayri ses YOK", false, t.ayriSesVar());

        System.out.println("== F) Cinsiyet ayrimi KAPALI ==");
        t = new SesSecimTest();
        t.sesler = Arrays.asList("tr-A", "tr-B");
        t.erkekSesAdi = "tr-A"; t.kadinSesAdi = "tr-B";
        t.cinsiyetAyrimi = false;
        esit("erkek replik en iyi sesle", "tr-A", t.okunanSes(ERKEK));
        esit("kadin replik en iyi sesle", "tr-A", t.okunanSes(KADIN));

        System.out.println("== G) Motor hic ses listelemiyor ==");
        t = new SesSecimTest();
        t.sesler = new ArrayList<>();
        esit("ses yok, cokmez", "null", t.okunanSes(ERKEK));
        esit("ayri ses YOK", false, t.ayriSesVar());

        System.out.println("\nGecti: " + gecti + " · Kaldi: " + kaldi);
        if (kaldi > 0) System.exit(1);
    }
}
