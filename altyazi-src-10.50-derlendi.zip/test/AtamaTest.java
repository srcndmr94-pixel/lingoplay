import java.util.*;

/** MainActivity.sesleriAta() mantığının simülasyonu. */
public class AtamaTest {

    static final int BELIRSIZ=0, ERKEK=1, KADIN=2;

    static class Olcum {
        final String ad; final double hz; final int cinsiyet;
        Olcum(String a,double h,int c){ad=a;hz=h;cinsiyet=c;}
        boolean olculdu(){ return hz>0; }
        public String toString(){ return ad+"("+(int)hz+")"; }
    }

    /** Döndürür: "erkekSesi|kadinSesi" ("" = atanmadı). */
    static String ata(List<Olcum> olcumler) {
        List<Olcum> olculen = new ArrayList<>();
        for (Olcum o : olcumler) if (o.olculdu()) olculen.add(o);

        Olcum enAlcakErkek=null, enYuksekKadin=null;
        for (Olcum o : olculen) {
            if (o.cinsiyet==ERKEK && (enAlcakErkek==null || o.hz<enAlcakErkek.hz)) enAlcakErkek=o;
            if (o.cinsiyet==KADIN && (enYuksekKadin==null || o.hz>enYuksekKadin.hz)) enYuksekKadin=o;
        }
        String erkekAd = enAlcakErkek==null ? "" : enAlcakErkek.ad;
        String kadinAd = enYuksekKadin==null ? "" : enYuksekKadin.ad;

        if ((erkekAd.isEmpty() || kadinAd.isEmpty()) && olculen.size()>=2) {
            Olcum enKalin=null, enInce=null;
            for (Olcum o : olculen) {
                if (enKalin==null || o.hz<enKalin.hz) enKalin=o;
                if (enInce==null || o.hz>enInce.hz) enInce=o;
            }
            if (enKalin!=null && enInce!=null && !enKalin.ad.equals(enInce.ad)) {
                if (erkekAd.isEmpty()) erkekAd=enKalin.ad;
                if (kadinAd.isEmpty()) kadinAd=enInce.ad;
            }
        }
        if (!erkekAd.isEmpty() && erkekAd.equals(kadinAd)) kadinAd="";
        return erkekAd+"|"+kadinAd;
    }

    static int gecti=0, kaldi=0;
    static void esit(String ad,String bek,String gel){
        if(bek.equals(gel)){gecti++;System.out.println("  OK   "+ad+"  -> "+gel);}
        else{kaldi++;System.out.println("  HATA "+ad+"  beklenen=["+bek+"] gelen=["+gel+"]");}
    }

    public static void main(String[] a) {
        System.out.println("== A) Net durum: iki erkek bir kadin ==");
        esit("en kalin erkek, kadin secilir", "A|C", ata(Arrays.asList(
            new Olcum("A",105,ERKEK), new Olcum("B",140,ERKEK), new Olcum("C",215,KADIN))));

        System.out.println("== B) Iki kadin: en incesi secilir ==");
        esit("en ince kadin", "A|C", ata(Arrays.asList(
            new Olcum("A",110,ERKEK), new Olcum("B",190,KADIN), new Olcum("C",240,KADIN))));

        System.out.println("== C) Hicbiri siniflanamadi ama ikisi olculdu ==");
        esit("en kalin erkek, en ince kadin sayilir", "A|B", ata(Arrays.asList(
            new Olcum("A",160,BELIRSIZ), new Olcum("B",172,BELIRSIZ))));

        System.out.println("== D) Yalniz erkekler var ==");
        esit("kadin icin en ince olculen", "A|B", ata(Arrays.asList(
            new Olcum("A",100,ERKEK), new Olcum("B",145,ERKEK))));

        System.out.println("== E) Tek ses: atama yapilmaz, perdeye kalir ==");
        esit("tek olculen", "A|", ata(Arrays.asList(new Olcum("A",120,ERKEK))));
        esit("tek belirsiz", "|", ata(Arrays.asList(new Olcum("A",165,BELIRSIZ))));

        System.out.println("== F) Hicbiri olculemedi ==");
        esit("olcum yok", "|", ata(Arrays.asList(
            new Olcum("A",0,BELIRSIZ), new Olcum("B",0,BELIRSIZ))));

        System.out.println("== G) Olculemeyenler karisiyor ==");
        esit("yalniz olculenler sayilir", "B|C", ata(Arrays.asList(
            new Olcum("A",0,BELIRSIZ), new Olcum("B",115,ERKEK),
            new Olcum("C",225,KADIN), new Olcum("D",0,BELIRSIZ))));

        System.out.println("== H) Ayni ses ikisine birden atanmaz ==");
        esit("tek ses iki role girmez", "A|", ata(Arrays.asList(
            new Olcum("A",120,ERKEK), new Olcum("A",120,ERKEK))));

        System.out.println("== I) Bos liste ==");
        esit("bos", "|", ata(new ArrayList<Olcum>()));

        System.out.println("== J) Gercekci Google tr sesleri ==");
        esit("dort ses", "tr-c|tr-b", ata(Arrays.asList(
            new Olcum("tr-a",198,KADIN), new Olcum("tr-b",232,KADIN),
            new Olcum("tr-c",112,ERKEK), new Olcum("tr-d",138,ERKEK))));

        System.out.println("\nGecti: "+gecti+" · Kaldi: "+kaldi);
        if(kaldi>0) System.exit(1);
    }
}
