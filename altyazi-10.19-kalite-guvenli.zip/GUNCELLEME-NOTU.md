# GameLingo 10.19 — sınırlı kalite iyileştirmesi (kaynak)

**Temel:** `altyazi-10.18-duzeltme.zip`. 10.18'in OCR, ekran yakalama, Firefox, Google, ML Kit, uygulama ayarları ve kaplama kodu korunmuştur.

## Değişiklikler
- `SubtitlePreparation.kt`: günlüklerde görülen yedi DAR OCR onarımı (ör. `most hand some`, `mnonths`, `momn`, `tw O-week`, `wara million`, `There'sa`, `Aint`); başka metne dokunmama testleri var.
- `CaptureService.kt`: şüpheli OCR ilk karede çevrilmez; aynı metin ikinci karede tekrar okununca geçebilir. Güvenilir okumalar birinci karede çevrilmeye devam eder.
- `OfflineFix.kt`: Google açıkken **aynı OCR altyazısının** birden fazla cümlesi, bunlardan biri hazır sözlükle eşleşmiyorsa tek blok hâlinde çevrilir. Tek cümleler, kullanıcının sözlüğü ve Google > Firefox > ML Kit düşüşü korunur.
- `Phrases.kt`: dört açık, tam eşleşmeli doğal Türkçe karşılık (eğlenmek, otobüs deyimi, aileleri yok etmek); başka ifadelerin içindeki sözcükler değişmez.
- `GoogleCeviri.kt`: tanı modu açıkken Google'ın gerçek giriş/ham çıkışı tek bir satırda kayıt edilir. Ek bir çeviri isteği veya token gerektirmez.
- `TranslationStore.kt`: hızlı çeviri hafızası sürümü 3→4. Eski yanlış hızlı kayıtları ilk güncellemede bir kez temizlenir. `Sözlüğüm`, uygulama ayarları ve AI hafızası silinmez.
- `app/build.gradle.kts`: sürüm 10.19 / versionCode 152.

## Doğrulama
- Var olan **60 Python test betiği** ayrı ayrı çalıştırıldı, tamamı geçti (çalıştırma / statik / taklitli test karışımı).
- Ek `test_context_guard_1019.py` testi geçti.
- `SubtitlePreparationTest.kt` ve `SubtitleQualityTest.kt` gerçek `kotlinc` ile derlenip çalıştırıldı: toplam 28 örnek/koruma kontrolü geçti.
- ZIP bütünlüğü ayrıca doğrulanır.

## Sınırlar
- **Kaynak ZIP'tir, APK değildir.** Android SDK/Gradle bulunmadığından APK derlenmedi; telefonda denenmedi.
- Birbirini takip eden **ayrı ekran altyazılarını** birleştirme bu değişiklikte yoktur; riskli olduğu için mevcut gösterim sırası değiştirilmedi.
- Bu düzeltme Google'ın her bağlam hatasını veya bütün OCR hatalarını çözmeyi garanti etmez.
- Anahtarsız Google arayüzü resmî, garantili bir API değildir.
