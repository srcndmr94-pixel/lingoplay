# GameLingo Chrome–Android çeviri karşılaştırması

Bu dosya 14 Kasım 2026 tarihli kullanıcının Android logundan alınan 12 örneği içerir.

- `android_observed`: Android logunda gerçekten görülen sonuç.
- `expected_turkish`: İnsan tarafından önerilen doğal karşılık; tek mümkün çeviri değildir.
- `chrome_translation`: **Boş**; Chrome'dan aynı metinlerle gerçek sonuç alınmadı. Chrome sonucunu uydurmayın.
- `status`: Android çıktısında gözlenen sorun sınıfı.

## Nasıl test edilir?

Chrome eklentisi, `chrome/icerik.js` içinde `Translator.create({sourceLanguage:'en',targetLanguage:'tr'})` kullanır. Bu API'yi Android'de doğrudan çalıştırmak mümkün değildir. Chrome'da aynı İngilizce cümleleri altyazı olarak oynatıp gerçek sonuçları `chrome_translation` sütununa girin; ardından iki motorun anlam/argo/özne doğruluğunu karşılaştırın.

## Kaynak koddan doğrulananlar

- Chrome: DOM'dan YouTube/Netflix/Prime altyazısını alıyor, OCR kullanmıyor; tek işlem kuyruğu ve 800 kayıt önbelleği var.
- Android: `GoogleCeviri.kt` çevrimiçi Google çevirisini kullanıyor; diğer yerel/alternatif motorlar ayrı sınıflarda.

## Kritik not

Bu dosya bir test veri kümesidir, APK yaması değildir. Chrome çeviri çıktıları ve gerçek cihaz karşılaştırması henüz yapılmadı.
