package com.example.altyazi

/**
 * Güvenli oturum-içi isim onarımı. Yalnız kabul edilen altyazılar hatırlanır.
 * "Pout's" ancak yakın geçmişte "Paul" adı açık bağlamda geçerse "Paul's" olur.
 * Kanıt yoksa metin değiştirilmez. Yeni ağ isteği/çeviri gecikmesi yoktur.
 */
class DialogueContextRepair {
    private var acceptedCount = 0
    private var lastPaulAt = -1
    private var lastAccepted = ""
    // Kaynak -> hemen önce kabul edilen altyazı. Asenkron çeviri gelince de
    // doğru önceki satırı kullanmak için kabul anında kaydedilir.
    private data class AcceptedBefore(val text: String, val timestampMs: Long, val earlier: String = "", val earlierAtMs: Long = 0L)
    private val preceding = object : LinkedHashMap<String, AcceptedBefore>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, AcceptedBefore>?): Boolean = size > 32
    }
    private var lastAcceptedAtMs = 0L
    private val incompleteEnding = Regex(
        "(?i)\\b(?:a|an|the|of|for|to|from|with|without|about|by|at|in|on|as|than|" +
            "because|if|when|while|and|but|or|that|which|who|whose|" +
            "am|is|are|was|were|have|has|had|do|does|did|will|would|can|could|should)\\s*$"
    )
    private val sentenceEnding = Regex("[.!?…][\"'’)]*$")
    // A following sound cue is not a speaker change. It may follow a spoken
    // continuation: "any difference at all. -[insects trilling]".
    private val trailingSoundCue = Regex("""(?i)\s*(?:-\s*)?\[[a-z]+(?:[ ,'-][a-z]+){0,5}]\s*$""")
    private val incompletePredicate = Regex("""(?i)\b(?:would|could|will|might|can|should)\s+make\s*$""")

    /**
     * Açıkça yarım bırakılan iki satırı tek çeviri girdisine dönüştürür.
     * Farklı konuşmacı, ses etiketi, cümle sonu veya eski sahne birleştirilmez.
     * Çıktı yalnızca çeviri girdisidir; kaynak altyazının kimliği değişmez.
     */
    @Synchronized fun joinedTranslationInput(source: String, nowMs: Long = System.currentTimeMillis()): String? {
        val before = preceding[source] ?: return null
        if (nowMs < before.timestampMs || nowMs - before.timestampMs > 7_000L) return null
        val previous = before.text.trim()
        val current = source.trim()
        val spokenCurrent = current.replace(trailingSoundCue, "").trimEnd()
        val splitNegation = previous.matches(Regex("(?i)^not[.\\s]{2,}$")) &&
            spokenCurrent.matches(Regex("(?i)^be\\s+here[.!?]*$"))
        if ((previous.length !in 10..140 && !splitNegation) || spokenCurrent.length !in 7..130 ||
            previous.length + current.length > 190) return null
        if (previous.equals(current, ignoreCase = true)) return null
        if (previous.any { it == '[' || it == ']' || it == ':' } ||
            spokenCurrent.any { it == '[' || it == ']' || it == ':' }) return null
        val interruptedJust = Regex("(?i)^(?:i\\s+(?:was|am)\\s+just)[.\\s]*$")
            .matches(previous) && Regex("(?i)^making\\b").containsMatchIn(spokenCurrent)
        if (sentenceEnding.containsMatchIn(previous) && !interruptedJust && !splitNegation) return null
        if (spokenCurrent.firstOrNull()?.isLowerCase() != true) return null
        // Continuation beginnings are grammatical dependencies, not new speakers.
        // Require missing punctuation in the preceding subtitle to avoid
        // merging unrelated finished lines.
        val continuesClause = Regex("(?i)^(?:trying|making|and|but|because|to|so|while|which|that)\\b")
            .containsMatchIn(spokenCurrent) && !sentenceEnding.containsMatchIn(previous)
        val evidentlyIncomplete = previous.endsWith(',') || previous.endsWith('—') ||
            previous.endsWith('-') || incompleteEnding.containsMatchIn(previous) ||
            incompletePredicate.containsMatchIn(previous) || continuesClause || interruptedJust || splitNegation
        val earlierIncomplete = before.earlier.trim().let { e ->
            e.isNotEmpty() && !sentenceEnding.containsMatchIn(e) &&
                (e.endsWith(',') || e.endsWith('-') || incompleteEnding.containsMatchIn(e))
        }
        if (!evidentlyIncomplete && !(earlierIncomplete && !sentenceEnding.containsMatchIn(previous))) return null
        // If the previous line was itself a continuation, include its opener.
        // This fixes three-screen sentences without translating the final clause alone.
        val earlier = before.earlier.trim()
        if (earlier.length in 10..130 && nowMs >= before.earlierAtMs &&
            before.timestampMs - before.earlierAtMs in 0..7_000L &&
            earlier.length + previous.length + current.length <= 220 &&
            earlier.none { it == '[' || it == ']' || it == ':' } &&
            !sentenceEnding.containsMatchIn(earlier) &&
            (earlier.endsWith(',') || earlier.endsWith('-') ||
                incompleteEnding.containsMatchIn(earlier)) &&
            previous.firstOrNull()?.isLowerCase() == true) {
            return "$earlier $previous $current"
        }
        return "${if (interruptedJust || splitNegation) previous.trimEnd('.', ' ') else previous} $current"
    }
    /** Previous accepted English subtitles, never the current line or future dialog.
     * Used only for the DeepL live API's context parameter; no extra API call.
     * A fragment not attributable to the current subtitle gets NO context.
     */
    @Synchronized fun contextForTranslation(body: String, nowMs: Long = System.currentTimeMillis()): String {
        val requested = body.trim().replace(Regex("\\s+"), " ")
        val match = preceding.entries.toList().asReversed().firstOrNull { (source, record) ->
            nowMs >= record.timestampMs && nowMs - record.timestampMs <= 10_000L &&
                source.trim().removePrefixSpeaker().let { plain ->
                    plain.equals(requested, ignoreCase = true) ||
                        GoogleSourcePreparation.prepare(plain).equals(requested, ignoreCase = true)
                }
        } ?: return ""
        val first = match.value.text.trim()
        val older = match.value.earlier.trim()
        val context = listOf(older, first).filter {
            it.length in 3..170 && it != requested && !it.startsWith("[")
        }
        return context.joinToString("\n").takeLast(340)
    }

    private fun String.removePrefixSpeaker(): String =
        replace(Regex("^\\[[^]]{1,35}]\\s*"), "").trim()

    private val paulEvidence = Regex("\\b(?:with\\s+Paul|about\\s+this\\s+Paul\\s+guy|Paul\\s+is)\\b")
    private val likelyPoutName = Regex("\\bPout(?=['’]s\\b)")

    @Synchronized fun reset() {
        acceptedCount = 0
        lastPaulAt = -1
        lastAccepted = ""
        lastAcceptedAtMs = 0L
        preceding.clear()
    }

    /** Saf işlem: aynı kare birden çok kez okunsa da geçmişi ilerletmez. */
    @Synchronized fun repair(text: String): String {
        if (lastPaulAt == -1 || acceptedCount - lastPaulAt > 40) return text
        return likelyPoutName.replace(text, "Paul")
    }

    /**
     * Yalnız anlamı açık, arka arkaya gelen KOPUK replikler için ikinci
     * altyazının tamamını doğal Türkçeye çevirir. Tahmin yok; eşleşme yoksa
     * Google/Firefox hattına aynen bırakılır. Ağ çağrısı / gecikme eklemez.
     * Hangi önceki repliğe ait olduğu kabul ANINDA sabitlenir.
     */
    @Synchronized fun contextualTranslation(source: String): String? {
        val previous = preceding[source]?.text?.lowercase()?.trim() ?: return null
        val current = source.lowercase().trim()
        return when {
            // "They" refers to powers when the immediately preceding speaker
            // explicitly said "my powers came back"; no noun is invented.
            previous.endsWith("my powers came back.") &&
                current.matches(Regex("""(?:\[mark\]\s*)?they just came back\?""")) ->
                "Kendiliğinden mi geri geldiler?"
            // "...back in the day" ardından "Was?!" zaman vurgusudur.
            current.matches(Regex("was[?!]+")) &&
                Regex("\\bback in the day[.!?]*$").containsMatchIn(previous) ->
                "Eskiden mi?!"
            previous == "have we been" && current == "here before?" ->
                "Daha önce buraya gelmiş miydik?"
            previous == "want to take our relationship" &&
                current.matches(Regex("to the next level[.!?, ]*so[.!?…]*")) ->
                "İlişkimizi bir sonraki aşamaya taşımak istiyorum. O yüzden..."
            previous.startsWith("oh, uh, what was it you wanted to tell me yesterday") &&
                current == "when my dad and allen showed up?" ->
                "Dün babamla Allen geldiğinde bana ne söyleyecektin?"
            previous == "the kid has enough to deal with" &&
                current == "without me messing him up the way i did mark." ->
                "Ben de Mark'e yaptıklarımı ona yaşatmayayım."
            else -> null
        }
    }

    /** Gerçekten çevirmeye alınan altyazıdan öğrenir. */
    @Synchronized fun remember(acceptedSubtitle: String, nowMs: Long = System.currentTimeMillis()) {
        acceptedCount++
        val previousRecord = preceding[lastAccepted]
        preceding[acceptedSubtitle] = AcceptedBefore(lastAccepted, lastAcceptedAtMs,
            previousRecord?.text.orEmpty(), previousRecord?.timestampMs ?: 0L)
        lastAccepted = acceptedSubtitle
        lastAcceptedAtMs = nowMs
        if (paulEvidence.containsMatchIn(acceptedSubtitle)) lastPaulAt = acceptedCount
    }
}
