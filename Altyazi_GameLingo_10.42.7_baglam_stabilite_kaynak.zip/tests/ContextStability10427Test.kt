package com.example.altyazi

fun main() {
    var tests = 0
    fun equal(actual: String?, expected: String?) {
        check(actual == expected) { "got=<$actual> expected=<$expected>" }
        tests++
    }
    val a = DialogueContextRepair()
    a.remember("I risked my life out there", 1000L)
    a.remember("trying to win this war.", 1200L)
    equal(a.joinedTranslationInput("trying to win this war.", 1250L),
        "I risked my life out there trying to win this war.")
    equal(a.contextForTranslation("trying to win this war.", 1250L), "I risked my life out there")
    equal(a.contextForTranslation("some unrelated phrase", 1250L), "")
    val b = DialogueContextRepair()
    b.remember("I was just.", 1000L)
    b.remember("making things worse out there.", 1100L)
    equal(b.joinedTranslationInput("making things worse out there.", 1200L),
        "I was just making things worse out there.")
    val c = DialogueContextRepair()
    c.remember("I'm gonna have to go back out there", 1000L)
    c.remember("and fight them again, a-and not be here.", 1200L)
    equal(c.joinedTranslationInput("and fight them again, a-and not be here.", 1300L),
        "I'm gonna have to go back out there and fight them again, a-and not be here.")
    val d = DialogueContextRepair()
    d.remember("We finished the race.", 1000L)
    d.remember("and took the train.", 1200L)
    equal(d.joinedTranslationInput("and took the train.", 1300L), null)
    val e = DialogueContextRepair()
    e.remember("[Mark] The battle is over", 1000L)
    e.remember("and we can rest", 1100L)
    equal(e.joinedTranslationInput("and we can rest", 1150L), null)
    equal(e.contextForTranslation("and we can rest", 1150L), "") // stage/speaker text is excluded
    val f = DialogueContextRepair()
    f.remember("I need to go now", 1000L)
    f.remember("trying to make it home.", 1200L)
    equal(f.joinedTranslationInput("trying to make it home.", 10000L), null)
    equal(f.contextForTranslation("trying to make it home.", 20000L), "")
    val g = DialogueContextRepair()
    g.remember("[Eve] This is my choice", 1000L)
    g.remember("[Mark] Are you sure?", 1300L)
    equal(g.contextForTranslation("Are you sure?", 1400L), "")
    equal(TranslationQualityGate.check("Tell Oliver I miss him?", "Tell Oliver Onu özlüyor muyum?")?.name,
        "ENGLISH_FRAGMENT")
    equal(TranslationQualityGate.check("Just Nolan, please.", "Just Nolan, lütfen.")?.name,
        "ENGLISH_FRAGMENT")
    equal(TranslationQualityGate.check("Just Nolan, please.", "Nolan demen yeterli, lütfen.")?.name, null)
    equal(TranslationQualityGate.mustReject(TranslationQualityGate.Problem.ENGLISH_FRAGMENT).toString(), "true")
    val h = DialogueContextRepair()
    h.remember("Not...", 1000L)
    h.remember("be here.", 1200L)
    equal(h.joinedTranslationInput("be here.", 1300L), "Not be here.")
    equal(SubtitlePreparation.repair("Call the ship or the shuttle or what eve."),
        "Call the ship or the shuttle or whatever.")
    equal(SubtitlePreparation.repair("I don't know how long It be gone, So all the bills are on auto pay."),
        "I don't know how long I'll be gone, So all the bills are on auto pay.")
    equal(SourceAwareDialogueFix.correct("Jesus fucking Christ."), "Hassiktir be!")
    println("$tests/$tests GameLingo context stability regression checks PASS")
}
