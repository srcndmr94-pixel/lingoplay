import com.example.altyazi.SourceAwareDialogueFix as Fix
import com.example.altyazi.SoundTags

fun main() {
    var tests = 0
    fun expect(name: String, expected: String?, actual: String?) {
        check(actual == expected) { "$name: expected=$expected got=$actual" }
        tests++
    }
    expect("quietly cue", "[alçak sesle]", SoundTags.translate("[quietly]"))
    expect("softly cue", "[hafifçe]", SoundTags.translate("[softly]"))
    expect("quietly speech not consumed", null, SoundTags.translate("[quietly] Mark, I."))
    expect("Mark interrupted", "Mark, ben...", Fix.correct("Mark, I."))
    expect("Mark interrupted with ellipsis", "Mark, ben...", Fix.correct("Mark, I..."))
    expect("No invented speech", null, Fix.correct("Mark, I was hungry."))
    expect("Sound cue unaffected", "[iç çekiyor]", SoundTags.translate("[sighs]"))
    expect("Character not misclassified", null, SoundTags.translate("[Eve] Mark?"))
    println("$tests/$tests PASS GameLingo 10.42.6 cue regression")
}
