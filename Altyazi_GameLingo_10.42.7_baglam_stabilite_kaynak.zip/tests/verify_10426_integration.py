from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=r/'app/src/main/java/com/example/altyazi'
gradle=(r/'app/build.gradle.kts').read_text()
fix=(s/'OfflineFix.kt').read_text()
source=(s/'SourceAwareDialogueFix.kt').read_text()
service=(s/'CaptureService.kt').read_text()
checks={
    "correct release code": 'versionCode = 174' in gradle,
    "correct release name": 'versionName = "10.42.6-stage-repair"' in gradle,
    "same package id": 'applicationId = "com.example.altyazi"' in gradle,
    "DeepL prioritized": 'useDeepL' in service and 'opusAttempt(text)' in service,
    "quiet stage cue": '"quietly" to "alçak sesle"' in fix,
    "soft stage cue": '"softly" to "hafifçe"' in fix,
    "incomplete verified speech": '"mark, i" to "Mark, ben..."' in source,
    "speech fix after cue processing": 'SourceAwareDialogueFix.correct(text)?.let { return it }' in fix,
    "DeepL failure telemetry": 'DeepLCeviri.status()' in service,
    "model-clean feature retained": 'MODEL' in (s/'ModelSetup.kt').read_text().upper(),
    "API key opt in": 'prefs.deepLEnabled && deeplKey.isNotBlank()' in service,
}
for k, v in checks.items():
    if not v: raise AssertionError(k)
print(f"{len(checks)}/{len(checks)} 10.42.6 integration checks PASS")
