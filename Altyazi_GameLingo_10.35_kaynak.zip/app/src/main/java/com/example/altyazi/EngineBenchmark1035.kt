package com.example.altyazi

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 10.35 - Telefon uzerinde GERCEK motor karsilastirmasi.
 *
 * Sabit bilinen altyazi kestirmelerini, onarim katmanini ve ceviri hafizasini
 * KULLANMAZ: her motora ayni ham Ingilizce gonderilir. Turkce referanslar
 * sadece insanin raporu okurken degerlendirmesi icindir, motora verilmez.
 * Bu arac hicbir motoru otomatik kazanan ilan etmez; sadece olcum yapar.
 */
object EngineBenchmark1035 {
    data class Case(
        val source: String,
        val reference: String,
        val previous: List<String> = emptyList()
    )

    val cases: List<Case> = listOf(
        Case("Dude could be a cop for all we know.", "Bu adam polis bile olabilir, nereden bilelim?"),
        Case("I don't think so.", "Sanmıyorum.", listOf("Ever tell you about the fairground?")),
        Case("and get you both home as soon as possible.", "ve ikinizi de bir an önce evinize gönderebilelim.",
            listOf("But let's hope we can end this war quickly")),
        Case("Yeah, yeah. You gotta know when to get off, Jason.", "Ne zaman çekileceğini bilmelisin, Jason."),
        Case("Leave no one alive.", "Kimseyi sağ bırakmayın!"),
        Case("Our planetary defense network is back up.", "Gezegen savunma ağımız yeniden devrede."),
        Case("This is so fucked!", "Bu iş fena halde boktan!"),
        Case("He wants it on the quiet. He only wants one of you.", "Bu işin gizli kalmasını istiyor. Sadece birinizi istiyor."),
        Case("Well, Brian was quite the stud back in the day.", "Brian eskiden tam bir çapkındı."),
        Case("And I fucking jumped.", "Ben de atladım, amına koyayım."),
        Case("It started going faster and faster and it was getting harder to hold on.", "Gitgide hızlandı, tutunmak zorlaştı.")
    )

    data class Observation(val engine: String, val text: String?, val elapsedMs: Long, val error: String? = null)

    suspend fun run(context: Context, onProgress: suspend (String) -> Unit): String = withContext(Dispatchers.IO) {
        require(cases.isNotEmpty())
        val prefs = Prefs(context)
        val llm = LlmTranslate(context)
        val fast = FastTranslate()
        val start = SystemClock.elapsedRealtime()
        val boot = SystemClock.elapsedRealtime()
        val llmAvailable = try { llm.hasModel() && llm.prepare() } catch (_: Throwable) { false }
        val llmBootMs = SystemClock.elapsedRealtime() - boot
        val fastStart = SystemClock.elapsedRealtime()
        val fastAvailable = try { fast.prepare() } catch (_: Throwable) { false }
        val fastBootMs = SystemClock.elapsedRealtime() - fastStart
        val useGoogle = prefs.googleCeviri

        val out = StringBuilder()
        out.appendLine("GameLingo 10.35 - MODEL KARSILASTIRMA")
        out.appendLine("Cihaz: ${android.os.Build.MODEL} / Android ${android.os.Build.VERSION.RELEASE}")
        out.appendLine("Model: ${if (llmAvailable) llm.backendName else "YUKLENEMEDI: ${llm.lastError ?: "model yok"}"}")
        out.appendLine("E4B/E2B yukleme: ${llmBootMs} ms; ML Kit hazirlama: ${fastBootMs} ms")
        out.appendLine("Google (anahtarsiz, tercihe bagli): ${if (useGoogle) "ACIK" else "KAPALI"}")
        out.appendLine("Not: Referanslar modele gonderilmez. Sureler sadece ceviri suresidir; OCR/overlay dahil degildir.")
        out.appendLine("Not: Kayitli diyaloglar, uygulama ici onbellek ve sabit duzeltmeler devre disidir.")
        out.appendLine()
        val observations = mutableMapOf<String, MutableList<Observation>>()
        try {
            for ((i, case) in cases.withIndex()) {
                currentCoroutineContext().ensureActive()
                onProgress("${i + 1}/${cases.size} replik olculuyor")
                out.appendLine("--- ${i + 1}/${cases.size} ---")
                out.appendLine("EN: ${case.source}")
                if (case.previous.isNotEmpty()) out.appendLine("Baglam: ${case.previous.joinToString(" / ")}")
                out.appendLine("Hedef TR (insan kontrolu): ${case.reference}")

                suspend fun measure(label: String, action: suspend () -> String?): Observation {
                    currentCoroutineContext().ensureActive()
                    val t0 = SystemClock.elapsedRealtime()
                    return try {
                        val value = action()?.trim()?.takeIf { it.isNotBlank() }
                        Observation(label, value, SystemClock.elapsedRealtime() - t0,
                            if (value == null) "bos yanit" else null)
                    } catch (t: kotlinx.coroutines.CancellationException) {
                        throw t
                    } catch (t: Throwable) {
                        Observation(label, null, SystemClock.elapsedRealtime() - t0,
                            t.message ?: t.javaClass.simpleName)
                    }
                }

                val candidates = listOfNotNull(
                    if (fastAvailable) measure("ML Kit", { fast.translate(case.source) }) else null,
                    if (useGoogle) measure("Google", { GoogleCeviri.cevir(case.source, kullanHafiza = false) }) else null,
                    if (llmAvailable) measure(llm.backendName, {
                        llm.translate(case.source, case.previous, "Oyun", "",
                            discardIfStale = false, stillWanted = { true })
                    }) else null
                )
                for (o in candidates) {
                    observations.getOrPut(o.engine) { mutableListOf() }.add(o)
                    out.appendLine("${o.engine} [${o.elapsedMs} ms]: ${o.text ?: "BASARISIZ (${o.error ?: "bilinmiyor"})"}")
                    if (o.text != null) {
                        val risk = MeaningSafety.risk(case.source, o.text)
                        if (risk != null) out.appendLine("  ! ANLAM GUVENLIGI: $risk")
                    }
                }
                out.appendLine()
            }
        } finally {
            fast.close()
        }
        out.appendLine("=== TOPLAM ===")
        for ((label, results) in observations) {
            val successes = results.filter { it.text != null }
            val times = successes.map { it.elapsedMs }
            val stat = BenchmarkStats1035.summarize(times)
            out.appendLine("$label: ${successes.size}/${results.size} basarili, ortanca ${stat.median} ms, p90 ${stat.p90} ms, 500ms alti ${stat.under500}/${stat.count}")
        }
        out.appendLine("Olcum duvari suresi: ${SystemClock.elapsedRealtime() - start} ms")
        out.appendLine("Kaliteyi secmek icin EN/Hedef TR/motor ciktisini karsilastirin. Bu rapor otomatik kalite puani degildir.")
        val report = out.toString()
        File(context.filesDir, "GameLingo_model_test_10_35.txt").writeText(report)
        onProgress("Test bitti. Rapor hazir.")
        report
    }

    fun lastReport(context: Context): String? =
        File(context.filesDir, "GameLingo_model_test_10_35.txt").takeIf { it.exists() }?.readText()
}
