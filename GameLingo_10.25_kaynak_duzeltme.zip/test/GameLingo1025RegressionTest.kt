package com.example.altyazi

fun main() {
    check(Phrases.lookup("He should recover.") == "İyileşmesi bekleniyor")
    check(Phrases.lookup("He'll pull through.") == "Bunu atlatacak")
    check(Phrases.lookup("Months, most likely.") == "Muhtemelen aylar sürecek")
    check(Phrases.lookup("This is bullshit.") == "Bu saçmalık")
    check(Phrases.lookup("He'll pull through if he rests.") == null)
    check(SubtitlePreparation.repair("What is it? ls he getting better?") ==
        "What is it? Is he getting better?")
    check(SubtitlePreparation.repair("Is he getting better?") == "Is he getting better?")
    println("OK 10.25: exact phrase and contextual OCR regressions")
}
