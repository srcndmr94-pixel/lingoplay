# GameLingo 10.25 – hedefli çeviri doğruluğu

10.24 kaynak kodu temel alınmıştır. Google/Firefox/ML Kit motorları, kullanıcı ayarları ve APK yapılandırması değiştirilmedi.

- Oyun test kayıtlarında yanlış çevrildiği görülen dört tam İngilizce repliğe doğal Türkçe karşılık eklendi: “He should recover”, “He'll pull through”, “Months, most likely”, “This is bullshit”. Yalnız tam eşleşme geçerlidir; genel amaçlı yapay zekâ çevirisi değildir.
- “ls he getting better” OCR okuması, yalnız belirgin soru kalıbında “Is he getting better” olarak düzeltilir.
- Yeni Kotlin regresyon testi eklendi: `test/GameLingo1025RegressionTest.kt`.
- Kotlin testini derleyip çalıştırdık: geçti. Tam test paketi, APK derlemesi ve gerçek cihaz testi yapılmadı.

Not: Kopuk repliklerin genel olarak birleştirilmesi ve bütün çevirilerin doğal Türkçe olması bu küçük düzeltme ile garanti edilmez. Mevcut çalışan APK'yı silmeyin.
