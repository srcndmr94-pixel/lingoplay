#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/check_capture_service_start.py
K=$(command -v kotlinc)
LIB=$(cd "$(dirname "$(readlink -f "$K")")/../lib" && pwd)
COR="$LIB/kotlinx-coroutines-core-jvm.jar"
B=app/src/main/java/com/example/altyazi
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
sed 's/val sonSatirlar = ArrayDeque<String>()/val sonSatirlar = java.util.ArrayDeque<String>()/' "$B/OfflineFix.kt" > "$TMP/OfflineFixJvm.kt"
"$K" "$TMP/OfflineFixJvm.kt" test/jvm/SozlukJvmStub.kt "$B"/{Phrases.kt,SourceAwareDialogueFix.kt,Slang.kt,ProperNameSequence1039.kt,LiveSubtitleQuality10425.kt,MeaningSafety.kt,TranslationQualityGate.kt,OpusLiveAdmission.kt,SubtitlePreparation.kt,DialogueContextRepair.kt,SubtitleHoldPolicy.kt,SubtitleRetryGate.kt,LiveSource10434.kt} -cp "$COR" -d "$TMP/core.jar"
TEST_FILES=(test/{RealLog10431Test,SourceFlow10429Test,SpeakerContext10428Test,ContextQuality1022Test,ContextQuality1021Test,ThreeLineContext1032Test,DialogueContextTest,MeaningSafety1033Test,SoundTags1038Test}.kt test/jvm/{JoinedLive10431Test,OfflineFixSpan10430Test,StrongOnly10432Test,SubtitleHold10432Test}.kt)
TEST_FILES+=(test/jvm/Source10434Test.kt test/jvm/LiveFallback10433Test.kt test/jvm/SubtitleRetry10433Test.kt test/jvm/OpusLiveAdmissionTest.kt)
"$K" "${TEST_FILES[@]}" -cp "$TMP/core.jar:$COR" -d "$TMP/tests.jar"
passed=0; failed=0
for file in "${TEST_FILES[@]}"; do
    base=$(basename "${file%.kt}")
    package="com.example.altyazi."
    if [ "$base" = "ThreeLineContext1032Test" ] || [ "$base" = "MeaningSafety1033Test" ]; then package=""; fi
    if java -cp "$TMP/tests.jar:$TMP/core.jar:$COR:$LIB/kotlin-stdlib.jar" "${package}${base}Kt" > "$TMP/$base.out" 2>&1; then
        echo "PASS $base"; passed=$((passed+1))
    else
        echo "FAIL $base"; tail -10 "$TMP/$base.out" || true; failed=$((failed+1))
    fi
done
printf 'JVM groups: %s passed, %s failed\n' "$passed" "$failed"
[ "$failed" -eq 0 ]
