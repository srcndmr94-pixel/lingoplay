plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.altyazi"
    compileSdk = 35

    defaultConfig {
        // PAKET KİMLİĞİ: com.example.altyazi — namespace ile AYNI.
        //
        // Sonuç: her yeni sürüm telefondaki uygulamanın ÜSTÜNE kurulur.
        // Ayarlar, "Sözlüğüm" girdileri ve çeviri hafızası korunur; ikinci
        // bir simge çıkmaz. versionCode her sürümde arttığı ve imza sabit
        // olduğu için Android bunu güncelleme sayar.
        //
        // (Burada eskiden "eski uygulamanın yanına ayrı kurulsun" diyen bir
        // yorum vardı; kimlik namespace ile aynı olduğu için doğru değildi.
        // Ayrı kalması istenirse bu satır değiştirilmeli, örneğin
        // "com.example.altyazi.yeni" — o zaman iki simge olur ve yeni
        // uygulama boş ayarlarla başlar.)
        //
        // TV uygulaması ayrı kimlik kullanıyor (com.example.altyazi.tv),
        // bu yüzden telefon sürümüyle çakışmaz; ikisi yan yana durur.
        applicationId = "com.example.altyazi"
        minSdk = 31
        targetSdk = 34
        versionCode = 186
        versionName = "10.43.5-opus-uyari-fix"
        // Pixel 9 Pro: yalnız ARM64; gereksiz x86/armeabi kütüphanelerini paketleme.
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // Sabit imza: her derleme aynı anahtarla imzalanır, güncelleme eskisinin üstüne kurulur.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }


    buildFeatures {
        viewBinding = false
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("com.google.mlkit:text-recognition:16.0.0")


    // Direct on-device Marian OPUS-MT ONNX inference, model weights imported separately.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")
}
