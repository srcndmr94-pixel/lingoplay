package com.example.altyazi

/**
 * Cihazdaki tek cümlelik DeepL/OPUS/Google sonucunun bariz eksikleri.
 * Serbest kalite puanlaması değildir: sadece kayıtlarla doğrulanan kaybolan
 * içerik ve çevrilmeden kalan İngilizce kısaltmaları saptar.
 * Ham benchmark sonuçlarına uygulanmaz; canlı çeviri kapısında çalışır.
 */
object LiveSubtitleQuality10425 {
    enum class Defect { ENGLISH_RESIDUE, MISSING_DETAIL }

    // İngilizce yardımcı fiil kısaltmaları Türkçe altyazı içinde kalmamalı.
    // Tek başına "Mark", "Eve", "Cecil" gibi adları bu denetim etkilemez.
    private val contractions = Regex(
        """(?i)(?<![\p{L}])(?:isn['’]t|aren['’]t|wasn['’]t|weren['’]t|doesn['’]t|didn['’]t|couldn['’]t|wouldn['’]t|shouldn['’]t|what['’]s|who['’]s|you['’]re|they['’]re)(?![\p{L}])"""
    )

    private data class RequiredMeaning(val source: Regex, val turkish: Regex)

    // Kaynakta kesin bulunan anlam bağı ile Türkçedeki açık izini karşılaştır.
    // Bu diziler mümkünse YALNIZ eksik ikinci repliğe uygulanmalı.
    private val required = listOf(
        RequiredMeaning(
            Regex("""(?i)\bi['’]ll be back for dessert\b"""),
            Regex("""(?iu)(?:tatlı|dessert)""")
        ),
        RequiredMeaning(
            Regex("""(?i)\bhe['’]s just cautious\b"""),
            Regex("""(?iu)(?:temkin|tedbir|ihtiyat|dikkatli|sakın|içine kapanık)""")
        ),
        RequiredMeaning(
            Regex("""(?i)\bwhere['’]s our payment\b"""),
            Regex("""(?iu)(?:ödeme|ücret|paramız|para(?:mız)?|alacağımız)""")
        )
    )

    // An untranslated English verb/adverb followed by a name at the START
    // of an otherwise Turkish subtitle: "Tell Oliver ..." or "Just Nolan ...".
    // A proper name alone is never classified as an English fragment.
    private val englishOpening = Regex("""(?i)^(?:tell|just)\s+[A-Z][a-z]{2,25}(?=[ ,.!?]|$)""")

    fun defect(source: String, translated: String): Defect? {
        if (contractions.containsMatchIn(translated) || englishOpening.containsMatchIn(translated.trim()))
            return Defect.ENGLISH_RESIDUE
        for (rule in required) {
            if (rule.source.containsMatchIn(source) && !rule.turkish.containsMatchIn(translated))
                return Defect.MISSING_DETAIL
        }
        return null
    }
}
