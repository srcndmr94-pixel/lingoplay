package com.example.altyazi

/** Bounded retry of a failed subtitle, including a completely unchanged frame. */
class SubtitleRetryGate(private val delayMs: Long = 1500L, private val maxFailures: Int = 3) {
    private var source = ""
    private var failedAt = 0L
    private var failures = 0

    @Synchronized fun failed(text: String, now: Long) {
        failures = if (source == text) failures + 1 else 1
        source = text
        failedAt = now
    }

    @Synchronized fun canAttempt(text: String, now: Long): Boolean =
        source != text || (failures < maxFailures && now - failedAt >= delayMs)

    @Synchronized fun hasPending(now: Long): Boolean =
        source.isNotEmpty() && failures < maxFailures && now - failedAt >= delayMs

    /** A retry is the same event: do not append it to dialogue context again. */
    @Synchronized fun accepted(text: String): Boolean {
        if (source == text && failures > 0) return true
        clear()
        return false
    }

    @Synchronized fun succeeded(text: String) {
        if (source == text) clear()
    }

    @Synchronized fun clear() {
        source = ""
        failures = 0
    }
}
