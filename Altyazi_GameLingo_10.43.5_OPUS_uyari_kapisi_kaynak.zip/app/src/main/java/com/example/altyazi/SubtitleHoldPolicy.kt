package com.example.altyazi

/**
 * A small bounded pause for obviously incomplete source subtitles.
 * Not a language-model guess: fully punctuated sentences and stage cues
 * are never delayed. A later subtitle is still joined by DialogueContextRepair.
 */
object SubtitleHoldPolicy {
    private const val HOLD_MS = 140L
    private val negativeVerbList = Regex("(?i)\\b(?:will|would|shall|can|could|must)\\s+not\\b[^.!?]{1,120},\\s*[a-z]+$")
    private val unfinishedToken = Regex(
        "(?i)\\b(?:and|or|if|because|the|a|to|of|is|are|was|were|will|would|" +
            "could|should|can|with|when|that|as|not)\\s*$"
    )

    fun holdMillis(source: String): Long {
        val s = source.trim()
        if (s.length !in 5..200) return 0L
        if (s.startsWith("[") && s.endsWith("]")) return 0L
        if (s.last() in listOf('.', '!', '?', '…')) return 0L
        if (s.endsWith(',') || s.endsWith('—') || s.endsWith('-') ||
            unfinishedToken.containsMatchIn(s) || negativeVerbList.containsMatchIn(s)) return HOLD_MS
        return 0L
    }
}
