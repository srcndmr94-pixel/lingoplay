package com.example.altyazi

import android.content.Context

/** Eski TV köprüsünün çağrı imzasını korur; gerçek motor yalnızca OPUS-MT'dir. */
class LlmTranslate(context: Context) {
    private val ctx = context.applicationContext
    private val opus by lazy { OpusMtEngine(ctx) }
    val ready: Boolean get() = OpusModelPack.isInstalled(ctx)
    val backendName: String get() = "OPUS-MT"
    val lastError: String? get() = opus.lastError
    val lastWaitMs: Long get() = 0L
    val lastKurulumMs: Long get() = 0L
    val lastSicak: Boolean get() = false

    suspend fun translate(
        line: String,
        previous: List<String>,
        contentType: String,
        title: String,
        discardIfStale: Boolean = true,
        stillWanted: () -> Boolean
    ): String? {
        if (!stillWanted() || !ready) return null
        if (!opus.prepare()) return null
        if (!stillWanted()) return null
        return opus.translate(line)
    }
    fun hazirla() {}
    fun close() { opus.close() }
    companion object {
        const val loadState = "OPUS-MT"
        fun isLoading(): Boolean = false
        fun isReady(context: Context): Boolean = OpusModelPack.isInstalled(context)
        fun preload(context: Context) {}
        fun hasModel(context: Context): Boolean = OpusModelPack.isInstalled(context)
    }
}
