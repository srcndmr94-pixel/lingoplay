package com.example.altyazi

/** Eski hızlı çeviri yolu artık kapalı; OCR için ML Kit Text Recognition kalır. */
class FastTranslate {
    val ready: Boolean get() = false
    val lastError: String? get() = "Yalnız OPUS-MT kullanılıyor"
    suspend fun prepare(): Boolean = false
    suspend fun translate(text: String): String? = null
    fun close() {}
}
