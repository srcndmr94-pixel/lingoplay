package com.example.altyazi

object LiveSource10434 {
    private val title = Regex("""\b(Mrs|Mr|Ms)\.\s+(?=\p{Lu})""")
    fun hasTitle(text: String): Boolean = title.containsMatchIn(text)
    // Only residual English honorifics before a capitalized name are changed.
    fun titles(text: String): String = title.replace(text) {
        (if (it.groupValues[1] == "Mr") "Bay" else "Bayan") + " "
    }
}
