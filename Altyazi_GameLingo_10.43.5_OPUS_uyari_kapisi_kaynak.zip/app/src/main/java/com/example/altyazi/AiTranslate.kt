package com.example.altyazi

/** Eski internet yolu için derleme uyumluluğu; internetten çeviri yapmaz. */
class AiTranslate(private val prefs: Prefs) {
    val lastError: String? get() = "Çevrimiçi çeviri kaldırıldı"
    suspend fun translate(source: String): String? = null
    fun remember(english: String, turkish: String) {}
    companion object { fun devreyiAc() {} }
}
