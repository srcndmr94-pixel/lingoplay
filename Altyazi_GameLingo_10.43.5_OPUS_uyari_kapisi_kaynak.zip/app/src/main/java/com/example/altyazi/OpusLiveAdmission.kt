package com.example.altyazi

/**
 * First-stage acceptance for raw OPUS output.
 *
 * Do not reject a *repairable warning* before OfflineFix gets a chance to
 * restore profanity or retry missing clauses. Keep unsafe polarity changes,
 * untranslated output and mixed-English fragments blocked.
 */
object OpusLiveAdmission {
    fun allowed(source: String, output: String?): Boolean {
        if (output.isNullOrBlank() || source.trim().equals(output.trim(), ignoreCase = true)) return false
        return when (TranslationQualityGate.check(source, output)) {
            null,
            TranslationQualityGate.Problem.LOST_PROFANITY,
            TranslationQualityGate.Problem.MISSING_DETAIL,
            TranslationQualityGate.Problem.MISSING_QUESTION,
            TranslationQualityGate.Problem.LITERAL_IDIOM -> true
            else -> false
        }
    }
}
