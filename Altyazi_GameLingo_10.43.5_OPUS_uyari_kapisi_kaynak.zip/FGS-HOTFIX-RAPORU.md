# GameLingo 10.43.5 – Ön plan servisi çökmesi düzeltmesi

## Kanıt

Kullanıcının Pixel 9 Pro / Android 37 çökme kaydı:
`RemoteServiceException$ForegroundServiceDidNotStartInTimeException`.
`CaptureService.kt` içinde `startForegroundSafely()` tanımlıydı ancak hiçbir yerden çağrılmıyordu. `MainActivity` servis için `ContextCompat.startForegroundService(...)` çağırıyordu. Android ön plan bildirimini beklediği sürede alamayınca uygulamayı kapatıyordu.

## Değişiklik

- `CaptureService.onStartCommand(ACTION_START)` içinde, ekran izni (`getMediaProjection`) işlenmeden ve `startPipeline()` çağrılmadan önce `startForegroundSafely()` çağrılır.
- Başlatma başarısızsa hata `CrashLog`'a yazılır ve servis güvenli şekilde durdurulur.
- `versionCode`: 184 → 185; `versionName`: `10.43.5-fgs-fix`.
- OPUS, OCR, model, sözlük, diğer çeviri yolları ve altyazı kuralları değiştirilmedi.

## Doğrulama

- Kod sırasını inceleyen 8 statik kontrol: **PASS 8/8**.
- Aynı kontrollerin eski 10.43.5 kaynakta uygulanması: **beklenen FAIL** (eksik foreground çağrısı yakalandı).
- Mevcut Kotlin/JVM testleri: **PASS 16/16**.
- ZIP bütünlüğü kontrol edildi.
- **Android Gradle/APK derlemesi ve Pixel 9 Pro cihaz testi burada yapılmadı**. Bu nedenle diğer olası çökme nedenlerinin bulunmadığı garanti edilemez.

## GitHub Actions ile kurulum

1. ZIP dosyasını GitHub ana depo köküne, çıkarmadan yükleyin. Dosya adında `Altyazi` geçtiğini kontrol edin.
2. **Telefon APK** işinin `Kaynagi ac` logundaki `Kaynak:` satırında `Altyazi_GameLingo_10.43.5_FGS_hotfix_kaynak.zip` görünmeli.
3. APK başarıyla derlenince telefonun mevcut GameLingo uygulamasının **üzerine** kurun; verileri silmeyin. Yeni sürüm `10.43.5-fgs-fix` olarak görünmeli.
4. Ekran izni verip başlatınca zorunlu `Lingo çalışıyor` ön plan bildiriminin geldiğini kontrol edin.

Android referansı: https://developer.android.com/media/grow/media-projection
