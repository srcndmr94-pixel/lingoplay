package com.example.altyazi

fun main() {
    fun joined(first: String, second: String): String? {
        val d=DialogueContextRepair()
        d.remember(first, 1000L)
        d.remember(second, 1300L)
        return d.joinedTranslationInput(second, 1400L)
    }
    check(joined("[Thragg] There's nothing he", "or anyone else can do to stop us.") ==
        "[Thragg] There's nothing he or anyone else can do to stop us.")
    check(joined("It's, it's like there's this.", "bomb that's gonna go off somewhere") ==
        "It's, it's like there's this bomb that's gonna go off somewhere")
    check(joined("I'm not sure I'll be here", "when the meeting starts.") ==
        "I'm not sure I'll be here when the meeting starts.")
    check(joined("[Cecil] the view through the main screen is.", "really spectacular,") ==
        "[Cecil] the view through the main screen is really spectacular,")
    check(joined("[Thragg] There's nothing he", "[Cecil] or anyone else can do to stop us.") == null)
    check(joined("[birds chirping]", "and then we left") == null)
    check(joined("A complete sentence.", "and a different sentence.") == null)
    check(joined("Just hold on.", "when the meeting starts.") == null)
    check(joined("Wear your clothes.", "Walk your streets.") == null)
    val triple=DialogueContextRepair()
    triple.remember("[Nolan] the view through the main screen is.", 1000L)
    triple.remember("really spectacular,", 1200L)
    triple.remember("if you'd like to see it.", 1400L)
    check(triple.joinedTranslationInput("if you'd like to see it.", 1450L) ==
        "[Nolan] the view through the main screen is really spectacular, if you'd like to see it.")
    println("PASS: 10.42.9 source-flow 10 structural scenarios")
}
