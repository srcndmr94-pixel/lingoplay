package com.example.altyazi
fun main() {
    val wait = listOf(
        "We will not influence, affect, aid",
        "or endanger Earth in any way,",
        "[Thragg] There's nothing he or",
        "We will"
    )
    val instant = listOf(
        "The war is over.",
        "Leave no one alive!",
        "[birds chirping]",
        "We will live among you.",
        "And I fucking jumped."
    )
    wait.forEach { check(SubtitleHoldPolicy.holdMillis(it) == 140L) { "Should wait: $it" } }
    instant.forEach { check(SubtitleHoldPolicy.holdMillis(it) == 0L) { "Should not wait: $it" } }
    println("PASS 9/9 short incomplete-line hold/complete-line no-hold checks")
}
