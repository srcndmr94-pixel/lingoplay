package com.example.altyazi
object Sozluk { val hazir=false; fun icinde(@Suppress("UNUSED_PARAMETER") word:String)=false }
