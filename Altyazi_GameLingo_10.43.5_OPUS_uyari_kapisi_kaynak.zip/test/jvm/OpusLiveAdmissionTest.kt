package com.example.altyazi

import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    // Regression: a profanity warning is not the same as an unusable result.
    val source = "Yo, what the fuck?"
    val soft = "Ne oluyor?"
    check(TranslationQualityGate.check(source, soft) == TranslationQualityGate.Problem.LOST_PROFANITY)
    check(OpusLiveAdmission.allowed(source, soft))
    // The live translator, not the raw benchmark, restores the tone.
    OfflineFix.gucluFn = { "Ne oluyor?" }
    OfflineFix.strongOnlyLive = true
    val fixed = OfflineFix.translate(source) { null }
    check(fixed != null && fixed.contains("amına koyayım")) { "Profanity restoration failed: $fixed" }
    // An unmodified English sentence must never pass as Turkish.
    check(!OpusLiveAdmission.allowed("Hello everyone", "Hello everyone"))
    check(!OpusLiveAdmission.allowed("Hello everyone", ""))
    // These are not repairable tone/format warnings.
    check(!OpusLiveAdmission.allowed("I don't want to go there.", "Oraya gitmek istiyorum."))
    check(!OpusLiveAdmission.allowed("Please tell Oliver.", "Tell Oliver lütfen."))
    OfflineFix.gucluFn = null
    OfflineFix.strongOnlyLive = false
    println("PASS OpusLiveAdmissionTest")
}
