package com.example.altyazi
import kotlinx.coroutines.runBlocking
fun main() = runBlocking {
    fun accumulated(vararg parts: String): String {
        val context=DialogueContextRepair()
        parts.forEachIndexed { i, line -> context.remember(line, 1000L+i*300L) }
        return context.joinedTranslationInput(parts.last(), 1000L+parts.size*300L)
            ?: error("Not joined: ${parts.toList()}")
    }
    suspend fun verify(vararg parts: String) {
        val joined=accumulated(*parts)
        val calls=mutableListOf<String>()
        OfflineFix.gucluFn={ s -> calls += s; "Cümlenin bütünü çevrildi." }
        OfflineFix.clearCache()
        val result=OfflineFix.translate(joined) { null }
        check(calls.size == 1) { "Expected ONE engine request for '$joined', got $calls" }
        check(calls.single().equals(joined, ignoreCase=true)) { "Unexpected fragment: ${calls.single()}" }
        check(!result.isNullOrBlank())
        println("PASS full context: ${parts.joinToString(" | ")} -> 1 call")
    }
    verify("We will not influence, affect, aid", "or endanger Earth in any way,", "as long as we are undisturbed.")
    verify("and I know you will live up to the responsibility", "I have cursed you with.")
    verify("A perfected version of what almost extinguished their empire", "so long ago.")
    verify("only hesitated to use it because it may also strike down", "those with similar genetics.")
    OfflineFix.gucluFn = null
    println("PASS: 4 new joined English spans forwarded exactly once to real OfflineFix translator")
}
