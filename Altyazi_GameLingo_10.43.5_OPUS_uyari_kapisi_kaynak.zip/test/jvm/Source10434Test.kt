package com.example.altyazi
fun main() {
 check(ProperNameSequence1039.protectedStarts("Maybe Zak's right.").isEmpty())
 check(ProperNameSequence1039.protectedStarts("Jonathan Crane is here.").size == 2)
 check(LiveSource10434.hasTitle("Mr. P won't know what hit him."))
 check(!LiveSource10434.hasTitle("ch At be w As worthy"))
 check(LiveSource10434.titles("Bay ve Mrs. Wilkins.") == "Bay ve Bayan Wilkins.")
 check(LiveSource10434.titles("Mr. P geliyor.") == "Bay P geliyor.")
 check(SoundTags.repair("[Igiggles] Mercury's funny.").startsWith("[giggles]"))
 check(SoundTags.repair("[Igor] Hello.") == "[Igor] Hello.")
 check(SoundTags.translate("[soft exhale]") == "[hafifçe nefes veriyor]")
 check(SoundTags.translate("[dog barking in distance]") == "[uzaktan köpek havlaması]")
 println("PASS 10 source/name/sound regression checks")
}
