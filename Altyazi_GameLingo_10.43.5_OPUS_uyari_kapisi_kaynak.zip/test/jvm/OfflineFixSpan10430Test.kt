package com.example.altyazi
import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    var checks=0
    suspend fun verify(source: String, expected: String) {
        val calls=mutableListOf<String>()
        OfflineFix.gucluFn = { fragment ->
            calls += fragment
            "Bu cümlenin bütünü çevrildi."
        }
        OfflineFix.clearCache()
        val result = OfflineFix.translate(source) { null }
        check(calls.size==1) { "Expected one MT call for $source, got $calls and $result" }
        check(calls.single().replace('’','\'').equals(expected.replace('’','\''), ignoreCase=true)) {
            "Actual input: ${calls.single()}, expected: $expected"
        }
        check(!result.isNullOrBlank()) { "Empty live result: $source" }
        checks++
    }
    verify("We will live among you.","We will live among you.")
    verify("Wear your clothes.","Wear your clothes.")
    verify("Walk your streets.","Walk your streets.")
    verify("It's, it's like there's this bomb that's gonna go off somewhere", "It's, it's like there's this bomb that's gonna go off somewhere")
    verify("There's nothing he or anyone else can do to stop us.","There's nothing he or anyone else can do to stop us.")
    verify("Now, more than ever, we need strong leadership.","Now, more than ever, we need strong leadership.")
    verify("He wants it on the quiet. He only wants one of you.","He wants it on the quiet. He only wants one of you.")
    verify("The view through the main screen is really spectacular, if you'd like to see it.","The view through the main screen is really spectacular, if you'd like to see it.")
    // User-defined glossary is a deliberate override, not a bundled patch.
    var remoteCalled = false
    OfflineFix.setUserEntries("wear your clothes = Giysilerinizi giyiyoruz")
    OfflineFix.gucluFn = { remoteCalled=true; "Remote result" }
    val personal = OfflineFix.translate("Wear your clothes.") { null }
    check(!remoteCalled && personal?.contains("Giysilerinizi giyiyoruz") == true) {
        "User glossary was not respected: $personal"
    }
    OfflineFix.setUserEntries("")
    // Explicit bracketed speaker labels remain protected.
    val speakerCalls=mutableListOf<String>()
    OfflineFix.gucluFn = { fragment -> speakerCalls += fragment; "Merhaba." }
    val speaker = OfflineFix.translate("[Nolan] We're about to leave orbit.") { null }
    check(speaker?.startsWith("[Nolan]") == true && speakerCalls.size == 1)
    // If every strong engine fails, the supplied local fallback can still run.
    OfflineFix.gucluFn = { null }
    val local = OfflineFix.translate("A sentence we have not seen before.") { "Yerel çeviri" }
    check(!local.isNullOrBlank()) { "Fallback lost when strong engine failed" }
    // Stage cue must stay out of MT; otherwise it is misread as conversation.
    OfflineFix.gucluFn = { throw IllegalStateException("Cue cannot go to MT") }
    val cue=OfflineFix.translate("[birds chirping]") { null }
    check(!cue.isNullOrEmpty()) { "Stage cue was lost" }
    println("PASS: $checks real OfflineFix engine calls sent the full English span; 1 stage-cue isolation")
}
