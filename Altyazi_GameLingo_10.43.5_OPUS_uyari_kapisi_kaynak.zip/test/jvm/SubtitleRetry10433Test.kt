package com.example.altyazi

fun main() {
    val gate = SubtitleRetryGate()
    check(gate.canAttempt("A", 0))
    gate.failed("A", 100)
    check(!gate.canAttempt("A", 1599) && !gate.hasPending(1599))
    check(gate.canAttempt("A", 1600) && gate.hasPending(1600))
    check(gate.accepted("A")) // Retry must not become a second dialogue turn.
    check(gate.canAttempt("B", 101)) // A's failure cannot block a new subtitle.
    gate.failed("A", 1600)
    check(gate.canAttempt("A", 3100))
    gate.failed("A", 3100)
    check(!gate.canAttempt("A", 9000) && !gate.hasPending(9000))
    gate.succeeded("B") // An old unrelated completion cannot release A.
    check(!gate.canAttempt("A", 9001))
    gate.clear() // Same line reappearing after a blank scene is a fresh attempt.
    check(gate.canAttempt("A", 9001))
    gate.failed("A", 9100)
    gate.succeeded("A")
    check(!gate.hasPending(9999) && gate.canAttempt("A", 9101))
    gate.failed("A", 10000)
    check(!gate.accepted("B") && !gate.hasPending(12000))
    println("PASS retry bounds, unchanged-frame wakeup, context isolation, new subtitle, success/reset")
}
