package com.example.altyazi

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    val source = "The technicians are approaching the maintenance bay."
    OfflineFix.clearCache()
    OfflineFix.setUserEntries("")
    OfflineFix.strongOnlyLive = false
    var fallbackCalls = 0
    // OPUS warming up, or DeepL timing out, must not disable the local engine.
    OfflineFix.gucluFn = { null }
    val fallback = OfflineFix.translate(source) {
        fallbackCalls++
        "Teknisyenler bakım bölümüne yaklaşıyor."
    }
    check(fallback?.contains("Teknisyenler") == true) { "Fallback lost: $fallback" }
    check(fallbackCalls == 1)
    OfflineFix.gucluFn = { error("Remote unavailable") }
    check(OfflineFix.translate(source) { "Teknisyenler bakım bölümüne yaklaşıyor." } != null)
    OfflineFix.gucluFn = { "Teknisyenler bakım bölümüne yaklaşıyor." }
    check(OfflineFix.translate(source) { error("Working preferred engine must win") } != null)
    OfflineFix.gucluFn = { throw CancellationException("old subtitle") }
    var cancelled = false
    try { OfflineFix.translate(source) { error("Cancellation must not trigger fallback") } }
    catch (_: CancellationException) { cancelled = true }
    check(cancelled)
    OfflineFix.gucluFn = null
    println("PASS 4/4 warmup/failure fallback, preferred success, cancellation propagation")
}
