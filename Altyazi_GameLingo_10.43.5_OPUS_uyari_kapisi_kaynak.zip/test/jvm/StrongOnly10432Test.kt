package com.example.altyazi
import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    OfflineFix.clearCache()
    OfflineFix.setUserEntries("")
    val source = "The technicians are approaching the maintenance bay."
    var localCalls = 0
    var apiCalls = 0
    OfflineFix.strongOnlyLive = true
    OfflineFix.gucluFn = { apiCalls++; null }
    val failed = OfflineFix.translate(source) { localCalls++; "Yanlış yerel çeviri" }
    check(failed == null) { "Strong engines failed yet lower-quality text was displayed: $failed" }
    check(apiCalls == 1 && localCalls == 0) { "Silent fallback: api=$apiCalls local=$localCalls" }

    OfflineFix.gucluFn = { apiCalls++; "Tek parçada çevrildi." }
    val success = OfflineFix.translate(source) { localCalls++; "Yerel cevap" }
    check(success?.contains("Tek parçada çevrildi") == true) { "Strong engine result lost: $success" }
    check(localCalls == 0)

    OfflineFix.setUserEntries("$source = Teknisyenler bakım bölümüne yaklaşıyor")
    OfflineFix.gucluFn = { apiCalls++; error("Personal dictionary must win") }
    val user = OfflineFix.translate(source) { null }
    check(user?.contains("Teknisyenler bakım bölümüne yaklaşıyor") == true)
    OfflineFix.setUserEntries("")
    OfflineFix.gucluFn = null
    OfflineFix.strongOnlyLive = false
    println("PASS 3/3 strict DeepL/OPUS path, no weak silent fallback, personal glossary retained")
}
