package com.example.altyazi

fun main() {
    fun joined(vararg parts: String): String? {
        val ctx=DialogueContextRepair()
        parts.forEachIndexed { idx, v -> ctx.remember(v,1000L+idx*300L) }
        return ctx.joinedTranslationInput(parts.last(),1000L+parts.size*300L)
    }
    val checks = listOf(
        Pair(arrayOf("We will not influence, affect, aid", "or endanger Earth in any way,"),
            "We will not influence, affect, aid or endanger Earth in any way,"),
        Pair(arrayOf("We will not influence, affect, aid", "or endanger Earth in any way,", "as long as we are undisturbed."),
            "We will not influence, affect, aid or endanger Earth in any way, as long as we are undisturbed."),
        Pair(arrayOf("I believe with every fiber of my being", "that the universe will never be safe", "until all Viltrumite life is ended."),
            "I believe with every fiber of my being that the universe will never be safe until all Viltrumite life is ended."),
        Pair(arrayOf("and I know you will live up to the responsibility", "I have cursed you with."),
            "and I know you will live up to the responsibility I have cursed you with."),
        Pair(arrayOf("A perfected version of what almost extinguished their empire", "so long ago."),
            "A perfected version of what almost extinguished their empire so long ago."),
        Pair(arrayOf("only hesitated to use it because it may also strike down", "those with similar genetics."),
            "only hesitated to use it because it may also strike down those with similar genetics."),
        Pair(arrayOf("It is well-earned,", "and I know you will live up to the responsibility", "I have cursed you with."),
            "It is well-earned, and I know you will live up to the responsibility I have cursed you with."),
        Pair(arrayOf("[Thragg] There's nothing he", "or anyone else can do to stop us."),
            "[Thragg] There's nothing he or anyone else can do to stop us."),
        Pair(arrayOf("A complete sentence.", "but a new one, too."), null),
        Pair(arrayOf("[Thragg] There's nothing he", "[Nolan] or anyone else can do to stop us."), null),
        Pair(arrayOf("[birds chirping]", "and then we left."), null),
        Pair(arrayOf("We will not influence, affect, aid", "[Cecil] or endanger Earth in any way,"), null),
        Pair(arrayOf("A complete sentence.", "until we find them."), null),
        Pair(arrayOf("A perfected version of what almost extinguished their empire.", "so long ago."), null),
    )
    var n = 0
    for ((parts, target) in checks) {
        val actual=joined(*parts)
        println("${if (actual==target) "PASS" else "FAIL"} ${parts.joinToString(" | ")} => $actual")
        if (actual==target) n++
    }
    println("$n/${checks.size} success")
    check(n==checks.size)
}
