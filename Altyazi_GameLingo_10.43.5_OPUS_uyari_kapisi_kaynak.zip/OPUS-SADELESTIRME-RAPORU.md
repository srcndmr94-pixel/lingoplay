# GameLingo 10.43.5 — OPUS-MT sadeleştirme

## Değişiklikler
- **Tek canlı çeviri motoru OPUS-MT.** DeepL, Firefox (AIDL dahil), anahtarsız Google, Gemini/Anthropic, E2B/E4B ve model karşılaştırma motorları uygulama kodundan kaldırıldı.
- **Ayar ekranı sade:** OPUS-MT durum, model ZIP yükleme, model silme; çeviri bölgesi ve görünüm ayarları korunur. Eski motor kutuları `visibility=gone` ile saklanmadı; XML düğümleri ve kod referansları silindi.
- OPUS modeli belleğe yüklenmeden OCR döngüsü başlamaz. Model yoksa kullanıcıya açık uyarı verilir. Başarısız çeviriler yanlışlıkla başka motorla tamamlanmaz.
- TV çeviri köprüsünün eski E4B uyumluluk kodu OPUS-MT adaptörüyle değiştirildi. OPUS-MT dışında GPU LLM kütüphanesi kullanılmaz.
- Aynı boyut tekrar bildirildiğinde yeniden boyutlandırma tetiklenmez; başarısız işlem sonraki callback'te yeniden denenebilir.
- Pixel 9 Pro için ARM64 APK hedeflenir; ONNX Runtime ve ML Kit metin tanıma dışında çeviri motoru bağımlılığı yoktur.
- Eski şifreli DeepL anahtarı ve kullanımdan kalkmış servis ayarları ilk açılışta temizlenir. Kullanıcının kelime sözlüğü/çeviri geçmişi korunur.

## Testler
- OPUS/altyazı kalitesi için **16/16 Kotlin/JVM test grubu PASS** (OPUS-JVM-TEST-RESULTS.txt).
- Android arayüz XML'i ve manifest dosyaları ayrıştırıldı; kaldırılan ayar ID'lerine kaynak kodunda erişim kalmadığı kontrol edildi.
- Kaldırılan motor sınıflarının ve bağımlılıklarının ana kaynakta bulunmadığı kontrol edildi.
- **Android APK derlemesi ve gerçek Pixel 9 Pro testi yapılmadı.** Testler canlı doğruluk garantisi değildir.

## Kurulum
Bu ZIP doğrudan APK değildir. GitHub Actions'ta doğru ZIP'in seçildiğini `Kaynak:` satırından denetleyin. Sürüm `10.43.5-opus-sade` / `versionCode 184` olmalıdır. OPUS-MT modeli daha önce kurulmuşsa silmeyin. Debug imzası eski kurulumla uyumluluk amacıyla korunmuştur; genel dağıtımda imza güvenliği ayrıca düzenlenmelidir.
