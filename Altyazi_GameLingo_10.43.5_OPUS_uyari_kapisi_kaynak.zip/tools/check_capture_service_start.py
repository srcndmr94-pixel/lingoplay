#!/usr/bin/env python3
"""Static guard for the exact FGS startup bug in GameLingo 10.43.5.

Does not substitute for an Android build or a Pixel device test.
"""
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
src = (root / 'app/src/main/java/com/example/altyazi/CaptureService.kt').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')

start = src.index('            ACTION_START -> {')
end = src.index('            else -> {', start)
action_start = src[start:end]

checks = {
    'startForeground call in ACTION_START': 'startForegroundSafely()' in action_start,
    'foreground before getMediaProjection': action_start.find('startForegroundSafely()') >= 0 and action_start.find('startForegroundSafely()') < action_start.find('getMediaProjection(code, data)'),
    'foreground before overlay': action_start.find('startForegroundSafely()') >= 0 and action_start.find('startForegroundSafely()') < action_start.find('overlay.show()'),
    'foreground before startPipeline': action_start.find('startForegroundSafely()') >= 0 and action_start.find('startForegroundSafely()') < action_start.find('startPipeline()'),
    'foreground call guarded by exception handler': 'CrashLog.note(this, "ön plan ekran yakalama servisi", e)' in action_start and 'catch (e: Exception)' in action_start,
    'Android mediaProjection foreground type': 'FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION' in src,
    'service manifest type': 'android:foregroundServiceType="mediaProjection"' in manifest,
    'service permission manifest': 'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION' in manifest,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' ' + label)
if not all(checks.values()):
    sys.exit(1)
