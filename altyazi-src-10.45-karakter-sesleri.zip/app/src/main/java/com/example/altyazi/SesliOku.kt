package com.example.altyazi

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * SESLİ OKUMA — 10.43'te eklendi, 10.44'te ses seçimi geldi.
 *
 * Ekrana çıkan Türkçe çeviriyi telefonun Türkçe konuşma motoruyla okur.
 * Ücretsiz, anahtarsız, kota yok.
 *
 * BU DUBLAJ DEĞİL. Karakterlerin gerçek sesi klonlanmıyor; telefonda yüklü
 * Türkçe seslerden biri okuyor.
 *
 * 10.44 — ERKEK/KADIN AYRIMI:
 * Altyazıdaki konuşan adına bakıp ([KonusanCinsiyeti]) erkek ya da kadın
 * sesini seçer. Android'in `Voice` sınıfı cinsiyet bildirmediği için hangi
 * sesin erkek hangisinin kadın olduğunu kullanıcı ayarlardan DİNLEYEREK
 * seçer; burada yalnız seçilen ses uygulanır.
 *
 * Telefonda tek Türkçe ses varsa ayrım perdeyle yapılır: erkek biraz kalın,
 * kadın biraz ince. Klonlama değil ama iki karakter karışmaz.
 *
 * Tasarım kararları (10.43'ten):
 *  - BİRİKME YOK: yeni replik gelince okunan kesilir (QUEUE_FLUSH).
 *  - AYNI YAZI İKİ KEZ OKUNMAZ.
 *  - Motor hazır olmadan gelen replik bekletilir; yalnız en sonu okunur.
 */
class SesliOku(context: Context, private val log: (String) -> Unit = {}) {

    /** Ayarlarda listelenen bir Türkçe ses. */
    data class SesBilgi(
        val ad: String,
        val kalite: Int,
        val agGerekir: Boolean,
    ) {
        /** Kullanıcıya gösterilen satır. */
        val etiket: String
            get() {
                val k = when {
                    kalite >= 500 -> "çok yüksek kalite"
                    kalite >= 400 -> "yüksek kalite"
                    kalite >= 300 -> "orta kalite"
                    else -> "düşük kalite"
                }
                return if (agGerekir) "$ad · $k · internet ister" else "$ad · $k"
            }
    }

    private val app = context.applicationContext
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var tts: TextToSpeech? = null
    @Volatile private var hazir = false
    @Volatile private var kapandi = false

    /** Telefonda bulunan Türkçe sesler, kaliteden düşüğe sıralı. */
    @Volatile private var sesler: List<Voice> = emptyList()

    /** Şu an motora uygulanmış ses adı; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananSes: String? = null

    /** Şu an uygulanmış perde; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananTon: Float = -1f

    /** Şu an uygulanmış konuşma hızı; gereksiz yere değiştirilmesin. */
    @Volatile private var uygulananHiz: Float = -1f

    /** Karakter adlarını tonlara dağıtır (bkz. KarakterSesi.kt). */
    private val dagitici = KarakterSesi.Dagitici()

    /** En son okunan yazının sade hali; aynısı tekrar okunmasın. */
    @Volatile private var sonOkunan = ""

    /** Motor açılırken gelen replik ve konuşanı; yalnız en sonu saklanır. */
    @Volatile private var bekleyen: Pair<String, String?>? = null

    /** Taban konuşma hızı, 0.5 - 2.0. Karakter tonu bunun üstüne biner. */
    @Volatile
    var hiz: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            uygulananHiz = -1f   // bir sonraki okumada yeniden uygulansın
        }

    /** Taban ses tonu, 0.5 - 2.0. Cinsiyet ayrımı bunun üstüne eklenir. */
    @Volatile
    var ton: Float = 1.0f
        set(v) {
            field = v.coerceIn(0.5f, 2.0f)
            uygulananTon = -1f   // bir sonraki okumada yeniden uygulansın
        }

    /** Baştaki konuşan adı okunmasın mı? (prefs.showSpeaker) */
    @Volatile
    var adiAtla: Boolean = true

    /** Erkek/kadın ayrımı yapılsın mı? */
    @Volatile
    var cinsiyetAyrimi: Boolean = true

    /**
     * Her karaktere ayrı ton verilsin mi?
     *
     * Kapalıyken tüm erkekler tek tonla, tüm kadınlar tek tonla okunur
     * (10.44 davranışı). Açıkken iki erkek karşılıklı konuşsa bile
     * birbirinden ayrılır.
     */
    @Volatile
    var karakterAyrimi: Boolean = true

    /** Ayarlardan seçilen erkek sesinin adı; boşsa en iyi ses kullanılır. */
    @Volatile
    var erkekSesAdi: String = ""

    /** Ayarlardan seçilen kadın sesinin adı; boşsa en iyi ses kullanılır. */
    @Volatile
    var kadinSesAdi: String = ""

    /**
     * Motoru açar. [onDurum] en çok bir kez, ana iş parçacığında çağrılır:
     * (çalışıyor mu, kullanıcıya gösterilecek açıklama).
     */
    fun baslat(onDurum: ((Boolean, String) -> Unit)? = null) {
        if (tts != null || kapandi) return
        try {
            tts = TextToSpeech(app, TextToSpeech.OnInitListener { status ->
                motorAcildi(status, onDurum)
            })
        } catch (t: Throwable) {
            log("SESLI OKUMA: motor kurulamadi (${t.javaClass.simpleName}: ${t.message})")
            bildir(onDurum, false, "Konuşma motoru başlatılamadı.")
        }
    }

    private fun motorAcildi(status: Int, onDurum: ((Boolean, String) -> Unit)?) {
        if (kapandi) return
        if (status != TextToSpeech.SUCCESS) {
            log("SESLI OKUMA: motor acilamadi (status=$status)")
            bildir(onDurum, false, "Telefonda çalışan bir konuşma motoru bulunamadı.")
            return
        }
        val motor = tts
        if (motor == null) {
            log("SESLI OKUMA: motor acilirken kapatildi")
            return
        }
        val sonuc = try {
            motor.setLanguage(TR)
        } catch (t: Throwable) {
            log("SESLI OKUMA: dil ayarlanamadi (${t.javaClass.simpleName})")
            TextToSpeech.LANG_NOT_SUPPORTED
        }
        val turkceVar = sonuc == TextToSpeech.LANG_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
            sonuc == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE
        if (!turkceVar) {
            log("SESLI OKUMA: Turkce ses yok (sonuc=$sonuc)")
            bildir(
                onDurum, false,
                "Türkçe ses paketi yüklü değil. Telefon Ayarları ▸ Erişilebilirlik ▸ " +
                    "Metin okuma bölümünden Türkçe sesi indirin."
            )
            return
        }
        sesleriTopla(motor)
        uygulananSes = null
        uygulananTon = -1f
        uygulananHiz = -1f
        hazir = true
        log("SESLI OKUMA: hazir · ${sesler.size} Turkce ses")
        bildir(onDurum, true, durumYazisi())
        val sira = bekleyen
        bekleyen = null
        if (sira != null) oku(sira.first, sira.second)
    }

    /**
     * Telefondaki Türkçe sesleri toplar, kaliteden düşüğe sıralar.
     * İnternet isteyen sesler listeye girer ama sona konur: uygulamanın
     * amacı internetsiz çalışmak.
     */
    private fun sesleriTopla(motor: TextToSpeech) {
        sesler = try {
            val hepsi = motor.voices ?: emptySet<Voice>()
            hepsi.filter { v ->
                try {
                    v.locale != null && v.locale.language.equals("tr", ignoreCase = true)
                } catch (_: Throwable) {
                    false
                }
            }.sortedWith(
                compareBy<Voice> { if (it.isNetworkConnectionRequired) 1 else 0 }
                    .thenByDescending { it.quality }
                    .thenBy { it.name }
            )
        } catch (t: Throwable) {
            log("SESLI OKUMA: ses listesi alinamadi (${t.javaClass.simpleName})")
            emptyList()
        }
        for (v in sesler) log("SESLI OKUMA: ses · ${v.name} · kalite=${v.quality} · ag=${v.isNetworkConnectionRequired}")
    }

    private fun durumYazisi(): String {
        if (sesler.isEmpty()) return "Türkçe ses hazır (motor ayrı ses listesi vermiyor)."
        val enIyi = sesler.first()
        val kalite = if (enIyi.quality >= 400) "yüksek kaliteli" else "standart"
        return "${sesler.size} Türkçe ses bulundu; en iyisi $kalite."
    }

    /** Ayarlar ekranı için: bulunan Türkçe sesler. */
    fun bulunanSesler(): List<SesBilgi> = sesler.map {
        SesBilgi(it.name, it.quality, it.isNetworkConnectionRequired)
    }

    fun hazirMi(): Boolean = hazir

    private fun bildir(onDurum: ((Boolean, String) -> Unit)?, ok: Boolean, mesaj: String) {
        if (onDurum == null) return
        ui.post { onDurum(ok, mesaj) }
    }

    /**
     * Çeviriyi okur. Okunmakta olan replik KESİLİR.
     * [konusan] altyazıdaki konuşan adı; ses seçimi buna göre yapılır.
     */
    fun oku(metin: String?, konusan: String? = null) {
        if (kapandi) return
        val temiz = temizle(metin, adiAtla) ?: return
        if (!hazir) {
            bekleyen = temiz to konusan
            return
        }
        val sade = sadeBicim(temiz)
        if (sade.isEmpty()) return
        if (sade == sonOkunan) return
        sonOkunan = sade
        val motor = tts ?: return

        val cinsiyet = if (cinsiyetAyrimi) KonusanCinsiyeti.tahmin(konusan)
        else KonusanCinsiyeti.BILINMIYOR
        sesiUygula(motor, cinsiyet, konusan)

        try {
            motor.speak(temiz, TextToSpeech.QUEUE_FLUSH, null, "gl-" + System.nanoTime())
        } catch (t: Throwable) {
            log("SESLI OKUMA: okunamadi (${t.javaClass.simpleName})")
        }
    }

    /**
     * Konuşanın cinsiyetine göre sesi ve perdeyi ayarlar.
     *
     * İKİ AYRI SES VARSA ses değiştirilir, perdeye dokunulmaz.
     * TEK SES VARSA (ya da ikisi için aynı ses seçilmişse) ayrım perdeyle
     * yapılır: erkek kalın, kadın ince. Cinsiyet bilinmiyorsa taban perde.
     */
    private fun sesiUygula(motor: TextToSpeech, cinsiyet: Int, konusan: String?) {
        val secilen = etkinSes(cinsiyet)
        if (secilen != null && secilen.name != uygulananSes) {
            try {
                motor.voice = secilen
                uygulananSes = secilen.name
            } catch (t: Throwable) {
                log("SESLI OKUMA: ses uygulanamadi (${t.javaClass.simpleName})")
            }
        }

        // ETKİN seslere bakılır, seçilen adlara değil: erkek için ses
        // seçilmiş ama kadın boş bırakılmışsa kadın da en iyi sese düşer;
        // o ses erkeğinkinden farklıysa ayrım zaten vardır.
        val ayriSesVar = etkinSes(KonusanCinsiyeti.ERKEK)?.name !=
            etkinSes(KonusanCinsiyeti.KADIN)?.name

        // Karakter tonu: iki erkek karşılıklı konuşsa bile ayrışsın.
        // Kapalıysa havuzun sabit "normal" tonu kullanılır.
        val kt = if (karakterAyrimi) dagitici.ton(konusan, cinsiyet, ayriSesVar)
        else KarakterSesi.varsayilan(cinsiyet, ayriSesVar)

        uygulaPerde((ton * kt.perde).coerceIn(0.5f, 2.0f), motor)
        uygulaHiz((hiz * kt.hiz).coerceIn(0.5f, 2.0f), motor)
    }

    private fun uygulaPerde(hedef: Float, motor: TextToSpeech) {
        if (yaklasikEsit(hedef, uygulananTon)) return
        try {
            motor.setPitch(hedef)
            uygulananTon = hedef
        } catch (_: Throwable) {
        }
    }

    private fun uygulaHiz(hedef: Float, motor: TextToSpeech) {
        if (yaklasikEsit(hedef, uygulananHiz)) return
        try {
            motor.setSpeechRate(hedef)
            uygulananHiz = hedef
        } catch (_: Throwable) {
        }
    }

    /**
     * Bu cinsiyet için gerçekten kullanılacak ses.
     * Seçim yapılmamışsa ya da seçilen ses artık yoksa en iyi sese düşer.
     */
    private fun etkinSes(cinsiyet: Int): Voice? {
        val istenen = when (cinsiyet) {
            KonusanCinsiyeti.ERKEK -> erkekSesAdi
            KonusanCinsiyeti.KADIN -> kadinSesAdi
            else -> ""
        }
        return sesBul(istenen) ?: sesler.firstOrNull()
    }

    /** Perde zaten uygulanmışsa motora tekrar yazmayalım. */
    private fun yaklasikEsit(a: Float, b: Float): Boolean =
        (if (a > b) a - b else b - a) < 0.001f

    private fun sesBul(ad: String?): Voice? {
        if (ad.isNullOrBlank()) return null
        return sesler.firstOrNull { it.name == ad }
    }

    /** Okumayı anında keser. */
    fun sus() {
        bekleyen = null
        sonOkunan = ""
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    /** Motoru kapatır. Bundan sonra bu nesne kullanılmaz. */
    fun kapat() {
        kapandi = true
        hazir = false
        bekleyen = null
        dagitici.unut()
        val motor = tts
        tts = null
        try {
            motor?.stop()
            motor?.shutdown()
        } catch (_: Throwable) {
        }
    }

    companion object {

        private val TR = Locale("tr", "TR")

        /** "James: Gel buraya." -> "Gel buraya." */
        private val KONUSAN =
            Regex("^\\p{Lu}[\\p{L}.'\\-]{1,19}(\\s\\p{Lu}[\\p{L}.'\\-]{1,19})?\\s*:\\s+")

        private val SATIR_SONU = Regex("[\\r\\n]+")
        private val COK_BOSLUK = Regex("\\s{2,}")

        /** Okunmayacak satırlar: uyarı, durum ve okunacak harf içermeyenler. */
        fun okunurMu(metin: String?): Boolean {
            if (metin.isNullOrBlank()) return false
            val t = metin.trim()
            if (t.startsWith("⚠")) return false
            if (t.startsWith("GameLingo")) return false
            return temizle(t, false) != null
        }

        /**
         * Ekrandaki yazıyı sese uygun hale getirir: turkuaz noktayı ve fazla
         * boşlukları atar, [adAt] ise baştaki konuşan adını da atar.
         * Okunacak bir şey kalmazsa null.
         *
         * [adAt] NEDEN SEÇİME BAĞLI: "Dikkat: arkanda!" cümlesinin de başı
         * büyük harfli kelime + iki nokta. Ad atma her zaman açık olsa
         * "Dikkat" yutulurdu. Ad öneki yalnız "Konuşanı göster" ayarı açıkken
         * ekleniyor, bu yüzden ad atma da yalnız o ayar açıkken çalışır.
         */
        fun temizle(metin: String?, adAt: Boolean): String? {
            if (metin.isNullOrBlank()) return null
            var t = metin.trim()
            if (t.startsWith("⚠") || t.startsWith("GameLingo")) return null
            t = t.replace("●", " ")
            if (adAt) t = KONUSAN.replace(t, "")
            t = SATIR_SONU.replace(t, " ")
            t = COK_BOSLUK.replace(t, " ").trim()
            if (!t.any { it.isLetter() }) return null
            return t
        }

        /** Karşılaştırma için sade biçim: küçük harf, yalnız harf ve rakam. */
        fun sadeBicim(metin: String): String =
            metin.lowercase(TR).filter { it.isLetterOrDigit() }
    }
}
