package com.example.altyazi

import java.util.Locale

/**
 * KARAKTER SESLERİ — 10.45
 *
 * Sorun: erkek/kadın ayrımı tek başına yetmiyor. İki erkek karşılıklı
 * konuşunca ikisi de aynı sesle çıkıyor ve kim konuşuyor anlaşılmıyor.
 *
 * Çözüm: her cinsiyet için DÖRT ton var. Perde ve konuşma hızı birlikte
 * değişiyor — derin ton aynı zamanda yavaş, ince ton aynı zamanda hızlı.
 * Kulak bunu yaş farkı olarak duyuyor: derin+yavaş yaşlı, ince+hızlı genç.
 *
 * DÜRÜST SINIR: uygulama kimin yaşlı olduğunu BİLMİYOR. İsimden yaş
 * çıkmaz. Yaptığı şey karakterleri birbirinden ayırmak; "bu karakter
 * yaşlı" iddiası değil. Tonlar yalnız ayırt edici olsun diye bu aralıkta.
 *
 * Seslerin kendisi değişmiyor: kullanıcı ayarlardan erkek ve kadın sesini
 * seçiyor, buradaki tonlar o seçilen sesin üstüne biniyor. Böylece
 * kullanıcının seçimi korunuyor.
 */
object KarakterSesi {

    /**
     * Bir karakter tonu. [perde] ve [hiz], kullanıcının taban ayarlarıyla
     * ÇARPILIR; yani kullanıcı tonu kalınlaştırırsa hepsi kalınlaşır.
     */
    data class Ton(
        val perde: Float,
        val hiz: Float,
        val etiket: String,
        /**
         * Adsız replikte ve karakter ayrımı kapalıyken kullanılan ton.
         * Her havuzda tam bir tane işaretli. Sıra numarasıyla seçmek
         * yanıltıcıydı: "1" erkek havuzunda "olgun"a denk geliyordu.
         */
        val varsayilan: Boolean = false,
    )

    /** Erkek tonları: derinden inceye, yavaştan hızlıya. */
    private val ERKEK = listOf(
        Ton(0.72f, 0.90f, "derin ve ağır"),
        Ton(0.82f, 0.97f, "olgun"),
        Ton(0.90f, 1.00f, "normal", varsayilan = true),
        Ton(0.98f, 1.06f, "genç"),
    )

    /** Kadın tonları. */
    private val KADIN = listOf(
        Ton(1.02f, 0.92f, "olgun ve ağır"),
        Ton(1.12f, 0.99f, "olgun"),
        Ton(1.22f, 1.03f, "normal", varsayilan = true),
        Ton(1.32f, 1.08f, "genç"),
    )

    /**
     * Cinsiyeti bilinmeyen karakterler. Taban sesin çevresinde dar bir
     * aralık: yanlış cinsiyette okuyormuş gibi durmasın, ama iki bilinmeyen
     * karakter yine de ayrışsın.
     */
    private val NOTR = listOf(
        Ton(0.88f, 0.97f, "kalın"),
        Ton(0.96f, 1.00f, "normal", varsayilan = true),
        Ton(1.06f, 1.02f, "ince"),
        Ton(1.14f, 1.05f, "daha ince"),
    )

    /**
     * Kullanılacak ton havuzu.
     *
     * [notr] = erkek ve kadın için GERÇEKTEN farklı iki ses seçilebilmiş
     * demektir; cinsiyeti sesin kendisi taşıdığı için perdeye yüklenmeye
     * gerek yok ve dar nötr havuz kullanılır. Yalnız tek ses varsa geniş
     * cinsiyet havuzları devreye girer: perde hem cinsiyeti hem karakteri
     * ayırmak zorundadır.
     */
    fun havuz(cinsiyet: Int, notr: Boolean = false): List<Ton> = when {
        notr -> NOTR
        cinsiyet == KonusanCinsiyeti.ERKEK -> ERKEK
        cinsiyet == KonusanCinsiyeti.KADIN -> KADIN
        else -> NOTR
    }

    /**
     * Karakter adlarını tonlara dağıtır.
     *
     * KALICI: bir ad hangi tonu aldıysa oturum boyunca onu kullanır.
     * Tercih edilen yuva adın özüt değerinden (hash) bulunur, böylece aynı
     * karakter çoğu oturumda aynı tonla konuşur. O yuva BAŞKA bir ada
     * verilmişse bir sonraki boş yuvaya kayar: aynı sahnedeki iki karakter
     * asla aynı tonu paylaşmaz (havuz dolana kadar).
     */
    class Dagitici {

        /** "cinsiyet|ad" -> ton sırası. */
        private val atanan = HashMap<String, Int>()

        /** "cinsiyet|sıra" -> ad. Yuvanın kimde olduğunu tutar. */
        private val yuvalar = HashMap<String, String>()

        /** Bu ad için ton. Ad yoksa havuzun "normal" tonu döner. */
        fun ton(ad: String?, cinsiyet: Int, notr: Boolean = false): Ton {
            val havuz = havuz(cinsiyet, notr)
            val anahtar = adAnahtari(ad) ?: return varsayilan(cinsiyet, notr)
            val tam = "$cinsiyet|$anahtar"
            atanan[tam]?.let { return havuz[it] }

            // Tercih edilen yuva adın özüt değerinden: aynı karakter çoğu
            // oturumda aynı tonu alır. Yuva doluysa ileri doğru kayılır;
            // havuz tamamen doluysa tercih edilen yuvada kalınır (dörtten
            // fazla karakterde ton paylaşımı kaçınılmaz).
            val tercih = Math.floorMod(anahtar.hashCode(), havuz.size)
            var sira = tercih
            for (i in havuz.indices) {
                val aday = (tercih + i) % havuz.size
                if (yuvalar["$cinsiyet|$aday"] == null) {
                    sira = aday
                    break
                }
            }
            yuvalar["$cinsiyet|$sira"] = anahtar
            atanan[tam] = sira
            return havuz[sira]
        }

        /** Bu ada atanmış ton sırası (test ve kayıt için). */
        fun sira(ad: String?, cinsiyet: Int): Int {
            val anahtar = adAnahtari(ad) ?: return varsayilanSira(cinsiyet)
            return atanan["$cinsiyet|$anahtar"] ?: varsayilanSira(cinsiyet)
        }

        /** Kaç karaktere ton verilmiş. */
        fun karakterSayisi(): Int = atanan.size

        /** Çeviri durunca unutulur; yeni oyunda dağıtım baştan yapılır. */
        fun unut() {
            atanan.clear()
            yuvalar.clear()
        }
    }

    /** Bu havuzun varsayılan tonu: adsız replikte ve karakter ayrımı kapalıyken. */
    fun varsayilan(cinsiyet: Int, notr: Boolean = false): Ton {
        val h = havuz(cinsiyet, notr)
        return h.firstOrNull { it.varsayilan } ?: h[h.size / 2]
    }

    /** Varsayılan tonun havuzdaki sırası. */
    fun varsayilanSira(cinsiyet: Int, notr: Boolean = false): Int {
        val h = havuz(cinsiyet, notr)
        val i = h.indexOfFirst { it.varsayilan }
        return if (i < 0) h.size / 2 else i
    }

    /**
     * Adı karşılaştırılabilir hale getirir: "JASON", "Jason" ve "jason"
     * aynı karakter sayılsın. Türkçe küçültme tuzağı için iki yerelden
     * ROOT seçildi; burada eşleşme değil yalnız teklik önemli.
     */
    private fun adAnahtari(ad: String?): String? {
        if (ad.isNullOrBlank()) return null
        val t = ad.trim().trim('.', ',', '!', '?', '"', '\'')
            .substringBefore(' ')
            .lowercase(Locale.ROOT)
        return if (t.isEmpty()) null else t
    }
}
