package org.json
class JSONArray(val source: String) {
    fun optJSONArray(index: Int): JSONArray? = null
    fun length(): Int = 0
    fun opt(index: Int): Any? = null
}
