package com.example.altyazi

/**
 * Güvenli oturum-içi isim onarımı. Yalnız kabul edilen altyazılar hatırlanır.
 * "Pout's" ancak yakın geçmişte "Paul" adı açık bağlamda geçerse "Paul's" olur.
 * Kanıt yoksa metin değiştirilmez. Yeni ağ isteği/çeviri gecikmesi yoktur.
 */
class DialogueContextRepair {
    private var acceptedCount = 0
    private var lastPaulAt = -1
    private var lastAccepted = ""
    // Kaynak -> hemen önce kabul edilen altyazı. Asenkron çeviri gelince de
    // doğru önceki satırı kullanmak için kabul anında kaydedilir.
    private data class AcceptedBefore(val text: String, val timestampMs: Long, val earlier: String = "", val earlierAtMs: Long = 0L)
    private val preceding = object : LinkedHashMap<String, AcceptedBefore>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, AcceptedBefore>?): Boolean = size > 32
    }
    private var lastAcceptedAtMs = 0L
    private val incompleteEnding = Regex(
        "(?i)\\b(?:a|an|the|of|for|to|from|with|without|about|by|at|in|on|as|than|" +
            "because|if|when|while|and|but|or|that|which|who|whose|" +
            "am|is|are|was|were|have|has|had|do|does|did|will|would|can|could|should)\\s*$"
    )
    private val sentenceEnding = Regex("[.!?…][\"'’)]*$")

    /**
     * Açıkça yarım bırakılan iki satırı tek çeviri girdisine dönüştürür.
     * Farklı konuşmacı, ses etiketi, cümle sonu veya eski sahne birleştirilmez.
     * Çıktı yalnızca çeviri girdisidir; kaynak altyazının kimliği değişmez.
     */
    @Synchronized fun joinedTranslationInput(source: String, nowMs: Long = System.currentTimeMillis()): String? {
        val before = preceding[source] ?: return null
        if (nowMs < before.timestampMs || nowMs - before.timestampMs > 7_000L) return null
        val previous = before.text.trim()
        val current = source.trim()
        if (previous.length !in 10..140 || current.length !in 7..130 ||
            previous.length + current.length > 190) return null
        if (previous.equals(current, ignoreCase = true)) return null
        if (previous.any { it == '[' || it == ']' || it == ':' } ||
            current.any { it == '[' || it == ']' || it == ':' }) return null
        if (sentenceEnding.containsMatchIn(previous)) return null
        if (current.firstOrNull()?.isLowerCase() != true) return null
        val evidentlyIncomplete = previous.endsWith(',') || previous.endsWith('—') ||
            previous.endsWith('-') || incompleteEnding.containsMatchIn(previous)
        val earlierIncomplete = before.earlier.trim().let { e ->
            e.isNotEmpty() && !sentenceEnding.containsMatchIn(e) &&
                (e.endsWith(',') || e.endsWith('-') || incompleteEnding.containsMatchIn(e))
        }
        if (!evidentlyIncomplete && !(earlierIncomplete && !sentenceEnding.containsMatchIn(previous))) return null
        // If the previous line was itself a continuation, include its opener.
        // This fixes three-screen sentences without translating the final clause alone.
        val earlier = before.earlier.trim()
        if (earlier.length in 10..130 && nowMs >= before.earlierAtMs &&
            before.timestampMs - before.earlierAtMs in 0..7_000L &&
            earlier.length + previous.length + current.length <= 220 &&
            earlier.none { it == '[' || it == ']' || it == ':' } &&
            !sentenceEnding.containsMatchIn(earlier) &&
            (earlier.endsWith(',') || earlier.endsWith('-') ||
                incompleteEnding.containsMatchIn(earlier)) &&
            previous.firstOrNull()?.isLowerCase() == true) {
            return "$earlier $previous $current"
        }
        return "$previous $current"
    }
    private val paulEvidence = Regex("\\b(?:with\\s+Paul|about\\s+this\\s+Paul\\s+guy|Paul\\s+is)\\b")
    private val likelyPoutName = Regex("\\bPout(?=['’]s\\b)")

    @Synchronized fun reset() {
        acceptedCount = 0
        lastPaulAt = -1
        lastAccepted = ""
        lastAcceptedAtMs = 0L
        preceding.clear()
    }

    /** Saf işlem: aynı kare birden çok kez okunsa da geçmişi ilerletmez. */
    @Synchronized fun repair(text: String): String {
        if (lastPaulAt == -1 || acceptedCount - lastPaulAt > 40) return text
        return likelyPoutName.replace(text, "Paul")
    }

    /**
     * Yalnız anlamı açık, arka arkaya gelen KOPUK replikler için ikinci
     * altyazının tamamını doğal Türkçeye çevirir. Tahmin yok; eşleşme yoksa
     * Google/Firefox hattına aynen bırakılır. Ağ çağrısı / gecikme eklemez.
     * Hangi önceki repliğe ait olduğu kabul ANINDA sabitlenir.
     */
    @Synchronized fun contextualTranslation(source: String): String? {
        val previous = preceding[source]?.text?.lowercase()?.trim() ?: return null
        val current = source.lowercase().trim()
        return when {
            // "...back in the day" ardından "Was?!" zaman vurgusudur.
            current.matches(Regex("was[?!]+")) &&
                Regex("\\bback in the day[.!?]*$").containsMatchIn(previous) ->
                "Eskiden mi?!"
            previous == "have we been" && current == "here before?" ->
                "Daha önce buraya gelmiş miydik?"
            previous == "want to take our relationship" &&
                current.matches(Regex("to the next level[.!?, ]*so[.!?…]*")) ->
                "İlişkimizi bir sonraki aşamaya taşımak istiyorum. O yüzden..."
            previous.startsWith("oh, uh, what was it you wanted to tell me yesterday") &&
                current == "when my dad and allen showed up?" ->
                "Dün babamla Allen geldiğinde bana ne söyleyecektin?"
            previous == "the kid has enough to deal with" &&
                current == "without me messing him up the way i did mark." ->
                "Ben de Mark'e yaptıklarımı ona yaşatmayayım."
            else -> null
        }
    }

    /** Gerçekten çevirmeye alınan altyazıdan öğrenir. */
    @Synchronized fun remember(acceptedSubtitle: String, nowMs: Long = System.currentTimeMillis()) {
        acceptedCount++
        val previousRecord = preceding[lastAccepted]
        preceding[acceptedSubtitle] = AcceptedBefore(lastAccepted, lastAcceptedAtMs,
            previousRecord?.text.orEmpty(), previousRecord?.timestampMs ?: 0L)
        lastAccepted = acceptedSubtitle
        lastAcceptedAtMs = nowMs
        if (paulEvidence.containsMatchIn(acceptedSubtitle)) lastPaulAt = acceptedCount
    }
}
