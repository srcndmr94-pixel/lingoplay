package com.example.altyazi
class Prefs {
    companion object {
        const val BICIM_HIZLI = 0
        const val BICIM_DENGELI = 1
        const val BICIM_DOGRU = 2
        const val MODE_INSTANT = 0
        const val MODE_AI = 1
    }
}
