GameLingo 10.24 kaynak ZIP'i. APK DEĞİLDİR.
- 10.23'ün altyazı bölgesi ayarı ve derleme hatası düzeltmesi korunur.
- Google HTTP 429 sonrası istekleri sınırlar.
- Google kullanılamazken oluşan yedek çevirileri kalıcı hafızaya yazmaz.
- Test notları: GUNCELLEME-NOTU-10.24.md
APK derlemesi/cihaz testi yapılmamıştır. Eski APK'yi silmeyin.
