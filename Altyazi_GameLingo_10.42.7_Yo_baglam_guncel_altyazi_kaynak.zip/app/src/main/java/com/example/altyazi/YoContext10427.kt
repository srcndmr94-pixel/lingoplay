package com.example.altyazi

/**
 * "Yo" bir hitaptır; tek başına küfür değildir. Türkçede zorunlu "lan" yoktur.
 * Küfür varsa bu sınıf küfür onarımı yapmaz, asıl çeviriyi korur.
 * Yeni selamlama dayatmak yerine yalnız kaynakta olmayan sert hitapları temizler.
 */
object YoContext10427 {
    private val heyYoSource = Regex("(?i)^hey[,!]?\\s+yo\\b")
    private val repeatedHey = Regex("(?i)^hey[,!.\\s]+hey\\b")
    private val yoStart = Regex("(?i)^yo+\\b")
    private val yoExclamation = Regex("(?i)^yo+\\s*!")
    private val hardEnglish = Regex("(?i)\\b(fuck\\w*|shit\\w*|bitch\\w*|motherfuck\\w*|asshole\\w*|cunt\\w*|bastard\\w*|damn\\w*)\\b")
    private val genericGreeting = Regex("(?i)^(?:hey|selam)\\b[\\s,!.…]*")
    private val hasTurkishLan = Regex("(?i)\\b(lan|ulan)\\b")
    private val addedHarshStart = Regex("(?i)^(?:lan|ulan)\\b([\\s,!.…]*)")
    private val addedHarshEnd = Regex("(?i)\\s+(?:lan|ulan)([?.!]*)$")

    fun startsWithYo(source: String): Boolean {
        val s = source.trimStart(' ', '-', '–', '\"', '\'')
        return yoStart.containsMatchIn(s)
    }

    fun correct(source: String, translated: String): String {
        val current = translated.trim()
        // "Hey, yo, Ray!" must not become "Hey, hey, Ray!".
        if (heyYoSource.containsMatchIn(source.trimStart()))
            return repeatedHey.replaceFirst(current, "Hey")
        if (!startsWithYo(source)) return translated
        if (hardEnglish.containsMatchIn(source)) {
            // The swear is already rendered by "lan"; avoid stacking "Hey" onto it.
            val greeting = genericGreeting.find(current)
            if (greeting != null) {
                val tail = current.substring(greeting.value.length).trimStart()
                if (hasTurkishLan.containsMatchIn(tail))
                    return tail.replaceFirstChar { it.uppercaseChar() }
            }
            return current  // Keep actual profanity; never strip it as an unwanted Yo.
        }
        val match = addedHarshStart.find(current)
        if (match != null) {
            val rest = current.substring(match.value.length).trimStart()
            if (rest.isEmpty()) return "Hey!"
            val natural = rest.replaceFirstChar { it.uppercaseChar() }
            // "Yo!" güçlü dikkat çekmedir, "Yo," ise cümleye eklenmesi şart olmayan hitap.
            return if (yoExclamation.containsMatchIn(source.trimStart())) "Hey, ${natural.replaceFirstChar { it.lowercaseChar() }}" else natural
        }
        return addedHarshEnd.replace(current) { it.groupValues[1] }
    }
}
