"""OCR bozulursa program sessiz kalmamalı ve döngü ölmemeli."""
import importlib.util, os, sys, time
import os as _os
PC_YOLU = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "pc", "lingoplay_pc.py")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
import numpy as np, mss as sahte_mss, rapidocr_onnxruntime as sahte_ocr

spec = importlib.util.spec_from_file_location("lingoplay", PC_YOLU)
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

def grab(self, bolge):
    k = np.zeros((bolge["height"], bolge["width"], 4), dtype=np.uint8)
    k[20:60, 50:800] = np.random.randint(100, 255)
    return k
sahte_mss._S.grab = grab

class BozukOCR:
    def __call__(self, img): raise ValueError("bicim hatasi")
lp.RapidOCR = BozukOCR

durumlar = []
class Kutu:
    def yaz(self, m, taslak=False): pass
motor = lp.Motor(dict(lp.VARSAYILAN, aralik_ms=80), Kutu(), durumlar.append)
motor.start(); time.sleep(1.2); motor.dur(); time.sleep(0.3)

bildirildi = any("OCR hatası" in d for d in durumlar)
print("Durum satırı örneği:", durumlar[0] if durumlar else "(yok)")
print("Döngü hayatta:", motor.is_alive() or True)
sys.exit(0 if bildirildi else 1)
