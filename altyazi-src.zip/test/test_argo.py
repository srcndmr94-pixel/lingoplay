"""
Sokak argosu: "Y'all tryna smoke?" sigara değil.

Kullanıcının 11 Kasım kaydında uyuşturucu köşesi sahnesi vardı. Hem taslak
hem yapay zekâ "smoke"u sigara sandı:
    taslak: Hey, naber? Hepiniz sigara içmeye mi çalışıyorsunuz?
    YZ:     Selam, ne var ne yok? Sigara mı yakacaksınız?
Sahnede "tryna smoke" ot/mal içmek demek. Ayrıca "y'all" ÇOĞUL; taslak
"biliyor musun" diye tekil çeviriyordu.

Testin ikinci yarısı gerçek cümlelerin bozulmadığını doğruluyor: "Smoke rose
from the chimney" ya da "I want to go home" değişmemeli.
"""

import os
import re
import sys

KAYNAK = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main",
                      "java", "com", "example", "altyazi", "Slang.kt")
metin = open(KAYNAK, encoding="utf-8").read()

hata = []


def bekle(kosul, mesaj):
    if not kosul:
        hata.append(mesaj)


blok = re.search(r"rewrites: List<Pair<Regex, String>> = listOf\((.*?)\n\s*\)\.map",
                 metin, re.S)
if not blok:
    print("rewrites listesi bulunamadi")
    sys.exit(1)

KURALLAR = [(d, k) for d, k in re.findall(r'"((?:[^"\\]|\\.)*)" to "((?:[^"\\]|\\.)*)"',
                                          blok.group(1))]
bekle(len(KURALLAR) >= 20, f"kural sayisi dustu: {len(KURALLAR)}")

# "tryna smoke" genel "tryna"dan ONCE gelmeli, yoksa "trying to smoke" olur.
_sira = [i for i, (d, _) in enumerate(KURALLAR) if "tryna" in d]
bekle(len(_sira) >= 2 and "smoke" in KURALLAR[_sira[0]][0],
      "tryna smoke kurali genel tryna'dan sonra kalmis")


def normalize(t):
    for desen, karsilik in KURALLAR:
        d = desen.replace("\\\\", "\\")

        def _f(m, k=karsilik):
            r = k
            for g, deger in enumerate(m.groups(), 1):
                if deger is not None:
                    r = r.replace(f"${g}", deger)
            if m.group(0)[:1].isupper() and r:
                r = r[0].upper() + r[1:]
            return r

        t = re.sub(d, _f, t, flags=re.IGNORECASE)
    return t


DUZELMELI = [
    ("Yo, what's up? Y'all tryna smoke?", "Yo, what's up? You all looking to buy weed?"),
    ("No. Y'all know Boobie?", "No. You all know Boobie?"),
    ("Nah. Whatchu want?", "Nah. What do you want?"),
    ("Boobie, huh? Yeah, he ain't here, though.", "Boobie, huh? Yeah, he is not here, though."),
    ("I ain't going.", "I am not going."),
    ("They ain't here.", "They are not here."),
    ("Aight, hold up.", "Alright, hold up."),
    ("Eh, fo sho.", "Eh, for sure."),
    ("I'm gonna go.", "I'm going to go."),
    ("You wanna come?", "You want to come?"),
]
for giris, beklenen in DUZELMELI:
    cikti = normalize(giris)
    if cikti != beklenen:
        hata.append(f"argo duzelmedi: {giris!r} -> {cikti!r} (beklenen {beklenen!r})")

BOZULMAMALI = [
    "The wall is tall.",
    "I want to go home.",
    "He is not here.",
    "Smoke rose from the chimney.",
    "Alright then.",
    "We got a lot to do.",
]
for giris in BOZULMAMALI:
    cikti = normalize(giris)
    if cikti != giris:
        hata.append(f"gercek cumle bozuldu: {giris!r} -> {cikti!r}")

# Yapay zekaya giden ipuclari
IPUCU = ["tryna smoke", "y'?all", "crackhead", "bruh", "the block"]
for p in IPUCU:
    if not re.search(p, metin):
        hata.append(f"yapay zeka ipucu yok: {p}")

if hata:
    print("Argo testi DÜŞTÜ:")
    for h in hata:
        print("  ✗", h)
    sys.exit(1)

print(f"Argo testi geçti ({len(KURALLAR)} kural, {len(DUZELMELI)} düzeltme, "
      f"{len(BOZULMAMALI)} koruma).")
