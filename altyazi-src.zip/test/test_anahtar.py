"""Gömülü anahtar gerçekten geliyor mu?"""
import importlib.util, os, sys, json, tempfile
import os as _os
PC_YOLU = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "pc", "lingoplay_pc.py")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
spec = importlib.util.spec_from_file_location("lingoplay", PC_YOLU)
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

hata = []
def kontrol(ad, kosul, ek=""):
    print(("  ✓ " if kosul else "  ✗ ") + ad + ("" if kosul else f"  {ek}"))
    if not kosul: hata.append(ad)

# Sürüm numarası her değişiklikte artıyor; biçimi doğru olsun yeter.
import re as _re
kontrol("sürüm numarası geçerli", bool(_re.fullmatch(r"\d+\.\d+", lp.SURUM)), lp.SURUM)
kontrol("gömülü anahtar kasıtlı boş", lp.GOMULU_ANAHTAR == "", lp.GOMULU_ANAHTAR[:8])

# ayar dosyası yokmuş gibi
lp.CONFIG_PATH = os.path.join(tempfile.mkdtemp(), "yok.json")
a = lp.ayarlari_yukle()
kontrol("ayar dosyası yokken çökmüyor", isinstance(a.get("api_key"), str))

# ayar dosyası var ama anahtar boş
yol = os.path.join(tempfile.mkdtemp(), "ayar.json")
json.dump({"api_key": "", "oyun": "X"}, open(yol, "w"))
lp.CONFIG_PATH = yol
a2 = lp.ayarlari_yukle()
kontrol("boş kayıt boş kalıyor", a2["api_key"] == "", a2["api_key"])
kontrol("diğer ayarlar korunuyor", a2["oyun"] == "X")

# kullanıcı kendi anahtarını yazmışsa ona dokunulmuyor
json.dump({"api_key": "AIzaKENDI"}, open(yol, "w"))
a3 = lp.ayarlari_yukle()
kontrol("kullanıcının anahtarı eziliyor mu (ezilmemeli)", a3["api_key"] == "AIzaKENDI", a3["api_key"])

# çevirmen anahtarı görüyor mu
# Anahtar yokken kullanıcıya ne yapacağını söylemeli
c = lp.Cevirmen(dict(lp.VARSAYILAN, api_key=""))
c.cevir("Hello.")
kontrol("anahtar yokken yol gösteriyor",
        "aistudio" in (c.son_hata or "").lower(), c.son_hata)

# Hata kodları anlaşılır Türkçeye çevriliyor mu
kontrol("401 → yeni anahtar al", "yeni anahtar" in lp.hata_turkce(401, "").lower())
kontrol("429 → kota", "kota" in lp.hata_turkce(429, "").lower())
kontrol("404 → model", "model" in lp.hata_turkce(404, "").lower())

sys.exit(1 if hata else 0)
