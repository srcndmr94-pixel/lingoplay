"""
Kotlin'de "taşıma sırasında unutulan parametre" hatasını derlemeden önce yakalar.

Geniş bir denetim yanlış alarm üretiyor, o yüzden tek bir hata türüne
odaklanıyoruz: bir fonksiyon, BAŞKA bir fonksiyonun parametresi olan ama
kendisinde tanımlı olmayan bir ismi kullanıyorsa uyarıyoruz. Kodu bölüp
taşırken yapılan hata tam olarak budur ve derlemeyi durdurur.
"""

import os
import re
import sys

KOK = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "java")

FUN_BASI = re.compile(
    r"^[ \t]*(?:(?:private|public|internal|protected|override|suspend|inline|open)\s+)*"
    r"fun\s+(?:<[^>]+>\s*)?(\w+)\s*\(",
    re.M,
)


def temizle(kod):
    kod = re.sub(r"//[^\n]*", "", kod)
    kod = re.sub(r"/\*.*?\*/", "", kod, flags=re.S)
    kod = re.sub(r'"""(?:.|\n)*?"""', '""', kod)
    kod = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', kod)
    return kod


def eslesen_kapanis(metin, acilis, ac, kapa):
    derinlik = 0
    for j in range(acilis, len(metin)):
        if metin[j] == ac:
            derinlik += 1
        elif metin[j] == kapa:
            derinlik -= 1
            if derinlik == 0:
                return j
    return len(metin) - 1


def fonksiyonlari_cikar(kod):
    """[(ad, parametre kümesi, gövde)] döndürür."""
    sonuc = []
    for m in FUN_BASI.finditer(kod):
        ad = m.group(1)
        acilis = kod.index("(", m.start())
        kapanis = eslesen_kapanis(kod, acilis, "(", ")")
        par = set(re.findall(r"(\w+)\s*:", kod[acilis + 1:kapanis]))

        govde_basi = kod.find("{", kapanis)
        esittir = kod.find("=", kapanis)
        if govde_basi == -1 or (esittir != -1 and esittir < govde_basi):
            # tek satırlık gövde: = ile başlar
            satir_sonu = kod.find("\n\n", kapanis)
            govde = kod[kapanis:satir_sonu if satir_sonu != -1 else len(kod)]
        else:
            son = eslesen_kapanis(kod, govde_basi, "{", "}")
            govde = kod[govde_basi + 1:son]
        sonuc.append((ad, par, govde))
    return sonuc


def yerel_isimler(govde):
    isimler = set()
    isimler |= set(re.findall(r"\b(?:val|var)\s+(\w+)", govde))
    isimler |= set(re.findall(r"\bcatch\s*\(\s*(\w+)\s*:", govde))
    isimler |= set(re.findall(r"\bfor\s*\(\s*(\w+)\s+in", govde))
    # for ((a, b) in ...) ve { a, b -> } gibi çoklu tanımlar
    for kalip in (r"\(\s*\((\w+)\s*,\s*(\w+)\)", r"\{\s*(\w+)\s*,\s*(\w+)\s*->"):
        for ikili in re.findall(kalip, govde):
            isimler |= set(ikili)
    isimler |= set(re.findall(r"\{\s*(\w+)\s*->", govde))
    # gövde içindeki iç içe fonksiyonların parametreleri de burada tanımlıdır
    for ic in re.finditer(r"\bfun\s+\w+\s*\(([^)]*)\)", govde):
        isimler |= set(re.findall(r"(\w+)\s*:", ic.group(1)))
    isimler |= set(re.findall(r"\bval\s*\((\w+)\s*,\s*(\w+)\)", govde) and
                   [x for t in re.findall(r"\bval\s*\((\w+)\s*,\s*(\w+)\)", govde) for x in t])
    return isimler


def denetle(yol):
    kod = temizle(open(yol, encoding="utf-8").read())
    sinif_uyeleri = set(re.findall(r"^\s*(?:private |)(?:@Volatile\s+)?(?:val|var|const val)\s+(\w+)",
                                   kod, re.M))
    fonksiyonlar = fonksiyonlari_cikar(kod)

    # Tüm parametre isimleri havuzu: bunlar "taşınabilir" isimlerdir.
    tum_parametreler = set()
    for _, par, _ in fonksiyonlar:
        tum_parametreler |= par

    sorunlar = []
    for ad, par, govde in fonksiyonlar:
        tanimli = par | yerel_isimler(govde) | sinif_uyeleri
        # yalnızca başka fonksiyonun parametresi olan isimleri kontrol et
        supheli = tum_parametreler - tanimli
        for isim in sorted(supheli):
            # nokta olmadan, tek başına kullanılıyor mu
            # adlandırılmış argüman (fonk(x = 1)) kullanım sayılmaz
            kullanim = re.search(rf"(?<![\w.]){re.escape(isim)}(?![\w])\s*(?!=[^=])", govde)
            adlandirilmis = re.search(rf"[(,]\s*{re.escape(isim)}\s*=[^=]", govde)
            if kullanim and not adlandirilmis:
                sorunlar.append((ad, isim))
    return sorunlar


def bloklari_cikar(kod):
    """Örtülü alıcılı blokların içini siler."""
    kalipler = [r"\.apply\s*\{", r"\.also\s*\{", r"\.run\s*\{",
                r"\.let\s*\{", r"\.use\s*\{", r"object\s*:[^{]*\{",
                r"\bwith\s*\([^)]*\)\s*\{"]
    degisti = True
    while degisti:
        degisti = False
        for kalip in kalipler:
            m = re.search(kalip, kod)
            if not m:
                continue
            acilis = kod.index("{", m.start())
            kapanis = eslesen_kapanis(kod, acilis, "{", "}")
            kod = kod[:m.start()] + " " + kod[kapanis + 1:]
            degisti = True
            break
    return kod


def cagri_denetle(yol):
    """Tanımlanmamış fonksiyonların çağrılmasını yakalar."""
    ham = open(yol, encoding="utf-8").read()
    tum_kod = temizle(ham)
    tum_fonksiyonlar = set(re.findall(r"\bfun\s+(\w+)", tum_kod))
    kod = tum_kod

    # apply/run/also/let/use blokları ve object ifadeleri içindeki çağrılarda
    # alıcı örtülüdür (textView.apply { setTextColor(...) }); bunları çıkarıyoruz
    # yoksa her Android çağrısı yanlışlıkla "tanımsız" görünür.
    kod = bloklari_cikar(kod)

    tanimli = tum_fonksiyonlar
    tanimli |= set(re.findall(r"\b(?:val|var)\s+(\w+)", tum_kod))
    tanimli |= set(re.findall(r"\b(?:class|object|enum class|interface)\s+(\w+)", tum_kod))

    # this.xxx(...) ya da sade xxx(...) biçiminde, nokta olmadan yapılan çağrılar
    cagrilar = set(re.findall(r"(?<![\w.])([a-z]\w*)\s*\(", kod))

    # Kotlin/Android'in hazır fonksiyonları: tanımlı saymamız gerekenler
    hazir = {
        "listOf", "setOf", "mapOf", "arrayOf", "mutableListOf", "mutableMapOf",
        "emptyList", "emptySet", "emptyMap", "buildMap", "intArrayOf",
        "minOf", "maxOf", "require", "check", "error", "println", "print",
        "launch", "delay", "withContext", "runBlocking", "async", "await",
        "suspendCancellableCoroutine", "measureTimeMillis", "lazy", "run",
        "let", "also", "apply", "takeIf", "takeUnless", "repeat", "with",
        "synchronized", "arrayOfNulls", "booleanArrayOf", "byteArrayOf",
        "if", "when", "while", "for", "catch", "return", "throw", "super",
        "this", "it", "intent", "resources", "startActivity", "startService",
        "stopSelf", "stopForeground", "startForeground", "getSystemService",
        "registerForActivityResult", "findViewById", "setContentView",
        "runOnUiThread", "requestPermissions", "moveTaskToBack", "post",
        "toString", "trim", "take", "format", "valueOf", "joinToString",
        "contains", "startsWith", "endsWith", "replace", "split", "indexOf",
        "substring", "lowercase", "uppercase", "firstOrNull", "ifBlank",
        "coerceIn", "coerceAtLeast", "coerceAtMost", "copyOf", "abs",
        "arraycopy", "currentTimeMillis", "sleep", "max", "min", "sqrt",
        # property accessor'ları ve örtülü alıcılı yaygın çağrılar
        "get", "set", "put", "append", "add", "remove", "clear", "close",
        "val", "var", "fun", "init",
        # Activity / View / Service'ten miras alinan hazir fonksiyonlar
        "finish", "invalidate", "postInvalidate", "onTouchEvent",
        "performClick", "requestLayout", "constructor", "setOnTouchListener",
        "setOnClickListener", "setContentView", "getContext", "getWidth",
        "getHeight", "drawRect", "drawCircle", "drawText", "drawRoundRect",
        "contains", "coerceIn", "coerceAtLeast", "coerceAtMost", "isEmpty",
        "isNotEmpty", "indices", "listOf", "first", "second",
    }

    sorunlar = []
    for ad in sorted(cagrilar - tanimli - hazir):
        if len(ad) <= 2:
            continue
        # tanımlıysa ve import edilmişse atla
        if re.search(rf"import .*\b{re.escape(ad)}\b", ham):
            continue
        # sınıf adı gibi büyük harfle başlıyorsa atla (yukarıda filtrelendi)
        sorunlar.append(ad)
    return sorunlar


def main():
    toplam = []
    for dizin, _, dosyalar in os.walk(KOK):
        for d in sorted(dosyalar):
            if d.endswith(".kt"):
                yol = os.path.join(dizin, d)
                for fonk, isim in denetle(yol):
                    toplam.append(f"{d} → fun {fonk}() içinde tanımsız olabilir: {isim}")
                for ad in cagri_denetle(yol):
                    toplam.append(f"{d} → tanımlı olmayan fonksiyon çağrısı: {ad}()")

    if toplam:
        print("Olası tanımsız parametreler:")
        for satir in sorted(set(toplam)):
            print("  ✗", satir)
        return 1
    print("Kotlin parametre denetimi temiz.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
