"""
Kullanıcının 6 Kasım 22:17 kaydındaki dört sorunu sınar.

  1. Konuşan adı iki nokta olmadan başa yapışıyor:
       "D-don't come any closer!"  /  "Old Man Gen D-don't come any closer!"
     İki ayrı satır sanılıp üst üste çevriliyordu.
  2. Tek basamaklı OCR çöpü ("1 remember", "g0od") doğru YZ çevirisini
     "sayı düştü" diye reddettiriyordu.
  3. "Press O to throw..." tuş uyarısı altyazı sanılıyordu.
  4. "Now all LCàndo Refollo M hehindwomand" gibi çöp okumalar çevriliyordu.
"""

import gzip
import os
import re
import sys

KOK = os.path.dirname(__file__)
APP = os.path.join(KOK, "..", "app", "src", "main")
KAYNAK = os.path.join(APP, "java", "com", "example", "altyazi")

yakala = open(os.path.join(KAYNAK, "CaptureService.kt"), encoding="utf-8").read()
koruma = open(os.path.join(KAYNAK, "AiGuard.kt"), encoding="utf-8").read()
ocr = open(os.path.join(KAYNAK, "OcrSozluk.kt"), encoding="utf-8").read()

hata = []


def bekle(kosul, mesaj):
    if not kosul:
        hata.append(mesaj)


# --------------------------------------------- 1) adı iki nokta olmadan

bekle("fun adEkliMi" in yakala, "adEkliMi yok")
bekle("adEkliMi(a, b)" in yakala, "adEkliMi similar() icinde cagrilmiyor")

TR = str.maketrans("ışğüöçâîû", "isguocaiu")


def normalize(s):
    return "".join(c for c in s.lower().translate(TR) if c.isalnum())


def ad_ekli_mi(kisa, uzun):
    nk, nu = normalize(kisa), normalize(uzun)
    if len(nk) < 12 or len(nu) <= len(nk):
        return False
    if not nu.endswith(nk):
        return False
    fazla = len(nu) - len(nk)
    if fazla > len(nk):
        return False
    birikim = adet = 0
    for w in uzun.strip().split():
        if birikim >= fazla:
            break
        if not w[:1].isupper():
            return False
        birikim += len(normalize(w))
        adet += 1
        if adet > 4:
            return False
    return 1 <= adet <= 4 and birikim == fazla


def ayni(a, b):
    return ad_ekli_mi(a, b) or ad_ekli_mi(b, a)


for k, u in [
    ("D-don't come any closer!", "Old Man Gen D-don't come any closer!"),
    ("Come, come. Let's catch up a bit, eh?", "Old Man Gen Come, come. Let's catch up a bit, eh?"),
    ("A rare guest indeed! Come in, let's talk!",
     "Blue Clad Young Master Arare guest indeed! Come in, let's talk!"),
    ("Oh? A living soul in this place?", "Blue Clad Young Master Oh? A living soul in this place?"),
]:
    bekle(ayni(k, u), f"ayni sayilmadi: {k!r} / {u!r}")

for k, u in [
    ("I have to find her...", "It's too dangerous. I have to find her..."),
    ("Come in, let's talk!", "A rare guest indeed! Come in, let's talk!"),
    ("this old man could take on all of you!", "Back in my day, this old man could take on all of you!"),
]:
    bekle(not ayni(k, u), f"yanlis birlestirildi: {k!r} / {u!r}")


# --------------------------------------------------------- 2) sayı kuralı

m = re.search(r'Regex\("(\(\?<!\[\\\\p\{L\}\\\\d\]\)[^"]*)"\)', koruma)
bekle("\\\\d{2,}" in koruma, "sayi kurali iki basamakli olmali")
SAYI = re.compile(r"(?<![^\W\d_\d])\d{2,}(?![^\W\d_\d])")


def sayilar(s):
    return re.findall(r"(?<![^\W_])\d{2,}(?![^\W_])", s)


bekle(sayilar("The Village of Lu.. 1 remember it as a quiet place,") == [],
      "tek basamakli OCR copu hala sayi sayiliyor")
bekle(sayilar("what g0od is money") == [], "g0od hala sayi sayiliyor")
bekle(sayilar("We have 51 ships and 2 boats.") == ["51"], "gercek sayi yakalanmadi")


# ---------------------------------------------------------- 3) tuş uyarısı

bekle("TUS_UYARISI" in yakala, "tus uyarisi deseni yok")
TUS = re.compile(r"(?i)\b(press|hold|tap|push)\s+(?:and\s+hold\s+)?(?:the\s+)?"
                 r"([a-z]|[lr][123]|△|○|□|✕|circle|square|triangle|cross|touchpad|options)\b")
for s in ["Press O to throw the Crimson Viper", "Hold R2 to aim",
          "Press the Touchpad to open the map", "Tap X to continue"]:
    bekle(TUS.search(s) is not None, f"tus uyarisi gecti: {s}")
for s in ["Press on, men!", "Hold the line!", "Press your advantage.",
          "Hold still, this will hurt."]:
    bekle(TUS.search(s) is None, f"gercek replik tus sanildi: {s}")


# ----------------------------------------------------------- 4) çöp okuma

bekle("fun cokBozuk" in ocr, "cokBozuk yok")
bekle("OcrOnar.cokBozuk" in yakala, "cokBozuk OCR akisinda cagrilmiyor")

SOZ = os.path.join(APP, "res", "raw", "kelimeler.gz")
with gzip.open(SOZ, "rt", encoding="utf-8") as f:
    KELIMELER = {w.strip() for w in f if w.strip()}


def cok_bozuk(metin):
    toplam = bilinen = 0
    for ham in re.split(r"[^\w'’]+", metin, flags=re.UNICODE):
        w = re.split(r"['’]", ham)[0]
        if len(w) < 4 or any(ord(c) > 127 for c in w):
            continue
        toplam += 1
        if w.lower() in KELIMELER:
            bilinen += 1
    return toplam >= 4 and bilinen * 2 < toplam


for s in ["Years go by, and a man's nerve justain'twhat it used to be... "
          "Now all LCando Refollo M hehindwomand he Carefu",
          "Now alll candofsfollo Mehehind vo L andbo carefu"]:
    bekle(cok_bozuk(s), f"cop okuma gecti: {s[:40]}")
for s in ["A rare guest indeed! Come in, let's talk!",
          "But I heard something terrible happened in the Village of Lu!",
          "I should pay you for the damaged cart.",
          "When I was young I dreamt of roaming the Wulin... fearless, just like you."]:
    bekle(not cok_bozuk(s), f"gercek altyazi cop sanildi: {s[:40]}")


# ------------------------------------------- 5) "YZ her satirda" ayari

prefs = open(os.path.join(KAYNAK, "Prefs.kt"), encoding="utf-8").read()
ana = open(os.path.join(KAYNAK, "MainActivity.kt"), encoding="utf-8").read()
duzen = open(os.path.join(APP, "res", "layout", "activity_main.xml"), encoding="utf-8").read()

bekle("var alwaysAi" in prefs, "alwaysAi ayari Prefs'te yok")
bekle('getBoolean("alwaysAi", false)' in prefs, "varsayilan kapali olmali")
bekle("cbAlwaysAi" in duzen, "ayar kutusu arayuzde yok")
bekle(ana.count("cbAlwaysAi") >= 4, "ayar kutusu MainActivity'ye tam baglanmamis")
bekle("prefs.alwaysAi = cbAlwaysAi.isChecked" in ana, "ayar kaydedilmiyor")
bekle("cbAlwaysAi.isChecked = prefs.alwaysAi" in ana, "ayar yuklenmiyor")
bekle("!prefs.alwaysAi && !AiGuard.yzGerekli" in yakala, "ayar YZ kapisina baglanmamis")
bekle("YZ her satırda" in yakala, "surum satirinda ayar gorunmuyor")


# ------------------------------------------ 6) bozuk okuma hafizaya girmesin

depo = open(os.path.join(KAYNAK, "TranslationStore.kt"), encoding="utf-8").read()
bekle("fun hafizayaUygun" in yakala, "hafiza suzgeci yok")
bekle("HARF_RAKAM" in yakala, "harf+rakam deseni yok")
bekle("if (!hafizayaUygun(source))" in yakala, "saveToMemory suzgeci cagirmiyor")
bekle("fun purge" in depo, "eski bozuk kayitlari silen purge yok")
bekle("purge { HARF_RAKAM" in yakala, "acilista hafiza temizlenmiyor")

HR = re.compile(r"[^\W\d_]\d|\d[^\W\d_]", re.UNICODE)
# Kayittaki bozuk okumalar hafizaya girmemeli
for s_ in ["Old Man Gen I asked where she came from. She said the valley outpost... and... the campin thow O0d",
           "and. the. cam pin the WOode nhh O0d",
           "3old Man Gen I asked where she came from."]:
    bekle(HR.search(s_) is not None, f"bozuk okuma hafizaya girecek: {s_[:40]}")
# Temiz satirlar girebilmeli
for s_ in ["Tell me more about the girl.",
           "She was scared. Even her voice was shaking.",
           "We have 51 ships and 2 boats.",
           "Her eyes were red... but she didn't shed a single tear."]:
    bekle(HR.search(s_) is None, f"temiz satir hafizadan men edildi: {s_[:40]}")


# ------------------------------------------------------------------- sonuc

if hata:
    print("BAŞARISIZ:")
    for h in hata:
        print("  ✗", h)
    sys.exit(1)

print("Ad eki + sayı + tuş + çöp + YZ ayarı + hafıza süzgeci testi geçti.")
