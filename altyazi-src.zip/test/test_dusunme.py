#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
İnternet modu: düşünme ayarı modele göre seçiliyor mu?

Kullanıcının 12 Kasım 9.87 kaydında internet modundaki HER istek
"400: Request contains an invalid argument." ile döndü. İstek gövdesi her
modele sabit {"thinkingBudget": 0} gönderiyordu; bu alan yalnız Gemini 2.x
ailesinde geçerli, 3.x "thinkingLevel" istiyor.

Bu test canlı sunucuya GİDEMEZ (burada ağ ve anahtar yok). Baktığı şey,
kodun tek bir ayara bağlı kalmadığı: 400 gelince sıradaki ayarı deniyor,
tutanı hatırlıyor, başka hatalarda boşuna yeniden denemiyor.
"""
import os
import re
import sys

KOK = os.path.dirname(os.path.abspath(__file__))
K = os.path.join(KOK, "..", "app", "src", "main", "java", "com", "example", "altyazi")
s = open(os.path.join(K, "AiTranslate.kt"), encoding="utf-8").read()
cap = open(os.path.join(K, "CaptureService.kt"), encoding="utf-8").read()
hata = []

a = s.find("private fun requestGemini")
b = s.find("private fun geminiIstek")
govde = s[a:b]
kod = "\n".join(l for l in govde.splitlines() if not l.strip().startswith("//"))

# 1) üç ayar da var ve ayrı gövde üretiyor
for parca, ne in (('.put("thinkingBudget", 0)', "Gemini 2.x ayarı"),
                  ('.put("thinkingLevel", "minimal")', "Gemini 3.x ayarı"),
                  ('else -> uretim.put("maxOutputTokens", 2048)', "ayarsız gövde")):
    if parca not in kod:
        hata.append("Eksik: " + ne + " (" + parca + ")")
if kod.count("thinkingBudget") != 1 or kod.count("thinkingLevel") != 1:
    hata.append("thinkingBudget ve thinkingLevel birer kez, AYRI dallarda olmalı; "
                "ikisi aynı istekte giderse sunucu 400 döner.")
m = re.search(r"DUSUNME_BUTCE -> (.*?)DUSUNME_SEVIYE -> (.*?)else ->", kod, re.S)
if not m or "thinkingLevel" in m.group(1) or "thinkingBudget" in m.group(2):
    hata.append("Düşünme dalları karışmış.")

# 2) sıra: 2.x'te bütçe, diğerlerinde seviye başta; ikisinde de üç ayar
m = re.search(r'startsWith\("gemini-2"\).*?listOf\((.*?)\).*?listOf\((.*?)\)', kod, re.S)
if not m:
    hata.append("dusunmeSirasi bulunamadı.")
else:
    eski = [x.strip() for x in m.group(1).split(",")]
    yeni = [x.strip() for x in m.group(2).split(",")]
    if eski[0] != "DUSUNME_BUTCE" or yeni[0] != "DUSUNME_SEVIYE":
        hata.append("İlk denenen ayar yanlış: 2.x -> bütçe, 3.x -> seviye olmalı.")
    if sorted(eski) != sorted(yeni) or len(set(eski)) != 3:
        hata.append("Her model için ÜÇ ayar da denenmeli (tahmin tutmazsa çıkış yolu).")

# 3) yalnız 400'de sıradaki ayar; tutan hatırlanıyor; bozulan unutuluyor
for parca, ne in (
    ('if (lastError?.startsWith("400") != true) return null',
     "400 dışındaki hatada (kota, anahtar, bağlantı) yeniden deneme olmamalı"),
    ("Usage.dusunmeAyari[model] = ayar", "tutan ayar hatırlanmıyor — her satır üç istek atar"),
    ("if (bilinen != null) Usage.dusunmeAyari.remove(model)",
     "hatırlanan ayar 400 vermeye başlarsa unutulmuyor"),
    ("val sira = if (bilinen != null) listOf(bilinen) else dusunmeSirasi(model)",
     "hatırlanan ayar kullanılmıyor"),
):
    if parca not in kod:
        hata.append("Eksik: " + ne)

# 4) hata iletisi modeli ve ayarı söylüyor; kayıt başlığı modeli yazıyor
if '" · model=" + model + " · düşünme=" + ayar' not in kod:
    hata.append("400 iletisinde model/ayar yok — bir sonraki kayıttan sebep okunamaz.")
if '" · model:" + (if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel else prefs.model)' not in cap:
    hata.append("Kayıt başlığı internet modunda modeli yazmıyor.")

# 5) Kotlin sabitleri tanımlı
for ad in ("DUSUNME_BUTCE", "DUSUNME_SEVIYE", "DUSUNME_YOK"):
    if ("const val " + ad + " = ") not in s:
        hata.append("Sabit tanımsız: " + ad)

if hata:
    print("BAŞARISIZ:")
    for h in hata:
        print("  - " + h)
    sys.exit(1)
print("Düşünme ayarı testi geçti: üç ayar ayrı gövdede, 400'de sıradaki deneniyor, "
      "tutan hatırlanıyor. (Canlı sunucu burada denenemez.)")
