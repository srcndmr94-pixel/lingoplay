"""
Yapay zekânın SAĞLAM taslağı bozmasını engelleyen denetimler.

Kullanıcının 11 Kasım 10:25 kaydında küçük model (E2B) satırların çoğunda
taslaktan kötü sonuç üretti. İki tür bozma kesin olarak yakalanabiliyor:

1. KALIP BOZULMASI — elle yazılmış, İngilizcesinden tahmin edilemeyen
   karşılıklar. Sözlükte doğru duruyor, taslak doğru çeviriyor, yapay zekâ
   kelime kelime çevirip anlamı tersine döndürüyor:
       "It's twelve!"     taslak "Polis geldi"    YZ "Yüz on iki!"
       "street pushers"   taslak "sokak satıcısı" YZ "sokak polisleri"
       "Aww, too bad!"    taslak "Ah, ne yazık!"  YZ "Aman, neyse ki!"

2. KÜFÜR DÜŞMESİ — "küfür korunuyor" ayarı açıkken yapay zekâ sertliği
   siliyor: "What the fuck you talking about?" taslakta "Ne bok konuşuyorsun
   sen?" iken cevapta "Ne cidden bahsediyorsun?" oluyordu.

Testin ikinci yarısı en az birincisi kadar önemli: yapay zekânın DAHA İYİ
çevirilerini engellememeli. "Hold up" için taslak "Bekle", yapay zekâ "Dur
bir" diyor; ikisi de doğru, reddedilmemeli.
"""

import os
import re
import sys

KAYNAK = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main",
                      "java", "com", "example", "altyazi", "AiGuard.kt")
metin = open(KAYNAK, encoding="utf-8").read()

hata = []


def bekle(kosul, mesaj):
    if not kosul:
        hata.append(mesaj)


bekle("private val KORUNAN" in metin, "korunan kalıp listesi yok")
bekle("fun kalipDustu" in metin, "kalıp denetimi yok")
bekle("küfür düştü" in metin, "küfür denetimi yok")
bekle("kalipDustu(kaynak, yKucukTam)" in metin, "kalıp denetimi redSebebi'ye bağlanmamış")


def desenler(ad):
    blok = re.search(rf"private val {ad}[^=]*= Regex\(\s*(.*?)\n\s*\)", metin, re.S)
    return blok.group(1) if blok else ""


IN_KUFUR = re.compile(desenler("IN_KUFUR").replace('"', "").replace("+", "").replace("\\\\", "\\")
                      .replace("(?i)", "").strip(), re.IGNORECASE) if desenler("IN_KUFUR") else None
bekle(IN_KUFUR is not None, "İngilizce küfür deseni okunamadı")

_kor = re.search(r"private val KORUNAN: List<Pair<Regex, String>> = listOf\((.*?)\n\s*\)\.map",
                 metin, re.S)
bekle(_kor is not None, "KORUNAN listesi okunamadı")
KORUNAN = [(d.replace("\\\\", "\\"), k)
           for d, k in re.findall(r'"((?:[^"\\]|\\.)*)" to "((?:[^"\\]|\\.)*)"', _kor.group(1))] if _kor else []
bekle(len(KORUNAN) >= 3, f"korunan kalıp az: {len(KORUNAN)}")

TR_KUFUR = re.compile(
    r"(sik|siktir|amına|amina|orospu|piç|pic|\bbok\b|hassiktir|kahretsin|lanet|"
    r"\blan\b|\bulan\b|\bbe\b|götü|gotu|yarrak|aptal|salak|şerefsiz)", re.IGNORECASE)


def red(kaynak, taslak, yz):
    y = yz.lower()
    for desen, kok in KORUNAN:
        if re.search(desen, kaynak, re.IGNORECASE) and kok not in y:
            return "kalıp bozuldu"
    if (taslak and IN_KUFUR and IN_KUFUR.search(kaynak)
            and TR_KUFUR.search(taslak) and not TR_KUFUR.search(yz)):
        return "küfür düştü"
    return None


KOTU = [
    ("Hey, yo, Ray! It's twelve! They tooled up and everything!",
     "Hey, hey, Ray! Polis geldi! Tepeden tırnağa silahlılar!",
     "Hey, yo, Ray! Yüz on iki! Silahlı geldiler ve her şey!"),
    ("Can't you fucking handle a bunch of street pushers?",
     "Bir avuç sokak satıcısıyla bile başa çıkamıyor musunuz be?",
     "Sokak polislerini yönetemiyor musun lan?"),
    ("Aww, too bad!", "Ah, ne yazık!", "Aman, neyse ki!"),
    ("What the fuck you talking about?", "Ne bok konuşuyorsun sen?",
     "Ne cidden bahsediyorsun?"),
]
for kaynak, taslak, yz in KOTU:
    if red(kaynak, taslak, yz) is None:
        hata.append(f"bozma yakalanmadı: {yz!r}")

IYI = [
    ("Alright, that's the block right here.", "Pekâlâ, Buradaki blok bu.",
     "Tamam, o mahalle burası."),
    ("Hold up, bruh.", "Bekle, bruh.", "Dur bir, kanka."),
    ("Yeah, he fucking knows.", "Evet, biliyor amına koyayım.", "Evet, biliyor lan."),
    ("Police! Don't fucking move!", "Polis! Kıpırdama lan!", "Polis! Kıpırdama lan!"),
    ("Fuck Boobie! We gotta get out of this.",
     "Boobie'yi siktir et! Bu işten sıyrılmamız lazım.",
     "Boobie'ye siktir! Bundan kurtulmalıyız."),
    ("My partner's off the grid right now, you feel me?",
     "Ortağım şu an ortalarda yok, anlıyorsun ya?",
     "Ortaklığım şu an tamamen izole, anlıyor musun?"),
    ("we in a holding pattern right here.", "Burada bekliyoruz.", "Burada bekliyoruz."),
    ("Come on, we need to find a way out.", "Hadi, Bir çıkış yolu bulmalıyız.",
     "Hadi ya, bir çıkış yolu bulmalıyız."),
    ("Appreciate it.", "Sağ ol.", "Teşekkürler."),
    ("Looks like it.", "Gibi görünüyor.", "Görünüşe göre öyle."),
]
for kaynak, taslak, yz in IYI:
    sebep = red(kaynak, taslak, yz)
    if sebep is not None:
        hata.append(f"doğru çeviri reddedildi ({sebep}): {yz!r}")

if hata:
    print("Yapay zekâ denetim testi DÜŞTÜ:")
    for h in hata:
        print("  ✗", h)
    sys.exit(1)

print(f"Yapay zekâ denetim testi geçti ({len(KOTU)} bozma yakalandı, "
      f"{len(IYI)} doğru çeviri geçti, {len(KORUNAN)} korunan kalıp).")
