"""401 olmayan hatada ikinci deneme yapılmamalı (boşuna istek gitmesin)."""
import importlib.util, json, os, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import os as _os
PC_YOLU = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "pc", "lingoplay_pc.py")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
denemeler=[]
class S(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_POST(self):
        denemeler.append(1)
        v=json.dumps({"error":{"message":"You exceeded your current quota"}}).encode()
        self.send_response(429); self.send_header("content-length",str(len(v))); self.end_headers(); self.wfile.write(v)
srv=HTTPServer(("127.0.0.1",8753),S); threading.Thread(target=srv.serve_forever,daemon=True).start()
src=open(PC_YOLU,encoding="utf-8").read().replace(
    "https://generativelanguage.googleapis.com","http://127.0.0.1:8753")
y={}; exec(compile(src,"t","exec"),y)
c=y["Cevirmen"](dict(y["VARSAYILAN"],api_key="AQ.X1234567890ABCDEFGH"))
c.cevir("Hello.")
print("deneme sayısı:",len(denemeler))
print("hata:",c.son_hata)
srv.shutdown()
sys.exit(0 if len(denemeler)==1 and "kota" in (c.son_hata or "").lower() else 1)
