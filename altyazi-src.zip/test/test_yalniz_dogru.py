#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
"YALNIZ DOĞRU ÇEVİRİ" modu bağlı mı?

Kullanıcının isteği (12 Kasım): hızlı motorun ilk çevirisi ekrana HİÇ
çıkmasın, yalnız doğru olan görünsün; ilk çeviri arka planda kalsın.

Bu mod dört yerde birden doğru bağlanmak zorunda; biri eksik kalırsa ya
taslak yine görünür ya da ekran boş kalır:
  1. ayar saklanıyor ve ekrandaki kutuya bağlı,
  2. taslak yayınlanmıyor,
  3. yapay zekâ cevap veremezse / reddedilirse taslak YEDEK olarak çıkıyor,
  4. geç gelen doğru çeviri boşa gitmiyor.
Ayrıca yapay zekâ konuşmasının önceden hazırlanması (ısıtma) tek konuşma
kuralına uyuyor mu, ona bakılıyor.
"""
import os
import re
import sys

KOK = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(KOK, "..", "app", "src", "main")
K = os.path.join(APP, "java", "com", "example", "altyazi")


def oku(*p):
    with open(os.path.join(*p), encoding="utf-8") as f:
        return f.read()


prefs = oku(K, "Prefs.kt")
main = oku(K, "MainActivity.kt")
cap = oku(K, "CaptureService.kt")
llm = oku(K, "LlmTranslate.kt")
xml = oku(APP, "res", "layout", "activity_main.xml")
hata = []

# 1) ayar
if 'sp.getBoolean("yalnizDogru", false)' not in prefs:
    hata.append("Prefs.yalnizDogru yok ya da varsayılanı kapalı değil.")
if '@+id/cbYalnizDogru' not in xml:
    hata.append("activity_main.xml içinde cbYalnizDogru kutusu yok.")
for parca in ("findViewById(R.id.cbYalnizDogru)",
              "cbYalnizDogru.isChecked = prefs.yalnizDogru",
              "prefs.yalnizDogru = cbYalnizDogru.isChecked"):
    if parca not in main:
        hata.append("MainActivity bağlantısı eksik: " + parca)

# 2) taslak yayınlanmıyor: taslakIsi dalının İLK koşulu yalnizDogru olmalı
m = re.search(r"val taslakIsi = if \(!failed\) \{\s*if \(prefs\.yalnizDogru\) \{(.*?)\} else if", cap, re.S)
if not m:
    hata.append("taslakIsi dalı yalnizDogru ile başlamıyor — taslak yine ekrana çıkar.")
elif "publish(" in "\n".join(l for l in m.group(1).splitlines() if not l.strip().startswith("//")):
    hata.append("yalnizDogru dalında taslak yayınlanıyor.")

# 3) yedek yollar
if cap.count('tag = " · taslak (yedek)"') < 2:
    hata.append("Yedek taslak iki yolda da olmalı (YZ cevap vermedi + YZ reddedildi); "
                "yoksa bu modda ekran boş kalır.")
i = cap.find('log("YZ REDDEDİLDİ')
if i < 0 or "prefs.yalnizDogru" not in cap[i:i + 700]:
    hata.append("YZ reddedilince yalnizDogru modunda yedek taslak gösterilmiyor.")

# 4) geç gelen cevap
if "val gecGoster = translatingFor != source && prefs.yalnizDogru" not in cap:
    hata.append("Geç gelen doğru çeviri bu modda gösterilmiyor (gecGoster yok).")
if "if (translatingFor != source && !gecGoster)" not in cap:
    hata.append("gecGoster hesaplanıyor ama geç-kaldı dalını atlatmıyor.")
if "sonGidenKaynak = translatingFor" not in cap:
    hata.append("sonGidenKaynak hiç güncellenmiyor — gecGoster asla doğru olmaz.")
# yalnız yapay zekâ cevabı geç gösterilebilir, taslak değil
if 'tag.contains("YZ") && sonGidenKaynak == source' not in cap:
    hata.append("gecGoster yalnız yapay zekâ cevabına sınırlı değil.")

# 5) kayıt başlığı modu söylüyor mu
if "YALNIZ DOĞRU ÇEVİRİ (taslak gizli)" not in cap:
    hata.append("Kayıt başlığı modu yazmıyor; kayıttan hangi modda çekildiği anlaşılmaz.")

# 6) ısıtma: tek konuşma kuralı ve güvenli geri düşüş
if "val conv = hazir ?: yeniKonusma(e)" not in llm:
    hata.append("Sıcak konuşma yoksa yenisi açılmıyor.")
if "shared.sicak = try { yeniKonusma(e) } catch (_: Throwable) { null }" not in llm:
    hata.append("Isıtma hatası yakalanmıyor — hazırlık çökerse çeviri de çöker.")
i = llm.find("try { conv.close() } catch")
j = llm.find("isit()", i)
if i < 0 or j < 0:
    hata.append("isit() konuşma kapatıldıktan SONRA çağrılmıyor — aynı anda iki konuşma açılır.")
if "try { shared.sicak?.close() } catch" not in llm:
    hata.append("Model yenilenirken sıcak konuşma kapatılmıyor.")
if "kurulum ${l.lastKurulumMs} ms" not in cap:
    hata.append("Kurulum süresi kayda yazılmıyor — ısıtmanın kazancı ölçülemez.")

if hata:
    print("BAŞARISIZ:")
    for h in hata:
        print("  - " + h)
    sys.exit(1)
print("Yalnız-doğru modu testi geçti: ayar bağlı, taslak gizli, iki yedek yol ve "
      "geç cevap yolu yerinde, ısıtma tek konuşma kuralına uyuyor.")
