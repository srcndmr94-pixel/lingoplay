"""Yeni arayüz gerçekten kuruluyor mu; her düğmeye basınca hata çıkıyor mu?"""
import importlib.util, json, os, sys, tempfile
PC_YOLU = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pc", "lingoplay_pc.py")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
import tkinter as sahte_tk
spec = importlib.util.spec_from_file_location("lingoplay", PC_YOLU)
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

d = tempfile.mkdtemp()
lp.APP_DIR = d
lp.CONFIG_PATH = os.path.join(d, "ayarlar.json")
json.dump({"ust_yuzde": 70, "alt_yuzde": 95, "tur": "Dizi", "api_key": ""}, open(lp.CONFIG_PATH, "w"))

# Ağ ve OCR kullanılmasın
class SahteCevirmen:
    son_sure = 0.1; son_hata = "yok"
    def __init__(self, a): pass
    def cevir(self, m): return "Dışarıda bekliyor."
    def modelleri_getir(self): return ["gemini-a", "gemini-b"]
    @staticmethod
    def en_uygun(adlar): return adlar[0]
lp.Cevirmen = SahteCevirmen
class SahteMotor:
    def __init__(self, *a): pass
    def start(self): pass
    def dur(self): pass
lp.Motor = SahteMotor

print("Sürüm:", lp.SURUM)
sorun = []
lp.main()
ana = [b for b in sahte_tk.DUGMELER]
etiketler = [b.cget("text") for b in ana]
print("Ana düğmeler:", etiketler)
for gerekli in ("Başlat", "Oyun", "Dizi", "Film", "Bölgeyi ekranda göster", "Ayarlar ›"):
    if gerekli not in etiketler:
        sorun.append(f"'{gerekli}' düğmesi yok")

def bul(metin):
    return next(b for b in sahte_tk.DUGMELER if b.cget("text") == metin)

# Kayıtlı tür (Dizi) seçili görünmeli
if bul("Dizi").cget("bg") != lp.RENK["turkuaz"]:
    sorun.append("kayıtlı tür seçili görünmüyor")
bul("Film").invoke()
if bul("Film").cget("bg") != lp.RENK["turkuaz"] or bul("Dizi").cget("bg") == lp.RENK["turkuaz"]:
    sorun.append("tür düğmesi seçimi değişmiyor")

pencere_sayisi = len(sahte_tk.PENCERELER)
bul("Bölgeyi ekranda göster").invoke()
if len(sahte_tk.PENCERELER) != pencere_sayisi + 1:
    sorun.append("bölge çerçevesi açılmadı")

ana_d = bul("Başlat")
ana_d.invoke()
if ana_d.cget("text") != "Durdur":
    sorun.append("Başlat → Durdur olmadı")
kayit = json.load(open(lp.CONFIG_PATH))
if kayit.get("tur") != "Film" or kayit.get("ust_yuzde") != 70 or kayit.get("alt_yuzde") != 95:
    sorun.append(f"ayarlar yanlış kaydedildi: {kayit}")
ana_d.invoke()
if ana_d.cget("text") != "Başlat":
    sorun.append("Durdur → Başlat olmadı")

bul("Ayarlar ›").invoke()
for metin in ("Modelleri bul", "Çeviriyi test et", "Kaydet ve kapat"):
    try:
        bul(metin).invoke()
    except StopIteration:
        sorun.append(f"çeviri ayarlarında '{metin}' yok")
if json.load(open(lp.CONFIG_PATH)).get("model") != "gemini-a":
    sorun.append("bulunan model kaydedilmedi")

# Durum rengi
if lp.durum_rengi("Çeviri başarısız ✗") != lp.RENK["kirmizi"]: sorun.append("hata rengi")
if lp.durum_rengi("OCR 140 ms · çeviri 600 ms") != lp.RENK["turkuaz"]: sorun.append("çalışma rengi")
if lp.durum_rengi("Hazır.") != lp.RENK["gri"]: sorun.append("hazır rengi")

# Kutu: konuşan adı ayrı
k = lp.Kutu(sahte_tk.Tk())
k.yaz("JOEL: Sakin ol.")
if k.ad.cget("text").strip() != "JOEL:" or k.etiket.cget("text") != "Sakin ol.":
    sorun.append(f"konuşan adı ayrılmadı: {k.ad.cget('text')!r} {k.etiket.cget('text')!r}")
k.yaz("Sakin ol.")
if k.ad.cget("text") != "" or k.etiket.cget("text") != "Sakin ol.":
    sorun.append("adsız satır yanlış")

if sorun:
    print("BAŞARISIZ:", sorun); sys.exit(1)
print("Arayüz hatasız kuruldu, bütün düğmeler çalıştı.")
