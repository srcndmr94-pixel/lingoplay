"""Arayüz gerçekten kuruluyor mu, versiyon görünüyor mu?"""
import importlib.util, os, sys
import os as _os
PC_YOLU = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "pc", "lingoplay_pc.py")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "stubs"))
spec = importlib.util.spec_from_file_location("lingoplay", PC_YOLU)
lp = importlib.util.module_from_spec(spec); spec.loader.exec_module(lp)

print("Sürüm:", lp.SURUM)
lp.main()   # stub mainloop hemen döner; hata olursa burada patlar
print("Arayüz hatasız kuruldu.")
