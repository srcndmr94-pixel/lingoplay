import java.io.*; import java.nio.file.*; import java.util.*; import java.util.regex.*; import java.util.zip.*;
/**
 * OcrOnar.susluCop + temizKuyruk aynasi. Sozluk gercek .gz dosyasindan okunur.
 * Kurallar OcrSozluk.kt'den calisma aninda okunmuyor (duz kod); bayatlama
 * alarmi icin esik degeri kaynaktan dogrulaniyor.
 */
public class Suslu {
    static Set<String> SOZ = new HashSet<>();
    static Set<String> KISALTMA = new HashSet<>();
    static int ESIK;
    static final Pattern IKI_BUYUK = Pattern.compile("^\\p{Lu}{2}\\p{Ll}");
    static final Pattern OZEL_AD = Pattern.compile("^\\p{Lu}\\p{Ll}+$");
    static int hata = 0;
    static final String KIRP = ".,!?:;\"'’-…[]";

    static String kirp(String s) {
        int a = 0, b = s.length();
        while (a < b && KIRP.indexOf(s.charAt(a)) >= 0) a++;
        while (b > a && KIRP.indexOf(s.charAt(b - 1)) >= 0) b--;
        return s.substring(a, b);
    }

    static void yukle(String kaynak, String gz) throws Exception {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new GZIPInputStream(new FileInputStream(gz)), "UTF-8"))) {
            String l; while ((l = r.readLine()) != null) if (!l.isEmpty()) SOZ.add(l.trim().toLowerCase());
        }
        String s = new String(Files.readAllBytes(Paths.get(kaynak + "/OcrSozluk.kt")), "UTF-8");
        int i = s.indexOf("private val KISALTMA = setOf(");
        Matcher m = Pattern.compile("\"([^\"]+)\"").matcher(s.substring(i, s.indexOf(")", i)));
        while (m.find()) KISALTMA.add(m.group(1));
        Matcher e = Pattern.compile("return puan >= (\\d+)").matcher(s);
        if (!e.find()) throw new RuntimeException("esik bulunamadi");
        ESIK = Integer.parseInt(e.group(1));
        System.out.println("  sozluk " + SOZ.size() + ", kisaltma " + KISALTMA.size() + ", esik " + ESIK);
    }

    static boolean susluCop(String metin) {
        String[] kel = metin.trim().split("\\s+");
        if (kel.length < 4) return false;
        int puan = 0;
        for (String ham : kel) {
            String k = kirp(ham);
            if (k.isEmpty()) continue;
            String kucuk = k.toLowerCase();
            boolean rakam = false, harf = false;
            for (char c : k.toCharArray()) { if (Character.isDigit(c)) rakam = true; if (Character.isLetter(c)) harf = true; }
            if (rakam && harf && k.length() >= 4) { puan += 2; continue; }
            if (IKI_BUYUK.matcher(k).find()) { puan += 2; continue; }
            if (k.length() == 1) { if (!kucuk.equals("i") && !kucuk.equals("a")) puan += 2; continue; }
            if (k.length() <= 3 && k.equals(k.toUpperCase()) && !KISALTMA.contains(kucuk)) { puan++; continue; }
            if (k.length() == 2 && !SOZ.contains(kucuk)) puan++;
        }
        return puan >= ESIK;
    }

    static final Set<String> KUCUK_OK = new HashSet<>(Arrays.asList("i","a","to","of","he","be","is","it"));

    static String temizKuyruk(String metin) {
        String[] p = metin.trim().split("\\s+");
        if (p.length < 5) return null;
        int bas = p.length, sayac = 0;
        for (int i = p.length - 1; i >= 0; i--) {
            String k = kirp(p[i]);
            int ap = k.indexOf('\''); if (ap >= 0) k = k.substring(0, ap);
            boolean tanidik = k.length() >= 2 && (SOZ.contains(k.toLowerCase())
                || OZEL_AD.matcher(k).matches() || KUCUK_OK.contains(k.toLowerCase()));
            if (!tanidik) break;
            bas = i; sayac++;
        }
        if (sayac < 4 || bas == 0) return null;
        return String.join(" ", Arrays.copyOfRange(p, bas, p.length));
    }

    static void cop(String s, String beklenenKuyruk) {
        boolean c = susluCop(s);
        String k = c ? temizKuyruk(s) : null;
        if (!c) { hata++; System.out.println("  X COP SANILMADI: " + s.substring(0, Math.min(60, s.length()))); return; }
        if (!Objects.equals(k, beklenenKuyruk)) {
            hata++;
            System.out.println("  X " + s.substring(0, Math.min(56, s.length())));
            System.out.println("      beklenen kuyruk: " + beklenenKuyruk);
            System.out.println("      cikan           : " + k);
        }
    }

    static void temiz(String s) {
        if (susluCop(s)) { hata++; System.out.println("  X YANLIS ALARM: " + s); }
    }

    public static void main(String[] a) throws Exception {
        yukle(a[0], a[1]);
        // --- Shrek fragmani: basi suslu yazi copu, sonu gercek altyazi
        // "Drince" (OCR'in bozdugu "Prince") ozel ad bicimine uyuyor ve
        // kuyrukta kaliyor. KABUL EDILEBILIR kalinti: gercek cumle korunuyor.
        // Ozel adlari kuyruktan atmak "Nolan went home" gibi satirlari
        // bozardi (kuyruk 2 kelimeye duser, satirin tamami atilir).
        cop("ch At be w As worthy o F DArrying che Drince who had to prove to the King of Far Far Away",
            "Drince who had to prove to the King of Far Far Away");
        cop("ch At be w As Worthy o F MArrying he prncao that he was worthy of marrying the princess.",
            "that he was worthy of marrying the princess.");
        cop("chat be w As WOrthy ha nn that he was worthy of marrying the princess.",
            "that he was worthy of marrying the princess.");
        cop("ch At be w AS WOrchy o F MATTying that he was worthy of marrying the princess.",
            "that he was worthy of marrying the princess.");
        // --- GERCEK replikler: hicbiri cop sayilmamali
        for (String s : new String[]{
            "Put it on speakerphone.", "It is what it is, my friend.",
            "I'm holding out for a hero 'til the morning light",
            "With The Witcher 4, we're are stepping things up.",
            "Thank you, Wyatt, and hello everyone.", "[SHREK] Great job, guys.",
            "First things first, I'm here with Sebastian and Keitech from CD Projekt Red.",
            "Captured on PS5", "Trailer I PS5 Games", "And he's gotta be larger than life",
            "This is Worg, Download and Councilor Tuva.",
            "We're the finest ship in the Coalition's navy",
            "Yo! Crackheads! Woo!", "I guess they know we're coming.", "No, General.",
            "[Grand Regent] How many are dead?", "Eh, fo sho. Yeah, yeah. Mmm hmm.",
            "Alright, that's the block right here.",
            "Let me tell y'all something, at this point I really don't give a fuck.",
            "Hey, yo, Ray! It's twelve! They tooled up and everything!",
            "Our friends on the task force are on their way.",
            "I know a ship we can take that won't raise any suspicions.",
            "announced a collaboration to make open-world development in Unreal even better.",
        }) temiz(s);
        if (hata > 0) { System.out.println("SUSLU DUSTU: " + hata); System.exit(1); }
        System.out.println("Suslu yazi testi gecti: cop kirpiliyor, gercek replikler dokunulmuyor.");
    }
}
