import com.metallic.chiaki.gamelingo.AltyaziSecici
import com.metallic.chiaki.gamelingo.AltyaziSecici.Satir

// Ölçüler 6 Kasım ekran görüntüsünden (Assassin's Creed menüsü, 2142x960 kare) oran olarak.
fun s(x0: Int, y0: Int, x1: Int, y1: Int, t: String) = Satir(x0 / 2142f, y0 / 960f, x1 / 2142f, y1 / 960f, t)

fun main() {
    val sorun = ArrayList<String>()

    // 1) Menü ekranı: sağdaki panel ve alttaki tuş çubuğu altyazı değil → hiçbir şey seçilmez
    val menu = listOf(
        s(1440, 556, 1604, 588, "Customize"), s(1440, 616, 1574, 648, "Change"),
        s(262, 880, 728, 916, "Close Tutorials Rotate"),
        s(430, 528, 450, 552, "A"), s(1400, 870, 1900, 900, "4012 Store"))
    val m = AltyaziSecici.sec(menu)
    if (m != null) sorun.add("menü ekranında altyazı sanıldı: ${m.metin}")

    // 2) Ortadaki iki satırlık altyazı, aynı karede menü yazılarıyla
    val iki = menu + listOf(s(620, 760, 1520, 800, "We need to find the others"), s(760, 808, 1380, 848, "before it gets dark."))
    val a = AltyaziSecici.sec(iki)
    if (a?.metin != "We need to find the others before it gets dark." || a.satirSayisi != 2) sorun.add("iki satır: $a")
    if (a != null && (a.ust > 760 / 960f + 0.001f || a.alt < 848 / 960f - 0.001f)) sorun.add("kutu yanlış: $a")

    // 3) Altyazının altında ortalı kısa tuş ipucu: altyazı yine seçilir (daha çok yazı)
    val ipucu = listOf(s(560, 700, 1580, 740, "Edward, the Templars are coming for the map!"), s(940, 900, 1200, 930, "Skip"))
    if (AltyaziSecici.sec(ipucu)?.metin != "Edward, the Templars are coming for the map!") sorun.add("ipucu altyazının yerine geçti: ${AltyaziSecici.sec(ipucu)}")

    // 4) Satır içinde parçalı okunan kelimeler soldan sağa birleşir
    val parcali = listOf(s(1100, 780, 1400, 820, "the ship."), s(700, 782, 1090, 820, "Get to"))
    if (AltyaziSecici.sec(parcali)?.metin != "Get to the ship.") sorun.add("parçalı satır: ${AltyaziSecici.sec(parcali)}")

    // 5) Konuşan adı + replik (ortalı) seçilir
    val adli = listOf(s(760, 780, 1380, 820, "EDWARD: Hold your fire!"))
    if (AltyaziSecici.sec(adli)?.metin != "EDWARD: Hold your fire!") sorun.add("adlı satır")

    // 6) Boş / tek harf
    if (AltyaziSecici.sec(emptyList()) != null || AltyaziSecici.sec(listOf(s(1000, 800, 1020, 820, "A"))) != null) sorun.add("boş giriş")

    if (sorun.isNotEmpty()) { println("BAŞARISIZ:"); sorun.forEach { println(" - $it") }; kotlin.system.exitProcess(1) }
    println("AltyaziSecici testi geçti (6 durum).")
}
