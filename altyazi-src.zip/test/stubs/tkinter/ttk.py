from . import _W


class Combobox(_W): pass
class Frame(_W): pass
class Label(_W): pass
class Entry(_W): pass
class Button(_W): pass
class LabelFrame(_W): pass
