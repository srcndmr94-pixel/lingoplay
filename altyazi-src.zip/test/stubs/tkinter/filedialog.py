"""Sahte dosya seçici: testler SECILECEK'i ayarlar."""
SECILECEK = ""


def askopenfilename(**k):
    return SECILECEK
