#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
9.91 — ÇEVİRİ BİÇİMİ: beş kutu yerine tek seçim.

12 Kasım 9.89 kayıtlarında ayarlar "hız öncelikli + iki satırlı yığın +
yalnız doğru çeviri" bileşimindeydi; ekranda iki ayrı repliğin çevirisi yan
yana kalıyor, kutulardan biri de hiç işlemiyordu. Kullanıcı: "gereksiz
kutucukları çıkaralım, kafa karışıklığı yapmasın".

Bu test şunlara bakar:
  1. Beş kutu ve "internet karma" ekranda GİZLİ, üçlü seçim var.
  2. Her biçim beş eski ayarı TEK ve tutarlı bir bileşime yazıyor.
  3. Güncellemeden gelen eski bileşim temizleniyor (ekran açılışı + yakalama başı).
  4. "Hızlı" biçimde yapay zekâ gerçekten devre dışı (telefon + internet).
"""
import os
import re
import sys
import xml.dom.minidom as minidom

KOK = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(KOK, "..", "app", "src", "main")
K = os.path.join(APP, "java", "com", "example", "altyazi")
oku = lambda ad: open(os.path.join(K, ad), encoding="utf-8").read()
prefs, ana, cap = oku("Prefs.kt"), oku("MainActivity.kt"), oku("CaptureService.kt")
xml_yol = os.path.join(APP, "res", "layout", "activity_main.xml")
hata = []

# 1) düzen
belge = minidom.parse(xml_yol)
ogeler = {}
for ad in ("CheckBox", "RadioButton", "RadioGroup"):
    for o in belge.getElementsByTagName(ad):
        ogeler[o.getAttribute("android:id").replace("@+id/", "")] = o
for gizli in ("cbAccuracy", "cbDogruyuBekle", "cbYalnizDogru", "cbYigin", "cbAlwaysAi", "rbHybrid"):
    o = ogeler.get(gizli)
    if o is None:
        hata.append("%s düzenden silinmiş — MainActivity findViewById çöker." % gizli)
    elif o.getAttribute("android:visibility") != "gone":
        hata.append("%s hâlâ ekranda görünüyor." % gizli)
grup = ogeler.get("rgBicim")
if grup is None:
    hata.append("rgBicim yok.")
else:
    ic = [c.getAttribute("android:id").replace("@+id/", "")
          for c in grup.getElementsByTagName("RadioButton")]
    if ic != ["rbBicimHizli", "rbBicimDengeli", "rbBicimDogru"]:
        hata.append("rgBicim içinde üç seçenek bu sırayla olmalı: %s" % ic)
    for c in grup.getElementsByTagName("RadioButton"):
        if c.getAttribute("android:visibility") == "gone":
            hata.append("Biçim seçeneği gizli kalmış.")

# 2) bicimUygula: her biçim için beş ayarın değeri (kaynaktan okunup yürütülüyor)
m = re.search(r"fun bicimUygula\(bicim: Int\) \{(.*?)\n    \}", prefs, re.S)
sabit = dict((a, int(d)) for a, d in re.findall(r"const val (BICIM_\w+) = (\d+)", prefs))
if not m or len(sabit) != 3 or len(set(sabit.values())) != 3:
    hata.append("bicimUygula ya da BICIM_* sabitleri bulunamadı.")
else:
    def uygula(b):
        d = {}
        for satir in m.group(1).strip().splitlines():
            ad, deger = [x.strip() for x in satir.split("=", 1)]
            deger = deger.replace("true", "True").replace("false", "False")
            for k, v in sabit.items():
                deger = deger.replace(k, str(v))
            d[ad] = eval(deger, {"bicim": b})
        return d
    for ad, b in sabit.items():
        d = uygula(b)
        beklenen = {"ceviriBicimi": b, "accuracyFirst": True, "dogruyuBekle": False,
                    "yigin": False, "alwaysAi": False, "yalnizDogru": ad == "BICIM_DOGRU"}
        if d != beklenen:
            hata.append("%s yanlış bileşim yazıyor: %s" % (ad, d))
if 'get() = sp.getInt("ceviriBicimi", BICIM_DENGELI)' not in prefs:
    hata.append("Varsayılan biçim Dengeli değil.")

# 3) eski bileşimin temizlenmesi
if not re.search(r'fun bicimiOnar\(\) \{\s*if \(!sp\.contains\("ceviriBicimi"\)\) bicimUygula\(BICIM_DENGELI\) '
                 r'else bicimUygula\(ceviriBicimi\)\s*if \(sp\.getInt\("mode", MODE_INSTANT\) == MODE_HYBRID\) mode = MODE_AI',
                 prefs):
    hata.append("bicimiOnar eski bileşimi / karma modu temizlemiyor.")
i_onar = ana.find("prefs.bicimiOnar()")
i_kutu = ana.find("cbAccuracy.isChecked = prefs.accuracyFirst")
if i_onar < 0 or i_kutu < 0 or i_onar > i_kutu:
    hata.append("Ayar ekranı kutuları onarımdan ÖNCE yüklüyor — eski bileşim geri kaydedilir.")
if "AdDefteri.temizle()\n        prefs.bicimiOnar()" not in cap:
    hata.append("Yakalama başında biçim onarılmıyor.")
# kaydetme: biçim, gizli kutulardan ÖNCE uygulanmalı
i_b = ana.find("prefs.ceviriBicimi = bicim")
i_k = ana.find("prefs.accuracyFirst = cbAccuracy.isChecked")
arasi = ana[i_b:i_k] if 0 <= i_b < i_k else ""
for parca in ("cbAccuracy.isChecked = true", "cbDogruyuBekle.isChecked = false",
              "cbYalnizDogru.isChecked = bicim == Prefs.BICIM_DOGRU",
              "cbYigin.isChecked = false", "cbAlwaysAi.isChecked = false"):
    if parca not in arasi:
        hata.append("Kaydederken gizli kutu biçime göre ayarlanmıyor: " + parca)
if "rgBicim = findViewById(R.id.rgBicim)" not in ana:
    hata.append("rgBicim bağlanmamış (lateinit çöker).")

# 4) Hızlı: yapay zekâ yok
for parca, ne in (
    ("val hizli = prefs.ceviriBicimi == Prefs.BICIM_HIZLI", "hızlı biçim okunmuyor"),
    ("val mode = if (hizli) Prefs.MODE_INSTANT else prefs.mode", "Hızlı'da internet yapay zekâsı çalışır"),
    ("val llmOn = l != null && l.ready && !hizli", "Hızlı'da telefon yapay zekâsı çalışır"),
    ("mode == Prefs.MODE_INSTANT && !hizli && (llm?.ready == true || bridge)",
     "Hızlı'da kaba çeviri hafızası kullanılmaz"),
    ("biçim:$bicimAdi", "kayıt başlığı biçimi yazmıyor"),
):
    if parca not in cap:
        hata.append("Eksik: " + ne)

if hata:
    print("BAŞARISIZ:")
    for h in hata:
        print("  - " + h)
    sys.exit(1)
print("Çeviri biçimi testi geçti: beş kutu gizli, üç biçim tutarlı bileşim yazıyor, "
      "eski ayarlar temizleniyor, Hızlı'da yapay zekâ kapalı.")
