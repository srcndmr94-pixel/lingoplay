"""10.11 — Google'a gitmeden önce deyim sadeleştirme (ICU ile, Kotlin'deki kurallar okunarak)."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import icu_regex as I
K = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "java", "com", "example", "altyazi")
of = open(os.path.join(K, "OfflineFix.kt"), encoding="utf-8").read()
hata = []

def kural(anahtar):
    m = re.search(r'^\s*"((?:[^"\\]|\\.)*' + re.escape(anahtar) + r'(?:[^"\\]|\\.)*)" to "((?:[^"\\]|\\.)*)",', of, re.M)
    if not m:
        hata.append("Kural yok: " + anahtar); return None
    coz = lambda x: x.encode().decode("unicode_escape")
    return "(?i)" + coz(m.group(1)), coz(m.group(2))

kurallar = [k for k in (kural("stud\\\\b"), kural("back in the day"), kural("(view|sights|scenery)")) if k]

def uygula(t):
    for pat, rep in kurallar:
        r, e = I.degistir(pat, t, rep)
        if e: hata.append(f"ICU derleme hatası: {pat} {e}"); return t
        t = r
    return t

ornekler = [
    ("Well, Brian was quite the stud back in the day.", "Well, Brian was quite the ladies' man back then."),
    ("He was a stud in college.", "He was a ladies' man in college."),
    ("Yeah, let's take in the view.", "Yeah, let's enjoy the view."),
    ("We should take in the sights.", "We should enjoy the sights."),
    # dokunulmamalı
    ("I lost my earring stud.", "I lost my earring stud."),
    ("Take the view from the hill.", "Take the view from the hill."),
    ("The day is back in our hands.", "The day is back in our hands."),
]
for giris, beklenen in ornekler:
    cikis = uygula(giris)
    if cikis != beklenen:
        hata.append(f"{giris!r} -> {cikis!r}, beklenen {beklenen!r}")

m = re.search(r"gucluFn\?\.let \{ g ->(.*?)\n        \}", of, re.S)
if not m or "SlangNormalizer.normalize(Slang.normalize(text))" not in m.group(1):
    hata.append("Google yolunda argo/deyim sadeleştirme yapılmıyor.")
elif "ProfanityShield" in m.group(1):
    hata.append("Google yolunda küfür kalkanı yine çalışıyor.")

if hata:
    print("BAŞARISIZ:")
    for h in hata: print("  -", h)
    sys.exit(1)
print(f"Deyim testi geçti (ICU): {len(ornekler)} örnek; 'stud', 'back in the day', 'take in the view' sadeleşiyor, benzer ama farklı cümlelere dokunulmuyor.")
