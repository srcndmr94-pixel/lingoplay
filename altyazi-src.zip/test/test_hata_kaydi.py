"""
Hata kaydının eskimesini sınar (CrashLog.kt).

Kullanıcı 6 Kasım'da aynı hata raporunu üç kez gönderdi; hepsinin tarihi
20:59'du. Hata 21:23'te düzeltilmişti ama kayıt silinmiyordu: CrashLog eski
kaydı yalnızca SÜRÜM ADI değişirse siliyordu, sürüm adı ise güncellemeler
boyunca "9.35" olarak sabit kalmıştı. Bir kez düşen hata sonsuza kadar
gösteriliyordu.

Çözüm: kurulum zamanı (lastUpdateTime) damgası. Her APK kurulumunda değişir.
"""

import os
import re
import sys

KOK = os.path.dirname(__file__)
APP = os.path.join(KOK, "..", "app")
KAYNAK = os.path.join(APP, "src", "main", "java", "com", "example", "altyazi")

crash = open(os.path.join(KAYNAK, "CrashLog.kt"), encoding="utf-8").read()
ana = open(os.path.join(KAYNAK, "MainActivity.kt"), encoding="utf-8").read()
yakala = open(os.path.join(KAYNAK, "CaptureService.kt"), encoding="utf-8").read()
duzen = open(os.path.join(APP, "src", "main", "res", "layout", "activity_main.xml"),
             encoding="utf-8").read()
gradle = open(os.path.join(APP, "build.gradle.kts"), encoding="utf-8").read()

hata = []


def bekle(kosul, mesaj):
    if not kosul:
        hata.append(mesaj)


# ------------------------------------------------- 1) kurulum damgası

bekle("lastUpdateTime" in crash, "kurulum zamani damgasi yok")
bekle("fun installStamp" in crash, "installStamp yok")
bekle('append("Kurulum: ")' in crash, "kurulum damgasi dosyaya yazilmiyor")
bekle("Kurulum: (.+)" in crash, "kurulum damgasi okunmuyor")
bekle("kurulum != installStamp(context)" in crash,
      "eski kurulumdan kalan hata silinmiyor")
# Sürüm adı tek başına yeterli değildi; yine de ek kontrol olarak kalabilir.
bekle("f.delete()" in crash, "eskiyen kayit silinmiyor")


# ------------------------------------------------- 2) elle silme düğmesi

bekle("btnClearError" in duzen, "hata silme dugmesi arayuzde yok")
bekle("btnClearError" in ana, "hata silme dugmesi baglanmamis")
bekle("CrashLog.clear(this)" in ana, "dugme kaydi silmiyor")


# ------------------------------------------- 3) sürüm kayda elle yazılmasın

bekle("SÜRÜM $surumAdi" in yakala,
      "kayitta surum elle yazilmis; build.gradle degisince yanlis gosterir")
bekle(re.search(r'log\("SÜRÜM \d', yakala) is None,
      "kayitta sabit sürüm numarasi kalmis")
bekle("val surumAdi" in yakala, "surum adi APK'dan okunmuyor")


# --------------------------------------------- 4) sürüm gerçekten arttı mı

kod = re.search(r"versionCode\s*=\s*(\d+)", gradle)
ad = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
bekle(kod is not None and ad is not None, "surum bilgisi bulunamadi")
if kod and ad:
    bekle(int(kod.group(1)) >= 70, f"versionCode artmamis: {kod.group(1)}")
    bekle(ad.group(1) != "9.35", f"versionName hala eski: {ad.group(1)}")


# ------------------------------------------------------------------- sonuc

if hata:
    print("BAŞARISIZ:")
    for h in hata:
        print("  ✗", h)
    sys.exit(1)

print(f"Hata kaydı testi geçti (sürüm {ad.group(1) if ad else '?'}, "
      f"kurulum damgası devrede).")
