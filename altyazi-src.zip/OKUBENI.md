# LingoPlay

Üç uygulama, tek kaynak:

| Klasör | Ne üretir | Telefonda/bilgisayarda adı |
|---|---|---|
| `app/` | Telefon uygulaması (APK) | **LingoPlay** |
| `pc/` | Windows programı (EXE) | **LingoPlay** |
| `remote/` | Kendi Remote Play uygulamamız (APK) | **LingoPlay Remote** |

`test/` klasöründeki denetimler her değişiklikten önce çalıştırılır.

## Derleme

Depoya `lingoplay-src.zip` yüklemek yeterli.
`.github/workflows/build.yml` üç uygulamayı da derler ve ayrı ayrı indirmeye sunar:

- `1-Telefon-APK-…`
- `2-Bilgisayar-EXE-…`
- `3-Remote-APK-…`

Numaralar her derlemede artar, böylece hangisinin yeni olduğu adından bellidir.
