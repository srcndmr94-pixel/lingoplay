# GameLingo

Tek kaynak, dört çıktı:

| Klasör | Ne üretir | Cihazdaki adı |
|---|---|---|
| `app/` | Telefon uygulaması (APK) | **GameLingo** |
| `tv/` | Android TV uygulaması (APK) | **GameLingo TV** |
| `pc/` | Windows programı (EXE) | **LingoPlay** |
| `chrome/` | Chrome eklentisi | **GameLingo** |

`test/` klasöründeki denetimler her değişiklikten önce çalıştırılır:
`python3 test/run_all.py`

## Derleme

Depoya `altyazi-src.zip` yüklemek yeterli.
`.github/workflows/build.yml` üç işi birbirinden bağımsız çalıştırır; biri hata
verse diğerleri yine çıktı üretir:

- `1-Telefon-APK-…`
- `2-TV-APK-…`
- `3-Bilgisayar-EXE-…` (+ `3b-Dil-Paketi`)

Numaralar her derlemede artar, böylece hangisinin yeni olduğu adından bellidir.

## Not

PS5 uygulaması (GameLingo PS5 / chiaki-ng yaması) kaynaktan çıkarıldı.
PS5'i TV'de çevirili oynamak için TV kılavuzundaki Chiaki-Up yolu kullanılıyor.
