package com.metallic.chiaki.gamelingo

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Uygulama çökerse hatayı dosyaya yazar ve bir sonraki adımda "Hata raporu" ekranını açar.
 * Uygulama açılır açılmaz (her şeyden önce) çalışsın diye ContentProvider olarak kayıtlı.
 */
class HataYakalayici : ContentProvider() {

    companion object {
        const val DOSYA = "gl_hata.txt"
        fun dosya(c: Context) = File(c.filesDir, DOSYA)
    }

    override fun onCreate(): Boolean {
        val c = context?.applicationContext ?: return true
        val eski = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val surum = try {
                    c.packageManager.getPackageInfo(c.packageName, 0).versionName
                } catch (_: Throwable) { "?" }
                val metin = "GameLingo PS5 hata raporu\n" +
                        "Zaman: " + SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) + "\n" +
                        "Sürüm: " + surum + "\n" +
                        "Cihaz: " + Build.MANUFACTURER + " " + Build.MODEL + " · Android " + Build.VERSION.RELEASE +
                        " · " + Build.SUPPORTED_ABIS.joinToString(",") + "\n" +
                        "İş parçacığı: " + t.name + "\n\n" + sw.toString()
                dosya(c).writeText(metin)
                val i = Intent(c, HataActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                c.startActivity(i)
            } catch (_: Throwable) {
            }
            try {
                Process.killProcess(Process.myPid())
                System.exit(10)
            } catch (_: Throwable) {
                eski?.uncaughtException(t, e)
            }
        }
        return true
    }

    override fun query(u: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun getType(u: Uri): String? = null
    override fun insert(u: Uri, v: ContentValues?): Uri? = null
    override fun delete(u: Uri, s: String?, a: Array<out String>?): Int = 0
    override fun update(u: Uri, v: ContentValues?, s: String?, a: Array<out String>?): Int = 0
}

/** Son hatayı gösterir; "Kopyala" ile panoya alınıp sohbete yapıştırılabilir. Ayrı süreçte çalışır. */
class HataActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = HataYakalayici.dosya(this)
        val metin = if (f.exists()) f.readText() else "Kayıtlı hata yok."

        val pad = (16 * resources.displayMetrics.density).toInt()
        val kok = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val baslik = TextView(this).apply {
            text = "GameLingo PS5 çöktü. \"Kopyala\"ya basıp sohbete yapıştır."
            textSize = 18f
        }
        val dugmeler = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val kopyala = Button(this).apply {
            text = "Kopyala"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("GameLingo PS5 hata", metin))
                Toast.makeText(this@HataActivity, "Kopyalandı", Toast.LENGTH_SHORT).show()
            }
        }
        val kapat = Button(this).apply {
            text = "Kapat"
            setOnClickListener { finish() }
        }
        dugmeler.addView(kopyala)
        dugmeler.addView(kapat)
        val yazi = TextView(this).apply {
            text = metin
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        val kaydir = ScrollView(this).apply { addView(yazi) }
        kok.addView(baslik)
        kok.addView(dugmeler)
        kok.addView(kaydir, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(kok)
        kopyala.requestFocus()
    }
}
