package com.metallic.chiaki.gamelingo

import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.metallic.chiaki.common.exportAllSettings
import com.metallic.chiaki.common.getDatabase
import com.metallic.chiaki.common.importSettingsFromUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.random.Random

/**
 * Konsolu telefonda kaydet, TV'ye kodla gönder.
 *  - Telefon: menü → "Konsolu TV'ye gönder" → ekranda 4 haneli kod
 *  - TV:      menü → "Telefondan konsol al" (ya da ilk açılışta çıkan soru) → kodu yaz
 */
object Eslestirme {

    private const val PREFS = "gl_eslesme"

    fun tvMi(c: Context): Boolean =
        c.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
                c.packageManager.hasSystemFeature("android.software.leanback_only")

    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------- telefon: gönder

    fun gonder(a: AppCompatActivity) {
        a.lifecycleScope.launch {
            val db = getDatabase(a)
            val kayitli = withContext(Dispatchers.IO) { db.registeredHostDao().getAll().first() }
            if (kayitli.isEmpty()) {
                MaterialAlertDialogBuilder(a)
                    .setTitle("Önce konsolu kaydet")
                    .setMessage("Bu cihazda kayıtlı PS5 yok. Önce + düğmesinden \"Register Console\" ile PS5'ini kaydet, sonra TV'ye gönder.")
                    .setPositiveButton("Tamam", null)
                    .show()
                return@launch
            }
            val json = exportAllSettings(db)
            val kod = String.format("%04d", Random.nextInt(0, 10000))
            val ip = EslesmeAg.yerelIp()

            val wifi = a.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val kilit = try { wifi?.createMulticastLock("gl-eslesme")?.apply { setReferenceCounted(false); acquire() } } catch (_: Throwable) { null }

            val mesaj = TextView(a).apply {
                textSize = 16f
                setPadding(dp(a, 24), dp(a, 12), dp(a, 24), 0)
            }
            val adlar = kayitli.joinToString(", ") { it.serverNickname ?: it.serverMac.toString() }
            fun metin(durum: String) =
                "TV'de GameLingo PS5'i aç → menü → \"Telefondan konsol al\" ve bu kodu yaz:\n\n" +
                        "        $kod\n\n" +
                        "Gönderilecek konsol: $adlar\n" +
                        "Telefonun adresi: ${ip.ifEmpty { "?" }}\n\n$durum"
            mesaj.text = metin("TV bekleniyor… (bu pencere açık kalsın)")

            lateinit var sunucu: EslesmeAg.Sunucu
            sunucu = EslesmeAg.Sunucu(kod, { json }, { kimden ->
                a.runOnUiThread { mesaj.text = metin("Gönderildi ✓  ($kimden)\nTV'de \"İçe aktar\"a bas.") }
            })
            val acildi = sunucu.baslat()
            if (!acildi) mesaj.text = metin("Bağlantı açılamadı. Wi-Fi açık mı?")

            MaterialAlertDialogBuilder(a)
                .setTitle("Konsolu TV'ye gönder")
                .setView(mesaj)
                .setPositiveButton("Kapat", null)
                .setOnDismissListener {
                    sunucu.durdur()
                    try { kilit?.release() } catch (_: Throwable) {}
                }
                .show()
        }
    }

    // ------------------------------------------------------------------ TV: al

    fun al(a: AppCompatActivity, ipSor: Boolean = false, hataMesaji: String? = null) {
        val kutu = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 24), dp(a, 8), dp(a, 24), 0)
        }
        val kodGiris = EditText(a).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Telefondaki 4 haneli kod"
        }
        val ipGiris = EditText(a).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "Telefonun adresi (ör. 192.168.1.111)"
        }
        kutu.addView(kodGiris)
        if (ipSor) kutu.addView(ipGiris)

        MaterialAlertDialogBuilder(a)
            .setTitle("Telefondan konsol al")
            .setMessage(
                (hataMesaji?.let { "$it\n\n" } ?: "") +
                        "Telefonda GameLingo PS5'i aç → menü → \"Konsolu TV'ye gönder\". Ekranda çıkan kodu buraya yaz." +
                        (if (ipSor) "\n\nTelefon kendiliğinden bulunamadı; telefonda yazan adresi de gir." else "")
            )
            .setView(kutu)
            .setPositiveButton("Al") { _, _ -> cek(a, kodGiris.text.toString(), if (ipSor) ipGiris.text.toString() else "") }
            .setNegativeButton("Vazgeç", null)
            .show()
        kodGiris.requestFocus()
    }

    private fun cek(a: AppCompatActivity, kod: String, ip: String) {
        val bekle = MaterialAlertDialogBuilder(a).setMessage("Telefon aranıyor…").setCancelable(false).show()
        a.lifecycleScope.launch {
            val sonuc = withContext(Dispatchers.IO) { EslesmeAg.al(kod, ip) }
            try { bekle.dismiss() } catch (_: Throwable) {}
            when (sonuc) {
                is EslesmeAg.Sonuc.Tamam -> {
                    val f = File(a.cacheDir, "telefondan-konsol.json")
                    withContext(Dispatchers.IO) { f.writeText(sonuc.kayit, Charsets.UTF_8) }
                    a.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("alindi", true).apply()
                    importSettingsFromUri(a, Uri.fromFile(f), a.lifecycleScope)
                }
                is EslesmeAg.Sonuc.Hata -> al(a, ipSor = true, hataMesaji = sonuc.sebep)
            }
        }
    }

    // ------------------------------------------------- TV ilk açılış: kendiliğinden sor

    fun acilista(a: AppCompatActivity) {
        if (!tvMi(a)) return
        val prefs = a.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("alindi", false) || prefs.getBoolean("sorma", false)) return
        a.lifecycleScope.launch {
            val bos = withContext(Dispatchers.IO) { getDatabase(a).registeredHostDao().getAll().first().isEmpty() }
            if (!bos || a.isFinishing) return@launch
            MaterialAlertDialogBuilder(a)
                .setTitle("Konsolu telefondan al")
                .setMessage("PS5 kaydını TV kumandasıyla yazmak zahmetli. Telefonda kaydettiysen kodla buraya aktarabilirsin.")
                .setPositiveButton("Telefondan al") { _, _ -> al(a) }
                .setNegativeButton("Burada kaydet", null)
                .setNeutralButton("Bir daha sorma") { _, _ -> prefs.edit().putBoolean("sorma", true).apply() }
                .show()
        }
    }
}
