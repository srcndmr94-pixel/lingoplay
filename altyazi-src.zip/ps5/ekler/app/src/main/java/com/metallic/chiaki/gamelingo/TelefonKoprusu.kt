package com.metallic.chiaki.gamelingo

import android.app.Activity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.content.Context
import android.text.InputType
import android.widget.EditText
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Telefondaki GameLingo'nun yapay zekâsına bağlanır (GameLingo TV'deki köprünün aynısı).
 * Telefonda: GameLingo → "TV'ye yapay zekâ ver" açık olmalı; ekranda 4 haneli kod görünür.
 *
 * Protokol (UTF-8, satır satır):
 *   Bulma (UDP 47322):  "GLFIND <kod>" -> "GLHERE"
 *   Deneme (TCP 47321): "GL1 <kod> PING" -> "PONG 1/0"
 *   Çeviri (TCP 47321): "GL1 <kod> <sıra> <öncekiSayısı>" + tür + ad + satır + öncekiler
 *                       -> "OK <çeviri>" | "SKIP" | "ERR <sebep>"
 */
class TelefonKoprusu(private val activity: Activity) {

    companion object {
        private const val TCP_PORT = 47321
        private const val UDP_PORT = 47322
        private const val PREFS = "gl_kopru"
        private const val YEREL = "127.0.0.1"
        private fun tek(s: String) = s.replace('\n', ' ').replace('\r', ' ').trim()
    }

    sealed class Sonuc {
        class Tamam(val metin: String) : Sonuc()
        object Atla : Sonuc()
        class Hata(val sebep: String) : Sonuc()
    }

    private val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Volatile var hazir = false
        private set
    @Volatile private var son_deneme = 0L

    val kod: String get() = prefs.getString("kod", "") ?: ""
    private var host: String
        get() = prefs.getString("host", "") ?: ""
        set(v) { prefs.edit().putString("host", v).apply() }

    /** Kod hiç sorulmadıysa bir kere sorar; sonra telefonu arka planda arar. */
    fun hazirla(durum: (String) -> Unit) {
        if (kod.isEmpty() && !prefs.getBoolean("soruldu", false)) {
            koduSor(durum)
            return
        }
        bul(durum)
    }

    fun koduSor(durum: (String) -> Unit) {
        val giris = EditText(activity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "4 haneli kod"
            setText(kod)
        }
        try {
            MaterialAlertDialogBuilder(activity)
                .setTitle("Telefonun yapay zekâsı")
                .setMessage("Daha iyi çeviri için telefonda GameLingo'yu açıp \"TV'ye yapay zekâ ver\"i başlat " +
                        "ve ekrandaki 4 haneli kodu yaz.\n\nBoş bırakırsan hızlı çeviri kullanılır.")
                .setView(giris)
                .setPositiveButton("Bağlan") { _, _ ->
                    prefs.edit().putBoolean("soruldu", true)
                        .putString("kod", giris.text.toString().trim()).putString("host", "").apply()
                    bul(durum)
                }
                .setNegativeButton("Hızlı çeviri") { _, _ ->
                    prefs.edit().putBoolean("soruldu", true).apply()
                }
                .show()
        } catch (_: Throwable) {
        }
    }

    @Volatile private var sonMesaj: String? = null

    /** Telefonu arar ve hazır olup olmadığını öğrenir. (Ağ işi kendi iş parçacığında.) */
    fun bul(durum: (String) -> Unit) {
        val k = kod
        if (k.isEmpty()) { hazir = false; return }
        son_deneme = System.currentTimeMillis()
        Thread {
            var h = host
            var p = if (h.isNotEmpty()) ping(h, k) else null
            if (p == null) {
                // GameLingo aynı telefondaysa: ağda aramadan doğrudan telefonun kendisi
                p = ping(YEREL, k)
                if (p != null) { h = YEREL; host = YEREL }
            }
            if (p == null) {
                val bulunan = discover(k)
                if (bulunan != null) { h = bulunan; host = bulunan; p = ping(h, k) }
            }
            hazir = p == true
            val mesaj = when (p) {
                null -> "Telefon bulunamadı (GameLingo'da \"TV ve bilgisayara çeviri sağla\" açık mı?) · hızlı çeviri"
                false -> "Telefonda yapay zekâ modeli yüklü değil · hızlı çeviri"
                true -> "Telefonun yapay zekâsı bağlı"
            }
            // Aynı mesajı tekrar tekrar gösterme (30 sn'de bir deniyor, altyazıyı örtüyordu)
            if (mesaj != sonMesaj) {
                sonMesaj = mesaj
                activity.runOnUiThread { durum(mesaj) }
            }
        }.apply { isDaemon = true }.start()
    }

    /** Bağlantı koptuysa en fazla 30 sn'de bir yeniden dener. */
    fun gerekirseYenidenDene(durum: (String) -> Unit) {
        if (!hazir && kod.isNotEmpty() && System.currentTimeMillis() - son_deneme > 30_000) bul(durum)
    }

    /** Bir satırı telefona çevirtir. Arka planda çağır. */
    fun cevir(sira: Int, satir: String, onceki: List<String>): Sonuc {
        val h = host
        val k = kod
        if (h.isEmpty() || k.isEmpty()) return Sonuc.Hata("bağlı değil")
        val sb = StringBuilder()
        sb.append("GL1 ").append(tek(k)).append(' ').append(sira).append(' ').append(onceki.size).append('\n')
        sb.append("oyun\n")
        sb.append("PS5\n")
        sb.append(tek(satir)).append('\n')
        for (o in onceki) sb.append(tek(o)).append('\n')
        val r = istek(h, sb.toString(), 12000)
        if (r == null) { hazir = false; return Sonuc.Hata("telefona ulaşılamadı") }
        return when {
            r.startsWith("OK ") -> Sonuc.Tamam(r.substring(3).trim())
            r.startsWith("SKIP") -> Sonuc.Atla
            else -> Sonuc.Hata(r.removePrefix("ERR").trim())
        }
    }

    private fun ping(h: String, k: String): Boolean? {
        val r = istek(h, "GL1 ${tek(k)} PING\n", 3000) ?: return null
        if (!r.startsWith("PONG")) return null
        return r.trim().endsWith("1")
    }

    private fun discover(k: String): String? = try {
        DatagramSocket().use { s ->
            s.broadcast = true
            s.soTimeout = 2500
            val msg = "GLFIND ${tek(k)}".toByteArray(Charsets.UTF_8)
            s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("255.255.255.255"), UDP_PORT))
            val buf = ByteArray(64)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            val cevap = String(p.data, 0, p.length, Charsets.UTF_8)
            if (cevap.startsWith("GLHERE")) p.address.hostAddress else null
        }
    } catch (_: Throwable) {
        null
    }

    private fun istek(h: String, govde: String, sure: Int): String? = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(h, TCP_PORT), 2000)
            s.soTimeout = sure
            val w = OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8)
            w.write(govde)
            w.flush()
            BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8)).readLine()
        }
    } catch (_: Throwable) {
        null
    }
}
