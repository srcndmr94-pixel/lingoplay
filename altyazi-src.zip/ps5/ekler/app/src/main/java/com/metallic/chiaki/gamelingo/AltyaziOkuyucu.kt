package com.metallic.chiaki.gamelingo

import android.app.Activity
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.TextureView
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/**
 * GameLingo PS5: oyun görüntüsü kendi TextureView'imizde oynadığı için kareleri doğrudan
 * buradan alırız; ekran kaydı gerekmez, hiçbir şey engelleyemez.
 *
 * Akış: alt bölgeyi oku (ML Kit) → aynı satırsa atla → hızlı çeviri (ML Kit, taslak)
 *       → telefon bağlıysa yapay zekâ çevirisi (asıl) → oyunun üstünde göster.
 */
class AltyaziOkuyucu(
    private val activity: Activity,
    private val goruntu: TextureView,
    private val yazi: TextView
) {
    companion object {
        private const val ARALIK_MS = 350L          // tarama sıklığı
        private const val GIZLE_MS = 2500L          // yazı kaybolunca kutuyu gizle
        private const val OKUMA_GENISLIK = 960      // okunacak kare genişliği
        private const val UST_SINIR = 0.55f         // ekranın alt %45'i okunur
        private const val TASLAK_RENK = 0xFFD0D0D0.toInt()
        private const val ASIL_RENK = 0xFFFFE14D.toInt()
    }

    private val ana = Handler(Looper.getMainLooper())
    private val ag = Executors.newSingleThreadExecutor()
    private val tanima = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val cevirmen = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.TURKISH)
            .build()
    )
    private val kopru = TelefonKoprusu(activity)

    private var calisiyor = false
    private var mesgul = false
    private var modelHazir = false
    private var sonOkunan = ""
    private var sonGoruldu = 0L
    private var sira = 0
    private val oncekiler = ArrayDeque<String>()

    private val durumGoster: (String) -> Unit = { m ->
        try { Toast.makeText(activity, "GameLingo: $m", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
    }

    fun baslat() {
        if (calisiyor) return
        calisiyor = true
        yazi.visibility = View.GONE
        cevirmen.downloadModelIfNeeded()
            .addOnSuccessListener { modelHazir = true }
            .addOnFailureListener { durumGoster("Hızlı çeviri modeli indirilemedi (internet?)") }
        kopru.hazirla(durumGoster)
        ana.postDelayed(tur, 2000)
    }

    fun durdur() {
        calisiyor = false
        ana.removeCallbacksAndMessages(null)
        try { tanima.close() } catch (_: Throwable) {}
        try { cevirmen.close() } catch (_: Throwable) {}
        ag.shutdownNow()
    }

    private val tur = object : Runnable {
        override fun run() {
            if (!calisiyor) return
            try { tara() } catch (_: Throwable) { mesgul = false }
            if (yazi.visibility == View.VISIBLE && SystemClock.uptimeMillis() - sonGoruldu > GIZLE_MS)
                yazi.visibility = View.GONE
            ana.postDelayed(this, ARALIK_MS)
        }
    }

    private fun tara() {
        if (mesgul || !goruntu.isAvailable || goruntu.width < 64 || goruntu.height < 64) return
        val w = OKUMA_GENISLIK
        val h = (w.toFloat() * goruntu.height / goruntu.width).toInt().coerceAtLeast(120)
        val kare = goruntu.getBitmap(w, h) ?: return
        val y0 = (h * UST_SINIR).toInt()
        val kesit = Bitmap.createBitmap(kare, 0, y0, w, h - y0)
        if (kesit !== kare) kare.recycle()
        mesgul = true
        tanima.process(InputImage.fromBitmap(kesit, 0))
            .addOnSuccessListener { t -> okundu(satirlar(t)) }
            .addOnCompleteListener {
                kesit.recycle()
                mesgul = false
            }
    }

    /** Okunan satırları alttan yukarı sıralı tek bir altyazı satırına çevirir. */
    private fun satirlar(t: Text): String {
        val hepsi = ArrayList<Pair<Int, String>>()
        for (blok in t.textBlocks) for (satir in blok.lines) {
            val m = satir.text.replace('|', 'I').trim()
            if (m.count { it.isLetter() } >= 2) hepsi.add((satir.boundingBox?.top ?: 0) to m)
        }
        hepsi.sortBy { it.first }
        return hepsi.joinToString(" ") { it.second }.replace(Regex("\\s+"), " ").trim()
    }

    private fun sade(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun okundu(metin: String) {
        if (!calisiyor) return
        val simdi = SystemClock.uptimeMillis()
        if (metin.count { it.isLetter() } < 3) return
        sonGoruldu = simdi
        if (sade(metin) == sade(sonOkunan)) return
        sonOkunan = metin
        val s = ++sira
        val onceki = oncekiler.toList()
        oncekiler.addLast(metin)
        while (oncekiler.size > 2) oncekiler.removeFirst()

        val telefon = kopru.hazir
        if (modelHazir) {
            cevirmen.translate(metin).addOnSuccessListener { tr ->
                // Telefonun çevirisi daha önce geldiyse taslakla üstüne yazma.
                if (s == sira && (!telefon || yazi.tag != s)) goster(tr, taslak = telefon, s = -1)
            }
        }
        if (telefon) {
            ag.execute {
                val r = kopru.cevir(s, metin, onceki)
                ana.post {
                    if (!calisiyor || s != sira) return@post
                    if (r is TelefonKoprusu.Sonuc.Tamam && r.metin.isNotBlank()) goster(r.metin, taslak = false, s = s)
                    else if (r is TelefonKoprusu.Sonuc.Hata) {
                        yazi.setTextColor(ASIL_RENK)   // taslak kalıcı olsun
                        kopru.gerekirseYenidenDene(durumGoster)
                    }
                }
            }
        } else {
            kopru.gerekirseYenidenDene(durumGoster)
        }
    }

    private fun goster(metin: String, taslak: Boolean, s: Int) {
        yazi.text = metin
        yazi.setTextColor(if (taslak) TASLAK_RENK else ASIL_RENK)
        yazi.tag = s
        yazi.visibility = View.VISIBLE
        sonGoruldu = SystemClock.uptimeMillis()
    }
}
