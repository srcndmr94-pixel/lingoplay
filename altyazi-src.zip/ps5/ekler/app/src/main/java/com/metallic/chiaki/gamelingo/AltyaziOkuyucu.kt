package com.metallic.chiaki.gamelingo

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.util.TypedValue
import android.view.Gravity
import android.widget.FrameLayout
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.TextureView
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/**
 * GameLingo PS5: oyun görüntüsü kendi TextureView'imizde oynadığı için kareleri doğrudan
 * buradan alırız; ekran kaydı gerekmez, hiçbir şey engelleyemez.
 *
 * Akış: alt bölgeyi oku (ML Kit) → aynı satırsa atla → hızlı çeviri (ML Kit, taslak)
 *       → telefon bağlıysa yapay zekâ çevirisi (asıl) → İngilizce altyazının TAM ÜSTÜNDE,
 *       koyu siyah kutuda göster (İngilizce görünmez).
 *
 * Kutu İngilizceyi örtse de okuma bozulmaz: kareleri TextureView'den alıyoruz, kutu ise ayrı bir
 * görünüm; okunan karede kutu yok, İngilizce altyazı hep görünür. (Ekran kaydıyla bu yapılamaz.)
 */
class AltyaziOkuyucu(
    private val activity: Activity,
    private val goruntu: TextureView,
    private val yazi: TextView
) {
    companion object {
        private const val ARALIK_MS = 350L          // tarama sıklığı
        private const val GIZLE_MS = 2500L          // yazı kaybolunca kutuyu gizle
        private const val OKUMA_GENISLIK = 960      // okunacak kare genişliği
        private const val UST_SINIR = 0.55f         // ekranın alt %45'i okunur
        private const val TASLAK_RENK = 0xFFD0D0D0.toInt()
        private const val ASIL_RENK = 0xFFFFE14D.toInt()
    }

    private val ana = Handler(Looper.getMainLooper())
    private val ag = Executors.newSingleThreadExecutor()
    private val tanima = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val cevirmen = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.TURKISH)
            .build()
    )
    private val kopru = TelefonKoprusu(activity)

    private var calisiyor = false
    private var mesgul = false
    private var modelHazir = false
    private var sonOkunan = ""
    private var sonGoruldu = 0L
    private var sira = 0
    private val oncekiler = ArrayDeque<String>()

    /** Okunan altyazının karedeki yeri (0..1 oranları) ve satır sayısı. */
    private class Yer(val kutu: RectF, val satirSayisi: Int)
    private var sonYer: Yer? = null
    private val yerler = HashMap<Int, Yer>()

    private val durumGoster: (String) -> Unit = { m ->
        try { Toast.makeText(activity, "GameLingo: $m", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
    }

    fun baslat() {
        if (calisiyor) return
        calisiyor = true
        yazi.visibility = View.GONE
        cevirmen.downloadModelIfNeeded()
            .addOnSuccessListener { modelHazir = true }
            .addOnFailureListener { durumGoster("Hızlı çeviri modeli indirilemedi (internet?)") }
        kopru.hazirla(durumGoster)
        ana.postDelayed(tur, 2000)
    }

    fun durdur() {
        calisiyor = false
        ana.removeCallbacksAndMessages(null)
        try { tanima.close() } catch (_: Throwable) {}
        try { cevirmen.close() } catch (_: Throwable) {}
        ag.shutdownNow()
    }

    private val tur = object : Runnable {
        override fun run() {
            if (!calisiyor) return
            try { tara() } catch (_: Throwable) { mesgul = false }
            if (yazi.visibility == View.VISIBLE && SystemClock.uptimeMillis() - sonGoruldu > GIZLE_MS)
                yazi.visibility = View.GONE
            ana.postDelayed(this, ARALIK_MS)
        }
    }

    private fun tara() {
        if (mesgul || !goruntu.isAvailable || goruntu.width < 64 || goruntu.height < 64) return
        val w = OKUMA_GENISLIK
        val h = (w.toFloat() * goruntu.height / goruntu.width).toInt().coerceAtLeast(120)
        val kare = goruntu.getBitmap(w, h) ?: return
        val y0 = (h * UST_SINIR).toInt()
        val kesit = Bitmap.createBitmap(kare, 0, y0, w, h - y0)
        if (kesit !== kare) kare.recycle()
        mesgul = true
        tanima.process(InputImage.fromBitmap(kesit, 0))
            .addOnSuccessListener { t ->
                val (metin, yer) = satirlar(t, w, h, y0)
                okundu(metin, yer)
            }
            .addOnCompleteListener {
                kesit.recycle()
                mesgul = false
            }
    }

    /**
     * Okunan satırlardan altyazıyı seçer (menü paneli, tuş çubuğu gibi kenar yazıları atılır; bkz. [AltyaziSecici])
     * ve kutusunun karedeki yerini (0..1 oranı) döner. [w]x[h]: kare boyu, [y0]: kesitin karedeki üstü.
     */
    private fun satirlar(t: Text, w: Int, h: Int, y0: Int): Pair<String, Yer?> {
        if (w <= 0 || h <= 0) return "" to null
        val hepsi = ArrayList<AltyaziSecici.Satir>()
        for (blok in t.textBlocks) for (satir in blok.lines) {
            val b = satir.boundingBox ?: continue
            val m = satir.text.replace('|', 'I').trim()
            hepsi.add(AltyaziSecici.Satir(b.left.toFloat() / w, (b.top + y0).toFloat() / h,
                b.right.toFloat() / w, (b.bottom + y0).toFloat() / h, m))
        }
        val secim = AltyaziSecici.sec(hepsi) ?: return "" to null
        return secim.metin to Yer(RectF(secim.sol, secim.ust, secim.sag, secim.alt), secim.satirSayisi)
    }

    private fun sade(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun okundu(metin: String, yer: Yer?) {
        if (!calisiyor) return
        val simdi = SystemClock.uptimeMillis()
        if (metin.count { it.isLetter() } < 3) return
        sonGoruldu = simdi
        if (sade(metin) == sade(sonOkunan)) return
        sonOkunan = metin
        val s = ++sira
        if (yer != null) {
            yerler[s] = yer
            yerler.keys.filter { it < s - 5 }.forEach { yerler.remove(it) }
        }
        val onceki = oncekiler.toList()
        oncekiler.addLast(metin)
        while (oncekiler.size > 2) oncekiler.removeFirst()

        val telefon = kopru.hazir
        if (modelHazir) {
            cevirmen.translate(metin).addOnSuccessListener { tr ->
                // Telefonun çevirisi daha önce geldiyse taslakla üstüne yazma.
                if (s == sira && (!telefon || yazi.tag != s)) goster(tr, taslak = telefon, s = -1, yer = yerler[s])
            }
        }
        if (telefon) {
            ag.execute {
                val r = kopru.cevir(s, metin, onceki)
                ana.post {
                    if (!calisiyor || s != sira) return@post
                    if (r is TelefonKoprusu.Sonuc.Tamam && r.metin.isNotBlank()) goster(r.metin, taslak = false, s = s, yer = yerler[s])
                    else if (r is TelefonKoprusu.Sonuc.Hata) {
                        yazi.setTextColor(ASIL_RENK)   // taslak kalıcı olsun
                        kopru.gerekirseYenidenDene(durumGoster)
                    }
                }
            }
        } else {
            kopru.gerekirseYenidenDene(durumGoster)
        }
    }

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()

    /**
     * Kutuyu İngilizce altyazının HEMEN ALTINA, ona ortalı ve koyu siyah yerleştirir (telefondaki gibi).
     * Altta yer yoksa İngilizcenin hemen üstüne geçer. Yer bilinmiyorsa ekranın altında ortalı durur.
     * Kutunun yazısı önceden ayarlanmış olmalı (genişliği ona göre ölçülür).
     */
    private fun yerlestir(yer: Yer?) {
        val lp = (yazi.layoutParams as? FrameLayout.LayoutParams) ?: return
        val ana = yazi.parent as? View
        val ekranGen = ana?.width?.takeIf { it > 0 } ?: goruntu.width
        val ekranYuk = ana?.height?.takeIf { it > 0 } ?: goruntu.height
        val bosluk = dp(4)
        yazi.minHeight = 0
        yazi.minWidth = 0
        yazi.maxWidth = (ekranGen - dp(16)).coerceAtLeast(dp(120))
        lp.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        lp.rightMargin = 0; lp.marginEnd = 0
        if (yer == null || goruntu.width <= 0 || goruntu.height <= 0) {
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.topMargin = 0; lp.bottomMargin = dp(28)
            lp.leftMargin = 0; lp.marginStart = 0
            yazi.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            yazi.layoutParams = lp
            return
        }
        val g = IntArray(2); goruntu.getLocationInWindow(g)
        val p = IntArray(2); (ana ?: goruntu).getLocationInWindow(p)
        val ox = g[0] - p[0]; val oy = g[1] - p[1]
        val sol = ox + yer.kutu.left * goruntu.width
        val sag = ox + yer.kutu.right * goruntu.width
        val ust = oy + yer.kutu.top * goruntu.height
        val alt = oy + yer.kutu.bottom * goruntu.height
        // Yazı boyu İngilizce satırın boyuna yakın olsun (14–30 sp arası).
        val satirPx = (alt - ust) / yer.satirSayisi
        val sp = activity.resources.displayMetrics.scaledDensity
        yazi.setTextSize(TypedValue.COMPLEX_UNIT_PX, (satirPx * 0.78f).coerceIn(14f * sp, 30f * sp))
        yazi.measure(
            View.MeasureSpec.makeMeasureSpec(yazi.maxWidth, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val kGen = yazi.measuredWidth
        val kYuk = yazi.measuredHeight
        val kSol = ((sol + sag) / 2f - kGen / 2f).toInt().coerceIn(dp(8), maxOf(dp(8), ekranGen - kGen - dp(8)))
        var kUst = alt.toInt() + bosluk                        // İngilizcenin hemen altı
        if (kUst + kYuk > ekranYuk - bosluk) kUst = ust.toInt() - kYuk - bosluk   // sığmazsa üstü
        kUst = kUst.coerceIn(0, maxOf(0, ekranYuk - kYuk - bosluk))             // her durumda ekranda kalsın
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = kSol; lp.marginStart = kSol
        lp.topMargin = kUst.coerceAtLeast(0); lp.bottomMargin = 0
        yazi.layoutParams = lp
    }

    private fun goster(metin: String, taslak: Boolean, s: Int, yer: Yer? = null) {
        val y = yer ?: sonYer
        if (yer != null) sonYer = yer
        yazi.setBackgroundColor(Color.BLACK)   // koyu siyah bant
        yazi.text = metin                      // önce yazı: kutu genişliği ona göre ölçülür
        yazi.setTextColor(if (taslak) TASLAK_RENK else ASIL_RENK)
        yerlestir(y)
        yazi.tag = s
        yazi.visibility = View.VISIBLE
        sonGoruldu = SystemClock.uptimeMillis()
    }
}
