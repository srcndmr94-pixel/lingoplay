package com.metallic.chiaki.gamelingo

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.util.TypedValue
import android.view.Gravity
import android.widget.FrameLayout
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.TextureView
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/**
 * GameLingo PS5: oyun görüntüsü kendi TextureView'imizde oynadığı için kareleri doğrudan
 * buradan alırız; ekran kaydı gerekmez, hiçbir şey engelleyemez.
 *
 * Akış: alt bölgeyi oku (ML Kit) → aynı satırsa atla → hızlı çeviri (ML Kit, taslak)
 *       → telefon bağlıysa yapay zekâ çevirisi (asıl) → İngilizce altyazının TAM ÜSTÜNDE,
 *       koyu siyah kutuda göster (İngilizce görünmez).
 *
 * Kutu İngilizceyi örtse de okuma bozulmaz: kareleri TextureView'den alıyoruz, kutu ise ayrı bir
 * görünüm; okunan karede kutu yok, İngilizce altyazı hep görünür. (Ekran kaydıyla bu yapılamaz.)
 */
class AltyaziOkuyucu(
    private val activity: Activity,
    private val goruntu: TextureView,
    private val yazi: TextView
) {
    companion object {
        private const val ARALIK_MS = 350L          // tarama sıklığı
        private const val GIZLE_MS = 2500L          // yazı kaybolunca kutuyu gizle
        private const val OKUMA_GENISLIK = 960      // okunacak kare genişliği
        private const val UST_SINIR = 0.55f         // ekranın alt %45'i okunur
        private const val TASLAK_RENK = 0xFFD0D0D0.toInt()
        private const val ASIL_RENK = 0xFFFFE14D.toInt()
    }

    private val ana = Handler(Looper.getMainLooper())
    private val ag = Executors.newSingleThreadExecutor()
    private val tanima = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val cevirmen = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.TURKISH)
            .build()
    )
    private val kopru = TelefonKoprusu(activity)

    private var calisiyor = false
    private var mesgul = false
    private var modelHazir = false
    private var sonOkunan = ""
    private var sonGoruldu = 0L
    private var sira = 0
    private val oncekiler = ArrayDeque<String>()

    /** Okunan altyazının karedeki yeri (0..1 oranları) ve satır sayısı. */
    private class Yer(val kutu: RectF, val satirSayisi: Int)
    private var sonYer: Yer? = null
    private val yerler = HashMap<Int, Yer>()

    private val durumGoster: (String) -> Unit = { m ->
        try { Toast.makeText(activity, "GameLingo: $m", Toast.LENGTH_SHORT).show() } catch (_: Throwable) {}
    }

    fun baslat() {
        if (calisiyor) return
        calisiyor = true
        yazi.visibility = View.GONE
        cevirmen.downloadModelIfNeeded()
            .addOnSuccessListener { modelHazir = true }
            .addOnFailureListener { durumGoster("Hızlı çeviri modeli indirilemedi (internet?)") }
        kopru.hazirla(durumGoster)
        ana.postDelayed(tur, 2000)
    }

    fun durdur() {
        calisiyor = false
        ana.removeCallbacksAndMessages(null)
        try { tanima.close() } catch (_: Throwable) {}
        try { cevirmen.close() } catch (_: Throwable) {}
        ag.shutdownNow()
    }

    private val tur = object : Runnable {
        override fun run() {
            if (!calisiyor) return
            try { tara() } catch (_: Throwable) { mesgul = false }
            if (yazi.visibility == View.VISIBLE && SystemClock.uptimeMillis() - sonGoruldu > GIZLE_MS)
                yazi.visibility = View.GONE
            ana.postDelayed(this, ARALIK_MS)
        }
    }

    private fun tara() {
        if (mesgul || !goruntu.isAvailable || goruntu.width < 64 || goruntu.height < 64) return
        val w = OKUMA_GENISLIK
        val h = (w.toFloat() * goruntu.height / goruntu.width).toInt().coerceAtLeast(120)
        val kare = goruntu.getBitmap(w, h) ?: return
        val y0 = (h * UST_SINIR).toInt()
        val kesit = Bitmap.createBitmap(kare, 0, y0, w, h - y0)
        if (kesit !== kare) kare.recycle()
        mesgul = true
        tanima.process(InputImage.fromBitmap(kesit, 0))
            .addOnSuccessListener { t ->
                val (metin, yer) = satirlar(t, w, h, y0)
                okundu(metin, yer)
            }
            .addOnCompleteListener {
                kesit.recycle()
                mesgul = false
            }
    }

    /**
     * Okunan satırları yukarıdan aşağı tek bir altyazı satırına çevirir; ayrıca hepsini kapsayan
     * kutunun karedeki yerini (0..1 oranı) döner. [w]x[h]: kare boyu, [y0]: kesitin karedeki üstü.
     */
    private fun satirlar(t: Text, w: Int, h: Int, y0: Int): Pair<String, Yer?> {
        val hepsi = ArrayList<Pair<Int, String>>()
        var sol = Int.MAX_VALUE; var ust = Int.MAX_VALUE; var sag = Int.MIN_VALUE; var alt = Int.MIN_VALUE
        for (blok in t.textBlocks) for (satir in blok.lines) {
            val m = satir.text.replace('|', 'I').trim()
            if (m.count { it.isLetter() } < 2) continue
            val b = satir.boundingBox
            hepsi.add((b?.top ?: 0) to m)
            if (b != null) {
                sol = minOf(sol, b.left); ust = minOf(ust, b.top)
                sag = maxOf(sag, b.right); alt = maxOf(alt, b.bottom)
            }
        }
        hepsi.sortBy { it.first }
        val metin = hepsi.joinToString(" ") { it.second }.replace(Regex("\\s+"), " ").trim()
        val yer = if (sol < sag && ust < alt && w > 0 && h > 0) Yer(
            RectF(sol.toFloat() / w, (ust + y0).toFloat() / h, sag.toFloat() / w, (alt + y0).toFloat() / h),
            hepsi.size.coerceAtLeast(1)
        ) else null
        return metin to yer
    }

    private fun sade(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun okundu(metin: String, yer: Yer?) {
        if (!calisiyor) return
        val simdi = SystemClock.uptimeMillis()
        if (metin.count { it.isLetter() } < 3) return
        sonGoruldu = simdi
        if (sade(metin) == sade(sonOkunan)) return
        sonOkunan = metin
        val s = ++sira
        if (yer != null) {
            yerler[s] = yer
            yerler.keys.filter { it < s - 5 }.forEach { yerler.remove(it) }
        }
        val onceki = oncekiler.toList()
        oncekiler.addLast(metin)
        while (oncekiler.size > 2) oncekiler.removeFirst()

        val telefon = kopru.hazir
        if (modelHazir) {
            cevirmen.translate(metin).addOnSuccessListener { tr ->
                // Telefonun çevirisi daha önce geldiyse taslakla üstüne yazma.
                if (s == sira && (!telefon || yazi.tag != s)) goster(tr, taslak = telefon, s = -1, yer = yerler[s])
            }
        }
        if (telefon) {
            ag.execute {
                val r = kopru.cevir(s, metin, onceki)
                ana.post {
                    if (!calisiyor || s != sira) return@post
                    if (r is TelefonKoprusu.Sonuc.Tamam && r.metin.isNotBlank()) goster(r.metin, taslak = false, s = s, yer = yerler[s])
                    else if (r is TelefonKoprusu.Sonuc.Hata) {
                        yazi.setTextColor(ASIL_RENK)   // taslak kalıcı olsun
                        kopru.gerekirseYenidenDene(durumGoster)
                    }
                }
            }
        } else {
            kopru.gerekirseYenidenDene(durumGoster)
        }
    }

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()

    /**
     * Kutuyu İngilizce altyazının tam üstüne, onu örtecek kadar büyük ve koyu siyah yerleştirir.
     * Yer bilinmiyorsa ekranın üstünde ortalı durur.
     */
    private fun yerlestir(yer: Yer?) {
        val lp = (yazi.layoutParams as? FrameLayout.LayoutParams) ?: return
        val pay = dp(8)
        if (yer == null || goruntu.width <= 0 || goruntu.height <= 0) {
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.topMargin = dp(24); lp.leftMargin = dp(48); lp.rightMargin = dp(48)
            lp.marginStart = dp(48); lp.marginEnd = dp(48)
            lp.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            yazi.minHeight = 0
            yazi.minWidth = 0
            yazi.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            yazi.layoutParams = lp
            return
        }
        val g = IntArray(2); goruntu.getLocationInWindow(g)
        val p = IntArray(2); ((yazi.parent as? View) ?: goruntu).getLocationInWindow(p)
        val ox = g[0] - p[0]; val oy = g[1] - p[1]
        val sol = ox + (yer.kutu.left * goruntu.width).toInt()
        val ust = oy + (yer.kutu.top * goruntu.height).toInt()
        val gen = ((yer.kutu.right - yer.kutu.left) * goruntu.width).toInt()
        val yuk = ((yer.kutu.bottom - yer.kutu.top) * goruntu.height).toInt()
        val ekranGen = (yazi.parent as? View)?.width ?: goruntu.width
        // Türkçe genelde daha uzun: kutu en az İngilizce kadar, gerekirse daha geniş (ortası aynı kalır).
        val kutuGen = maxOf(gen + 2 * pay, dp(220)).coerceAtMost(ekranGen - dp(16))
        val kutuSol = (sol + gen / 2 - kutuGen / 2).coerceIn(dp(8), maxOf(dp(8), ekranGen - kutuGen - dp(8)))
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = kutuSol; lp.marginStart = kutuSol
        lp.rightMargin = 0; lp.marginEnd = 0
        lp.topMargin = (ust - pay).coerceAtLeast(0)
        lp.width = kutuGen
        yazi.minHeight = yuk + 2 * pay
        // Yazı boyu İngilizce satırın boyuna yakın olsun (14–34 sp arası).
        val satirPx = yuk.toFloat() / yer.satirSayisi
        val sp = activity.resources.displayMetrics.scaledDensity
        yazi.setTextSize(TypedValue.COMPLEX_UNIT_PX, (satirPx * 0.78f).coerceIn(14f * sp, 34f * sp))
        yazi.layoutParams = lp
    }

    private fun goster(metin: String, taslak: Boolean, s: Int, yer: Yer? = null) {
        val y = yer ?: sonYer
        if (yer != null) sonYer = yer
        yazi.setBackgroundColor(Color.BLACK)   // koyu siyah: arkadaki İngilizce görünmez
        yerlestir(y)
        yazi.text = metin
        yazi.setTextColor(if (taslak) TASLAK_RENK else ASIL_RENK)
        yazi.tag = s
        yazi.visibility = View.VISIBLE
        sonGoruldu = SystemClock.uptimeMillis()
    }
}
