package com.metallic.chiaki.gamelingo

/**
 * Ekranın alt kısmında okunan bütün yazılardan altyazıyı seçer (saf Kotlin, Android'siz; JVM'de test edilir).
 *
 * Oyun ekranının altında altyazıdan başka şeyler de olur: menü panelleri ("Damage 17", "Customize"),
 * tuş çubuğu ("Close · Tutorials · Rotate"), harita, can barı. Hepsini birleştirince saçma bir cümle çıkıyordu.
 *  - Altyazı ortadadır: ortası ekranın %32–%68'i dışında kalan satırlar atılır.
 *  - Satırlar alt alta öbeklere ayrılır (araya bir satır boyundan fazla boşluk girerse yeni öbek).
 *  - En çok harf içeren öbek altyazıdır (kısa tuş ipuçları altyazının yerine geçmesin); eşitse alttaki.
 *  - En çok 3 satır.
 * Bütün ölçüler karenin 0..1 oranıdır.
 */
object AltyaziSecici {
    data class Satir(val sol: Float, val ust: Float, val sag: Float, val alt: Float, val metin: String)
    data class Secim(val metin: String, val sol: Float, val ust: Float, val sag: Float, val alt: Float, val satirSayisi: Int)

    private const val ORTA_MIN = 0.32f
    private const val ORTA_MAX = 0.68f

    fun sec(hepsi: List<Satir>): Secim? {
        val orta = hepsi.filter { s ->
            val m = s.metin.trim()
            val x = (s.sol + s.sag) / 2f
            m.count { it.isLetter() } >= 2 && x in ORTA_MIN..ORTA_MAX && s.alt > s.ust
        }.sortedBy { it.ust }
        if (orta.isEmpty()) return null
        val boylar = orta.map { it.alt - it.ust }.sorted()
        val boy = boylar[boylar.size / 2].coerceAtLeast(0.005f)

        // aynı yükseklikteki parçalar aynı satır
        val satirlar = ArrayList<MutableList<Satir>>()
        for (s in orta) {
            val son = satirlar.lastOrNull()
            if (son != null && kotlin.math.abs(s.ust - son.first().ust) < boy * 0.6f) son.add(s) else satirlar.add(mutableListOf(s))
        }
        // satırları öbeklere ayır
        val obekler = ArrayList<MutableList<MutableList<Satir>>>()
        for (st in satirlar) {
            val son = obekler.lastOrNull()
            val oncekiAlt = son?.last()?.maxOf { it.alt }
            if (son != null && oncekiAlt != null && st.minOf { it.ust } - oncekiAlt <= boy * 1.0f && son.size < 3) son.add(st)
            else obekler.add(mutableListOf(st))
        }
        val secilen = obekler.withIndex().maxWith(compareBy({ ob -> harf(ob.value) }, { it.index })).value

        val metin = secilen.joinToString(" ") { st -> st.sortedBy { it.sol }.joinToString(" ") { it.metin.trim() } }
            .replace(Regex("\\s+"), " ").trim()
        val parcalar = secilen.flatten()
        return Secim(metin, parcalar.minOf { it.sol }, parcalar.minOf { it.ust }, parcalar.maxOf { it.sag },
            parcalar.maxOf { it.alt }, secilen.size)
    }

    private fun harf(ob: List<List<Satir>>) = ob.sumOf { st -> st.sumOf { s -> s.metin.count { it.isLetter() } } }
}
