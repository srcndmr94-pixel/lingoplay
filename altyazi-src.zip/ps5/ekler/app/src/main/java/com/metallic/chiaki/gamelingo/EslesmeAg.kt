package com.metallic.chiaki.gamelingo

import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException

/**
 * Konsol kaydını telefondan TV'ye aktaran ağ kısmı (Android'e bağlı değil, bilgisayarda test edilir).
 *
 * Telefon (gönderen) sunucu olur, ekranda 4 haneli kod gösterir. TV (alan) kodla arar ve kaydı çeker.
 *   Bulma (UDP 47324, yayın):  "GLPS5 <kod>"     -> "GLPS5HERE"
 *   Alma  (TCP 47323):         "GLPS5 <kod> AL"  -> "OK <bayt>\n" + kayıt (JSON)  |  "ERR <sebep>"
 * Her şey ev Wi-Fi'ının içinde kalır.
 */
object EslesmeAg {
    const val TCP_PORT = 47323
    const val UDP_PORT = 47324
    private const val EN_FAZLA = 1_000_000

    fun yerelIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }?.hostAddress ?: ""
    } catch (_: Throwable) {
        ""
    }

    /** Gönderen taraf. [durdur] çağrılana kadar istekleri karşılar. */
    class Sunucu(
        private val kod: String,
        private val kayit: () -> String,
        private val gonderildi: (String) -> Unit,
        private val tcpPort: Int = TCP_PORT,
        private val udpPort: Int = UDP_PORT
    ) {
        @Volatile private var calisiyor = false
        private var tcp: ServerSocket? = null
        private var udp: DatagramSocket? = null

        fun baslat(): Boolean {
            calisiyor = true
            return try {
                tcp = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(tcpPort)) }
                try {
                    udp = DatagramSocket(null).apply { reuseAddress = true; broadcast = true; bind(InetSocketAddress(udpPort)) }
                } catch (_: Throwable) {
                    udp = null   // bulma olmasa da IP ile alınabilir
                }
                Thread({ tcpDongu() }, "gl-eslesme-tcp").apply { isDaemon = true }.start()
                udp?.let { Thread({ udpDongu(it) }, "gl-eslesme-udp").apply { isDaemon = true }.start() }
                true
            } catch (_: Throwable) {
                durdur()
                false
            }
        }

        fun durdur() {
            calisiyor = false
            try { tcp?.close() } catch (_: Throwable) {}
            try { udp?.close() } catch (_: Throwable) {}
        }

        private fun udpDongu(s: DatagramSocket) {
            val buf = ByteArray(128)
            while (calisiyor) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    val m = String(p.data, 0, p.length, Charsets.UTF_8).trim()
                    if (m == "GLPS5 $kod") {
                        val r = "GLPS5HERE".toByteArray(Charsets.UTF_8)
                        s.send(DatagramPacket(r, r.size, p.address, p.port))
                    }
                } catch (_: Throwable) {
                    if (!calisiyor) return
                }
            }
        }

        private fun tcpDongu() {
            val ss = tcp ?: return
            while (calisiyor) {
                val c = try { ss.accept() } catch (_: Throwable) { if (!calisiyor) return else continue }
                Thread {
                    c.use { soket ->
                        try {
                            soket.soTimeout = 5000
                            val satir = BufferedReader(InputStreamReader(soket.getInputStream(), Charsets.UTF_8)).readLine()?.trim() ?: ""
                            val o = soket.getOutputStream()
                            if (satir != "GLPS5 $kod AL") {
                                o.write("ERR kod yanlış\n".toByteArray(Charsets.UTF_8)); o.flush(); return@use
                            }
                            val veri = kayit().toByteArray(Charsets.UTF_8)
                            o.write("OK ${veri.size}\n".toByteArray(Charsets.UTF_8))
                            o.write(veri)
                            o.flush()
                            gonderildi(soket.inetAddress.hostAddress ?: "?")
                        } catch (_: Throwable) {
                        }
                    }
                }.apply { isDaemon = true }.start()
            }
        }
    }

    sealed class Sonuc {
        class Tamam(val kayit: String, val kimden: String) : Sonuc()
        class Hata(val sebep: String) : Sonuc()
    }

    /** Alan taraf: [ip] boşsa telefonu kodla ağda arar. Arka planda çağır. */
    fun al(kod: String, ip: String = "", tcpPort: Int = TCP_PORT, udpPort: Int = UDP_PORT): Sonuc {
        val k = kod.trim()
        if (k.isEmpty()) return Sonuc.Hata("Kod boş")
        val hedef = ip.trim().ifEmpty { bul(k, udpPort) ?: return Sonuc.Hata("Telefon bulunamadı") }
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(hedef, tcpPort), 3000)
                s.soTimeout = 8000
                s.getOutputStream().apply { write("GLPS5 $k AL\n".toByteArray(Charsets.UTF_8)); flush() }
                val giris = s.getInputStream()
                val bas = satirOku(giris)
                when {
                    bas.startsWith("OK ") -> {
                        val boy = bas.removePrefix("OK ").trim().toIntOrNull() ?: return Sonuc.Hata("Bozuk cevap")
                        if (boy <= 0 || boy > EN_FAZLA) return Sonuc.Hata("Bozuk cevap")
                        val veri = ByteArray(boy)
                        var okunan = 0
                        while (okunan < boy) {
                            val n = giris.read(veri, okunan, boy - okunan)
                            if (n < 0) return Sonuc.Hata("Aktarım yarıda kesildi")
                            okunan += n
                        }
                        Sonuc.Tamam(String(veri, Charsets.UTF_8), hedef)
                    }
                    bas.startsWith("ERR") -> Sonuc.Hata(bas.removePrefix("ERR").trim().replaceFirstChar { it.uppercase() })
                    else -> Sonuc.Hata("Bozuk cevap")
                }
            }
        } catch (_: SocketTimeoutException) {
            Sonuc.Hata("Telefon cevap vermedi")
        } catch (_: Throwable) {
            Sonuc.Hata("Telefona bağlanılamadı ($hedef)")
        }
    }

    private fun satirOku(g: java.io.InputStream): String {
        val b = ByteArrayOutputStream()
        while (b.size() < 256) {
            val c = g.read()
            if (c < 0 || c == '\n'.code) break
            b.write(c)
        }
        return String(b.toByteArray(), Charsets.UTF_8).trim()
    }

    private fun bul(kod: String, udpPort: Int): String? {
        repeat(3) {
            try {
                DatagramSocket().use { s ->
                    s.broadcast = true
                    s.soTimeout = 1500
                    val m = "GLPS5 $kod".toByteArray(Charsets.UTF_8)
                    s.send(DatagramPacket(m, m.size, InetAddress.getByName("255.255.255.255"), udpPort))
                    val buf = ByteArray(64)
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    if (String(p.data, 0, p.length, Charsets.UTF_8).startsWith("GLPS5HERE"))
                        return p.address.hostAddress
                }
            } catch (_: Throwable) {
            }
        }
        return null
    }
}
