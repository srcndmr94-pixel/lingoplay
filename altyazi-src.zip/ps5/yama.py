#!/usr/bin/env python3
"""
GameLingo PS5 yaması.

chiaki-ng'nin Android uygulamasını (açık kaynak PS5 Remote Play) alır ve şunları yapar:
  * adı "GameLingo PS5", paket adı com.example.altyazi.ps5 (Pylux / Chiaki ile çakışmaz)
  * oyun görüntüsü SurfaceView yerine TextureView'de oynar → kareleri kendimiz okuruz
  * AltyaziOkuyucu: alt bölgeyi okur, ML Kit ile hızlı çevirir, telefon bağlıysa
    telefonun yapay zekâsıyla düzeltir ve oyunun üstünde gösterir
  * GameLingo'nun imza anahtarıyla imzalanır (güncellemede kaldırıp kurmak gerekmez)

Kullanım:  python3 yama.py <chiaki-ng klasörü> <ps5 klasörü>
Her değişiklik tam bir kez uygulanmalı; bulunamazsa derleme hemen durur.
"""
import os
import shutil
import sys


def degistir(yol, eski, yeni, adet=1):
    with open(yol, encoding="utf-8") as f:
        metin = f.read()
    bulunan = metin.count(eski)
    if bulunan != adet:
        sys.exit(f"YAMA HATASI: {yol}\n  aranan {adet} kez bekleniyordu, {bulunan} kez bulundu:\n  {eski!r}")
    metin = metin.replace(eski, yeni)
    with open(yol, "w", encoding="utf-8") as f:
        f.write(metin)
    print(f"  tamam: {os.path.relpath(yol)}")


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    kok = os.path.join(sys.argv[1], "android")
    ps5 = sys.argv[2]
    app = os.path.join(kok, "app")
    src = os.path.join(app, "src", "main")
    java = os.path.join(src, "java", "com", "metallic", "chiaki")

    # 1) Kendi dosyalarımızı kopyala (gamelingo/*.kt, imza anahtarı)
    ekler = os.path.join(ps5, "ekler")
    for kl, _, dosyalar in os.walk(ekler):
        for d in dosyalar:
            kaynak = os.path.join(kl, d)
            hedef = os.path.join(kok, os.path.relpath(kaynak, ekler))
            os.makedirs(os.path.dirname(hedef), exist_ok=True)
            shutil.copyfile(kaynak, hedef)
            print(f"  eklendi: {os.path.relpath(hedef, kok)}")

    # 2) build.gradle: paket adı, mimariler, imza, ML Kit
    g = os.path.join(app, "build.gradle")
    degistir(g, 'applicationId "com.metallic.chiaki"', 'applicationId "com.example.altyazi.ps5"')
    degistir(g, "        versionName chiakiVersion\n",
             "        versionName \"PS5 1.1 (chiaki \" + chiakiVersion + \")\"\n"
             "        ndk { abiFilters 'armeabi-v7a', 'arm64-v8a' }\n")
    degistir(g, "    signingConfigs {\n        release\n    }\n",
             "    signingConfigs {\n        release\n"
             "        debug {\n"
             "            storeFile file('gl-debug.keystore')\n"
             "            storePassword 'android'\n"
             "            keyAlias 'androiddebugkey'\n"
             "            keyPassword 'android'\n"
             "        }\n"
             "    }\n")
    degistir(g, "    implementation libs.oboe\n",
             "    implementation libs.oboe\n"
             "    implementation 'com.google.mlkit:text-recognition:16.0.1'\n"
             "    implementation 'com.google.mlkit:translate:17.0.3'\n")

    # 3) Ad
    degistir(os.path.join(src, "res", "values", "strings.xml"),
             '<string name="app_name">Chiaki</string>', '<string name="app_name">GameLingo PS5</string>')

    # 4) Dosya paylaşımı yetkisi başka Chiaki/Pylux kurulumuyla çakışmasın
    degistir(os.path.join(src, "AndroidManifest.xml"),
             'android:authorities="com.metallic.chiaki.fileprovider"',
             'android:authorities="com.example.altyazi.ps5.fileprovider"')
    degistir(os.path.join(java, "common", "LogManager.kt"),
             'val fileProviderAuthority = "com.metallic.chiaki.fileprovider"',
             'val fileProviderAuthority = "com.example.altyazi.ps5.fileprovider"')

    # 4b) Çökme raporu: uygulama çökerse hatayı gösteren ekran
    degistir(os.path.join(src, "AndroidManifest.xml"),
             "    </application>\n",
             '        <provider\n'
             '            android:name="com.metallic.chiaki.gamelingo.HataYakalayici"\n'
             '            android:authorities="com.example.altyazi.ps5.hata"\n'
             '            android:exported="false"\n'
             '            android:initOrder="1000" />\n'
             '\n'
             '        <activity\n'
             '            android:name="com.metallic.chiaki.gamelingo.HataActivity"\n'
             '            android:process=":hata"\n'
             '            android:exported="false"\n'
             '            android:theme="@android:style/Theme.DeviceDefault" />\n'
             "    </application>\n")

    # 4c) Paket adı değişince "." ile başlayan kısa sınıf adları yanlış pakete gider:
    #     tam adlarını yaz (yoksa ana ekran açılırken çöker)
    ana = os.path.join(src, "res", "layout", "activity_main.xml")
    degistir(ana, 'app:layout_behavior=".main.FloatingActionButtonBackgroundBehavior"',
             'app:layout_behavior="com.metallic.chiaki.main.FloatingActionButtonBackgroundBehavior"')
    degistir(ana, 'app:layout_behavior=".main.FloatingActionButtonSpeedDialBehavior"',
             'app:layout_behavior="com.metallic.chiaki.main.FloatingActionButtonSpeedDialBehavior"')
    import re
    for kl, _, dosyalar in os.walk(os.path.join(src, "res")):
        for d in dosyalar:
            if d.endswith(".xml"):
                with open(os.path.join(kl, d), encoding="utf-8") as f:
                    m = re.findall(r'(?<!tools:context)(?<!android:name)="\.[a-z]+\.[A-Z]\w+"', f.read())
                if m:
                    sys.exit(f"YAMA HATASI: {d} içinde kısa sınıf adı kaldı: {m}")

    # 4d) Telefondan TV'ye konsol aktarma (kodla eşleşme)
    degistir(os.path.join(src, "AndroidManifest.xml"),
             '    <uses-permission android:name="android.permission.INTERNET" />\n',
             '    <uses-permission android:name="android.permission.INTERNET" />\n'
             '    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />\n'
             '    <uses-permission android:name="android.permission.CHANGE_WIFI_MULTICAST_STATE" />\n')
    degistir(os.path.join(src, "res", "menu", "main.xml"),
             "</menu>",
             '    <item\n'
             '        android:id="@+id/gl_konsol_gonder"\n'
             '        android:title="Konsolu TV\\\'ye gönder"\n'
             '        app:showAsAction="never" />\n'
             '\n'
             '    <item\n'
             '        android:id="@+id/gl_konsol_al"\n'
             '        android:title="Telefondan konsol al"\n'
             '        app:showAsAction="never" />\n'
             "</menu>")
    mact = os.path.join(java, "main", "MainActivity.kt")
    degistir(mact,
             "		R.id.action_settings ->\n",
             "		R.id.gl_konsol_gonder ->\n"
             "		{\n"
             "			com.metallic.chiaki.gamelingo.Eslestirme.gonder(this)\n"
             "			true\n"
             "		}\n"
             "\n"
             "		R.id.gl_konsol_al ->\n"
             "		{\n"
             "			com.metallic.chiaki.gamelingo.Eslestirme.al(this)\n"
             "			true\n"
             "		}\n"
             "\n"
             "		R.id.action_settings ->\n")
    degistir(mact,
             "			updateEmptyInfo()\n		})\n	}\n\n	private fun updateEmptyInfo()",
             "			updateEmptyInfo()\n		})\n"
             "		com.metallic.chiaki.gamelingo.Eslestirme.acilista(this)\n"
             "	}\n\n	private fun updateEmptyInfo()")

    # 5) Oyun ekranı: TextureView + altyazı kutusu
    lay = os.path.join(src, "res", "layout", "activity_stream.xml")
    degistir(lay,
             '        <SurfaceView\n'
             '            android:id="@+id/surfaceView"\n'
             '            android:layout_width="wrap_content"\n'
             '            android:layout_height="wrap_content"/>\n'
             '    </com.metallic.chiaki.stream.AspectRatioFrameLayout>\n',
             '        <TextureView\n'
             '            android:id="@+id/textureView"\n'
             '            android:layout_width="match_parent"\n'
             '            android:layout_height="match_parent"/>\n'
             '    </com.metallic.chiaki.stream.AspectRatioFrameLayout>\n'
             '\n'
             '    <TextView\n'
             '        android:id="@+id/glAltyazi"\n'
             '        android:layout_width="wrap_content"\n'
             '        android:layout_height="wrap_content"\n'
             '        android:layout_gravity="bottom|center_horizontal"\n'
             '        android:layout_marginBottom="28dp"\n'
             '        android:layout_marginStart="48dp"\n'
             '        android:layout_marginEnd="48dp"\n'
             '        android:background="#FF000000"\n'
             '        android:paddingStart="16dp"\n'
             '        android:paddingEnd="16dp"\n'
             '        android:paddingTop="8dp"\n'
             '        android:paddingBottom="8dp"\n'
             '        android:gravity="center"\n'
             '        android:textSize="24sp"\n'
             '        android:textStyle="bold"\n'
             '        android:textColor="#FFFFE14D"\n'
             '        android:shadowColor="#FF000000"\n'
             '        android:shadowRadius="4"\n'
             '        android:focusable="false"\n'
             '        android:clickable="false"\n'
             '        android:visibility="gone"/>\n')

    # 5b) Dokunmatik kol tuşları varsayılan KAPALI (gerçek kol ya da TV kumandası kullanılır).
    #     Anahtar adı değişir: eski "açık" kaydı geçersiz kalır. Ekrana dokununca çıkan menüden açılabilir.
    degistir(os.path.join(src, "res", "values", "strings.xml"),
             '<string name="preferences_on_screen_controls_enabled_key">on_screen_controls_enabled</string>',
             '<string name="preferences_on_screen_controls_enabled_key">gl_on_screen_controls_enabled</string>')
    degistir(os.path.join(java, "common", "Preferences.kt"),
             "		get() = sharedPreferences.getBoolean(onScreenControlsEnabledKey, true)\n",
             "		get() = sharedPreferences.getBoolean(onScreenControlsEnabledKey, false)\n")
    # 5c) Tam ekran: varsayılan görüntü "Esnet" (kesme yok, altyazı hep görünür; yanlarda siyah bant yok).
    degistir(lay,
             'app:checkedButton="@id/display_mode_normal_button">',
             'app:checkedButton="@id/display_mode_stretch_button">')

    act = os.path.join(java, "stream", "StreamActivity.kt")
    degistir(act,
             "\tprivate val uiVisibilityHandler = Handler(Looper.getMainLooper())\n",
             "\tprivate val uiVisibilityHandler = Handler(Looper.getMainLooper())\n"
             "\tprivate var glOkuyucu: com.metallic.chiaki.gamelingo.AltyaziOkuyucu? = null\n")
    degistir(act,
             "\t\tviewModel.session.attachToSurfaceView(binding.surfaceView)\n",
             "\t\tviewModel.session.attachToTextureView(binding.textureView)\n"
             "\t\tglOkuyucu = com.metallic.chiaki.gamelingo.AltyaziOkuyucu(this, binding.textureView, binding.glAltyazi)\n"
             "\t\tglOkuyucu?.baslat()\n")
    degistir(act,
             "\t\tsuper.onDestroy()\n\t\tcontrolsJob?.cancel()\n",
             "\t\tsuper.onDestroy()\n\t\tcontrolsJob?.cancel()\n\t\tglOkuyucu?.durdur()\n\t\tglOkuyucu = null\n")

    print("GameLingo PS5 yaması uygulandı.")


if __name__ == "__main__":
    main()
