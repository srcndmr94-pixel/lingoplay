"""GameLingo PC'yi derler (GitHub Actions, Windows). Derleme adımları zip'in içinde durur:
PC tarafında yeni bir paket gerekirse yalnızca bu dosya ve gereksinimler.txt değişir,
GitHub'daki build.yml'ye dokunmak gerekmez.

  python kaynak/pc/derle.py        -> dist/LingoPlay.exe + dist/model-testi.txt
"""
import os
import subprocess
import sys

PC = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.abspath("dist")


def calistir(komut, **k):
    print(">", " ".join(komut), flush=True)
    return subprocess.run(komut, **k).returncode


def main():
    # 1) Paketler
    if calistir([sys.executable, "-m", "pip", "install", "-r", os.path.join(PC, "gereksinimler.txt")]) != 0:
        sys.exit("Paketler kurulamadı")

    # 2) Kurulan çeviri motoru gerçekten açılıyor mu (EXE'den önce, açık hata mesajı için)
    calistir([sys.executable, "-c", "import ctranslate2, sentencepiece; print('ctranslate2', ctranslate2.__version__)"])

    # 3) EXE
    komut = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--onefile", "--noconsole", "--name", "LingoPlay",
             "--paths", PC]
    for paket in ("rapidocr_onnxruntime", "onnxruntime", "ctranslate2", "sentencepiece"):
        komut += ["--collect-all", paket]
    komut += ["--hidden-import", "ctranslate2", "--hidden-import", "sentencepiece", "--hidden-import", "kelimeler",
              os.path.join(PC, "lingoplay_pc.py")]
    if calistir(komut) != 0:
        sys.exit("EXE derlenemedi")
    exe = os.path.join(DIST, "LingoPlay.exe")
    if not os.path.exists(exe):
        sys.exit("dist/LingoPlay.exe yok")

    # 4) EXE'nin içindeki çeviri motorunu dene: modeli indirip birkaç cümle çevirir.
    #    Sonuç model-testi.txt'ye yazılır; başarısız olsa da EXE yine yüklenir.
    rapor = os.path.join(DIST, "model-testi.txt")
    try:
        kod = subprocess.run([exe, "--model-testi", rapor], timeout=600).returncode
    except subprocess.TimeoutExpired:
        kod = "zaman aşımı"
    if not os.path.exists(rapor):
        with open(rapor, "w", encoding="utf-8") as f:
            f.write(f"model-testi.txt yazılmadı (çıkış: {kod})\n")
    print(open(rapor, encoding="utf-8").read(), flush=True)


if __name__ == "__main__":
    main()
