"""
GameLingo PC (eski adıyla LingoPlay) — ekrandaki İngilizce altyazıyı anlık Türkçeye çevirir.

Windows için tek dosyalık program. Ekranın alt şeridini yakalar, yazıyı okur,
Google Gemini ile Türkçeye çevirir ve ekranın üstünde bir kutuda gösterir.

Android sürümüyle aynı mantık: kalıp sözlüğü önce, sonra kalıcı hafıza,
en son yapay zekâ. Bir replik için ekrana bir kez yazılır, değişmez.
"""

import json
import socket
import os
import re
import sys
import threading
import time
import tkinter as tk
import urllib.error
import urllib.request
from tkinter import ttk

try:
    import mss
except ImportError:
    mss = None

try:
    from rapidocr_onnxruntime import RapidOCR
except ImportError:
    RapidOCR = None


SURUM = "5.3"

# Anahtar KASITLI olarak boş: herkese açık depoya gömülen anahtarları
# Google otomatik iptal ediyor. Anahtar uygulamaya bir kez elle girilir,
# telefonda/bilgisayarda saklanır, bir daha sorulmaz.
GOMULU_ANAHTAR = ""

APP_DIR = os.path.join(os.path.expanduser("~"), ".lingoplay")
CONFIG_PATH = os.path.join(APP_DIR, "ayarlar.json")
MEMORY_PATH = os.path.join(APP_DIR, "hafiza.json")

VARSAYILAN = {
    "api_key": GOMULU_ANAHTAR,
    "model": "gemini-3.8",
    "oyun": "",
    "tur": "Oyun",
    "ust_yuzde": 74,
    "alt_yuzde": 99,
    "sol_yuzde": 8,
    "sag_yuzde": 92,
    "aralik_ms": 350,
    "kaynak": "Gemini",
    "telefon_kod": "",
    "telefon_ip": "",
    "yazi_boyutu": 20,
    "konusan_goster": True,
    "ekran": 1,
}


# ---------------------------------------------------------------- kalıp sözlüğü

KALIPLAR = {
    "yes": "Evet", "no": "Hayır", "okay": "Tamam", "ok": "Tamam",
    "alright": "Pekâlâ", "all right": "Pekâlâ", "sure": "Tabii",
    "of course": "Elbette", "exactly": "Aynen öyle", "maybe": "Belki",
    "never": "Asla", "always": "Her zaman", "nothing": "Hiçbir şey",
    "i dont know": "Bilmiyorum", "i dont understand": "Anlamıyorum",
    "i see": "Anlıyorum", "got it": "Anladım", "understood": "Anlaşıldı",
    "forget it": "Boş ver", "never mind": "Boş ver", "no way": "Mümkün değil",
    "damn it": "Kahretsin", "what the hell": "Bu da ne böyle",
    "oh no": "Olamaz", "my god": "Tanrım",
    "hello": "Merhaba", "hi": "Selam", "hey": "Hey",
    "good morning": "Günaydın", "good evening": "İyi akşamlar",
    "good night": "İyi geceler", "goodbye": "Hoşça kal", "farewell": "Elveda",
    "see you": "Görüşürüz", "take care": "Kendine iyi bak",
    "thank you": "Teşekkür ederim", "thanks": "Teşekkürler",
    "youre welcome": "Rica ederim", "please": "Lütfen",
    "sorry": "Üzgünüm", "im sorry": "Üzgünüm", "excuse me": "Affedersiniz",
    "forgive me": "Beni bağışla", "congratulations": "Tebrikler",
    "well done": "Aferin", "good luck": "Bol şans",
    "look out": "Dikkat et", "watch out": "Dikkat et",
    "careful": "Dikkatli ol", "be careful": "Dikkatli ol",
    "get down": "Eğil", "take cover": "Siper al", "behind you": "Arkanda",
    "run": "Kaç", "move": "Kımılda", "go": "Git", "lets go": "Gidelim",
    "come on": "Hadi", "hurry": "Çabuk ol", "hurry up": "Acele et",
    "wait": "Bekle", "hold on": "Bir dakika", "stop": "Dur",
    "stop it": "Kes şunu", "stay back": "Geride dur", "stay here": "Burada kal",
    "follow me": "Beni takip et", "this way": "Bu taraftan",
    "over here": "Buraya", "get up": "Kalk", "im on it": "Hallediyorum",
    "leave it to me": "Bana bırak", "cover me": "Beni koru",
    "reloading": "Dolduruyorum", "theyre coming": "Geliyorlar",
    "hes dead": "Öldü", "dont move": "Kıpırdama", "dont": "Yapma",
    "its a trap": "Bu bir tuzak", "were surrounded": "Kuşatıldık",
    "i need help": "Yardıma ihtiyacım var", "help me": "Bana yardım et",
    "are you okay": "İyi misin", "are you all right": "İyi misin",
    "im fine": "İyiyim",
    "who are you": "Sen kimsin", "what is this": "Bu ne",
    "whats this": "Bu ne", "whats going on": "Neler oluyor",
    "what happened": "Ne oldu", "what do you mean": "Ne demek istiyorsun",
    "what do you want": "Ne istiyorsun", "where are you": "Neredesin",
    "where are we": "Neredeyiz", "why": "Neden", "why not": "Neden olmasın",
    "how": "Nasıl", "are you sure": "Emin misin",
    "do you understand": "Anlıyor musun", "can you hear me": "Beni duyuyor musun",
    "whos there": "Kim var orada", "what now": "Şimdi ne olacak",
    "i promise": "Söz veriyorum", "i swear": "Yemin ederim",
    "trust me": "Bana güven", "listen to me": "Beni dinle", "listen": "Dinle",
    "look at me": "Bana bak", "tell me": "Anlat bana",
    "its over": "Her şey bitti", "its too late": "Çok geç",
    "it doesnt matter": "Fark etmez", "theres no time": "Vakit yok",
    "i knew it": "Biliyordum", "youre right": "Haklısın",
    "youre wrong": "Yanılıyorsun", "im serious": "Ciddiyim",
    "are you serious": "Ciddi misin", "thats enough": "Bu kadar yeter",
    "enough": "Yeter", "calm down": "Sakin ol", "relax": "Rahatla",
    "dont worry": "Merak etme", "be quiet": "Sessiz ol",
    "shut up": "Kes sesini", "leave me alone": "Beni yalnız bırak",
    "get out": "Defol", "come with me": "Benimle gel",
    "stay with me": "Yanımda kal", "im coming": "Geliyorum",
    "im here": "Buradayım", "thank god": "Çok şükür",
    "i miss you": "Seni özledim", "i love you": "Seni seviyorum",
    "loading": "Yükleniyor", "saving": "Kaydediliyor",
    "checkpoint reached": "Kontrol noktasına ulaşıldı",
    "objective complete": "Görev tamamlandı", "new objective": "Yeni görev",
    "mission failed": "Görev başarısız", "level up": "Seviye atladın",
    "you died": "Öldün", "game over": "Oyun bitti", "continue": "Devam et",
    "skip": "Atla", "settings": "Ayarlar", "options": "Seçenekler",
    "inventory": "Envanter", "map": "Harita", "exit": "Çıkış",
}

ARAYUZ_KELIMELERI = {
    "l1", "l2", "l3", "r1", "r2", "r3", "ps", "touchpad", "skip",
    "options", "start", "select", "esc", "tab", "enter", "space",
}

KISALTMALAR = [
    ("dont", "don't"), ("doesnt", "doesn't"), ("didnt", "didn't"),
    ("cant", "can't"), ("couldnt", "couldn't"), ("wont", "won't"),
    ("wouldnt", "wouldn't"), ("shouldnt", "shouldn't"), ("isnt", "isn't"),
    ("arent", "aren't"), ("wasnt", "wasn't"), ("werent", "weren't"),
    ("havent", "haven't"), ("hasnt", "hasn't"), ("im", "I'm"),
    ("ive", "I've"), ("ill", "I'll"), ("youre", "you're"),
    ("youve", "you've"), ("hes", "he's"), ("shes", "she's"),
    ("thats", "that's"), ("theres", "there's"), ("theyre", "they're"),
    ("lets", "let's"), ("whats", "what's"),
]


def hata_turkce(kod, mesaj):
    """Sunucu hatasını ne yapılması gerektiğini söyleyen bir cümleye çevirir."""
    if kod == 401:
        return ("Anahtar geçersiz veya iptal edilmiş. "
                "aistudio.google.com/api-keys adresinden yeni anahtar alıp yapıştırın.")
    if kod == 429:
        return "Günlük ücretsiz kota doldu. Yarın yenilenir ya da başka anahtar kullanın."
    if kod == 404:
        return "Model bulunamadı. MODELLERİ BUL tuşuna basıp listeden seçin."
    if kod == 403:
        return "Bu anahtarın Gemini yetkisi yok. AI Studio'dan yeni anahtar alın."
    return f"{kod}: {mesaj[:120]}"


def anahtar_basliklari(anahtar):
    """
    Google'ın belgelediği yöntem x-goog-api-key başlığı. Bazı anahtar
    türlerinde bu reddedilirse Bearer ile ikinci bir deneme yapıyoruz.
    """
    anahtar = (anahtar or "").strip()
    return [("x-goog-api-key", anahtar), ("Authorization", "Bearer " + anahtar)]


def sadelestir(metin):
    return re.sub(r"[^a-z0-9 ]", "", metin.lower()).strip()


def metni_onar(ham):
    metin = ham.replace("…", "...")
    metin = re.sub(r"\s+", " ", metin).strip(" -—\"'")
    for yanlis, dogru in KISALTMALAR:
        metin = re.sub(rf"\b{yanlis}\b", dogru, metin, flags=re.IGNORECASE)
    return metin.strip()


def konusani_ayir(metin):
    """'JAMES: Merhaba' → ('JAMES', 'Merhaba'). İsim çeviriye girmez."""
    yer = metin.find(":")
    if 0 < yer <= 24:
        ad = metin[:yer].strip()
        geri = metin[yer + 1:].strip()
        if len(geri) > 1 and all(c.isalpha() or c in " .'-" for c in ad):
            return ad, geri
    return None, metin


# -------------------------------------------------------------------- hafıza

class Hafiza:
    """Çevrilen replikler diske yazılır; tekrar edince bedava ve anında gelir."""

    def __init__(self):
        self.veri = {}
        try:
            with open(MEMORY_PATH, encoding="utf-8") as f:
                self.veri = json.load(f)
        except Exception:
            self.veri = {}
        self.kilit = threading.Lock()

    def al(self, metin):
        return self.veri.get(sadelestir(metin))

    def koy(self, metin, ceviri):
        with self.kilit:
            self.veri[sadelestir(metin)] = ceviri
            if len(self.veri) > 5000:
                self.veri = dict(list(self.veri.items())[-3000:])
            try:
                os.makedirs(APP_DIR, exist_ok=True)
                with open(MEMORY_PATH, "w", encoding="utf-8") as f:
                    json.dump(self.veri, f, ensure_ascii=False)
            except Exception:
                pass


# ------------------------------------------------------------------- çeviri

class Cevirmen:
    def __init__(self, ayarlar):
        self.ayarlar = ayarlar
        self.gecmis = []
        self.son_hata = None
        self.son_sure = 0.0

    def talimat(self):
        tur = self.ayarlar.get("tur") or "Oyun"
        ad = self.ayarlar.get("oyun") or f"bilinmeyen bir {tur.lower()}"
        t = (
            f"{tur} altyazısı çevirmeni. {tur}: {ad}. "
            "OCR ile okunmuş İngilizce repliği doğal Türkçeye çevir. "
            "Özel isimleri çevirme. OCR hatalarını bağlamdan düzelt. "
            "Argoyu yumuşatma. Altyazı tek bakışta okunacak, kısa ve akıcı olsun. "
        )
        if self.ayarlar.get("konusan_goster"):
            t += "Replikte konuşan adı varsa 'İsim: çeviri' biçiminde koru. "
        t += "Sadece çeviriyi yaz, açıklama yazma, mutlaka bir çeviri ver."
        return t

    def modelleri_getir(self):
        """Hesabın kullanabildiği model adlarını getirir."""
        anahtar = (self.ayarlar.get("api_key") or "").strip()
        if not anahtar:
            self.son_hata = "API anahtarı girilmemiş"
            return []
        url = "https://generativelanguage.googleapis.com/v1beta/models"
        veri = None
        for ad, deger in anahtar_basliklari(anahtar):
            istek = urllib.request.Request(url)
            istek.add_header(ad, deger)
            try:
                with urllib.request.urlopen(istek, timeout=15) as cevap:
                    veri = json.loads(cevap.read().decode("utf-8"))
                self.son_hata = None
                break
            except urllib.error.HTTPError as e:
                try:
                    detay = json.loads(e.read().decode("utf-8"))
                    mesaj = detay.get("error", {}).get("message", "")
                except Exception:
                    mesaj = ""
                self.son_hata = hata_turkce(e.code, mesaj)
                if e.code != 401:
                    return []
            except Exception as e:
                self.son_hata = str(e)[:150]
                return []
        if veri is None:
            return []
        adlar = []
        for m in veri.get("models", []):
            if "generateContent" not in (m.get("supportedGenerationMethods") or []):
                continue
            ad = (m.get("name") or "").replace("models/", "")
            if ad:
                adlar.append(ad)
        return adlar

    @staticmethod
    def en_uygun(adlar):
        for ad in adlar:
            if "flash" in ad and "thinking" not in ad and "embedding" not in ad:
                return ad
        return adlar[0] if adlar else None

    def cevir(self, metin):
        self.son_sure = 0.0
        baslangic = time.time()
        sonuc = self._cevir(metin)
        self.son_sure = time.time() - baslangic
        return sonuc

    def _cevir(self, metin):
        anahtar = (self.ayarlar.get("api_key") or "").strip()
        if not anahtar:
            self.son_hata = ("API anahtarı girilmemiş. aistudio.google.com/api-keys "
                             "adresinden alıp yukarıdaki kutuya yapıştırın.")
            return None

        icerik = []
        for en, tr in self.gecmis[-2:]:
            icerik.append({"role": "user", "parts": [{"text": en}]})
            icerik.append({"role": "model", "parts": [{"text": tr}]})
        icerik.append({"role": "user", "parts": [{"text": metin}]})

        govde = json.dumps({
            "system_instruction": {"parts": [{"text": self.talimat()}]},
            "contents": icerik,
            "generationConfig": {
                "maxOutputTokens": 256,
                # Düşünme kapalı: cevap sınırını tüketip boş yanıt dönmesini önler.
                "thinkingConfig": {"thinkingBudget": 0},
            },
        }).encode("utf-8")

        model = self.ayarlar.get("model") or "gemini-3.8"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        veri = None
        for ad, deger in anahtar_basliklari(anahtar):
            istek = urllib.request.Request(url, data=govde, method="POST")
            istek.add_header("content-type", "application/json")
            istek.add_header(ad, deger)
            try:
                with urllib.request.urlopen(istek, timeout=12) as cevap:
                    veri = json.loads(cevap.read().decode("utf-8"))
                self.son_hata = None
                break
            except urllib.error.HTTPError as e:
                try:
                    detay = json.loads(e.read().decode("utf-8"))
                    mesaj = detay.get("error", {}).get("message", "")
                except Exception:
                    mesaj = ""
                self.son_hata = hata_turkce(e.code, mesaj)
                # Yalnızca kimlik hatasında diğer başlığı deniyoruz.
                if e.code != 401:
                    return None
            except Exception as e:
                self.son_hata = str(e)[:120]
                return None
        if veri is None:
            return None

        try:
            parcalar = veri["candidates"][0]["content"]["parts"]
            sonuc = "".join(p.get("text", "") for p in parcalar).strip().strip('"')
        except Exception:
            sonuc = ""

        if not sonuc:
            self.son_hata = "boş yanıt"
            return None

        self.son_hata = None
        self.gecmis.append((metin, sonuc))
        self.gecmis = self.gecmis[-2:]
        return sonuc


# ---------------------------------------------------------- telefon köprüsü

class TelefonKopru:
    """Çeviriyi telefondaki GameLingo'nun yapay zekâsına yaptırır (internet ve anahtar gerekmez).
    Telefonda: GameLingo → "TV ve bilgisayara çeviri sağla". GameLingo TV ile aynı protokol:
      Bulma (UDP 47322, yayın): "GLFIND <kod>" -> "GLHERE"
      Deneme (TCP 47321):       "GL1 <kod> PING" -> "PONG 1/0"
      Çeviri (TCP 47321):       "GL1 <kod> <sıra> <öncekiSayısı>" + tür + ad + satır + öncekiler
                                -> "OK <çeviri>" | "SKIP" | "ERR <sebep>"
    Cevirmen ile aynı arayüz: cevir(metin), son_hata, son_sure."""

    TCP_PORT = 47321
    UDP_PORT = 47322

    def __init__(self, ayarlar):
        self.ayarlar = ayarlar
        self.son_hata = None
        self.son_sure = 0.0
        self.atlandi = False
        self.sira = 0
        self.onceki = []
        self.kilit = threading.Lock()

    @staticmethod
    def _tek(s):
        return (s or "").replace("\n", " ").replace("\r", " ").strip()

    def kod(self):
        return self._tek(str(self.ayarlar.get("telefon_kod", "")))

    def _istek(self, host, govde, sure):
        try:
            with socket.create_connection((host, self.TCP_PORT), timeout=2.0) as s:
                s.settimeout(sure)
                s.sendall(govde.encode("utf-8"))
                veri = b""
                while not veri.endswith(b"\n") and len(veri) < 65536:
                    parca = s.recv(4096)
                    if not parca:
                        break
                    veri += parca
                return veri.decode("utf-8", "replace").strip()
        except Exception:
            return None

    def bul(self, sure=2.5):
        """Telefonu kodla ağda arar; bulursa adresini döner."""
        kod = self.kod()
        if not kod:
            return None
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                s.settimeout(sure)
                s.sendto(f"GLFIND {kod}".encode("utf-8"), ("255.255.255.255", self.UDP_PORT))
                veri, adres = s.recvfrom(64)
                if veri.decode("utf-8", "replace").startswith("GLHERE"):
                    return adres[0]
        except Exception:
            pass
        return None

    def ping(self, host):
        """None: ulaşılamadı; True/False: telefonda yapay zekâ hazır mı."""
        r = self._istek(host, f"GL1 {self.kod()} PING\n", 3.0)
        if not r or not r.startswith("PONG"):
            return None
        return r.endswith("1")

    def baglan(self):
        """Kayıtlı adresi dener, olmazsa arar. (durum metni, hazır mı) döner."""
        if not self.kod():
            return "Telefon kodu girilmemiş", False
        host = self._tek(self.ayarlar.get("telefon_ip", ""))
        p = self.ping(host) if host else None
        if p is None:
            bulunan = self.bul()
            if bulunan:
                host = bulunan
                self.ayarlar["telefon_ip"] = bulunan
                p = self.ping(host)
        if p is None:
            return "Telefon bulunamadı. Telefonda \"TV ve bilgisayara çeviri sağla\" açık mı, aynı Wi-Fi'da mısınız?", False
        if p is False:
            return f"Telefon bulundu ({host}) ama yapay zekâ modeli hazır değil", False
        return f"Telefon bağlı ✓ ({host})", True

    def cevir(self, metin):
        self.son_sure = 0.0
        self.atlandi = False
        baslangic = time.time()
        kod = self.kod()
        if not kod:
            self.son_hata = "Telefon kodu girilmemiş (Çeviri → Ayarlar)"
            return None
        host = self._tek(self.ayarlar.get("telefon_ip", ""))
        if not host:
            host = self.bul()
            if not host:
                self.son_hata = "Telefon bulunamadı"
                return None
            self.ayarlar["telefon_ip"] = host
        with self.kilit:
            self.sira += 1
            sira = self.sira
            onceki = list(self.onceki[-2:])
            self.onceki = (self.onceki + [metin])[-2:]
        govde = (f"GL1 {kod} {sira} {len(onceki)}\n"
                 f"{self._tek(self.ayarlar.get('tur') or 'Oyun')}\n"
                 f"{self._tek(self.ayarlar.get('oyun') or '')}\n"
                 f"{self._tek(metin)}\n" + "".join(self._tek(o) + "\n" for o in onceki))
        r = self._istek(host, govde, 15.0)
        if r is None:
            # Adres değişmiş olabilir: bir kez yeniden ara.
            yeni = self.bul()
            if yeni and yeni != host:
                self.ayarlar["telefon_ip"] = yeni
                r = self._istek(yeni, govde, 15.0)
        self.son_sure = time.time() - baslangic
        if r is None:
            self.son_hata = "Telefona ulaşılamadı"
            return None
        if r.startswith("OK "):
            self.son_hata = None
            return r[3:].strip() or None
        if r.startswith("SKIP"):
            self.atlandi = True
            self.son_hata = None
            return None
        self.son_hata = "Telefon: " + (r[3:].strip() if r.startswith("ERR") else "anlaşılmayan cevap")
        return None


def cevirmen_olustur(ayarlar):
    return TelefonKopru(ayarlar) if ayarlar.get("kaynak") == "Telefon" else Cevirmen(ayarlar)


# ------------------------------------------------------------------- görünüm

RENK = {
    "zemin": "#0B1220",      # pencere
    "kart": "#131C2E",       # kartlar
    "cizgi": "#1F2B44",      # kart kenarı
    "alan": "#0B1220",       # yazı kutuları
    "alan_cizgi": "#2A3A58",
    "yazi": "#E6EDF7",
    "soluk": "#8FA3BF",
    "turkuaz": "#2EE6D6",
    "turkuaz_koyu": "#04342C",
    "mavi": "#2EA8FF",
    "mavi_zemin": "#13324A",
    "kirmizi": "#FF6B6B",
    "gri": "#5B6B85",
}
YAZI = "Segoe UI"


def durum_rengi(metin):
    """Durum satırına göre nokta rengi: hata kırmızı, çalışıyor turkuaz, diğerleri gri."""
    m = (metin or "").lower()
    if any(k in m for k in ("hata", "başarısız", "✗", "alınamadı", "yüklenemedi")):
        return RENK["kirmizi"]
    if any(k in m for k in ("çalışıyor", "ocr ", "✓")):
        return RENK["turkuaz"]
    return RENK["gri"]


# ------------------------------------------------------------------- ekran

class Kutu:
    """Ekranın üstünde duran, her zaman önde çeviri kutusu: koyu zemin, turkuaz alt şerit,
    konuşanın adı turkuaz."""

    def __init__(self, kok, yazi_boyutu=20):
        self.pencere = tk.Toplevel(kok)
        self.pencere.overrideredirect(True)
        self.pencere.attributes("-topmost", True)
        self.pencere.attributes("-alpha", 0.93)
        self.pencere.configure(bg=RENK["zemin"])
        govde = tk.Frame(self.pencere, bg=RENK["zemin"])
        govde.pack()
        self.ad = tk.Label(govde, text="", font=(YAZI, yazi_boyutu, "bold"),
                           fg=RENK["turkuaz"], bg=RENK["zemin"], padx=0, pady=8)
        self.etiket = tk.Label(govde, text="", font=(YAZI, yazi_boyutu, "bold"),
                               fg="white", bg=RENK["zemin"], wraplength=1100,
                               justify="center", padx=16, pady=8)
        self.ad.pack(side="left", anchor="n")
        self.etiket.pack(side="left")
        tk.Frame(self.pencere, bg=RENK["turkuaz"], height=3).pack(fill="x")
        self.pencere.withdraw()

    def yaz(self, metin):
        if not metin:
            self.pencere.withdraw()
            return
        ad, govde = konusani_ayir(metin)
        if ad:
            self.ad.config(text="  " + ad + ":")
            self.etiket.config(text=govde, padx=8)
        else:
            self.ad.config(text="")
            self.etiket.config(text=metin, padx=16)
        self.pencere.update_idletasks()
        genislik = self.pencere.winfo_width()
        ekran = self.pencere.winfo_screenwidth()
        self.pencere.geometry(f"+{max(0, (ekran - genislik) // 2)}+40")
        self.pencere.deiconify()
        self.pencere.lift()


def bolgeyi_goster(kok, ayarlar, sure_ms=2500):
    """Okunan altyazı bölgesini birkaç saniye yarı saydam turkuaz çerçeveyle gösterir."""
    try:
        ekran_no = int(ayarlar.get("ekran", 1))
    except (TypeError, ValueError):
        ekran_no = 1
    ekran = None
    if mss is not None:
        try:
            with mss.mss() as sct:
                ekranlar = sct.monitors
                ekran = ekranlar[ekran_no] if ekran_no < len(ekranlar) else ekranlar[0]
        except Exception:
            ekran = None
    if not ekran:
        ekran = {"left": 0, "top": 0, "width": kok.winfo_screenwidth(), "height": kok.winfo_screenheight()}
    yuk, gen = ekran["height"], ekran["width"]
    ust = ekran["top"] + int(yuk * ayarlar["ust_yuzde"] / 100)
    alt = ekran["top"] + int(yuk * ayarlar["alt_yuzde"] / 100)
    sol = ekran["left"] + int(gen * ayarlar.get("sol_yuzde", 8) / 100)
    sag = ekran["left"] + int(gen * ayarlar.get("sag_yuzde", 92) / 100)
    p = tk.Toplevel(kok)
    p.overrideredirect(True)
    p.attributes("-topmost", True)
    p.attributes("-alpha", 0.35)
    p.configure(bg=RENK["turkuaz"])
    tk.Label(p, text="GameLingo burayı okuyor", font=(YAZI, 14, "bold"),
             fg=RENK["turkuaz_koyu"], bg=RENK["turkuaz"]).pack(expand=True)
    p.geometry(f"{max(40, sag - sol)}x{max(20, alt - ust)}+{sol}+{ust}")
    p.after(sure_ms, p.destroy)
    return p


# -------------------------------------------------------------------- motor

# Oyunu yavaşlatmasın diye: okuma en fazla bu kadar sık yapılır ve okuma, sürdüğü
# zamanın en az 2 katı kadar dinlenir (işlemcinin en fazla ~%33'ü okumaya gider).
EN_KISA_ARALIK = 0.30
OKUMA_GENISLIGI = 800
OCR_IS_PARCACIGI = 2


def ocr_olustur():
    """OCR'ı işlemcinin tamamını değil, yalnızca birkaç çekirdeğini kullanacak şekilde kurar."""
    if not RapidOCR:
        return None
    for ayar in ({"intra_op_num_threads": OCR_IS_PARCACIGI, "inter_op_num_threads": 1}, {}):
        try:
            return RapidOCR(**ayar)
        except Exception:
            continue
    return None


def dusuk_oncelik():
    """Windows'ta programı 'normalin altı' önceliğe alır: oyun her zaman önce çalışır."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
        k32 = ctypes.windll.kernel32
        k32.SetPriorityClass(k32.GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS)
    except Exception:
        pass


class Motor(threading.Thread):
    def __init__(self, ayarlar, kutu, durum_yaz):
        super().__init__(daemon=True)
        self.ayarlar = ayarlar
        self.kutu = kutu
        self.durum_yaz = durum_yaz
        self.calisiyor = True
        self.hafiza = Hafiza()
        self.cevirmen = cevirmen_olustur(ayarlar)
        self.ocr = ocr_olustur()
        self.yon_kapali = True   # altyazı hep düz: yön düzeltme adımını atla
        self.gosterilen = ""
        self.bos_kare = 0
        self.isleniyor = set()
        self.kilit = threading.Lock()
        self.onceki_kare = None
        self.ocr_suresi = 0.0
        self.gosterim_zamani = 0.0

    def dur(self):
        self.calisiyor = False

    def bolge(self, sct):
        ekran_no = int(self.ayarlar.get("ekran", 1))
        ekranlar = sct.monitors
        ekran = ekranlar[ekran_no] if ekran_no < len(ekranlar) else ekranlar[0]
        yuk = ekran["height"]
        gen = ekran["width"]
        ust = ekran["top"] + int(yuk * self.ayarlar["ust_yuzde"] / 100)
        alt = ekran["top"] + int(yuk * self.ayarlar["alt_yuzde"] / 100)
        sol = ekran["left"] + int(gen * self.ayarlar["sol_yuzde"] / 100)
        sag = ekran["left"] + int(gen * self.ayarlar["sag_yuzde"] / 100)
        return {"top": ust, "left": sol, "width": max(8, sag - sol), "height": max(8, alt - ust)}

    def oku(self, goruntu):
        if not self.ocr:
            return ""
        try:
            if self.yon_kapali:
                try:
                    sonuc, _ = self.ocr(goruntu, use_cls=False)
                except TypeError:
                    self.yon_kapali = False
                    sonuc, _ = self.ocr(goruntu)
            else:
                sonuc, _ = self.ocr(goruntu)
        except Exception as e:
            # Sessiz kalmıyoruz: okuma hiç çalışmıyorsa sebebi görünsün.
            self.durum_yaz(f"OCR hatası: {type(e).__name__}: {e}")
            return ""
        if not sonuc:
            return ""
        satirlar = []
        for kutu_, metin, guven in sonuc:
            t = (metin or "").strip()
            if not t or guven < 0.5:
                continue
            if sadelestir(t) in ARAYUZ_KELIMELERI:
                continue
            if len(t) < 3 or sum(c.isalpha() for c in t) < 3:
                continue
            ust = min(p[1] for p in kutu_)
            satirlar.append((ust, t))
        satirlar.sort()
        return " ".join(t for _, t in satirlar)

    def benzer(self, a, b):
        if not a or not b:
            return a == b
        na, nb = sadelestir(a), sadelestir(b)
        if na == nb:
            return True
        uzun, kisa = (na, nb) if len(na) >= len(nb) else (nb, na)
        if not uzun or len(kisa) / len(uzun) < 0.8:
            return False
        fark = sum(1 for x, y in zip(uzun, kisa) if x != y) + (len(uzun) - len(kisa))
        return fark / len(uzun) <= 0.12

    def run(self):
        if mss is None or self.ocr is None:
            self.durum_yaz("Gerekli bileşenler yüklenemedi.")
            return

        import numpy as np

        with mss.mss() as sct:
            while self.calisiyor:
                aralik = max(EN_KISA_ARALIK, self.ayarlar["aralik_ms"] / 1000)
                time.sleep(max(aralik, self.ocr_suresi * 2))
                try:
                    kare = sct.grab(self.bolge(sct))
                    dizi = np.array(kare)[:, :, :3]

                    # Görüntü küçültülürse OCR belirgin biçimde hızlanır.
                    if dizi.shape[1] > OKUMA_GENISLIGI:
                        adim = int(dizi.shape[1] / OKUMA_GENISLIGI) + 1
                        kucuk = np.ascontiguousarray(dizi[::adim, ::adim])
                    else:
                        kucuk = np.ascontiguousarray(dizi)

                    # Kare neredeyse aynıysa OCR'a hiç girmiyoruz.
                    imza = kucuk[::4, ::4].astype(np.int16)
                    if self.onceki_kare is not None and imza.shape == self.onceki_kare.shape:
                        if np.abs(imza - self.onceki_kare).max() < 6:
                            continue
                    self.onceki_kare = imza

                    ocr_basla = time.time()
                    ham = self.oku(kucuk)
                    self.ocr_suresi = time.time() - ocr_basla
                except Exception as e:
                    self.durum_yaz(f"Okuma hatası: {type(e).__name__}: {e}")
                    self.onceki_kare = None
                    time.sleep(0.5)
                    continue

                # Ekranda 10 saniyedir aynı çeviri duruyorsa bir aksilik var;
                # takılı kalmasın diye temizliyoruz.
                if self.gosterilen and time.time() - self.gosterim_zamani > 15:
                    self.gosterilen = ""
                    self.kutu.yaz("")

                metin = metni_onar(ham)
                if len(metin) < 3:
                    self.bos_kare += 1
                    if self.bos_kare >= 6 and self.gosterilen:
                        self.gosterilen = ""
                        self.kutu.yaz("")
                    continue
                self.bos_kare = 0

                if self.benzer(metin, self.gosterilen):
                    continue

                # Beklemeden çeviriye gönder; aynı replik ikinci kez gitmez.
                with self.kilit:
                    if metin in self.isleniyor or len(self.isleniyor) >= 3:
                        continue
                    self.isleniyor.add(metin)

                threading.Thread(target=self.isle, args=(metin,), daemon=True).start()

    def isle(self, kaynak):
        try:
            self._isle(kaynak)
        finally:
            with self.kilit:
                self.isleniyor.discard(kaynak)

    def _isle(self, kaynak):
        ad, govde = konusani_ayir(kaynak)

        kalip = KALIPLAR.get(sadelestir(govde))
        if kalip:
            self.goster(kaynak, f"{ad}: {kalip}" if ad else kalip)
            return

        kayitli = self.hafiza.al(kaynak)
        if kayitli:
            self.goster(kaynak, kayitli)
            return

        if isinstance(self.cevirmen, TelefonKopru):
            # İsim telefona gitmez; çeviriden sonra başa eklenir.
            ceviri = self.cevirmen.cevir(govde)
            if ceviri and ad and self.ayarlar.get("konusan_goster"):
                ceviri = f"{ad}: {ceviri}"
        else:
            ceviri = self.cevirmen.cevir(kaynak)
        if ceviri:
            self.hafiza.koy(kaynak, ceviri)
            self.goster(kaynak, ceviri)
            self.durum_yaz(
                f"OCR {int(self.ocr_suresi * 1000)} ms · "
                f"{'telefon' if isinstance(self.cevirmen, TelefonKopru) else 'çeviri'} "
                f"{int(self.cevirmen.son_sure * 1000)} ms"
            )
        elif getattr(self.cevirmen, "atlandi", False):
            pass   # daha yeni bir satır geldi; bu satır sessizce atlandı
        else:
            self.durum_yaz(f"Çeviri alınamadı: {self.cevirmen.son_hata}")

    def goster(self, kaynak, metin):
        self.gosterilen = kaynak
        self.gosterim_zamani = time.time()
        self.kutu.yaz(metin)


# ------------------------------------------------------------------ arayüz

def ayarlari_yukle():
    ayarlar = dict(VARSAYILAN)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            ayarlar.update(json.load(f))
    except Exception:
        pass
    if not (ayarlar.get("api_key") or "").strip():
        ayarlar["api_key"] = GOMULU_ANAHTAR
    # Eski sürümlerin kaydettiği çok kısa aralık (120 ms) oyunu kasıyordu.
    try:
        if int(ayarlar.get("aralik_ms", 350)) < 300:
            ayarlar["aralik_ms"] = 350
    except (TypeError, ValueError):
        ayarlar["aralik_ms"] = 350
    return ayarlar


def ayarlari_kaydet(ayarlar):
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(ayarlar, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def main():
    dusuk_oncelik()
    ayarlar = ayarlari_yukle()
    R = RENK

    kok = tk.Tk()
    kok.title(f"GameLingo {SURUM}")
    kok.geometry("540x760")
    kok.minsize(500, 680)
    kok.configure(bg=R["zemin"])

    dis = tk.Frame(kok, bg=R["zemin"], padx=14, pady=12)
    dis.pack(fill="both", expand=True)

    def kart(baslik_metni=None):
        cerceve = tk.Frame(dis, bg=R["kart"], highlightbackground=R["cizgi"],
                           highlightthickness=1, padx=14, pady=12)
        cerceve.pack(fill="x", pady=(0, 10))
        if baslik_metni:
            tk.Label(cerceve, text=baslik_metni.upper(), font=(YAZI, 8, "bold"),
                     fg=R["turkuaz"], bg=R["kart"]).pack(anchor="w", pady=(0, 6))
        return cerceve

    def giris(ust, degisken, gizli=False):
        return tk.Entry(ust, textvariable=degisken, font=(YAZI, 10), bg=R["alan"], fg=R["yazi"],
                        insertbackground=R["turkuaz"], relief="flat",
                        highlightthickness=1, highlightbackground=R["alan_cizgi"],
                        highlightcolor=R["turkuaz"], show="•" if gizli else "")

    def dugme(ust, metin, komut, dolu=False):
        if dolu:
            return tk.Button(ust, text=metin, command=komut, font=(YAZI, 11, "bold"),
                             bg=R["turkuaz"], fg=R["turkuaz_koyu"], activebackground="#5FF0E3",
                             activeforeground=R["turkuaz_koyu"], relief="flat", bd=0, cursor="hand2")
        return tk.Button(ust, text=metin, command=komut, font=(YAZI, 9, "bold"),
                         bg=R["kart"], fg=R["turkuaz"], activebackground=R["mavi_zemin"],
                         activeforeground=R["turkuaz"], relief="flat", bd=0, cursor="hand2",
                         highlightthickness=1, highlightbackground=R["turkuaz"])

    alanlar = {}

    def degisken(anahtar):
        d = tk.StringVar(value=str(ayarlar.get(anahtar, "")))
        alanlar[anahtar] = d
        return d

    # --- başlık ---
    baslik = tk.Frame(dis, bg=R["zemin"])
    baslik.pack(fill="x", pady=(0, 10))
    simge = tk.Canvas(baslik, width=38, height=38, bg=R["zemin"], highlightthickness=0)
    simge.pack(side="left")
    simge.create_rectangle(2, 2, 36, 36, outline=R["turkuaz"], width=2)
    simge.create_oval(8, 15, 20, 29, outline=R["turkuaz"], width=2)
    simge.create_oval(18, 15, 30, 29, outline=R["turkuaz"], width=2)
    simge.create_rectangle(13, 15, 25, 22, fill=R["zemin"], outline=R["zemin"])
    simge.create_line(13, 15, 25, 15, fill=R["turkuaz"], width=2)
    yazi_kutusu = tk.Frame(baslik, bg=R["zemin"], padx=10)
    yazi_kutusu.pack(side="left")
    ad_satiri = tk.Frame(yazi_kutusu, bg=R["zemin"])
    ad_satiri.pack(anchor="w")
    tk.Label(ad_satiri, text="Game", font=(YAZI, 17, "bold"), fg=R["yazi"], bg=R["zemin"]).pack(side="left")
    tk.Label(ad_satiri, text="Lingo", font=(YAZI, 17, "bold"), fg=R["turkuaz"], bg=R["zemin"]).pack(side="left")
    tk.Label(yazi_kutusu, text=f"Bilgisayar · sürüm {SURUM}", font=(YAZI, 8),
             fg=R["soluk"], bg=R["zemin"]).pack(anchor="w")
    tk.Label(baslik, text=" PC ", font=(YAZI, 8, "bold"), fg=R["mavi"], bg=R["mavi_zemin"],
             padx=6, pady=2).pack(side="right")

    # --- durum + başlat ---
    k0 = kart()
    durum_satiri = tk.Frame(k0, bg=R["kart"])
    durum_satiri.pack(fill="x", pady=(0, 10))
    nokta = tk.Canvas(durum_satiri, width=12, height=12, bg=R["kart"], highlightthickness=0)
    nokta.pack(side="left", padx=(0, 8))
    nokta_id = nokta.create_oval(1, 1, 11, 11, fill=R["gri"], outline="")
    durum = tk.StringVar(value="Hazır. Başlat'a basın.")
    tk.Label(durum_satiri, textvariable=durum, font=(YAZI, 9), fg=R["yazi"], bg=R["kart"],
             wraplength=430, justify="left").pack(side="left", fill="x")

    def durum_goster(metin):
        durum.set(metin)
        try:
            nokta.itemconfig(nokta_id, fill=durum_rengi(metin))
        except Exception:
            pass

    # --- içerik ---
    k1 = kart("İçerik")
    tur_degisken = tk.StringVar(value=ayarlar.get("tur", "Oyun"))
    alanlar["tur"] = tur_degisken
    cipler = tk.Frame(k1, bg=R["kart"])
    cipler.pack(fill="x", pady=(0, 8))
    cip_dugmeleri = {}

    def tur_sec(t):
        tur_degisken.set(t)
        for ad_, b in cip_dugmeleri.items():
            secili = ad_ == t
            b.config(bg=R["turkuaz"] if secili else R["kart"],
                     fg=R["turkuaz_koyu"] if secili else R["soluk"])

    for t in ("Oyun", "Dizi", "Film", "Belgesel", "Video"):
        b = tk.Button(cipler, text=t, font=(YAZI, 9, "bold"), relief="flat", bd=0, padx=10, pady=3,
                      cursor="hand2", highlightthickness=1, highlightbackground=R["alan_cizgi"],
                      command=lambda t=t: tur_sec(t))
        b.pack(side="left", padx=(0, 6))
        cip_dugmeleri[t] = b
    tur_sec(tur_degisken.get() if tur_degisken.get() in cip_dugmeleri else "Oyun")
    tk.Label(k1, text="Adı (çeviri bağlamı için, örn. The Last of Us)", font=(YAZI, 8),
             fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
    giris(k1, degisken("oyun")).pack(fill="x", ipady=4)

    # --- altyazı bölgesi ---
    k2 = kart("Altyazı bölgesi")
    surgu_degerleri = {}

    def surgu(ust, metin, anahtar):
        satir = tk.Frame(ust, bg=R["kart"])
        satir.pack(fill="x")
        tk.Label(satir, text=metin, font=(YAZI, 9), fg=R["soluk"], bg=R["kart"]).pack(side="left")
        deger = tk.StringVar(value=f"%{ayarlar.get(anahtar, 0)}")
        tk.Label(satir, textvariable=deger, font=(YAZI, 9, "bold"), fg=R["yazi"], bg=R["kart"]).pack(side="right")
        sayi = tk.IntVar(value=int(ayarlar.get(anahtar, 0)))

        def degisti(_=None):
            deger.set(f"%{sayi.get()}")
            ayarlar[anahtar] = int(sayi.get())

        tk.Scale(ust, from_=0, to=100, orient="horizontal", variable=sayi, showvalue=0,
                 command=degisti, bg=R["kart"], fg=R["yazi"], troughcolor=R["alan_cizgi"],
                 activebackground=R["turkuaz"], highlightthickness=0, bd=0, sliderrelief="flat",
                 sliderlength=18, width=10).pack(fill="x", pady=(2, 8))
        surgu_degerleri[anahtar] = sayi

    surgu(k2, "Üst sınır", "ust_yuzde")
    surgu(k2, "Alt sınır", "alt_yuzde")
    alt_satir = tk.Frame(k2, bg=R["kart"])
    alt_satir.pack(fill="x", pady=(0, 8))
    for metin, anahtar in (("Ekran no", "ekran"), ("Tarama (ms)", "aralik_ms"), ("Yazı boyutu", "yazi_boyutu")):
        sutun = tk.Frame(alt_satir, bg=R["kart"])
        sutun.pack(side="left", fill="x", expand=True, padx=(0, 8))
        tk.Label(sutun, text=metin, font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
        giris(sutun, degisken(anahtar)).pack(fill="x", ipady=3)
    dugme(k2, "Bölgeyi ekranda göster", lambda: (kaydet(), bolgeyi_goster(kok, ayarlar))).pack(fill="x", ipady=4)
    tk.Label(k2, text="Pencerede izliyorsanız üst sınırı 55 yapın; tam ekranda 74 uygundur.",
             font=(YAZI, 8), fg=R["soluk"], bg=R["kart"], wraplength=460, justify="left").pack(anchor="w", pady=(6, 0))

    # --- çeviri (kaynak seçimi + özet; ayrıntı ayrı pencerede) ---
    k3 = kart("Çeviri")
    kaynak_degisken = tk.StringVar(value=ayarlar.get("kaynak", "Gemini"))
    alanlar["kaynak"] = kaynak_degisken
    api_degisken = degisken("api_key")
    model_degisken = degisken("model")
    kod_degisken = degisken("telefon_kod")
    ip_degisken = degisken("telefon_ip")
    kaynak_satiri = tk.Frame(k3, bg=R["kart"])
    kaynak_satiri.pack(fill="x", pady=(0, 8))
    kaynak_dugmeleri = {}
    ozet = tk.StringVar()

    def ozet_yenile():
        if kaynak_degisken.get() == "Telefon":
            kod = (kod_degisken.get() or "").strip()
            ip = (ip_degisken.get() or "").strip()
            ozet.set("Telefonun yapay zekâsı · " + (f"kod {kod}" if kod else "kod girilmedi") +
                     (f" · {ip}" if ip else ""))
        else:
            anahtar_var = bool((api_degisken.get() or "").strip())
            ozet.set(f"Gemini · {model_degisken.get() or 'model seçilmedi'}" +
                     ("" if anahtar_var else "  ·  anahtar yok"))

    def kaynak_sec(k):
        kaynak_degisken.set(k)
        for ad_, b in kaynak_dugmeleri.items():
            secili = ad_ == k
            b.config(bg=R["turkuaz"] if secili else R["kart"],
                     fg=R["turkuaz_koyu"] if secili else R["soluk"])
        ozet_yenile()

    for k, metin in (("Telefon", "Telefonun yapay zekâsı"), ("Gemini", "Gemini (internet)")):
        b = tk.Button(kaynak_satiri, text=metin, font=(YAZI, 9, "bold"), relief="flat", bd=0, padx=10, pady=3,
                      cursor="hand2", highlightthickness=1, highlightbackground=R["alan_cizgi"],
                      command=lambda k=k: kaynak_sec(k))
        b.pack(side="left", padx=(0, 6))
        kaynak_dugmeleri[k] = b
    kaynak_sec(kaynak_degisken.get() if kaynak_degisken.get() in kaynak_dugmeleri else "Gemini")

    ozet_satiri = tk.Frame(k3, bg=R["kart"])
    ozet_satiri.pack(fill="x")
    tk.Label(ozet_satiri, textvariable=ozet, font=(YAZI, 9), fg=R["soluk"], bg=R["kart"]).pack(side="left")
    tk.Button(ozet_satiri, text="Ayarlar ›", font=(YAZI, 9, "bold"), fg=R["mavi"], bg=R["kart"],
              activebackground=R["kart"], activeforeground=R["mavi"], relief="flat", bd=0,
              cursor="hand2", command=lambda: ceviri_ayarlari()).pack(side="right")

    kutu = Kutu(kok, yazi_boyutu=int(ayarlar.get("yazi_boyutu", 20) or 20))
    motor = {"nesne": None}

    def durum_yaz(metin):
        kok.after(0, lambda: durum_goster(metin))

    def kaydet():
        for anahtar, d in alanlar.items():
            deger = d.get().strip()
            if anahtar in ("ekran", "aralik_ms", "yazi_boyutu"):
                try:
                    ayarlar[anahtar] = int(deger)
                except ValueError:
                    pass
            else:
                ayarlar[anahtar] = deger
        for anahtar, sayi in surgu_degerleri.items():
            ayarlar[anahtar] = int(sayi.get())
        if ayarlar["alt_yuzde"] <= ayarlar["ust_yuzde"]:
            ayarlar["alt_yuzde"] = min(100, ayarlar["ust_yuzde"] + 5)
        try:
            kutu.ad.config(font=(YAZI, int(ayarlar.get("yazi_boyutu", 20)), "bold"))
            kutu.etiket.config(font=(YAZI, int(ayarlar.get("yazi_boyutu", 20)), "bold"))
        except Exception:
            pass
        ozet_yenile()
        ayarlari_kaydet(ayarlar)

    def baslat_durdur():
        if motor["nesne"]:
            motor["nesne"].dur()
            motor["nesne"] = None
            kutu.yaz("")
            ana_dugme.config(text="Başlat")
            durum_goster("Durduruldu.")
            return
        kaydet()
        m = Motor(ayarlar, kutu, durum_yaz)
        m.start()
        motor["nesne"] = m
        ana_dugme.config(text="Durdur")
        durum_goster("Çalışıyor. Oyunu veya videoyu açabilirsiniz.")

    ana_dugme = dugme(k0, "Başlat", baslat_durdur, dolu=True)
    ana_dugme.pack(fill="x", ipady=7)

    def ceviri_ayarlari():
        p = tk.Toplevel(kok)
        p.title("Çeviri ayarları")
        p.configure(bg=R["zemin"])
        p.geometry("480x520")
        tf = tk.Frame(p, bg=R["kart"], padx=14, pady=12, highlightbackground=R["cizgi"], highlightthickness=1)
        tf.pack(fill="x", padx=12, pady=(12, 0))
        tk.Label(tf, text="TELEFONUN YAPAY ZEKÂSI", font=(YAZI, 8, "bold"), fg=R["turkuaz"], bg=R["kart"]).pack(anchor="w")
        tk.Label(tf, text="Telefonda GameLingo → \"TV ve bilgisayara çeviri sağla\". Ekrandaki 4 haneli kodu yaz.",
                 font=(YAZI, 8), fg=R["soluk"], bg=R["kart"], wraplength=420, justify="left").pack(anchor="w", pady=(2, 6))
        ksat = tk.Frame(tf, bg=R["kart"])
        ksat.pack(fill="x")
        ksol = tk.Frame(ksat, bg=R["kart"]); ksol.pack(side="left", fill="x", expand=True, padx=(0, 6))
        ksag = tk.Frame(ksat, bg=R["kart"]); ksag.pack(side="left", fill="x", expand=True, padx=(6, 0))
        tk.Label(ksol, text="Kod", font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
        giris(ksol, kod_degisken).pack(fill="x", ipady=4)
        tk.Label(ksag, text="Adres (boş bırak, kendisi bulur)", font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
        giris(ksag, ip_degisken).pack(fill="x", ipady=4)

        def telefonu_bul():
            kaydet()
            bilgi.set("Telefon aranıyor...")

            def calis():
                kopru = TelefonKopru(ayarlar)
                metin, hazir = kopru.baglan()

                def arayuze_yaz():
                    ip_degisken.set(ayarlar.get("telefon_ip", ""))
                    if hazir:
                        kaynak_sec("Telefon")
                    kaydet()
                    bilgi.set(metin)
                    durum_goster(metin)

                kok.after(0, arayuze_yaz)

            threading.Thread(target=calis, daemon=True).start()

        dugme(tf, "Telefonu bul ve bağlan", telefonu_bul).pack(fill="x", ipady=4, pady=(8, 0))

        ic = tk.Frame(p, bg=R["kart"], padx=14, pady=12, highlightbackground=R["cizgi"], highlightthickness=1)
        ic.pack(fill="both", expand=True, padx=12, pady=12)
        tk.Label(ic, text="GEMINI (İNTERNET)", font=(YAZI, 8, "bold"), fg=R["turkuaz"], bg=R["kart"]).pack(anchor="w", pady=(0, 4))
        tk.Label(ic, text="Google AI Studio anahtarı (AIza... ile başlar)", font=(YAZI, 8),
                 fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
        giris(ic, api_degisken, gizli=True).pack(fill="x", ipady=4, pady=(0, 8))
        tk.Label(ic, text="Model", font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
        model_kutusu = ttk.Combobox(ic, textvariable=model_degisken)
        model_kutusu.pack(fill="x", pady=(0, 8))
        bilgi = tk.StringVar(value="")
        tk.Label(ic, textvariable=bilgi, font=(YAZI, 8), fg=R["yazi"], bg=R["kart"],
                 wraplength=420, justify="left").pack(anchor="w", pady=(0, 8))

        def yaz(metin):
            kok.after(0, lambda: (bilgi.set(metin), durum_goster(metin)))

        def modelleri_bul():
            kaydet()
            bilgi.set("Modeller aranıyor...")

            def calis():
                c = Cevirmen(ayarlar)
                adlar = c.modelleri_getir()
                if not adlar:
                    yaz(f"Model listesi alınamadı ✗   {c.son_hata}")
                    return
                secilen = Cevirmen.en_uygun(adlar)

                def arayuze_yaz():
                    model_kutusu["values"] = adlar
                    if secilen:
                        model_degisken.set(secilen)
                        ayarlar["model"] = secilen
                        ayarlari_kaydet(ayarlar)
                    ozet_yenile()
                    bilgi.set(f"{len(adlar)} model bulundu ✓   Seçilen: {secilen}")

                kok.after(0, arayuze_yaz)

            threading.Thread(target=calis, daemon=True).start()

        def test_et():
            kaydet()
            bilgi.set("Deneniyor...")

            def calis():
                c = cevirmen_olustur(ayarlar)
                sonuc = c.cevir("He is waiting outside.")
                if sonuc:
                    yaz(f"Çeviri çalışıyor ✓   «{sonuc}»   ({int(c.son_sure * 1000)} ms)")
                else:
                    yaz(f"Çeviri başarısız ✗   {c.son_hata}")

            threading.Thread(target=calis, daemon=True).start()

        satir = tk.Frame(ic, bg=R["kart"])
        satir.pack(fill="x")
        dugme(satir, "Modelleri bul", modelleri_bul).pack(side="left", fill="x", expand=True, ipady=4, padx=(0, 6))
        dugme(satir, "Çeviriyi test et", test_et).pack(side="left", fill="x", expand=True, ipady=4, padx=(6, 0))
        dugme(ic, "Kaydet ve kapat", lambda: (kaydet(), p.destroy()), dolu=True).pack(fill="x", ipady=5, pady=(10, 0))
        return p

    kok.protocol("WM_DELETE_WINDOW", lambda: (kaydet(), kok.destroy()))
    kok.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as hata:
        print("Beklenmeyen hata:", hata)
        input("Kapatmak için Enter'a basın...")
