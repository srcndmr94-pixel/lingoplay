"""
GameLingo PC (eski adıyla LingoPlay) — ekrandaki İngilizce altyazıyı anlık Türkçeye çevirir.

Windows için tek dosyalık program. Ekranın alt şeridini yakalar, yazıyı okur,
telefondaki GameLingo'nun yapay zekâsıyla (internetsiz) Türkçeye çevirir ve ekranın üstünde bir kutuda gösterir.

Android sürümüyle aynı mantık: kalıp sözlüğü önce, sonra kalıcı hafıza,
en son yapay zekâ. Bir replik için ekrana bir kez yazılır, değişmez.
"""

import collections
import json
import socket
import os
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk

try:
    import mss
except ImportError:
    mss = None

try:
    from rapidocr_onnxruntime import RapidOCR
except ImportError:
    RapidOCR = None


SURUM = "5.7"

APP_DIR = os.path.join(os.path.expanduser("~"), ".lingoplay")
CONFIG_PATH = os.path.join(APP_DIR, "ayarlar.json")
MEMORY_PATH = os.path.join(APP_DIR, "hafiza.json")

VARSAYILAN = {
    "oyun": "",
    "tur": "Oyun",
    "ust_yuzde": 74,
    "alt_yuzde": 99,
    "sol_yuzde": 8,
    "sag_yuzde": 92,
    "aralik_ms": 350,
    "telefon_kod": "",
    "telefon_ip": "",
    "yazi_boyutu": 20,
    "konusan_goster": True,
    "ekran": 1,
}


# ---------------------------------------------------------------- kalıp sözlüğü

KALIPLAR = {
    "yes": "Evet", "no": "Hayır", "okay": "Tamam", "ok": "Tamam",
    "alright": "Pekâlâ", "all right": "Pekâlâ", "sure": "Tabii",
    "of course": "Elbette", "exactly": "Aynen öyle", "maybe": "Belki",
    "never": "Asla", "always": "Her zaman", "nothing": "Hiçbir şey",
    "i dont know": "Bilmiyorum", "i dont understand": "Anlamıyorum",
    "i see": "Anlıyorum", "got it": "Anladım", "understood": "Anlaşıldı",
    "forget it": "Boş ver", "never mind": "Boş ver", "no way": "Mümkün değil",
    "damn it": "Kahretsin", "what the hell": "Bu da ne böyle",
    "oh no": "Olamaz", "my god": "Tanrım",
    "hello": "Merhaba", "hi": "Selam", "hey": "Hey",
    "good morning": "Günaydın", "good evening": "İyi akşamlar",
    "good night": "İyi geceler", "goodbye": "Hoşça kal", "farewell": "Elveda",
    "see you": "Görüşürüz", "take care": "Kendine iyi bak",
    "thank you": "Teşekkür ederim", "thanks": "Teşekkürler",
    "youre welcome": "Rica ederim", "please": "Lütfen",
    "sorry": "Üzgünüm", "im sorry": "Üzgünüm", "excuse me": "Affedersiniz",
    "forgive me": "Beni bağışla", "congratulations": "Tebrikler",
    "well done": "Aferin", "good luck": "Bol şans",
    "look out": "Dikkat et", "watch out": "Dikkat et",
    "careful": "Dikkatli ol", "be careful": "Dikkatli ol",
    "get down": "Eğil", "take cover": "Siper al", "behind you": "Arkanda",
    "run": "Kaç", "move": "Kımılda", "go": "Git", "lets go": "Gidelim",
    "come on": "Hadi", "hurry": "Çabuk ol", "hurry up": "Acele et",
    "wait": "Bekle", "hold on": "Bir dakika", "stop": "Dur",
    "stop it": "Kes şunu", "stay back": "Geride dur", "stay here": "Burada kal",
    "follow me": "Beni takip et", "this way": "Bu taraftan",
    "over here": "Buraya", "get up": "Kalk", "im on it": "Hallediyorum",
    "leave it to me": "Bana bırak", "cover me": "Beni koru",
    "reloading": "Dolduruyorum", "theyre coming": "Geliyorlar",
    "hes dead": "Öldü", "dont move": "Kıpırdama", "dont": "Yapma",
    "its a trap": "Bu bir tuzak", "were surrounded": "Kuşatıldık",
    "i need help": "Yardıma ihtiyacım var", "help me": "Bana yardım et",
    "are you okay": "İyi misin", "are you all right": "İyi misin",
    "im fine": "İyiyim",
    "who are you": "Sen kimsin", "what is this": "Bu ne",
    "whats this": "Bu ne", "whats going on": "Neler oluyor",
    "what happened": "Ne oldu", "what do you mean": "Ne demek istiyorsun",
    "what do you want": "Ne istiyorsun", "where are you": "Neredesin",
    "where are we": "Neredeyiz", "why": "Neden", "why not": "Neden olmasın",
    "how": "Nasıl", "are you sure": "Emin misin",
    "do you understand": "Anlıyor musun", "can you hear me": "Beni duyuyor musun",
    "whos there": "Kim var orada", "what now": "Şimdi ne olacak",
    "i promise": "Söz veriyorum", "i swear": "Yemin ederim",
    "trust me": "Bana güven", "listen to me": "Beni dinle", "listen": "Dinle",
    "look at me": "Bana bak", "tell me": "Anlat bana",
    "its over": "Her şey bitti", "its too late": "Çok geç",
    "it doesnt matter": "Fark etmez", "theres no time": "Vakit yok",
    "i knew it": "Biliyordum", "youre right": "Haklısın",
    "youre wrong": "Yanılıyorsun", "im serious": "Ciddiyim",
    "are you serious": "Ciddi misin", "thats enough": "Bu kadar yeter",
    "enough": "Yeter", "calm down": "Sakin ol", "relax": "Rahatla",
    "dont worry": "Merak etme", "be quiet": "Sessiz ol",
    "shut up": "Kes sesini", "leave me alone": "Beni yalnız bırak",
    "get out": "Defol", "come with me": "Benimle gel",
    "stay with me": "Yanımda kal", "im coming": "Geliyorum",
    "im here": "Buradayım", "thank god": "Çok şükür",
    "i miss you": "Seni özledim", "i love you": "Seni seviyorum",
    "loading": "Yükleniyor", "saving": "Kaydediliyor",
    "checkpoint reached": "Kontrol noktasına ulaşıldı",
    "objective complete": "Görev tamamlandı", "new objective": "Yeni görev",
    "mission failed": "Görev başarısız", "level up": "Seviye atladın",
    "you died": "Öldün", "game over": "Oyun bitti", "continue": "Devam et",
    "skip": "Atla", "settings": "Ayarlar", "options": "Seçenekler",
    "inventory": "Envanter", "map": "Harita", "exit": "Çıkış",
}

ARAYUZ_KELIMELERI = {
    "l1", "l2", "l3", "r1", "r2", "r3", "ps", "touchpad", "skip",
    "options", "start", "select", "esc", "tab", "enter", "space",
}

KISALTMALAR = [
    ("dont", "don't"), ("doesnt", "doesn't"), ("didnt", "didn't"),
    ("cant", "can't"), ("couldnt", "couldn't"), ("wont", "won't"),
    ("wouldnt", "wouldn't"), ("shouldnt", "shouldn't"), ("isnt", "isn't"),
    ("arent", "aren't"), ("wasnt", "wasn't"), ("werent", "weren't"),
    ("havent", "haven't"), ("hasnt", "hasn't"), ("im", "I'm"),
    ("ive", "I've"), ("ill", "I'll"), ("youre", "you're"),
    ("youve", "you've"), ("hes", "he's"), ("shes", "she's"),
    ("thats", "that's"), ("theres", "there's"), ("theyre", "they're"),
    ("lets", "let's"), ("whats", "what's"),
]


def sadelestir(metin):
    return re.sub(r"[^a-z0-9 ]", "", metin.lower()).strip()


def metni_onar(ham):
    metin = ham.replace("…", "...")
    metin = re.sub(r"\s+", " ", metin).strip(" -—\"'")
    for yanlis, dogru in KISALTMALAR:
        metin = re.sub(rf"\b{yanlis}\b", dogru, metin, flags=re.IGNORECASE)
    return metin.strip()


def konusani_ayir(metin):
    """'JAMES: Merhaba' → ('JAMES', 'Merhaba'). İsim çeviriye girmez."""
    yer = metin.find(":")
    if 0 < yer <= 24:
        ad = metin[:yer].strip()
        geri = metin[yer + 1:].strip()
        if len(geri) > 1 and all(c.isalpha() or c in " .'-" for c in ad):
            return ad, geri
    return None, metin


# -------------------------------------------------------------------- hafıza

class Hafiza:
    """Çevrilen replikler diske yazılır; tekrar edince bedava ve anında gelir."""

    def __init__(self):
        self.veri = {}
        try:
            with open(MEMORY_PATH, encoding="utf-8") as f:
                self.veri = json.load(f)
        except Exception:
            self.veri = {}
        self.kilit = threading.Lock()

    def al(self, metin):
        return self.veri.get(sadelestir(metin))

    def koy(self, metin, ceviri):
        with self.kilit:
            self.veri[sadelestir(metin)] = ceviri
            if len(self.veri) > 5000:
                self.veri = dict(list(self.veri.items())[-3000:])
            try:
                os.makedirs(APP_DIR, exist_ok=True)
                with open(MEMORY_PATH, "w", encoding="utf-8") as f:
                    json.dump(self.veri, f, ensure_ascii=False)
            except Exception:
                pass


# ------------------------------------------------------------------- çeviri

# ---------------------------------------------------------- telefon köprüsü

class TelefonKopru:
    """Çeviriyi telefondaki GameLingo'nun yapay zekâsına yaptırır (internet ve anahtar gerekmez).
    Telefonda: GameLingo → "TV ve bilgisayara çeviri sağla". GameLingo TV ile aynı protokol:
      Bulma (UDP 47322, yayın): "GLFIND <kod>" -> "GLHERE"
      Deneme (TCP 47321):       "GL1 <kod> PING" -> "PONG 1/0"
      Çeviri (TCP 47321):       "GL1 <kod> <sıra> <öncekiSayısı>" + tür + ad + satır + öncekiler
                                -> "OK <çeviri>" | "SKIP" | "ERR <sebep>"
      Hızlı taslak:             başlığın sonuna " Q" -> telefonun hızlı çevirisi anında
    Arayüz: cevir(metin), son_hata, son_sure, atlandi."""

    TCP_PORT = 47321
    UDP_PORT = 47322

    def __init__(self, ayarlar):
        self.ayarlar = ayarlar
        self.son_hata = None
        self.son_sure = 0.0
        self.atlandi = False
        self.sira = 0
        self.onceki = []
        self.kilit = threading.Lock()

    @staticmethod
    def _tek(s):
        return (s or "").replace("\n", " ").replace("\r", " ").strip()

    def kod(self):
        return self._tek(str(self.ayarlar.get("telefon_kod", "")))

    def _istek(self, host, govde, sure):
        try:
            with socket.create_connection((host, self.TCP_PORT), timeout=2.0) as s:
                s.settimeout(sure)
                s.sendall(govde.encode("utf-8"))
                veri = b""
                while not veri.endswith(b"\n") and len(veri) < 65536:
                    parca = s.recv(4096)
                    if not parca:
                        break
                    veri += parca
                return veri.decode("utf-8", "replace").strip()
        except Exception:
            return None

    def bul(self, sure=2.5):
        """Telefonu kodla ağda arar; bulursa adresini döner."""
        kod = self.kod()
        if not kod:
            return None
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                s.settimeout(sure)
                s.sendto(f"GLFIND {kod}".encode("utf-8"), ("255.255.255.255", self.UDP_PORT))
                veri, adres = s.recvfrom(64)
                if veri.decode("utf-8", "replace").startswith("GLHERE"):
                    return adres[0]
        except Exception:
            pass
        return None

    def ping(self, host):
        """None: ulaşılamadı; True/False: telefonda yapay zekâ hazır mı."""
        r = self._istek(host, f"GL1 {self.kod()} PING\n", 3.0)
        if not r or not r.startswith("PONG"):
            return None
        return r.endswith("1")

    def baglan(self):
        """Kayıtlı adresi dener, olmazsa arar. (durum metni, hazır mı) döner."""
        if not self.kod():
            return "Telefon kodu girilmemiş", False
        host = self._tek(self.ayarlar.get("telefon_ip", ""))
        p = self.ping(host) if host else None
        if p is None:
            bulunan = self.bul()
            if bulunan:
                host = bulunan
                self.ayarlar["telefon_ip"] = bulunan
                p = self.ping(host)
        if p is None:
            return "Telefon bulunamadı. Telefonda \"TV ve bilgisayara çeviri sağla\" açık mı, aynı Wi-Fi'da mısınız?", False
        if p is False:
            return f"Telefon bulundu ({host}) ama yapay zekâ modeli hazır değil", False
        return f"Telefon bağlı ✓ ({host})", True

    def taslak(self, metin):
        """Telefonun hızlı (yapay zekâsız) çevirisi: anında gelir, ekranda önce bu görünür."""
        kod = self.kod()
        host = self._tek(self.ayarlar.get("telefon_ip", ""))
        if not kod or not host:
            return None
        govde = (f"GL1 {kod} 0 0 Q\n"
                 f"{self._tek(self.ayarlar.get('tur') or 'Oyun')}\n"
                 f"{self._tek(self.ayarlar.get('oyun') or '')}\n"
                 f"{self._tek(metin)}\n")
        r = self._istek(host, govde, 3.0)
        if r and r.startswith("OK "):
            return r[3:].strip() or None
        return None

    def cevir(self, metin):
        self.son_sure = 0.0
        self.atlandi = False
        baslangic = time.time()
        kod = self.kod()
        if not kod:
            self.son_hata = "Telefon kodu girilmemiş (Çeviri → Ayarlar)"
            return None
        host = self._tek(self.ayarlar.get("telefon_ip", ""))
        if not host:
            host = self.bul()
            if not host:
                self.son_hata = "Telefon bulunamadı"
                return None
            self.ayarlar["telefon_ip"] = host
        with self.kilit:
            self.sira += 1
            sira = self.sira
            onceki = list(self.onceki[-2:])
            self.onceki = (self.onceki + [metin])[-2:]
        govde = (f"GL1 {kod} {sira} {len(onceki)}\n"
                 f"{self._tek(self.ayarlar.get('tur') or 'Oyun')}\n"
                 f"{self._tek(self.ayarlar.get('oyun') or '')}\n"
                 f"{self._tek(metin)}\n" + "".join(self._tek(o) + "\n" for o in onceki))
        r = self._istek(host, govde, 15.0)
        if r is None:
            # Adres değişmiş olabilir: bir kez yeniden ara.
            yeni = self.bul()
            if yeni and yeni != host:
                self.ayarlar["telefon_ip"] = yeni
                r = self._istek(yeni, govde, 15.0)
        self.son_sure = time.time() - baslangic
        if r is None:
            self.son_hata = "Telefona ulaşılamadı"
            return None
        if r.startswith("OK "):
            self.son_hata = None
            return r[3:].strip() or None
        if r.startswith("SKIP"):
            self.atlandi = True
            self.son_hata = None
            return None
        self.son_hata = "Telefon: " + (r[3:].strip() if r.startswith("ERR") else "anlaşılmayan cevap")
        return None


def cevirmen_olustur(ayarlar):
    return TelefonKopru(ayarlar)


# ------------------------------------------------------------ çalışma kaydı

class Kayit:
    """Çalışma kaydı: ne okundu, ne yazıldı, ne kadar sürdü, hangi hata çıktı.
    Son 400 satır bellekte (pencerede gösterilir/kopyalanır), hepsi dosyaya da yazılır."""

    def __init__(self):
        self.satirlar = collections.deque(maxlen=400)
        self.son_hata = ""
        self.kilit = threading.Lock()

    def dosya(self):
        return os.path.join(APP_DIR, "calisma_kaydi.txt")

    def yaz(self, metin, hata=False):
        satir = time.strftime("%H:%M:%S") + "  " + ("HATA: " if hata else "") + str(metin).replace("\n", " ")
        with self.kilit:
            self.satirlar.append(satir)
            if hata:
                self.son_hata = satir
        try:
            os.makedirs(APP_DIR, exist_ok=True)
            yol = self.dosya()
            if os.path.exists(yol) and os.path.getsize(yol) > 1_000_000:
                os.replace(yol, yol + ".eski")
            with open(yol, "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d ") + satir + "\n")
        except Exception:
            pass

    def metin(self):
        with self.kilit:
            return "\n".join(self.satirlar)

    def temizle(self):
        with self.kilit:
            self.satirlar.clear()
            self.son_hata = ""


KAYIT = Kayit()


def sistem_bilgisi():
    """İşlemci çekirdeği ve boş bellek (Windows'ta); kayda yazılır."""
    parcalar = [f"{os.cpu_count() or '?'} çekirdek"]
    if sys.platform == "win32":
        try:
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]

            m = MEMORYSTATUSEX()
            m.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                parcalar.append(f"bellek %{m.dwMemoryLoad} dolu ({m.ullAvailPhys // 2**20} MB boş / "
                                f"{m.ullTotalPhys // 2**20} MB)")
        except Exception:
            pass
    return " · ".join(parcalar)


# ------------------------------------------------------------------- görünüm

RENK = {
    "zemin": "#0B1220",      # pencere
    "kart": "#131C2E",       # kartlar
    "cizgi": "#1F2B44",      # kart kenarı
    "alan": "#0B1220",       # yazı kutuları
    "alan_cizgi": "#2A3A58",
    "yazi": "#E6EDF7",
    "soluk": "#8FA3BF",
    "turkuaz": "#2EE6D6",
    "turkuaz_koyu": "#04342C",
    "mavi": "#2EA8FF",
    "mavi_zemin": "#13324A",
    "kirmizi": "#FF6B6B",
    "gri": "#5B6B85",
    "taslak": "#AEB9C8",
}
YAZI = "Segoe UI"


def durum_rengi(metin):
    """Durum satırına göre nokta rengi: hata kırmızı, çalışıyor turkuaz, diğerleri gri."""
    m = (metin or "").lower()
    if any(k in m for k in ("hata", "başarısız", "✗", "alınamadı", "yüklenemedi")):
        return RENK["kirmizi"]
    if any(k in m for k in ("çalışıyor", "ocr ", "✓")):
        return RENK["turkuaz"]
    return RENK["gri"]


# ------------------------------------------------------------------- ekran

class Kutu:
    """Ekranın üstünde duran, her zaman önde çeviri kutusu: koyu zemin, turkuaz alt şerit,
    konuşanın adı turkuaz."""

    def __init__(self, kok, yazi_boyutu=20):
        self.pencere = tk.Toplevel(kok)
        self.pencere.overrideredirect(True)
        self.pencere.attributes("-topmost", True)
        self.pencere.attributes("-alpha", 0.93)
        self.pencere.configure(bg=RENK["zemin"])
        govde = tk.Frame(self.pencere, bg=RENK["zemin"])
        govde.pack()
        self.ad = tk.Label(govde, text="", font=(YAZI, yazi_boyutu, "bold"),
                           fg=RENK["turkuaz"], bg=RENK["zemin"], padx=0, pady=8)
        self.etiket = tk.Label(govde, text="", font=(YAZI, yazi_boyutu, "bold"),
                               fg="white", bg=RENK["zemin"], wraplength=1100,
                               justify="center", padx=16, pady=8)
        self.ad.pack(side="left", anchor="n")
        self.etiket.pack(side="left")
        tk.Frame(self.pencere, bg=RENK["turkuaz"], height=3).pack(fill="x")
        self.pencere.withdraw()

    def yaz(self, metin, taslak=False):
        if not metin:
            self.pencere.withdraw()
            return
        # Taslak (hızlı çeviri) açık gri; yapay zekânın doğrusu beyaz.
        self.etiket.config(fg=RENK["taslak"] if taslak else "white")
        ad, govde = konusani_ayir(metin)
        if ad:
            self.ad.config(text="  " + ad + ":")
            self.etiket.config(text=govde, padx=8)
        else:
            self.ad.config(text="")
            self.etiket.config(text=metin, padx=16)
        self.pencere.update_idletasks()
        genislik = self.pencere.winfo_width()
        ekran = self.pencere.winfo_screenwidth()
        self.pencere.geometry(f"+{max(0, (ekran - genislik) // 2)}+40")
        self.pencere.deiconify()
        self.pencere.lift()


def bolgeyi_goster(kok, ayarlar, sure_ms=2500):
    """Okunan altyazı bölgesini birkaç saniye yarı saydam turkuaz çerçeveyle gösterir."""
    try:
        ekran_no = int(ayarlar.get("ekran", 1))
    except (TypeError, ValueError):
        ekran_no = 1
    ekran = None
    if mss is not None:
        try:
            with mss.mss() as sct:
                ekranlar = sct.monitors
                ekran = ekranlar[ekran_no] if ekran_no < len(ekranlar) else ekranlar[0]
        except Exception:
            ekran = None
    if not ekran:
        ekran = {"left": 0, "top": 0, "width": kok.winfo_screenwidth(), "height": kok.winfo_screenheight()}
    yuk, gen = ekran["height"], ekran["width"]
    ust = ekran["top"] + int(yuk * ayarlar["ust_yuzde"] / 100)
    alt = ekran["top"] + int(yuk * ayarlar["alt_yuzde"] / 100)
    sol = ekran["left"] + int(gen * ayarlar.get("sol_yuzde", 8) / 100)
    sag = ekran["left"] + int(gen * ayarlar.get("sag_yuzde", 92) / 100)
    p = tk.Toplevel(kok)
    p.overrideredirect(True)
    p.attributes("-topmost", True)
    p.attributes("-alpha", 0.35)
    p.configure(bg=RENK["turkuaz"])
    tk.Label(p, text="GameLingo burayı okuyor", font=(YAZI, 14, "bold"),
             fg=RENK["turkuaz_koyu"], bg=RENK["turkuaz"]).pack(expand=True)
    p.geometry(f"{max(40, sag - sol)}x{max(20, alt - ust)}+{sol}+{ust}")
    p.after(sure_ms, p.destroy)
    return p


# -------------------------------------------------------------------- motor

# Oyunu yavaşlatmasın diye: okuma en fazla bu kadar sık yapılır ve okuma, sürdüğü
# zamanın en az 2 katı kadar dinlenir (işlemcinin en fazla ~%33'ü okumaya gider).
EN_KISA_ARALIK = 0.30
OKUMA_GENISLIGI = 800
OCR_IS_PARCACIGI = 2


def ocr_olustur():
    """OCR'ı işlemcinin tamamını değil, yalnızca birkaç çekirdeğini kullanacak şekilde kurar."""
    if not RapidOCR:
        return None
    for ayar in ({"intra_op_num_threads": OCR_IS_PARCACIGI, "inter_op_num_threads": 1}, {}):
        try:
            return RapidOCR(**ayar)
        except Exception:
            continue
    return None


def dusuk_oncelik():
    """Windows'ta programı 'normalin altı' önceliğe alır: oyun her zaman önce çalışır."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
        k32 = ctypes.windll.kernel32
        k32.SetPriorityClass(k32.GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS)
    except Exception:
        pass


class Motor(threading.Thread):
    def __init__(self, ayarlar, kutu, durum_yaz):
        super().__init__(daemon=True)
        self.ayarlar = ayarlar
        self.kutu = kutu
        self.durum_yaz = durum_yaz
        self.calisiyor = True
        self.hafiza = Hafiza()
        self.cevirmen = cevirmen_olustur(ayarlar)
        self.ocr = ocr_olustur()
        self.yon_kapali = True   # altyazı hep düz: yön düzeltme adımını atla
        self.gosterilen = ""
        self.son_okunan = ""
        self.taslak_suresi = 0.0
        self.bos_kare = 0
        self.kilit = threading.Lock()
        self.tani = {"kare": 0, "ayni": 0, "okuma": 0, "bos": 0, "ocr_toplam": 0.0, "son": ""}
        self.tani_zamani = time.time()
        self.bekleyen = None
        self.yz_calisiyor = False
        self.taslaklar = {}
        self.onceki_kare = None
        self.ocr_suresi = 0.0
        self.gosterim_zamani = 0.0

    def dur(self):
        self.calisiyor = False
        KAYIT.yaz("Durduruldu")

    def hata(self, metin):
        """Hatayı hem durum satırına hem çalışma kaydına (son hata olarak) yazar."""
        KAYIT.yaz(metin, hata=True)
        self.durum_yaz(metin)

    def bolge(self, sct):
        ekran_no = int(self.ayarlar.get("ekran", 1))
        ekranlar = sct.monitors
        ekran = ekranlar[ekran_no] if ekran_no < len(ekranlar) else ekranlar[0]
        yuk = ekran["height"]
        gen = ekran["width"]
        ust = ekran["top"] + int(yuk * self.ayarlar["ust_yuzde"] / 100)
        alt = ekran["top"] + int(yuk * self.ayarlar["alt_yuzde"] / 100)
        sol = ekran["left"] + int(gen * self.ayarlar["sol_yuzde"] / 100)
        sag = ekran["left"] + int(gen * self.ayarlar["sag_yuzde"] / 100)
        return {"top": ust, "left": sol, "width": max(8, sag - sol), "height": max(8, alt - ust)}

    def oku(self, goruntu):
        if not self.ocr:
            return ""
        try:
            if self.yon_kapali:
                try:
                    sonuc, _ = self.ocr(goruntu, use_cls=False)
                except TypeError:
                    self.yon_kapali = False
                    sonuc, _ = self.ocr(goruntu)
            else:
                sonuc, _ = self.ocr(goruntu)
        except Exception as e:
            # Sessiz kalmıyoruz: okuma hiç çalışmıyorsa sebebi görünsün.
            self.hata(f"OCR hatası: {type(e).__name__}: {e}")
            return ""
        if not sonuc:
            return ""
        satirlar = []
        for kutu_, metin, guven in sonuc:
            t = (metin or "").strip()
            if not t or guven < 0.5:
                continue
            if sadelestir(t) in ARAYUZ_KELIMELERI:
                continue
            if len(t) < 3 or sum(c.isalpha() for c in t) < 3:
                continue
            ust = min(p[1] for p in kutu_)
            satirlar.append((ust, t))
        satirlar.sort()
        return " ".join(t for _, t in satirlar)

    def benzer(self, a, b):
        if not a or not b:
            return a == b
        na, nb = sadelestir(a), sadelestir(b)
        if na == nb:
            return True
        uzun, kisa = (na, nb) if len(na) >= len(nb) else (nb, na)
        if not uzun or len(kisa) / len(uzun) < 0.8:
            return False
        fark = sum(1 for x, y in zip(uzun, kisa) if x != y) + (len(uzun) - len(kisa))
        return fark / len(uzun) <= 0.12

    def run(self):
        if mss is None or self.ocr is None:
            self.hata("Gerekli bileşenler yüklenemedi.")
            return

        import numpy as np

        KAYIT.yaz(f"SÜRÜM {SURUM} · {sistem_bilgisi()} · tarama {self.ayarlar.get('aralik_ms')} ms · "
                  f"bölge %{self.ayarlar.get('ust_yuzde')}–%{self.ayarlar.get('alt_yuzde')} · "
                  f"ekran {self.ayarlar.get('ekran')} · telefon {self.ayarlar.get('telefon_ip') or 'aranacak'}")
        with mss.mss() as sct:
            while self.calisiyor:
                aralik = max(EN_KISA_ARALIK, self.ayarlar["aralik_ms"] / 1000)
                time.sleep(max(aralik, self.ocr_suresi * 2))
                try:
                    self.tani_yaz()
                    kare = sct.grab(self.bolge(sct))
                    self.tani["kare"] += 1
                    dizi = np.array(kare)[:, :, :3]

                    # Görüntü küçültülürse OCR belirgin biçimde hızlanır.
                    if dizi.shape[1] > OKUMA_GENISLIGI:
                        adim = int(dizi.shape[1] / OKUMA_GENISLIGI) + 1
                        kucuk = np.ascontiguousarray(dizi[::adim, ::adim])
                    else:
                        kucuk = np.ascontiguousarray(dizi)

                    # Kare neredeyse aynıysa OCR'a hiç girmiyoruz.
                    imza = kucuk[::4, ::4].astype(np.int16)
                    if self.onceki_kare is not None and imza.shape == self.onceki_kare.shape:
                        if np.abs(imza - self.onceki_kare).max() < 6:
                            self.tani["ayni"] += 1
                            continue
                    self.onceki_kare = imza

                    ocr_basla = time.time()
                    ham = self.oku(kucuk)
                    self.ocr_suresi = time.time() - ocr_basla
                    self.tani["okuma"] += 1
                    self.tani["ocr_toplam"] += self.ocr_suresi
                    if ham:
                        self.tani["son"] = ham[:60]
                    else:
                        self.tani["bos"] += 1
                except Exception as e:
                    self.hata(f"Okuma hatası: {type(e).__name__}: {e}")
                    self.onceki_kare = None
                    time.sleep(0.5)
                    continue

                # Ekranda 10 saniyedir aynı çeviri duruyorsa bir aksilik var;
                # takılı kalmasın diye temizliyoruz.
                if self.gosterilen and time.time() - self.gosterim_zamani > 15:
                    self.gosterilen = ""
                    self.kutu.yaz("")

                metin = metni_onar(ham)
                if len(metin) < 3:
                    self.bos_kare += 1
                    if self.bos_kare >= 6 and self.gosterilen:
                        self.gosterilen = ""
                        self.kutu.yaz("")
                    continue
                self.bos_kare = 0

                if self.benzer(metin, self.gosterilen) or self.benzer(metin, self.son_okunan):
                    continue   # zaten ekranda ya da yolda

                self.son_okunan = metin
                self.yeni_satir(metin)

    # --- çeviri akışı -------------------------------------------------------
    # Yeni satır gelince: kalıp/hafıza varsa anında; yoksa telefondan HIZLI TASLAK hemen (her satıra
    # ayrı, beklemesiz) ve YAPAY ZEKÂ için tek bir sıra: aynı anda tek istek, beklerken yeni satır
    # gelirse eskisi atlanır, hep en yenisi çevrilir (yavaş yapay zekâ ekranı geride bırakmaz).

    def yeni_satir(self, kaynak):
        KAYIT.yaz(f"OKUNAN (OCR {int(self.ocr_suresi * 1000)} ms): {kaynak}")
        if self._hazir_ceviri(kaynak):
            return
        threading.Thread(target=self._taslak_goster, args=(kaynak,), daemon=True).start()
        with self.kilit:
            self.bekleyen = kaynak
            if self.yz_calisiyor:
                return
            self.yz_calisiyor = True
        threading.Thread(target=self._yz_dongu, daemon=True).start()

    def _yz_dongu(self):
        while self.calisiyor:
            with self.kilit:
                kaynak = self.bekleyen
                self.bekleyen = None
                if kaynak is None:
                    self.yz_calisiyor = False
                    return
            try:
                self._yz(kaynak)
            except Exception as e:
                self.hata(f"Çeviri hatası: {type(e).__name__}: {e}")
        with self.kilit:
            self.yz_calisiyor = False

    def _adli(self, kaynak, metin):
        ad, _ = konusani_ayir(kaynak)
        return f"{ad}: {metin}" if (metin and ad and self.ayarlar.get("konusan_goster")) else metin

    def _hazir_ceviri(self, kaynak):
        """Kalıp sözlüğü ya da hafızada varsa anında gösterir."""
        ad, govde = konusani_ayir(kaynak)
        kalip = KALIPLAR.get(sadelestir(govde))
        if kalip:
            self.goster(kaynak, f"{ad}: {kalip}" if ad else kalip)
            KAYIT.yaz(f"YAZILAN · kalıp: {kalip}")
            return True
        kayitli = self.hafiza.al(kaynak)
        if kayitli:
            self.goster(kaynak, kayitli)
            KAYIT.yaz(f"YAZILAN · hafıza: {kayitli}")
            return True
        return False

    def _taslak_goster(self, kaynak):
        _, govde = konusani_ayir(kaynak)
        bas = time.time()
        taslak = self.cevirmen.taslak(govde) if hasattr(self.cevirmen, "taslak") else None
        if not taslak:
            KAYIT.yaz(f"TASLAK ALINAMADI ({int((time.time() - bas) * 1000)} ms) · telefon 9.25 mi?")
            return None
        KAYIT.yaz(f"YAZILAN · taslak {int((time.time() - bas) * 1000)} ms: {taslak}")
        self.taslaklar[kaynak] = taslak
        if len(self.taslaklar) > 50:
            self.taslaklar.pop(next(iter(self.taslaklar)), None)
        # Yapay zekâ daha önce bitirdiyse taslakla üstüne yazma.
        if self.guncel_mi(kaynak) and self.hafiza.al(kaynak) is None:
            self.taslak_suresi = time.time() - bas
            self.goster(kaynak, self._adli(kaynak, taslak), taslak=True)
        return taslak

    def _yz(self, kaynak):
        _, govde = konusani_ayir(kaynak)
        # İsim telefona gitmez; çeviriden sonra başa eklenir.
        ceviri = self._adli(kaynak, self.cevirmen.cevir(govde))
        taslak = self.taslaklar.get(kaynak)
        if ceviri:
            self.hafiza.koy(kaynak, ceviri)
            guncel = self.guncel_mi(kaynak)
            KAYIT.yaz(f"YAZILAN · yapay zekâ {int(self.cevirmen.son_sure * 1000)} ms"
                      + ("" if guncel else " (geç kaldı, hafızaya alındı)") + f": {ceviri}")
            if guncel:
                self.goster(kaynak, ceviri)
            self.durum_yaz(
                f"OCR {int(self.ocr_suresi * 1000)} ms · "
                + (f"taslak {int(self.taslak_suresi * 1000)} ms · " if taslak else "")
                + f"yapay zekâ {int(self.cevirmen.son_sure * 1000)} ms"
            )
        elif taslak:
            # Yapay zekâ cevap veremedi ama taslak ekranda: kalıcı hâle getir.
            if self.guncel_mi(kaynak):
                self.goster(kaynak, self._adli(kaynak, taslak))
            if not getattr(self.cevirmen, "atlandi", False):
                self.hata(f"Yapay zekâ çeviremedi, hızlı çeviri gösteriliyor: {self.cevirmen.son_hata}")
        elif getattr(self.cevirmen, "atlandi", False):
            KAYIT.yaz(f"ATLANDI (daha yeni satır geldi): {kaynak}")
        else:
            self.hata(f"Çeviri alınamadı: {self.cevirmen.son_hata}")

    def _isle(self, kaynak):
        """Tek satırı baştan sona sırayla işler (testler ve tek seferlik kullanım için)."""
        if self._hazir_ceviri(kaynak):
            return
        self._taslak_goster(kaynak)
        self._yz(kaynak)

    def tani_yaz(self, aralik=15):
        """15 sn'de bir özet: kaç kare alındı, kaçı aynıydı, okuma ortalama ne kadar sürdü."""
        if time.time() - self.tani_zamani < aralik:
            return
        t = self.tani
        ort = int(t["ocr_toplam"] / t["okuma"] * 1000) if t["okuma"] else 0
        KAYIT.yaz(f"TANI: kare {t['kare']} · aynı kare (atlandı) {t['ayni']} · okuma {t['okuma']} "
                  f"(boş {t['bos']}) · OCR ort. {ort} ms · son okunan: \"{t['son']}\"")
        self.tani = {"kare": 0, "ayni": 0, "okuma": 0, "bos": 0, "ocr_toplam": 0.0, "son": ""}
        self.tani_zamani = time.time()

    def guncel_mi(self, kaynak):
        """Bu satır hâlâ ekrandaki en son okunan satır mı? (Eski çeviri yenisinin üstüne yazılmasın.)"""
        return not self.son_okunan or self.benzer(kaynak, self.son_okunan)

    def goster(self, kaynak, metin, taslak=False):
        self.gosterilen = kaynak
        self.gosterim_zamani = time.time()
        if taslak:
            self.kutu.yaz(metin, taslak=True)
        else:
            self.kutu.yaz(metin)


# ------------------------------------------------------------------ arayüz

def ayarlari_yukle():
    ayarlar = dict(VARSAYILAN)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            ayarlar.update(json.load(f))
    except Exception:
        pass
    for eski in ("api_key", "model", "kaynak"):   # eski Gemini ayarları
        ayarlar.pop(eski, None)
    # Eski sürümlerin kaydettiği çok kısa aralık (120 ms) oyunu kasıyordu.
    try:
        if int(ayarlar.get("aralik_ms", 350)) < 300:
            ayarlar["aralik_ms"] = 350
    except (TypeError, ValueError):
        ayarlar["aralik_ms"] = 350
    return ayarlar


def ayarlari_kaydet(ayarlar):
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(ayarlar, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def main():
    dusuk_oncelik()
    ayarlar = ayarlari_yukle()
    R = RENK

    kok = tk.Tk()
    kok.title(f"GameLingo {SURUM}")
    kok.geometry("540x880")
    kok.minsize(500, 680)
    kok.configure(bg=R["zemin"])

    dis = tk.Frame(kok, bg=R["zemin"], padx=14, pady=12)
    dis.pack(fill="both", expand=True)

    def kart(baslik_metni=None):
        cerceve = tk.Frame(dis, bg=R["kart"], highlightbackground=R["cizgi"],
                           highlightthickness=1, padx=14, pady=12)
        cerceve.pack(fill="x", pady=(0, 10))
        if baslik_metni:
            tk.Label(cerceve, text=baslik_metni.upper(), font=(YAZI, 8, "bold"),
                     fg=R["turkuaz"], bg=R["kart"]).pack(anchor="w", pady=(0, 6))
        return cerceve

    def giris(ust, degisken, gizli=False):
        return tk.Entry(ust, textvariable=degisken, font=(YAZI, 10), bg=R["alan"], fg=R["yazi"],
                        insertbackground=R["turkuaz"], relief="flat",
                        highlightthickness=1, highlightbackground=R["alan_cizgi"],
                        highlightcolor=R["turkuaz"], show="•" if gizli else "")

    def dugme(ust, metin, komut, dolu=False):
        if dolu:
            return tk.Button(ust, text=metin, command=komut, font=(YAZI, 11, "bold"),
                             bg=R["turkuaz"], fg=R["turkuaz_koyu"], activebackground="#5FF0E3",
                             activeforeground=R["turkuaz_koyu"], relief="flat", bd=0, cursor="hand2")
        return tk.Button(ust, text=metin, command=komut, font=(YAZI, 9, "bold"),
                         bg=R["kart"], fg=R["turkuaz"], activebackground=R["mavi_zemin"],
                         activeforeground=R["turkuaz"], relief="flat", bd=0, cursor="hand2",
                         highlightthickness=1, highlightbackground=R["turkuaz"])

    alanlar = {}

    def degisken(anahtar):
        d = tk.StringVar(value=str(ayarlar.get(anahtar, "")))
        alanlar[anahtar] = d
        return d

    # --- başlık ---
    baslik = tk.Frame(dis, bg=R["zemin"])
    baslik.pack(fill="x", pady=(0, 10))
    simge = tk.Canvas(baslik, width=38, height=38, bg=R["zemin"], highlightthickness=0)
    simge.pack(side="left")
    simge.create_rectangle(2, 2, 36, 36, outline=R["turkuaz"], width=2)
    simge.create_oval(8, 15, 20, 29, outline=R["turkuaz"], width=2)
    simge.create_oval(18, 15, 30, 29, outline=R["turkuaz"], width=2)
    simge.create_rectangle(13, 15, 25, 22, fill=R["zemin"], outline=R["zemin"])
    simge.create_line(13, 15, 25, 15, fill=R["turkuaz"], width=2)
    yazi_kutusu = tk.Frame(baslik, bg=R["zemin"], padx=10)
    yazi_kutusu.pack(side="left")
    ad_satiri = tk.Frame(yazi_kutusu, bg=R["zemin"])
    ad_satiri.pack(anchor="w")
    tk.Label(ad_satiri, text="Game", font=(YAZI, 17, "bold"), fg=R["yazi"], bg=R["zemin"]).pack(side="left")
    tk.Label(ad_satiri, text="Lingo", font=(YAZI, 17, "bold"), fg=R["turkuaz"], bg=R["zemin"]).pack(side="left")
    tk.Label(yazi_kutusu, text=f"Bilgisayar · sürüm {SURUM}", font=(YAZI, 8),
             fg=R["soluk"], bg=R["zemin"]).pack(anchor="w")
    tk.Label(baslik, text=" PC ", font=(YAZI, 8, "bold"), fg=R["mavi"], bg=R["mavi_zemin"],
             padx=6, pady=2).pack(side="right")

    # --- durum + başlat ---
    k0 = kart()
    durum_satiri = tk.Frame(k0, bg=R["kart"])
    durum_satiri.pack(fill="x", pady=(0, 10))
    nokta = tk.Canvas(durum_satiri, width=12, height=12, bg=R["kart"], highlightthickness=0)
    nokta.pack(side="left", padx=(0, 8))
    nokta_id = nokta.create_oval(1, 1, 11, 11, fill=R["gri"], outline="")
    durum = tk.StringVar(value="Hazır. Başlat'a basın." if str(ayarlar.get("telefon_kod", "")).strip()
                         else "Telefon kodunu yazıp Başlat'a basın.")
    tk.Label(durum_satiri, textvariable=durum, font=(YAZI, 9), fg=R["yazi"], bg=R["kart"],
             wraplength=430, justify="left").pack(side="left", fill="x")

    def durum_goster(metin):
        durum.set(metin)
        try:
            nokta.itemconfig(nokta_id, fill=durum_rengi(metin))
        except Exception:
            pass
        try:
            son_hata.set(KAYIT.son_hata or "Son hata: yok")
            son_hata_etiketi.config(fg=R["kirmizi"] if KAYIT.son_hata else R["soluk"])
        except NameError:
            pass   # kayıt kartı henüz kurulmadı

    # --- telefonun yapay zekâsı (çeviriyi telefon yapar) ---
    kt = kart("Telefonun yapay zekâsı")
    tk.Label(kt, text="Telefonda GameLingo → \"TV ve bilgisayara çeviri sağla\"ya bas, ekrandaki 4 haneli kodu yaz.",
             font=(YAZI, 8), fg=R["soluk"], bg=R["kart"], wraplength=460, justify="left").pack(anchor="w", pady=(0, 6))
    kod_degisken = degisken("telefon_kod")
    ip_degisken = degisken("telefon_ip")
    ksat = tk.Frame(kt, bg=R["kart"])
    ksat.pack(fill="x")
    ksol = tk.Frame(ksat, bg=R["kart"])
    ksol.pack(side="left", fill="x", expand=True, padx=(0, 6))
    ksag = tk.Frame(ksat, bg=R["kart"])
    ksag.pack(side="left", fill="x", expand=True, padx=(6, 0))
    tk.Label(ksol, text="Kod", font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
    kod_girisi = giris(ksol, kod_degisken)
    kod_girisi.pack(fill="x", ipady=4)
    tk.Label(ksag, text="Adres (boş kalsın, kendisi bulur)", font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
    giris(ksag, ip_degisken).pack(fill="x", ipady=4)
    telefon_durumu = tk.StringVar(value="")
    tk.Label(kt, textvariable=telefon_durumu, font=(YAZI, 8), fg=R["yazi"], bg=R["kart"],
             wraplength=460, justify="left").pack(anchor="w", pady=(6, 0))

    def telefonu_bul():
        kaydet()
        telefon_durumu.set("Telefon aranıyor...")

        def calis():
            metin, hazir = TelefonKopru(ayarlar).baglan()
            KAYIT.yaz(f"Telefonu bul: {metin}", hata=not hazir)

            def arayuze_yaz():
                ip_degisken.set(ayarlar.get("telefon_ip", ""))
                kaydet()
                telefon_durumu.set(metin)
                durum_goster(metin)

            kok.after(0, arayuze_yaz)

        threading.Thread(target=calis, daemon=True).start()

    dugme(kt, "Telefonu bul ve bağlan", telefonu_bul).pack(fill="x", ipady=4, pady=(8, 0))

    # --- içerik ---
    k1 = kart("İçerik")
    tur_degisken = tk.StringVar(value=ayarlar.get("tur", "Oyun"))
    alanlar["tur"] = tur_degisken
    cipler = tk.Frame(k1, bg=R["kart"])
    cipler.pack(fill="x", pady=(0, 8))
    cip_dugmeleri = {}

    def tur_sec(t):
        tur_degisken.set(t)
        for ad_, b in cip_dugmeleri.items():
            secili = ad_ == t
            b.config(bg=R["turkuaz"] if secili else R["kart"],
                     fg=R["turkuaz_koyu"] if secili else R["soluk"])

    for t in ("Oyun", "Dizi", "Film", "Belgesel", "Video"):
        b = tk.Button(cipler, text=t, font=(YAZI, 9, "bold"), relief="flat", bd=0, padx=10, pady=3,
                      cursor="hand2", highlightthickness=1, highlightbackground=R["alan_cizgi"],
                      command=lambda t=t: tur_sec(t))
        b.pack(side="left", padx=(0, 6))
        cip_dugmeleri[t] = b
    tur_sec(tur_degisken.get() if tur_degisken.get() in cip_dugmeleri else "Oyun")
    tk.Label(k1, text="Adı (çeviri bağlamı için, örn. The Last of Us)", font=(YAZI, 8),
             fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
    giris(k1, degisken("oyun")).pack(fill="x", ipady=4)

    # --- altyazı bölgesi ---
    k2 = kart("Altyazı bölgesi")
    surgu_degerleri = {}

    def surgu(ust, metin, anahtar):
        satir = tk.Frame(ust, bg=R["kart"])
        satir.pack(fill="x")
        tk.Label(satir, text=metin, font=(YAZI, 9), fg=R["soluk"], bg=R["kart"]).pack(side="left")
        deger = tk.StringVar(value=f"%{ayarlar.get(anahtar, 0)}")
        tk.Label(satir, textvariable=deger, font=(YAZI, 9, "bold"), fg=R["yazi"], bg=R["kart"]).pack(side="right")
        sayi = tk.IntVar(value=int(ayarlar.get(anahtar, 0)))

        def degisti(_=None):
            deger.set(f"%{sayi.get()}")
            ayarlar[anahtar] = int(sayi.get())

        tk.Scale(ust, from_=0, to=100, orient="horizontal", variable=sayi, showvalue=0,
                 command=degisti, bg=R["kart"], fg=R["yazi"], troughcolor=R["alan_cizgi"],
                 activebackground=R["turkuaz"], highlightthickness=0, bd=0, sliderrelief="flat",
                 sliderlength=18, width=10).pack(fill="x", pady=(2, 8))
        surgu_degerleri[anahtar] = sayi

    surgu(k2, "Üst sınır", "ust_yuzde")
    surgu(k2, "Alt sınır", "alt_yuzde")
    alt_satir = tk.Frame(k2, bg=R["kart"])
    alt_satir.pack(fill="x", pady=(0, 8))
    for metin, anahtar in (("Ekran no", "ekran"), ("Tarama (ms)", "aralik_ms"), ("Yazı boyutu", "yazi_boyutu")):
        sutun = tk.Frame(alt_satir, bg=R["kart"])
        sutun.pack(side="left", fill="x", expand=True, padx=(0, 8))
        tk.Label(sutun, text=metin, font=(YAZI, 8), fg=R["soluk"], bg=R["kart"]).pack(anchor="w")
        giris(sutun, degisken(anahtar)).pack(fill="x", ipady=3)
    dugme(k2, "Bölgeyi ekranda göster", lambda: (kaydet(), bolgeyi_goster(kok, ayarlar))).pack(fill="x", ipady=4)
    tk.Label(k2, text="Pencerede izliyorsanız üst sınırı 55 yapın; tam ekranda 74 uygundur.",
             font=(YAZI, 8), fg=R["soluk"], bg=R["kart"], wraplength=460, justify="left").pack(anchor="w", pady=(6, 0))

    kutu = Kutu(kok, yazi_boyutu=int(ayarlar.get("yazi_boyutu", 20) or 20))
    motor = {"nesne": None}

    def durum_yaz(metin):
        kok.after(0, lambda: durum_goster(metin))

    def kaydet():
        for anahtar, d in alanlar.items():
            deger = d.get().strip()
            if anahtar in ("ekran", "aralik_ms", "yazi_boyutu"):
                try:
                    ayarlar[anahtar] = int(deger)
                except ValueError:
                    pass
            else:
                ayarlar[anahtar] = deger
        for anahtar, sayi in surgu_degerleri.items():
            ayarlar[anahtar] = int(sayi.get())
        if ayarlar["alt_yuzde"] <= ayarlar["ust_yuzde"]:
            ayarlar["alt_yuzde"] = min(100, ayarlar["ust_yuzde"] + 5)
        try:
            kutu.ad.config(font=(YAZI, int(ayarlar.get("yazi_boyutu", 20)), "bold"))
            kutu.etiket.config(font=(YAZI, int(ayarlar.get("yazi_boyutu", 20)), "bold"))
        except Exception:
            pass
        ayarlari_kaydet(ayarlar)

    def baslat_durdur():
        if motor["nesne"]:
            motor["nesne"].dur()
            motor["nesne"] = None
            kutu.yaz("")
            ana_dugme.config(text="Başlat")
            durum_goster("Durduruldu.")
            return
        kaydet()
        if not str(ayarlar.get("telefon_kod", "")).strip():
            durum_goster("Önce telefon kodunu yaz (telefonda \"TV ve bilgisayara çeviri sağla\").")
            try:
                kod_girisi.focus_set()
            except Exception:
                pass
            return
        m = Motor(ayarlar, kutu, durum_yaz)
        m.start()
        motor["nesne"] = m
        ana_dugme.config(text="Durdur")
        durum_goster("Çalışıyor. Oyunu veya videoyu açabilirsiniz.")

    ana_dugme = dugme(k0, "Başlat", baslat_durdur, dolu=True)
    ana_dugme.pack(fill="x", ipady=7)

    # --- çalışma kaydı ---
    kk = kart("Çalışma kaydı")
    son_hata = tk.StringVar(value=KAYIT.son_hata or "Son hata: yok")
    son_hata_etiketi = tk.Label(kk, textvariable=son_hata, font=(YAZI, 8), fg=R["soluk"], bg=R["kart"],
                                wraplength=460, justify="left")
    son_hata_etiketi.pack(anchor="w", pady=(0, 8))
    ksatir = tk.Frame(kk, bg=R["kart"])
    ksatir.pack(fill="x")

    def kaydi_kopyala():
        try:
            kok.clipboard_clear()
            kok.clipboard_append(KAYIT.metin() or "(kayıt boş)")
            durum_goster("Çalışma kaydı panoya kopyalandı ✓  Sohbete yapıştırabilirsin.")
        except Exception as e:
            durum_goster(f"Kopyalanamadı: {e}")

    def kaydi_goster():
        p = tk.Toplevel(kok)
        p.title("GameLingo · çalışma kaydı")
        p.configure(bg=R["zemin"])
        p.geometry("820x520")
        alan = tk.Text(p, font=("Consolas", 9), bg=R["alan"], fg=R["yazi"], insertbackground=R["turkuaz"],
                       relief="flat", wrap="word", padx=10, pady=8)
        kaydirma = tk.Scrollbar(p, command=alan.yview)
        alan.configure(yscrollcommand=kaydirma.set)
        alt = tk.Frame(p, bg=R["zemin"], pady=6, padx=8)
        alt.pack(side="bottom", fill="x")
        kaydirma.pack(side="right", fill="y")
        alan.pack(side="left", fill="both", expand=True)

        def yenile():
            alan.delete("1.0", "end")
            alan.insert("end", KAYIT.metin() or "(kayıt boş — Başlat'a basınca dolmaya başlar)")
            alan.see("end")

        def temizle():
            KAYIT.temizle()
            yenile()
            durum_goster("Kayıt temizlendi.")

        dugme(alt, "Yenile", yenile).pack(side="left", padx=(0, 6), ipady=3, ipadx=8)
        dugme(alt, "Kopyala", kaydi_kopyala).pack(side="left", padx=(0, 6), ipady=3, ipadx=8)
        dugme(alt, "Temizle", temizle).pack(side="left", ipady=3, ipadx=8)
        tk.Label(alt, text=f"Dosya: {KAYIT.dosya()}", font=(YAZI, 8), fg=R["soluk"], bg=R["zemin"]).pack(side="right")
        yenile()
        return p

    dugme(ksatir, "Kaydı göster", kaydi_goster).pack(side="left", fill="x", expand=True, ipady=4, padx=(0, 6))
    dugme(ksatir, "Kaydı kopyala", kaydi_kopyala).pack(side="left", fill="x", expand=True, ipady=4, padx=(6, 0))

    def arayuz_hatasi(tur, deger, iz):
        import traceback
        KAYIT.yaz("Arayüz hatası: " + "".join(traceback.format_exception(tur, deger, iz))[-600:], hata=True)
        durum_goster(f"Arayüz hatası: {deger}")

    kok.report_callback_exception = arayuz_hatasi

    kok.protocol("WM_DELETE_WINDOW", lambda: (kaydet(), kok.destroy()))
    kok.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as hata:
        import traceback
        KAYIT.yaz("Program çöktü: " + traceback.format_exc()[-800:], hata=True)
        print("Beklenmeyen hata:", hata)
        print("Ayrıntı çalışma kaydında:", KAYIT.dosya())
        input("Kapatmak için Enter'a basın...")
