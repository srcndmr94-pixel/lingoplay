#!/usr/bin/env bash
#
# LingoPlay Remote — Chiaki kaynağını alıp bizim değişikliklerimizi uygular.
#
# Aşama 1: uygulama kendi adıyla, kendi paket kimliğiyle derlensin.
# Böylece telefonda mevcut LingoPlay'in yanına ayrı bir uygulama olarak kurulur,
# birbirlerini silmezler.
#
set -euo pipefail

KAYNAK_DEPO="https://github.com/streetpea/chiaki-ng.git"
HEDEF="${1:-chiaki-kaynak}"

PAKET_ESKI="com.metallic.chiaki"
PAKET_YENI="com.lingoplay.remote"
AD_YENI="LingoPlay Remote"

echo "==> Chiaki kaynağı indiriliyor"
rm -rf "$HEDEF"
git clone --depth 1 "$KAYNAK_DEPO" "$HEDEF"

cd "$HEDEF/android"

echo "==> Paket kimliği değiştiriliyor: $PAKET_ESKI -> $PAKET_YENI"
# Yalnızca applicationId değişiyor; namespace aynı kalıyor çünkü tüm kaynak
# dosyalar o ad altında. Android için ayrı uygulama olmasına applicationId yeter.
sed -i "s|applicationId \"$PAKET_ESKI\"|applicationId \"$PAKET_YENI\"|" app/build.gradle
grep -q "applicationId \"$PAKET_YENI\"" app/build.gradle || {
    echo "HATA: applicationId değiştirilemedi"; exit 1; }

echo "==> Uygulama adı değiştiriliyor: $AD_YENI"
sed -i "s|<string name=\"app_name\">[^<]*</string>|<string name=\"app_name\">$AD_YENI</string>|" \
    app/src/main/res/values/strings.xml
grep -q "<string name=\"app_name\">$AD_YENI</string>" app/src/main/res/values/strings.xml || {
    echo "HATA: uygulama adı değiştirilemedi"; exit 1; }

# Diğer dillerdeki ad dosyaları da varsa aynı ada çekiliyor.
for f in app/src/main/res/values-*/strings.xml; do
    [ -f "$f" ] || continue
    sed -i "s|<string name=\"app_name\">[^<]*</string>|<string name=\"app_name\">$AD_YENI</string>|" "$f"
done

echo "==> Sürüm bilgisi ekleniyor"
sed -i "s|versionName chiakiVersion|versionName \"R1.0\"|" app/build.gradle
grep -q 'versionName "R1.0"' app/build.gradle || {
    echo "HATA: sürüm adı değiştirilemedi"; exit 1; }

echo "==> Değişiklikler tamam"
echo "    applicationId : $PAKET_YENI"
echo "    uygulama adı  : $AD_YENI"
echo "    sürüm         : R1.0"
