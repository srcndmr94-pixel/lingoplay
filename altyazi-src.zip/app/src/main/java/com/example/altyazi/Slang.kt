package com.example.altyazi

/**
 * Suç / sokak argosu sözlüğü. İki iş görür:
 *  1. Satırda geçen argo için telefondaki yapay zekâya anlam ipucu verir
 *     ("jug = prison"), küçük model bunları kendi başına bilmiyor.
 *  2. Kesin kalıpları ML Kit'e gitmeden sade İngilizceye çevirir.
 */
object Slang {
    private const val OBJ = "(you|him|her|them|me|us|'em|that guy|the guy|this guy)"

    /** Kalıp (regex, büyük/küçük harf duyarsız) -> anlamı. Belirsiz kelimeler sadece argo kalıbıyla eşleşir. */
    private val hints: List<Pair<Regex, String>> = listOf(
        // öldürmek
        "\\bic(e|ed|ing) $OBJ\\b|\\biced\\b" to "ice someone = kill (öldürmek)",
        "\\bwhack(ed)?\\b" to "whack = kill (öldürmek)",
        "\\bwast(e|ed) $OBJ\\b" to "waste someone = kill",
        "\\bcap(ped)? $OBJ\\b|\\bbust a cap\\b" to "cap someone = shoot (vurmak)",
        "\\bsmok(e|ed) $OBJ\\b" to "smoke someone = kill",
        "\\boff(ed)? $OBJ\\b" to "off someone = kill",
        "\\bpop(ped)? $OBJ\\b" to "pop someone = shoot/kill",
        "\\brub(bed)? out\\b" to "rub out = kill",
        "\\btake $OBJ out\\b|\\btook $OBJ out\\b" to "take someone out = kill",
        "\\bclip(ped)? $OBJ\\b" to "clip someone = kill",
        "\\bbump(ed)? $OBJ off\\b|\\bbump(ed)? off\\b" to "bump off = kill",
        "\\bsleep(s|ing)? with the fishes\\b" to "sleep with the fishes = be dead (murdered)",
        // hapis
        "\\b(the|in|to) jug\\b|\\bjug\\b" to "jug = prison (hapis)",
        "\\b(in|to) the can\\b" to "the can = prison",
        "\\b(in|to) the joint\\b" to "the joint = prison",
        "\\bslammer\\b" to "slammer = prison",
        "\\b(in|to) the pen\\b" to "the pen = prison",
        "\\bin stir\\b" to "stir = prison",
        "\\bbig house\\b" to "big house = prison",
        "\\bclink\\b" to "clink = prison",
        "\\b(in|to) the hole\\b" to "the hole = solitary confinement (hücre hapsi)",
        "\\bjuvie\\b" to "juvie = juvenile prison (ıslahevi)",
        "\\bon sabbatical\\b" to "on sabbatical = away (in prison)",
        "\\bdo(ing)? time\\b|\\bdid time\\b" to "do time = serve a prison sentence",
        "\\bscrews\\b|\\bthe screw\\b" to "screws = prison guards (gardiyanlar)",
        "\\bshiv\\b" to "shiv = improvised prison knife",
        "\\bcellmate\\b" to "cellmate = koğuş arkadaşı",
        "\\bmonkey[- ]suits?\\b" to "monkey suit = uniform",
        // kaçmak / paçayı kurtarmak
        "\\bskat(e|es|ed|ing)\\b" to "skate = get away with it, escape punishment (paçayı kurtarmak)",
        "\\bbeat the rap\\b" to "beat the rap = escape conviction",
        "\\bscram\\b" to "scram = get out fast",
        "\\blet's split\\b|\\bwe split\\b" to "split = leave",
        "\\bon the lam\\b" to "on the lam = on the run (firarda)",
        "\\bbreak ?out\\b|\\bbreakout\\b" to "break out = prison escape (firar)",
        // ispiyon
        "\\bsqueal(ed|ing|er)?\\b" to "squeal = snitch to police (ötmek)",
        "\\brat(s|ted|ting)?\\b" to "rat = snitch, informer (muhbir, ispiyoncu)",
        "\\bsnitch(ed|es|ing)?\\b" to "snitch = informer (muhbir)",
        "\\b(gonna|going to|will|'ll|started|start) sing(ing)?\\b" to "sing = confess/snitch to police (ötmek)",
        "\\bfink\\b" to "fink = informer",
        "\\bstool pigeon\\b" to "stool pigeon = informer",
        "\\bnarc\\b" to "narc = undercover cop / informer",
        // polis
        "\\bthe fuzz\\b" to "the fuzz = police",
        "\\bpigs\\b" to "pigs = police (aynasızlar)",
        "\\bthe heat\\b" to "the heat = police / police attention",
        "\\bfive-o\\b" to "five-o = police",
        "\\bit's twelve\\b|\\btwelve's\\b" to "twelve = police",
        "\\bfeds\\b" to "feds = federal agents",
        "\\bcopper\\b" to "copper = cop",
        "\\bbust(ed)?\\b" to "bust = arrest / raid (baskın, enselemek)",
        "\\bpinched\\b" to "pinched = arrested",
        "\\bcollared\\b" to "collared = arrested",
        // para
        "\\bdough\\b" to "dough = money",
        "\\bcheddar\\b" to "cheddar = money",
        "\\bmoolah\\b" to "moolah = money",
        "\\b(a|\\d+|two|three|five|ten|fifty|hundred) grand\\b" to "grand = 1000 dollars (bin dolar)",
        "\\bc-notes?\\b" to "C-note = 100 dollars",
        "\\b(my|your|his|her|their|our|the) cut\\b" to "cut = share of the money (pay)",
        "\\bbig score\\b|\\bthe score\\b" to "score = big theft / profit (vurgun)",
        "\\bthe take\\b" to "the take = stolen money (ganimet)",
        // silah
        "\\b(my|your|his|her|the) piece\\b(?! of)|\\bpacking a piece\\b" to "piece = gun (silah) when talking about weapons",
        "\\bheater\\b" to "heater = gun",
        "\\bgat\\b" to "gat = gun",
        "\\bstrapped\\b" to "strapped = armed (silahlı)",
        "\\btooled up\\b" to "tooled up = armed (silahlı)",
        "\\bpacking( heat)?\\b" to "packing = carrying a gun",
        // iş / suç
        "\\bheist\\b" to "heist = robbery (soygun)",
        "\\bthe job\\b" to "the job = the crime / robbery (iş, soygun) if criminals are talking",
        "\\b(the|easy) mark\\b" to "mark = victim of a con (enayi)",
        "\\bsucker\\b" to "sucker = dupe (enayi)",
        "\\bmooks\\b" to "mooks = thugs (adamlar)",
        "\\bgoons\\b" to "goons = thugs",
        "\\bwheelm[ae]n\\b" to "wheelman = getaway driver (kaçış şoförü)",
        "\\btag-along\\b" to "tag-along = someone who follows you around",
        "\\bon the spot\\b" to "on the spot = right there, at that moment",
        "\\bcapo\\b" to "capo = mob captain",
        "\\bmade man\\b" to "made man = full mafia member",
        "\\bthis stinks\\b|\\bit stinks\\b" to "this stinks = this is rotten/unfair/suspicious (bu iş kokuyor)",
        "\\bchump\\b" to "chump = fool",
        "\\bhomie\\b" to "homie = close friend",
        "\\bthe rap\\b" to "the rap = criminal charge",
        // genel deyimler (log'da yapay zekânın kaçırdıkları)
        "\\b\\p{Lu}\\p{Ll}+ dog\\b|\\bdawg\\b" to "'<Name> dog' / dawg = friendly address, buddy (kanka), not an animal",
        "\\bsalad (days|years)\\b" to "salad days = carefree youthful prime (gençliğin en güzel günleri)",
        "\\bon a roll\\b" to "on a roll = on a winning streak, things going great (işler tıkırında)",
        "\\bhard pass\\b" to "hard pass = definitely no (kesinlikle hayır)",
        "\\bweps\\b" to "weps = weapons (silahlar)",
        "\\bas you were\\b" to "as you were = carry on, continue what you were doing (devam edin / rahat)",
        "\\bhave $OBJ on\\b" to "have someone on = invite someone as a guest on a show (programa konuk almak)",
        "\\bbats?\\b" to "bat = the animal / Batman's bat symbol (yarasa), not a verb",
        "\\btop brass\\b" to "top brass = senior commanders (üst düzey amirler)",
        "\\bhave (their|his|her|your|my|our) backs?\\b" to "have someone's back = support/protect them (arkasında durmak)",
        "\\bput $OBJ up to\\b" to "put someone up to something = make them do it (birini bir işe kışkırtmak)",
        "\\bfor that matter\\b" to "for that matter = also, as well (hatta / o konuda)",
        "\\bto my knowledge\\b" to "to my knowledge = as far as I know (bildiğim kadarıyla)",
        "\\bi take it\\b" to "I take it = I assume (anladığım kadarıyla)",
        "\\bhit job\\b" to "hit job = a hostile attack piece / smear (karalama, linç)",
        "\\bcat burglar\\b" to "cat burglar = a skilled burglar who climbs into buildings (çatı hırsızı)",
        "\\bgo(es|ing)? after\\b|\\bwent after\\b" to "go after = attack, pursue (peşine düşmek, saldırmak)"
    ).map { (k, v) -> Regex("(?i)" + k.replace("\$OBJ", OBJ)) to v }

    /** Satırda geçen argo terimlerinin anlamları (en fazla 6). */
    fun hintsFor(line: String): List<String> =
        hints.filter { it.first.containsMatchIn(line) }.map { it.second }.distinct().take(6)

    /** ML Kit'e gitmeden önce kesin kalıpları sade İngilizceye çevirir. */
    private val rewrites: List<Pair<Regex, String>> = listOf(
        "\\bice (you|him|her|them|me|us)\\b" to "kill $1",
        "\\b(whack|clip|off|waste|smoke) (you|him|her|them|me|us)\\b" to "kill $2",
        "\\bin the (jug|can|joint|slammer|pen|stir|clink|big house)\\b" to "in prison",
        "\\bto the (jug|can|joint|slammer|pen|stir|clink|big house)\\b" to "to prison",
        "\\b(you|he|she|they|we|i) skated?\\b" to "$1 got away with it",
        "\\b(you|he|she|they|we|i) skates?\\b" to "$1 get away with it",
        "\\bsquealed\\b" to "informed the police",
        "\\bsquealing\\b" to "informing the police",
        "\\bsquealer\\b" to "informer",
        "\\bratted (him|her|them|me|us|you) out\\b" to "betrayed $1 to the police",
        "\\bratted\\b" to "betrayed us to the police",
        "\\bon sabbatical\\b" to "away",
        "\\bjuvie\\b" to "juvenile prison",
        "\\btag-along[- ]buddy\\b" to "companion",
        "\\bon the spot\\b" to "right there",
        "\\bthe fuzz\\b" to "the police",
        "\\bpacking heat\\b" to "carrying a gun",
        "\\bon the lam\\b" to "on the run"
    ).map { Regex("(?i)" + it.first) to it.second }

    fun normalize(text: String): String {
        var t = text
        for ((re, rep) in rewrites) {
            t = re.replace(t) { m ->
                var r = rep
                for (g in 1..m.groupValues.lastIndex) r = r.replace("$" + g, m.groupValues[g])
                if (m.value.first().isUpperCase() && r.isNotEmpty()) r.substring(0, 1).uppercase() + r.substring(1) else r
            }
        }
        return t
    }
}
