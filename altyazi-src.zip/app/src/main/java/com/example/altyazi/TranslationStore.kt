package com.example.altyazi

import android.content.Context

/**
 * Kalıcı çeviri hafızası.
 *
 * Bir kez çevrilen replik telefona yazılır. Aynı replik tekrar geçtiğinde
 * ne internet ne de jeton gerekir, anında ekrana gelir. Oyunu ikinci kez
 * oynarken veya aynı diziyi izlerken uygulama kendi kendine hızlanır.
 */
class TranslationStore(context: Context, name: String = QUICK) {

    // QUICK: hızlı (ML Kit) çeviriler. AI: telefondaki yapay zekânın çevirileri.
    // Ayrı tutulur: yapay zekâ açıkken kaba çeviri hafızası hiç kullanılmaz.
    private val sp = context.applicationContext
        .getSharedPreferences(name, Context.MODE_PRIVATE)

    fun get(english: String): String? {
        val key = key(english)
        if (key.isEmpty()) return null
        return sp.getString(key, null)
    }

    fun put(english: String, turkish: String) {
        val key = key(english)
        if (key.isEmpty() || turkish.isBlank()) return
        if (sp.all.size > MAX_ENTRIES) {
            // Hafıza şişerse sıfırlanır; yeniden dolması birkaç oturum sürer.
            sp.edit().clear().apply()
        }
        sp.edit().putString(key, turkish).apply()
    }

    fun count(): Int = sp.all.size

    fun clear() = sp.edit().clear().apply()

    /**
     * Anahtarına bakıp [bozuk] diyen kayıtları siler, silinen sayısını döner.
     * Bozuk bir OCR okumasının çevirisi hafızaya girdiyse kalıcı hasar veriyor:
     * aynı bozuk okuma her geldiğinde yanlış çeviri anında geri servis ediliyor.
     */
    fun purge(bozuk: (String) -> Boolean): Int {
        val silinecek = sp.all.keys.filter(bozuk)
        if (silinecek.isEmpty()) return 0
        val e = sp.edit()
        for (k in silinecek) e.remove(k)
        e.apply()
        return silinecek.size
    }

    /** Tek bir kaydı siler (bozuk çeviri hafızada kalıcı hasar vermesin). */
    fun forget(english: String) = sp.edit().remove(key(english)).apply()

    private fun key(text: String): String =
        text.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.trim().take(200)

    companion object {
        private const val MAX_ENTRIES = 5000
        const val QUICK = "ceviri_hafizasi_v2"
        const val AI = "ceviri_hafizasi_yz"

        /** Her iki hafızayı da siler. */
        fun clearAll(context: Context) {
            TranslationStore(context, QUICK).clear()
            TranslationStore(context, AI).clear()
        }
    }
}
