package com.example.altyazi

/**
 * OCR'ın düzenli olarak yaptığı hataları çeviriden ÖNCE düzeltir.
 *
 * Ekrandan okunan yazıda kesme işareti çoğu zaman kaybolur ("dont"), bazı
 * harfler birbirine karışır. Bunlar düzeltilmezse hem telefon çevirisi hem
 * yapay zekâ gereksiz yere yanılır.
 */
object TextFix {

    private val contractions = listOf(
        "dont" to "don't", "doesnt" to "doesn't", "didnt" to "didn't",
        "cant" to "can't", "couldnt" to "couldn't", "wont" to "won't",
        "wouldnt" to "wouldn't", "shouldnt" to "shouldn't", "isnt" to "isn't",
        "arent" to "aren't", "wasnt" to "wasn't", "werent" to "weren't",
        "havent" to "haven't", "hasnt" to "hasn't", "hadnt" to "hadn't",
        "im" to "I'm", "ive" to "I've",
        "youre" to "you're", "youve" to "you've", "youll" to "you'll",
        "shes" to "she's", "thats" to "that's",
        "theres" to "there's", "theyre" to "they're", "theyve" to "they've",
        "weve" to "we've",
        "whats" to "what's", "wheres" to "where's", "whos" to "who's"
    )

    // Bilerek YOK: "were", "its", "ill", "id", "lets", "hes" (hepsi gerçek İngilizce kelime;
    // "They were here" -> "They we're here" gibi bozuluyordu).

    fun clean(raw: String): String {
        var text = raw

        // Satır sonu tireleri ve üç nokta varyasyonları
        text = text.replace("…", "...")
        text = text.replace(Regex("\\s*\\.\\s*\\.\\s*\\."), "...")

        // Birden fazla boşluk
        text = text.replace(Regex("\\s+"), " ").trim()

        // Baştaki ve sondaki tırnak/tire kalıntıları
        text = text.trim('-', '—', '«', '»', '"').trim()

        // Kaybolan kesme işaretlerini geri koy (sadece tam kelime eşleşmesinde)
        for ((wrong, right) in contractions) {
            text = text.replace(Regex("(?i)\\b$wrong\\b"), right)
        }

        return text
    }
}
