package com.example.altyazi

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Çeviri alanını ekranda elle seçtiren ekran.
 *
 * Çubuklarla uğraşmak yerine çerçeveyi doğrudan oyundaki altyazının üstüne
 * oturtuyorsunuz. Alan ekran oranı olarak saklandığı için yatay/dikey ya da
 * farklı çözünürlükte aynı yere denk gelir.
 */
class RegionActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var alan: RegionView
    private lateinit var tvOlcu: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_region)

        prefs = Prefs(this)
        alan = findViewById(R.id.regionView)
        tvOlcu = findViewById(R.id.tvOlcu)

        alan.sol = prefs.leftPct / 100f
        alan.sag = prefs.rightPct / 100f
        alan.ust = prefs.topPct / 100f
        alan.alt = prefs.bottomPct / 100f

        olcuyuYaz()
        alan.setOnTouchListener { v, event ->
            val sonuc = v.onTouchEvent(event)
            olcuyuYaz()
            sonuc
        }

        findViewById<Button>(R.id.btnRegionDefault).setOnClickListener {
            alan.varsayilana_don()
            olcuyuYaz()
        }

        findViewById<Button>(R.id.btnRegionSave).setOnClickListener { kaydet() }
        findViewById<Button>(R.id.btnRegionCancel).setOnClickListener { finish() }
    }

    private fun olcuyuYaz() {
        // Çerçeve ekranın alt yarısındaysa tuşlar ortaya geçsin; yoksa alttaki tutamaçlar tuşların
        // altında kalıyor, "Kaydet"e basınca çerçeve oynuyordu.
        try {
            val bar = findViewById<View>(R.id.regionButtons)
            val lp = bar.layoutParams as FrameLayout.LayoutParams
            val istenen = if ((alan.ust + alan.alt) / 2f > 0.55f) Gravity.CENTER_VERTICAL else Gravity.BOTTOM
            if (lp.gravity != istenen) {
                lp.gravity = istenen
                bar.layoutParams = lp
            }
        } catch (_: Throwable) {
        }
        tvOlcu.text = "Yatay %${alan.yuzde(alan.sol)}–%${alan.yuzde(alan.sag)} · " +
            "Dikey %${alan.yuzde(alan.ust)}–%${alan.yuzde(alan.alt)}"
    }

    private fun kaydet() {
        if (alan.kucukMu()) {
            Toast.makeText(
                this,
                "Alan çok küçük; altyazı sığmayabilir. Biraz büyütün.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        prefs.leftPct = alan.yuzde(alan.sol)
        prefs.rightPct = alan.yuzde(alan.sag)
        prefs.topPct = alan.yuzde(alan.ust)
        prefs.bottomPct = alan.yuzde(alan.alt)
        Toast.makeText(this, "Çeviri alanı kaydedildi.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
