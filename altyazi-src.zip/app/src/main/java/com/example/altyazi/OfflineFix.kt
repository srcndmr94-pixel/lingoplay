package com.example.altyazi

import java.util.Locale
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/**
 * ÇEVRİM DIŞI altyazı kalitesi için düzeltme katmanı.
 *
 * Telefonun yerleşik çevirisini (ML Kit, FastTranslate) şu sırayla sarar:
 *  1. OCR hatalarını düzeltir ("l always" -> "I've always", baştaki kopmuş "I" vb.)
 *  2. Cümlelere, gerekirse virgüllü parçalara bölüp SÖZLÜKTE arar (argo, küfür, komutlar, özel satırlar)
 *  3. Sözlükte olmayan parçayı yerleşik çeviriye verir
 *  4. Yerleşik çevirinin çevirmeden bıraktığı küfürleri Türkçeleştirir
 *
 * Sözlüğü siz büyütürsünüz: "ingilizce = türkçe" satırları (bkz. SubtitleGlossary.parse).
 */
object OcrTextCleaner {
    private val loneL = Regex("(?<![\\p{L}\\p{N}'])[l|](?=\\s|')")
    private val loneOneBeforeApostrophe = Regex("(?<![\\p{L}\\p{N}'])1(?=')")
    private val ivePattern = Regex("\\bI (always|never|just|only|also|really|ever) (been|had|done|seen|got|gone|known|made|told|tried)\\b")
    private val droppedI = Regex("^(got|gotta|gonna|wanna)\\b") // küçük harfle başlıyorsa baştaki "I" kopmuş demektir

    fun clean(raw: String): String {
        var t = raw.replace('’', '\'').replace('‘', '\'').replace('“', '"').replace('”', '"')
        t = t.replace(Regex("\\s+"), " ").trim()
        t = t.trimStart('-', '–', '—', ' ')
        t = t.replace(Regex("\\b(of|in|is|to|for|on|at|as|was|be|down|up|out|with|from|like|into|about)a\\b"), "$1 a")   // "ofa" -> "of a"
        t = t.replace(Regex("\\b([Ww])el\\b(?=[.!?,]|\\s|$)"), "$1ell")   // "done wel." -> "done well."
        t = t.replace('ơ', 'o').replace('Ơ', 'O').replace('ư', 'u').replace('Ư', 'U')
        t = loneL.replace(t, "I")
        t = loneOneBeforeApostrophe.replace(t, "I")
        t = ivePattern.replace(t) { "I've ${it.groupValues[1]} ${it.groupValues[2]}" }
        t = t.replace(Regex("^\\S*\\p{L}\\S*[&#@%*]\\S*\\s+(?=\\p{Lu})"), "") // baştaki "PALN&S" gibi kırıntı
        t = t.replace(Regex("(?<=\\b\\p{Ll}{2,20})I(?=\\s)"), " I")   // "knowI got" -> "know I got"
        t = t.replace(Regex("^[|l]\\s*(?=I\\b)"), "")           // "|I already" -> "I already"
        t = t.replace(Regex("^[T|l](?=(already|always|never|just|am|was)\\b)"), "I ") // "Talready" -> "I already"
        t = t.replace(Regex("(?i)\\bthe y(?=['’]?(re|ll|ve|d)\\b)"), "they") // "the y're" -> "they're"
        t = t.replace(Regex("(?i)\\bthe y\\b"), "they")
        // "Ijust" -> "I just", "am ll going" -> "am I going", "1 don't" -> "I don't", "mOve" -> "move", "sthit" -> "shit"
        t = t.replace(Regex("\\bI(just|was|am|know|think|have|had|did|didn't|don't|can't|will|never|always|need|want|got|mean|guess|told|said|thought|miss|missed|love|loved|like|hate|hope|feel|felt|wish|see|saw|swear|promise|believe|remember|forgot|understand|should|could|would|really|still|also|only|get|go|went|made|found|lost|heard|tried|knew)\\b"), "I $1")
        t = t.replace(Regex("\\b(am|do|did|can|could|should|would|will|was|have|had|shall)\\s+(?:ll|l1|1l|\\|l)\\b"), "$1 I")
        t = t.replace(Regex("(^|[.!?…]\\s+)1\\s+(?=(?:don't|didn't|can't|won't|am|was|have|had|know|think|will|just|need|want|got)\\b)"), "$1I ")
        t = t.replace(Regex("(?<=\\p{Ll})O(?=\\p{Ll})"), "o")
        t = t.replace(Regex("\\bsthit\\b"), "shit")
        t = t.replace(Regex("^Well (talk|see|go|be|get|need|have|find|make|do|meet|figure)\\b"), "We'll $1")
        // Sık OCR harf hataları: "themn" -> "them", "ternd" -> "tend", "veah" -> "yeah"
        t = t.replace(Regex("\\b(the|hi|who|fro|see|roo|tea)mn\\b"), "$1m")
        t = t.replace(Regex("\\bternd(s|ed|ing)?\\b"), "tend$1")
        t = t.replace(Regex("\\b([Vv])eah\\b")) { if (it.groupValues[1] == "V") "Yeah" else "yeah" }
        // "Il investigate" -> "I'll investigate" (kesme işareti kaybolmuş)
        t = t.replace(Regex("^[I|l]l (?=[a-z])"), "I'll ")
        // "lassume" -> "I assume", "lI stop" -> "I stop", "I'Il" -> "I'll"
        t = t.replace(Regex("(^|\\s)[l|](assume|know|think|guess|mean|was|am|have|had|did|do|don't|can|can't|will|would|could|never|always|just|need|want|thought|told|said|got|see|hope|believe|swear|promise|wish|love|hate)\\b"), "$1I $2")
        t = t.replace(Regex("\\b[l|]I\\b"), "I")
        t = t.replace(Regex("['’]Il\\b"), "'ll")
        // Konuşmacı etiketinden sonra kalan kırıntı: "May: ) Never forget" -> "May: Never forget"
        t = t.replace(Regex("^(\\p{Lu}[\\p{L}'.]*(?: \\p{Lu}[\\p{L}'.]*)?:)\\s*[)\\]|}]+\\s*"), "$1 ")
        if (droppedI.containsMatchIn(t)) t = "I $t"
        return t
    }
}

class SubtitleGlossary private constructor(
    private val phrases: Map<String, String>,
    private val names: Set<String>
) {
    fun lookup(text: String): String? = phrases[keyOf(text)]
    fun isName(text: String): Boolean = text.trim().lowercase() in names
    fun startsWithName(text: String): Boolean {
        val first = text.trim().split(' ', '\'').firstOrNull()?.lowercase() ?: return false
        return first in names
    }

    companion object {
        fun keyOf(text: String): String = text.lowercase().filter { it.isLetterOrDigit() }

        /**
         * Satır biçimi:
         *   # yorum
         *   @Lu                      -> özel isim, çevrilmez
         *   holy shit = Hassiktir    -> "ingilizce = türkçe" (sondaki noktalama yazılmaz, metinden alınır)
         * Sonraki satırlar öncekini ezer; kendi satırlarınızı varsayılanın ALTINA ekleyin.
         */
        fun parse(text: String): SubtitleGlossary {
            val phrases = HashMap<String, String>()
            val names = HashSet<String>()
            for (line in text.lines()) {
                val l = line.trim()
                if (l.isEmpty() || l.startsWith("#")) continue
                if (l.startsWith("@")) { names += l.substring(1).trim().lowercase(); continue }
                val eq = l.indexOf('=')
                if (eq <= 0) continue
                val key = keyOf(l.substring(0, eq))
                val value = l.substring(eq + 1).trim().trimEnd('.', '!', '?', '…', ' ')
                if (key.isNotEmpty() && value.isNotEmpty()) phrases[key] = value
            }
            return SubtitleGlossary(phrases, names)
        }

        fun default(userEntries: String = ""): SubtitleGlossary = parse(DEFAULT_ENTRIES + "\n" + userEntries)

        const val DEFAULT_ENTRIES = """
# --- Komutlar, çatışma
police = Polis
freeze = Kıpırdama
hands up = Eller yukarı
put your hands up = Ellerini kaldır
drop it = Bırak onu
drop your weapon = Silahını bırak
drop the weapon = Silahı bırak
get down = Yere yat
get on the ground = Yere yat
on the ground = Yere yat
stay down = Yerde kal
stay with me = Benimle kal
don't move = Kıpırdama
don't fucking move = Kıpırdama lan
cover = Siper al
take cover = Siper alın
cover me = Beni kolla
move = Kımılda
move up = İlerle
push up = İlerle
go go go = Hadi hadi hadi
behind you = Arkanda
watch out = Dikkat et
look out = Dikkat
reload = Şarjör değiştir
i'm hit = Vuruldum
man down = Adam yaralandı
he's got a gun = Silahı var
he has a gun = Silahı var
shoot him = Vur onu
don't shoot = Ateş etme
hold your fire = Ateşi kesin
cease fire = Ateşi kesin
get out of here = Defol buradan
let's go = Hadi gidelim
come on = Hadi
hurry up = Çabuk ol
wait = Bekle
hold on = Bir dakika
shut up = Kapa çeneni
quiet = Sessiz ol
be quiet = Sessiz ol
hardly = Pek sayılmaz
godspeed = Yolun açık olsun
mmm hmm = Hı hı
mm hmm = Hı hı
mhm = Hı hı
fo sho = Kesin
shut the fuck up = Kapa çeneni lan

# --- Küfür ve ünlemler
fuck = Siktir
fuck me = Siktir
fuck you = Siktir git
fuck off = Siktir git
fuck this = Siktir et bunu
fuck it = Siktir et
shit = Siktir
holy shit = Hassiktir
oh shit = Hassiktir
oh my god = Aman tanrım
damn = Lanet olsun
damn it = Lanet olsun
goddamn it = Lanet olsun
son of a bitch = Orospu çocuğu
motherfucker = Orospu çocuğu
bullshit = Saçmalık
asshole = Pislik herif
what the fuck = Ne bok
what the fuck is going on = Ne bok oluyor
what the fuck is going on here = Burada ne bok oluyor
what the fuck are you doing = Ne bok yiyorsun
what the hell = Ne oluyor yahu
what the hell is going on = Neler oluyor yahu
are you out of your mind = Aklını mı kaçırdın
aww = Ah
too bad = Ne yazık

# --- Günlük konuşma
are you okay = İyi misin
are you ok = İyi misin
thank you = Teşekkürler
thanks = Sağ ol
sorry = Özür dilerim
no way = Olamaz
what's going on = Neler oluyor
i don't know = Bilmiyorum
trust me = Bana güven
follow me = Beni takip et
this way = Bu taraftan
over here = Buraya

# --- Ek genel kalıplar
where the fuck you at = Neredesin lan
where you at = Neredesin
pack that shit up = Toplayın şu boku
ay = Hey
pack it up = Toplayın
yo phone = Hey, telefon
appreciate it = Sağ ol
i don't give a fuck = Sikimde bile değil
this stinks = Bu işte bir bit yeniği var
somebody squealed = Biri ötmüş
someone squealed = Biri ötmüş
who squealed = Kim öttü
not anymore = Artık değil
take that = Al bakalım
take that ya damned screws = Al bakalım, lanet gardiyanlar
sure buddy sure = Tabii dostum, tabii
and here's eddie now = İşte Eddie de geldi
here he is = İşte geldi
here we go = İşte başlıyoruz
suit yourself = Sen bilirsin
drift = Defol
i'm just saying = Sadece söylüyorum
im just saying = Sadece söylüyorum
just saying = Sadece söylüyorum
well don't = O zaman yapma
you know what = Bak ne diyeceğim
makes sense = Mantıklı
make sense = Mantıklı
trying to hold on = Tutunmaya çalışıyorum
who i am = Kim olduğum
who i was = Kim olduğum
every fight = Her kavga
every death = Her ölüm
not actual gameplay = Gerçek oyun görüntüsü değildir
here we go again = Yine başlıyoruz
finally = Nihayet
what's up = Ne oldu
what's wrong = Ne oldu
i get it = Anlıyorum
i get that = Anlıyorum
i get that too = Bunu da anlıyorum
worth the wait = Beklemeye değdi
it was worth the wait = Beklemeye değdi
maybe i did get lucky = Belki de şansım yaver gitti
get lucky = Şansın yaver gitsin
it is what it is = Ne yapalım, durum bu
it's what it is = Ne yapalım, durum bu
my friend = Dostum
my man = Dostum
it's twelve = Polis geldi
twelve = Polis
twelve's here = Polis geldi
they tooled up and everything = Tepeden tırnağa silahlılar
they're tooled up = Silahlılar
you feel me = Anladın mı
what the hell are you doing = Sen ne yapıyorsun be
what are you doing = Ne yapıyorsun
what do you want = Ne istiyorsun
what happened = Ne oldu
who are you = Sen kimsin
where are you = Neredesin
where are you going = Nereye gidiyorsun
get out = Çık dışarı
get out of my way = Çekil yolumdan
get away from me = Uzak dur benden
leave me alone = Beni rahat bırak
let me go = Bırak beni
let go = Bırak
help me = Yardım et bana
help = İmdat
run = Koş
run away = Kaç
go = Git
stop = Dur
stop it = Kes şunu
wait here = Burada bekle
stay here = Burada kal
stay back = Geri çekil
step back = Geri çekil
back off = Geri çekil
calm down = Sakin ol
relax = Sakin ol
take it easy = Sakin ol
easy = Sakin ol
listen to me = Beni dinle
look at me = Bana bak
look = Bak
listen = Dinle
you idiot = Seni aptal
you bastard = Seni piç
you asshole = Seni pislik
you son of a bitch = Seni orospu çocuğu
you piece of shit = Seni pislik
piece of shit = Pislik
dumbass = Aptal
jackass = Salak
idiot = Aptal
scumbag = Pislik
bitch = Kaltak
bastard = Piç
suck my dick = Siktir git
kiss my ass = Siktir git
go to hell = Cehennem ol
go fuck yourself = Siktir git
get the fuck out = Siktir git
get the fuck out of here = Siktir git buradan
what the fuck was that = Bu da neydi amına koyayım
what the hell was that = O da neydi böyle
are you fucking kidding me = Benimle dalga mı geçiyorsun lan
are you kidding me = Dalga mı geçiyorsun
you've got to be kidding me = Dalga geçiyor olmalısın
i'm going to kill you = Seni öldüreceğim
i'll kill you = Seni öldürürüm
you're dead = Öldün sen
you're gonna die = Öleceksin
i'm done = Bittim ben
i'm fine = İyiyim
i'm okay = İyiyim
i'm sorry = Özür dilerim
i can't = Yapamam
i can't do this = Bunu yapamam
i don't care = Umurumda değil
i don't understand = Anlamıyorum
i know = Biliyorum
i see = Anlıyorum
i got you = Seni tuttum
i've got you = Seni tuttum
i got it = Hallettim
got it = Anlaşıldı
copy that = Anlaşıldı
roger = Anlaşıldı
understood = Anlaşıldı
yes sir = Emredersiniz
no sir = Hayır efendim
yes = Evet
no = Hayır
yeah = Evet
yep = Evet
nope = Hayır
okay = Tamam
ok = Tamam
alright = Pekâlâ
all right = Pekâlâ
please = Lütfen
hello = Merhaba
hi = Selam
hey = Hey
goodbye = Hoşça kal
bye = Hoşça kal
good luck = Bol şans
be careful = Dikkatli ol
you ready = Hazır mısın
are you ready = Hazır mısın
ready = Hazır
let's do this = Hadi yapalım şunu
let's move = Hadi gidelim
let's get out of here = Hadi çıkalım buradan
we have to go = Gitmemiz lazım
we need to go = Gitmemiz lazım
we need to move = Hareket etmeliyiz
we gotta go = Gitmemiz lazım
we gotta move = Hareket etmeliyiz
we're out of time = Vaktimiz kalmadı
we're running out of time = Vaktimiz tükeniyor
there he is = İşte orada
there they are = İşte oradalar
he's dead = Öldü
they're coming = Geliyorlar
they're here = Geldiler
incoming = Geliyorlar
enemy down = Düşman indi
target down = Hedef vuruldu
clear = Temiz
all clear = Ortalık temiz
nice shot = Güzel atış
nice = Güzel
good job = Aferin
well done = Aferin
oh no = Olamaz
oh god = Aman tanrım
jesus = Aman tanrım
jesus christ = Hay Allah
oh my god = Aman tanrım
what = Ne
why = Neden
how = Nasıl
really = Gerçekten mi
seriously = Cidden mi
come here = Gel buraya
get over here = Gel buraya
"""

    /** ÖRNEK oyuna özel sözlük (isimler + kayıttaki satırlar). Kendi oyununuz için bunu kopyalayıp değiştirin. */
    const val GAME_ENTRIES = """
# --- İsimler (çevrilmez)
@Lu
@Boobie
@Méndez
@Ray
@Raymond
@cabrón

# --- Oyuna özel (sizin kayıttan)
it's him = İşte o
it's fucking méndez = Siktiğimin Méndez'i bu
fuck boobie = Boobie'yi siktir et
we gotta get out of this = Bu işten sıyrılmamız lazım
i got boobie's bricks = Boobie'nin paketleri bende
hey man this ain't even loaded = Hey dostum, bunda mermi bile yok
can't you fucking handle a bunch of street pushers = Bir avuç sokak satıcısıyla bile başa çıkamıyor musunuz be
clean this shit up = Bu boku temizleyin
i've always been there for you = Hep yanında oldum
but this is what i get = Karşılığında aldığım bu mu yani
but this what i get = Karşılığında aldığım bu mu yani

aight hold up = Tamam, bekle
yeah he fucking knows = Evet, biliyor amına koyayım
what the fuck you talking about = Ne bok konuşuyorsun sen
what the fuck are you talking about = Ne bok konuşuyorsun sen
my partner's off the grid right now you feel me = Ortağım şu an ortalarda yok, anlıyorsun ya
problem is he only worried about himself = Sorun şu ki sadece kendini düşünüyor
he seriously sent y'all over here right now = Sizi gerçekten şimdi buraya mı gönderdi
let's get these workers out of here man = Bu işçileri buradan çıkaralım dostum
i already told that motherfucker what the fuck is going on man = O orospu çocuğuna ne bok döndüğünü zaten söyledim dostum
i already told that motherfucker what the fuck going on man = O orospu çocuğuna ne bok döndüğünü zaten söyledim dostum
these two say they're for boobie = Bu ikisi Boobie için geldiklerini söylüyor
yo = Hey
listen very closely = Çok dikkatli dinle
listen carefully = Dikkatle dinle
"""
    }
}

/** Argo / kısaltma yazımını standart İngilizceye çevirir ki yerleşik çeviri doğru anlasın. */
object SlangNormalizer {
    private val rules: List<Pair<Regex, String>> = listOf(
        "\\bain't (ask|tell|say|see|know|do|go|get|hear|call|give|take)\\b" to "didn't $1",
        "\\bI ain't\\b" to "I'm not",
        "\\b(you|we|they) ain't\\b" to "$1 aren't",
        "\\bain't\\b" to "isn't",
        "\\bby (himself|herself|myself|yourself|yourselves|themselves|ourselves)\\b" to "alone",
        "\\bgonna\\b" to "going to",
        "\\bwanna\\b" to "want to",
        "\\b(gotta|hafta)\\b" to "have to",
        "\\by'all\\b" to "you all",
        "\\blemme\\b" to "let me",
        "\\bgimme\\b" to "give me",
        "\\bI dunno\\b" to "I don't know",
        "\\bdunno\\b" to "don't know",
        "\\bkinda\\b" to "kind of",
        "\\bsorta\\b" to "sort of",
        "\\boutta\\b" to "out of",
        "\\b(coulda|woulda|shoulda)\\b" to "$1 have",
        "(?<![\\p{L}])'?(cause|cuz|coz)\\b" to "because",
        "(?<![\\p{L}])'em\\b" to "them",
        "\\bc'mon\\b" to "come on",
        "^sup\\b" to "What's up",
        "\\bfo(?: |')sho\\b" to "for sure",
        "\\bfa sho\\b" to "for sure",
        "\\bweps\\b" to "weapons",
        "\\bhard pass\\b" to "definitely not",
        "\\bon a roll\\b" to "doing great",
        "\\bdawg\\b" to "buddy",
        "\\bsalad (days|years)\\b" to "best youthful days",
        "\\bgotcha\\b" to "got you",
        "\\bwhatcha\\b" to "what are you",
        "\\bima\\b" to "I'm going to",
        "\\btryna\\b" to "trying to",
        "\\bfinna\\b" to "about to",
        "\\bya\\b" to "you",
        "\\byou feel me\\b" to "you understand me",
        "\\baight\\b" to "alright",
        "\\byo (momma|mama|mom|mother|ass|house|car|boy|girl|man|people|crew|place|brother|sister|family|money|shit)\\b" to "your $1",
        "\\b(momma|mama)\\b" to "mother",
        "\\b(your|my|his|her) mother house\\b" to "$1 mother's house",
        "\\bniggas\\b" to "guys",
        "\\bnigga\\b" to "guy",
        "\\btooled up\\b" to "armed",
        "\\bpaying (\\w+) a visit\\b" to "visiting $1",
        "\\bpay (\\w+) a visit\\b" to "visit $1",
        "\\byo\\b" to "hey",
        "\\bwound up (a little |a bit |pretty |really |real |so |too )?tight\\b" to "$1tense",
        "\\bI get (that|it)( too)?(?=[.!?,]|$)" to "I understand $1$2",
        "\\bget it\\?" to "understand?",
        "\\bcellmates?\\b" to "prison roommate",
        "\\b(former|ex-?) (\\w+ )?intelligence\\b" to "$1 $2intelligence officer",
        "^(anybody|anyone|somebody|someone|whoever) (messes|fucks|screws|touches|tries) " to "If $1 $2 ",
        "\\banswer to (my|the|his|her|our|your) boss\\b" to "will answer to $1 boss",
        "\\bburg\\b" to "town",
        "\\bwhat the (fuck|hell) going on\\b" to "what the $1 is going on",
        "\\b(we|we're|we are) in a holding pattern\\b" to "we are waiting",
        "\\bholding pattern\\b" to "waiting",
        "\\b(don't|do not|doesn't|didn't) give a damn\\b" to "$1 care",
        "^ay,\\s*" to "Hey, ",
        "\\b(mooks|goons)\\b" to "thugs",
        "\\b(damned|damn|fucking|goddamn|dirty|stinking|lousy) screws\\b" to "$1 prison guards",
        "\\bthe screws\\b" to "the prison guards",
        "\\bwheelm[ae]n\\b" to "getaway driver",
        "\\bmonkey[- ]suits?\\b" to "uniforms",
        "\\bfit right in\\b" to "fit in perfectly",
        "\\btop of the world\\b" to "king of the world",
        "\\bput (his |their |your |my |her )?hands on (me|you|him|her|us|them)\\b" to "touch $2",
        "\\breach out to\\b" to "contact",
        "\\breach out\\b" to "get in touch",
        "\\blooking for a situation\\b" to "looking for work",
        "\\bwhat's the deal\\b" to "what is going on",
        "\\bhang on\\b" to "wait",
        "\\bhang out\\b" to "spend time",
        "\\bfigure (it|this|that) out\\b" to "solve $1",
        "\\bmy bad\\b" to "my mistake",
        "\\bno big deal\\b" to "not important",
        "\\bbig deal\\b" to "important thing",
        "\\bfor real\\b" to "really",
        "\\bget lost\\b" to "go away",
        "\\bbeat it\\b" to "go away",
        "\\bpiss(ed)? off\\b" to "angry",
        "\\bfreak(ing)? out\\b" to "panicking",
        "\\bscrew(ed)? up\\b" to "ruined",
        "\\bmess(ed)? up\\b" to "ruined",
        "\\bcatch you later\\b" to "see you later",
        "\\bhit me up\\b" to "call me",
        "\\bcut it out\\b" to "stop it",
        "\\bknock it off\\b" to "stop it",
        "\\bget a move on\\b" to "hurry up",
        "\\bkeep it down\\b" to "be quiet",
        "\\bwatch your back\\b" to "be careful",
        "\\bgot your back\\b" to "will protect you",
        "\\bin a nutshell\\b" to "briefly",
        "\\bon the house\\b" to "free",
        "\\boff the grid\\b" to "unreachable",
        "\\bhold up\\b" to "wait",
        "\\bnah\\b" to "no",
        "(?<![\\p{L}])'bout\\b" to "about",
        "(?<![\\p{L}])'til\\b" to "until",
        "\\b(\\p{L}{2,})in'(?![\\p{L}])" to "$1ing"
    ).map { Regex(it.first, RegexOption.IGNORE_CASE) to it.second }

    fun normalize(text: String): String {
        var t = text
        for ((re, rep) in rules) {
            t = re.replace(t) { m ->
                var r = rep
                for (g in 1..m.groupValues.lastIndex) r = r.replace("$" + g, m.groupValues[g])
                if (m.value.first().isUpperCase() && r.isNotEmpty()) r.substring(0, 1).uppercase() + r.substring(1) else r
            }
        }
        return t
    }
}

/**
 * Küfürlü cümleler için: yerleşik çeviri küfürü yumuşatır, bozar ya da İngilizce bırakır.
 * Bu yüzden önce kelimeyi geçici bir "isim" ile (Zqa, Zqb...) değiştirir, çeviri sonrası Türkçe karşılığını yerine koyar.
 * Geçici isim çeviride kaybolursa cümle yedek yolla çevrilir (küfür sonradan Türkçeleştirilir).
 */
object ProfanityShield {
    class Slot(val token: String, val english: String, val turkish: String)
    /** tails: cümlenin sonuna eklenecek Türkçe küfür/ünlem ("amına koyayım"); sertlik kaybolmasın diye. */
    class Shielded(val text: String, val slots: List<Slot>, val tails: List<String> = emptyList())

    private const val HARD = "amına koyayım"
    private const val DAMN = "lanet olsun"
    private const val MILD = "be"

    // Kural: küfür SİLİNMEZ. Cümle içinde Türkçeye birebir oturmayan pekiştirici küfür
    // ("fucking", "the fuck") İngilizce cümleden çıkarılır ama sertliği cümlenin SONUNA
    // Türkçe olarak eklenir: "Don't fucking move!" -> "Kıpırdama, amına koyayım!"
    private class Rule(val re: Regex, val replacement: String, val tail: String?)
    private fun rule(p: String, r: String, tail: String?) = Rule(Regex("(?i)$p"), r, tail)

    private val rules: List<Rule> = listOf(
        // "I don't give a fuck" -> "Umurumda değil" + "amına koyayım"
        rule("\\b(don't|do not|doesn't|didn't)\\s+give\\s+a\\s+fuck\\b", "$1 care", HARD),
        rule("\\b(don't|do not|doesn't|didn't)\\s+give\\s+a\\s+shit\\b", "$1 care", MILD),
        // "I'm fucked" / "we're so fucked" -> "mahvolduk" + "amına koyayım"
        rule("\\b(I'm|I am|we're|we are|you're|you are|he's|he is|she's|she is|they're|they are|it's|it is)\\s+(so\\s+|totally\\s+|completely\\s+|really\\s+)?fucked(?!\\s+up)\\b", "$1 $2ruined", HARD),
        // "fucked up" sıfat: "fucked up shit" / "that's fucked up" -> "berbat"
        rule("\\bfucked[- ]up (?:shit|stuff|things?)\\b", "terrible things", HARD),
        rule("\\b(is|was|that's|it's|this is|so|really|pretty)\\s+fucked[- ]up\\b", "$1 terrible", HARD),
        // "fucked up" (fiil) -> "messed up" + sertlik
        rule("\\bfucked\\s+up\\b", "messed up", HARD),
        rule("\\bfucking\\s+up\\b", "messing up", HARD),
        rule("\\bfucks\\s+up\\b", "messes up", HARD),
        rule("\\bfuck\\s+up\\b", "mess up", HARD),
        rule("\\bfuck(?:ing|in'?)\\s+with\\b", "messing with", HARD),
        rule("\\bfucks\\s+with\\b", "messes with", HARD),
        rule("\\bfuck\\s+with\\b", "mess with", HARD),
        // "what the fuck ..." -> "what the hell ..." + sertlik
        rule("\\b(what|who|where|why|how|when)\\s+the\\s+(?:fuck|fucking hell)\\b", "$1 the hell", HARD),
        rule("\\s+the\\s+fuck\\b", "", HARD),
        rule("\\bfucking\\s+hell\\b", "damn it", HARD),
        // pekiştiriciler
        rule("\\bmotherfucking\\s+", "", HARD),
        rule("\\bfuck(?:ing|in'?)\\s+", "", HARD),
        rule("\\bgoddamn(?:ed)?\\s+", "", DAMN),
        rule("\\b(?:freaking|effing|frickin'?|friggin'?)\\s+", "", MILD),
        // "shit" bağlama göre: eşya, dayak, büyük bela
        rule("\\b(my|your|his|her|our|their) shit\\b", "$1 stuff", null),
        rule("\\bthe (?:shit|crap|hell) out of (me|you|him|her|them|us|it)\\b", "$1 badly", HARD),
        rule("\\bin deep shit\\b", "in big trouble", HARD),
        rule("\\bget your shit together\\b", "pull yourself together", MILD),
        // deyimler
        rule("\\blife's a bitch\\b", "life is hard", DAMN),
        rule("\\bbitch(?:ing)?\\s+about\\b", "complaining about", null)
    )

    // Bağlama göre: aynı kelime farklı yerde farklı anlam taşır. Özel kalıplar ÖNCE gelir.
    private val words: List<Pair<Regex, String>> = listOf(
        "holy shit" to "hassiktir",
        "oh,? shit" to "hassiktir",
        "no shit" to "yok artık",
        "pieces? of shit" to "pislik",
        "shit happens" to "olur böyle şeyler",
        "holy crap" to "vay anasını",
        "oh,? crap" to "hay aksi",
        "fuck no" to "hayatta olmaz",
        "fuck (?:that|this) shit" to "siktir et bunu",
        // Ünlem "shit" (başta ya da "Ah, shit!"): "siktir". Önünde kelime varsa ("that shit!") isimdir.
        "(?<![\\p{L}'’] )shit(?=\\s*[,!?.…]|$)" to "siktir",
        "fuck yeah" to "işte bu be",
        "son of a bitch(?:es)?" to "orospu çocuğu",
        "motherfuckers?" to "orospu çocuğu",
        "go fuck yourself" to "siktir git",
        "fuck (?:off|you)" to "siktir git",
        "fuck (?:this|that|it)" to "siktir et",
        "bullshit" to "saçmalık",
        "horseshit" to "saçmalık",
        "shitty" to "berbat",
        "shits?" to "bok",
        "crap" to "zırva",
        "assholes?" to "pislik herif",
        "dickheads?" to "göt herif",
        "bitch(?:es)?" to "kaltak",
        "bastards?" to "piç",
        "(?<=(?:ungrateful|dirty|filthy|little|cheap|stupid|you) )tramps?" to "sürtük",
        "pussy" to "korkak",
        "fuck(?:ed|s)?" to "siktir"
    ).map { Regex("(?i)\\b${it.first}\\b") to it.second }

    private val names = "abcdefghijklmnopqrstuvwxyz".map { "Zq$it" }

    // "this fucking car" -> "bu lanet olası araba": isimden önceki küfür YERİNDE kalır.
    private val inPlace = Regex("(?i)\\b(this|that|the|my|your|his|her|our|their|a|an|these|those|some|every|no|whole|one)\\s+(motherfucking|fucking|fuckin'?|goddamn(?:ed)?|damn|damned)\\s+(?=\\p{L})")

    fun shield(text: String): Shielded {
        var t = text
        val tails = ArrayList<String>()
        val slots = ArrayList<Slot>()
        // Yer tutucu yerine İngilizce "damn": yerleşik çeviri "lanet para" der; yer tutucu "lanet olası parası" gibi bozuyordu.
        t = inPlace.replace(t) { m -> m.groupValues[1] + " damn " }
        for (r in rules) {
            if (r.re.containsMatchIn(t)) {
                t = r.re.replace(t, r.replacement)
                if (r.tail != null && r.tail !in tails) tails += r.tail
            }
        }
        t = t.replace(Regex("\\s{2,}"), " ").trim()
        for ((re, tr) in words) {
            t = re.replace(t) { m ->
                if (slots.size >= names.size) m.value
                else {
                    val token = names[slots.size]
                    slots += Slot(token, m.value, tr)
                    token
                }
            }
        }
        // Cümlede zaten "siktir/orospu çocuğu" gibi sert bir küfür kalıyorsa ayrıca "be" eklemeye gerek yok.
        val finalTails = if (slots.isNotEmpty()) tails.filter { it != MILD } else tails
        return Shielded(t, slots, finalTails.take(1))
    }

    /** Çeviriye cümle sonu küfrünü ekler: "Kıpırdama!" + "amına koyayım" -> "Kıpırdama, amına koyayım!" */
    fun addTails(translated: String, tails: List<String>): String {
        if (tails.isEmpty() || translated.isBlank()) return translated
        val tail = tails.first()
        if (translated.contains(tail, ignoreCase = true)) return translated
        val m = Regex("[.!?…]+$").find(translated.trimEnd())
        val body = translated.trimEnd().removeSuffix(m?.value ?: "").trimEnd(',', ' ')
        val punct = m?.value ?: ""
        return if (tail == MILD) "$body $tail$punct" else "$body, $tail$punct"
    }

    /** Geçici isimleri Türkçe karşılığıyla değiştirir; biri kayıpsa null (yedek yol gerekir). */
    fun restore(translated: String, slots: List<Slot>, tr: Locale): String? {
        var t = translated
        for (s in slots) {
            val re = Regex("(?i)\\b${s.token}(?:['’][\\p{L}]+)?")
            if (!re.containsMatchIn(t)) return null
            t = re.replace(t) { m ->
                val atStart = m.range.first == 0 || t.substring(0, m.range.first).trimEnd().let { it.isEmpty() || it.last() in ".!?…" }
                if (atStart) s.turkish.substring(0, 1).uppercase(tr) + s.turkish.substring(1) else s.turkish
            }
        }
        return t
    }

    /** Yedek yol: geçici isimleri İngilizce kelimeye geri koyar. */
    fun unshield(text: String, slots: List<Slot>): String {
        var t = text
        for (s in slots) t = t.replace(s.token, s.english)
        return t
    }
}

/**
 * Ses efekti etiketleri: "[suspenseful music playing]" -> "[gerilim müziği çalıyor]".
 * ML Kit'e gitmez. OCR'ın köşeli parantezi I, l, |, (, { diye okumasını da tolere eder.
 */
object SoundTags {
    private val words: Map<String, String> = mapOf(
        "music" to "müzik", "song" to "şarkı", "suspenseful" to "gerilim", "dramatic" to "dramatik", "tense" to "gergin",
        "ominous" to "tekinsiz", "eerie" to "ürkütücü", "upbeat" to "hareketli", "soft" to "hafif", "sad" to "hüzünlü",
        "somber" to "hüzünlü", "action" to "aksiyon", "rock" to "rock", "jazz" to "caz", "classical" to "klasik", "gentle" to "yumuşak",
        "playing" to "çalıyor", "plays" to "çalıyor", "continues" to "devam ediyor", "continuing" to "devam ediyor",
        "swells" to "yükseliyor", "builds" to "yükseliyor", "rises" to "yükseliyor", "intensifies" to "yoğunlaşıyor",
        "fades" to "kısılıyor", "stops" to "duruyor", "ends" to "bitiyor", "resumes" to "yeniden başlıyor",
        "grunts" to "homurtular", "grunt" to "homurtu", "grunting" to "homurdanıyor",
        "groans" to "inlemeler", "groan" to "inleme", "groaning" to "inliyor", "moans" to "inlemeler", "moaning" to "inliyor",
        "pained" to "acılı", "struggling" to "boğuşuyor", "struggles" to "boğuşma", "straining" to "zorlanıyor",
        "cracking" to "çatırtı", "crack" to "çatırtı", "cracks" to "çatırtı", "crunch" to "çatırtı",
        "gunshot" to "silah sesi", "gunshots" to "silah sesleri", "gunfire" to "silah sesleri", "gun" to "silah",
        "cocks" to "kuruluyor", "cocking" to "kuruluyor", "reloads" to "dolduruluyor",
        "whimpers" to "sızlanma", "whimpering" to "sızlanıyor", "screams" to "çığlıklar", "scream" to "çığlık",
        "screaming" to "çığlık atıyor", "shrieks" to "çığlıklar", "laughs" to "gülüyor", "laughing" to "gülüyor",
        "laughter" to "kahkahalar", "chuckles" to "kıkırdıyor", "chuckling" to "kıkırdıyor", "sighs" to "iç çekiyor",
        "sighing" to "iç çekiyor", "gasps" to "nefesi kesiliyor", "gasping" to "nefes nefese", "panting" to "soluyor", "gasp" to "nefesi kesiliyor",
        "running" to "çalışıyor", "guitar" to "gitar", "unintelligible" to "anlaşılmaz", "facetious" to "alaycı", "shock" to "şaşkınlık",
        "chanting" to "tezahürat", "chant" to "tezahürat", "chants" to "tezahürat", "group" to "grup",
        "smoke" to "duman", "yelp" to "çığlık", "yelping" to "çığlık atıyor",
        "breathing" to "nefes alıyor", "heavily" to "derin derin", "coughing" to "öksürüyor", "coughs" to "öksürüyor",
        "crying" to "ağlıyor", "cries" to "ağlıyor", "sobbing" to "hıçkırıyor", "sobs" to "hıçkırıyor",
        "whispering" to "fısıldıyor", "whispers" to "fısıldıyor", "shouting" to "bağırıyor", "shouts" to "bağırıyor",
        "yelling" to "bağırıyor", "yells" to "bağırıyor", "indistinct" to "anlaşılmaz", "chatter" to "konuşmalar",
        "chattering" to "konuşmalar", "speaking" to "konuşuyor", "speaks" to "konuşuyor", "spanish" to "İspanyolca",
        "footsteps" to "ayak sesleri", "door" to "kapı", "opens" to "açılıyor", "closes" to "kapanıyor", "slams" to "çarpıyor",
        "knocking" to "kapı çalınıyor", "knocks" to "kapı çalınıyor", "phone" to "telefon", "ringing" to "çalıyor",
        "rings" to "çalıyor", "buzzing" to "titriyor", "vibrating" to "titriyor", "explosion" to "patlama",
        "explosions" to "patlamalar", "siren" to "siren", "sirens" to "sirenler", "wailing" to "çalıyor",
        "engine" to "motor", "revving" to "gürlüyor", "revs" to "gürlüyor", "tires" to "lastikler", "screeching" to "gıcırdıyor",
        "glass" to "cam", "shatters" to "kırılıyor", "shattering" to "kırılıyor", "thud" to "gümleme", "thuds" to "gümlemeler",
        "punch" to "yumruk", "punches" to "yumruklar", "fighting" to "dövüş", "fight" to "dövüş", "sounds" to "sesleri",
        "sound" to "sesi", "growls" to "hırlıyor", "growling" to "hırlıyor", "barking" to "havlıyor", "dog" to "köpek",
        "thunder" to "gök gürültüsü", "rain" to "yağmur", "wind" to "rüzgâr", "silence" to "sessizlik", "beeping" to "bip sesi",
        "static" to "parazit", "radio" to "telsiz", "helicopter" to "helikopter", "and" to "ve", "loud" to "yüksek",
        "distant" to "uzaktan", "muffled" to "boğuk", "sniffs" to "burnunu çekiyor", "groani" to "inleme",
        "inhales" to "nefes alıyor", "exhales" to "nefes veriyor", "clears" to "temizliyor", "throat" to "boğazını",
        "applause" to "alkış", "starts" to "çalışıyor", "starting" to "çalışıyor", "idling" to "rölantide", "alarm" to "alarm", "blaring" to "çalıyor", "blares" to "çalıyor",
        "beeps" to "bip sesi", "heavy" to "derin derin", "rumbling" to "gürlüyor",
        "rumbles" to "gürlüyor", "crashing" to "çarpışma", "crash" to "çarpışma", "smashing" to "kırılıyor",
        "splash" to "su sesi", "splashing" to "su sesi", "creaks" to "gıcırdıyor", "creaking" to "gıcırdıyor",
        "squeaks" to "gıcırdıyor", "rattling" to "tıkırdıyor", "rattles" to "tıkırdıyor", "hissing" to "tıslıyor",
        "humming" to "mırıldanıyor", "hums" to "mırıldanıyor", "yelps" to "çığlık",
        "kicks" to "tekmeler", "kick" to "tekme", "slap" to "tokat", "stabbing" to "bıçaklama", "squelch" to "vıcık ses",
        "body" to "ceset", "falls" to "düşüyor", "thumps" to "gümlüyor", "lock" to "kilit", "unlocks" to "açılıyor",
        "car" to "araba", "horn" to "korna", "honking" to "korna çalıyor", "honks" to "korna çalıyor",
        "door's" to "kapı", "open" to "açık", "shut" to "kapanıyor", "bell" to "zil", "cheering" to "tezahürat", "crowd" to "kalabalık", "clicks" to "tıklıyor", "click" to "tık",
        "thunderous" to "gök gürültüsü gibi", "roar" to "kükreme", "roars" to "kükrüyor", "roaring" to "kükrüyor",
        "booming" to "gümbürdüyor", "booms" to "gümbürdüyor", "boom" to "gümbürtü", "stomping" to "ağır adımlar",
        "stomps" to "ağır adımlar", "bellowing" to "böğürüyor", "bellows" to "böğürüyor", "snarling" to "hırlıyor",
        "snarls" to "hırlıyor", "howling" to "uluyor", "howls" to "uluyor"
    )
    private val skip = setOf("the", "a", "an", "both", "softly", "quietly", "continue", "in")
    // "gerilim müziği" (isim tamlaması) ama "dramatik müzik" (sıfat)
    private val adjectives = setOf("suspenseful", "action", "rock", "jazz", "guitar", "piano")
    private val tagRe = Regex("[\\[({]([^\\[\\](){}]*)[\\])}]?")

    private fun isSoundWords(s: String): Boolean {
        val toks = s.lowercase().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        return toks.isNotEmpty() && toks.all { w ->
            val x = w.trim('\'', '.', '-')
            x in words || x in skip || (x.endsWith("l") && x.dropLast(1) in words) || x == "and"
        }
    }

    /**
     * OCR'ın bozduğu köşeli parantezleri onarır (çeviriden ÖNCE, tüm zincir için):
     *  "Lgroup chanting] All hail" -> "[group chanting] All hail"
     *  "|chanting continues] -[suspenseful music playingl" -> "[chanting continues] -[suspenseful music playing]"
     *  "yelps, groans]" -> "[yelps, groans]"
     */
    fun repair(text: String): String {
        var t = text
        // Açılış parantezi I, l, L, | okunmuş
        t = t.replace(Regex("(^|\\s|-)[IlL|]\\s?([a-z][a-z ,'’-]*[\\])])")) { m ->
            if (isSoundWords(m.groupValues[2].dropLast(1))) m.groupValues[1] + "[" + m.groupValues[2] else m.value
        }
        // Açılış hiç yok: "yelps, groans]"
        Regex("^([a-z][a-z ,'’-]*)[\\])]").find(t)?.let { m ->
            if (isSoundWords(m.groupValues[1])) t = "[" + t
        }
        // Kapanış "l" okunmuş ya da hiç yok (satır sonunda)
        Regex("\\[([a-z][a-z ,'’-]*)$").find(t)?.let { m ->
            val inner = m.groupValues[1].trimEnd()
            val lastTok = inner.substringAfterLast(' ')
            val fixed = if (lastTok.endsWith("l") && lastTok.dropLast(1).lowercase() in words) inner.dropLast(1) else inner
            if (isSoundWords(fixed)) t = t.substring(0, m.range.first) + "[" + fixed + "]"
        }
        // İki parantez de yok, açılış I/l/L okunmuş: "Lguitar music playing" -> "[guitar music playing]"
        Regex("^[IlL|]([a-z][a-z ,'’-]*)$").find(t.trim())?.let { m ->
            if (isSoundWords(m.groupValues[1])) t = "[" + m.groupValues[1].trimEnd() + "]"
        }
        // Açılış "{" okunmuş: "{chanting continues]" -> "[chanting continues]"
        t = t.replace(Regex("\\{(?=[a-z][a-z ,'’-]*[\\])])"), "[")
        // Konuşmacı etiketinin kapanışı ")" okunmuş: "[Batman) What..." -> "[Batman] What..."
        t = t.replace(Regex("^\\[(\\p{Lu}[\\p{L}'’.]*(?: \\p{Lu}[\\p{L}'’.]*)?)\\)"), "[$1]")
        // Satır sonundaki etiket: iki parantez de bozuk "-lunintelligible strugglingl" -> "-[unintelligible struggling]"
        Regex("(\\s|-)[IlL|]([a-z][a-z ,'’-]*?)l$").find(t)?.let { m ->
            val inner = m.groupValues[2].trimEnd()
            if (isSoundWords(inner)) t = t.substring(0, m.range.first) + m.groupValues[1] + "[" + inner + "]"
        }
        // Kapanış ")" okunmuş: "[pained gasp)" -> "[pained gasp]"
        t = t.replace(Regex("\\[([a-z][a-z ,'’-]*)\\)")) { "[" + it.groupValues[1] + "]" }
        return t
    }

    /** Metin tamamen ses etiketlerinden oluşuyorsa Türkçesini döner, değilse null. */
    fun translate(text: String): String? {
        var t = text.trim()
        if (t.isEmpty()) return null
        val realOpen = t.first() in "[({"
        // OCR: "Igun cocks]" / "lgunshot)" -> "[gun cocks]" / "[gunshot)"
        t = t.replace(Regex("(^|\\s)[Il|](?=[a-z])"), "$1[")
        val hasClose = t.any { it in "])}" }
        if (!realOpen && !hasClose) {
            // "Igrunt, groan" -> iki parantez de okunmamış; tüm kelimeler ses kelimesiyse etiket say.
            if (!t.startsWith("[")) return null
            val inner = t.substring(1)
            if (inner.isBlank() || inner.any { it.isUpperCase() }) return null
            val toks = inner.lowercase().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
            if (toks.isEmpty() || toks.any { it.trim('\'', '.') !in words && it !in skip }) return null
            return "[" + translateContent(inner) + "]"
        }
        val tags = tagRe.findAll(t).toList()
        if (tags.isEmpty()) return null
        if (tagRe.replace(t, "").trim('-', '–', ' ').isNotBlank()) return null
        val out = ArrayList<String>()
        for (m in tags) {
            val content = m.groupValues[1].trim()
            if (content.isEmpty()) return null
            // "[Dez groaning]" -> baştaki isim korunur, gerisi ses etiketi
            val nameM = Regex("^(\\p{Lu}[\\p{L}'’]+)\\s+(.+)$").find(content)
            if (nameM != null && nameM.groupValues[2].none { it.isUpperCase() }) {
                out += "[" + nameM.groupValues[1] + " " + translateContent(nameM.groupValues[2]) + "]"
                continue
            }
            if (content.any { it.isUpperCase() }) return null
            out += "[" + translateContent(content) + "]"
        }
        return out.joinToString(" ")
    }

    private fun translateContent(content: String): String {
        // "groans, heavy breathing" -> her virgüllü parça ayrı, araya virgül
        val parts = content.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size > 1) {
            val tr = parts.map { translatePart(it) }.filter { it != "ses efekti" }
            return if (tr.isEmpty()) "ses efekti" else tr.joinToString(", ")
        }
        return translatePart(content)
    }

    // Kelime kelime çevrilemeyen kalıplar.
    private val phrases = mapOf(
        "no audible dialogue" to "konuşma duyulmuyor",
        "no dialogue" to "konuşma yok",
        "inaudible" to "anlaşılmıyor",
        "indistinct" to "anlaşılmıyor",
        "indistinct chatter" to "anlaşılmayan konuşmalar",
        "indistinct conversation" to "anlaşılmayan konuşma",
        "indistinct talking" to "anlaşılmayan konuşmalar",
        "speaking foreign language" to "yabancı dilde konuşuyor",
        "speaking spanish" to "İspanyolca konuşuyor",
        "silence" to "sessizlik",
        "car engine running" to "araba motoru çalışıyor",
        "engine running" to "motor çalışıyor",
        "both gasp" to "ikisinin de nefesi kesiliyor",
        "facetious shock" to "sahte şaşkınlık",
        "panting continues" to "soluma devam ediyor",
        "chanting continues" to "tezahürat devam ediyor",
        "group chanting" to "grup tezahürat ediyor",
        "crowd chanting" to "kalabalık tezahürat ediyor",
        "man panting" to "adam soluyor",
        "woman panting" to "kadın soluyor",
        "pained gasp" to "acıyla nefesi kesiliyor",
        "smoke hissing" to "duman tıslıyor",
        "grunts and groans" to "homurtular ve inlemeler",
        "groans and grunts continue" to "inlemeler ve homurtular sürüyor",
        "fighting grunts and groans" to "dövüş sesleri, homurtular ve inlemeler"
    )

    private fun translatePart(content: String): String {
        val tokens = content.lowercase().split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        run {
            val key = tokens.joinToString(" ") { it.trim('\'', '-', '.') }
            phrases[key]?.let { return it }
            if (key.endsWith("l")) phrases[key.dropLast(1)]?.let { return it }   // "dialoguel" (OCR: ] -> l)
        }
        val res = ArrayList<String>()
        var known = 0
        for ((i, raw) in tokens.withIndex()) {
            var w = raw.trim('\'', '-', '.')
            if (w !in words && w.endsWith("l") && w.dropLast(1) in words) w = w.dropLast(1) // "playingl" -> "playing"
            if (w in skip) continue
            val tr = words[w] ?: continue
            known++
            res += if (w == "music" && i > 0 && tokens[i - 1].trim('\'') in adjectives) "müziği" else tr
        }
        if (known == 0) return "ses efekti"
        return res.joinToString(" ")
    }
}

/**
 * Şeritteki OCR satırlarından ALTYAZI bloğunu seçer.
 * Altyazının üstünde başka bir yazı (X-Ray oyuncu listesi, görev yazısı) olabilir;
 * en alttaki bloğu alıp, araya BELİRGİN boşluk girince duruyoruz.
 * Boşluk = üstteki satırın ALT kenarı ile alttakinin ÜST kenarı arası; satır yüksekliğine göre ölçülür.
 * (Eskiden üst kenarlar arası ölçülüyordu; iki satırlı her altyazının ilk satırı atılıyordu.)
 */
object SubtitleBlocks {
    class Line(val top: Int, val bottom: Int, val text: String)

    fun bottomBlock(lines: List<Line>): List<Line> {
        if (lines.size <= 1) return lines
        val sorted = lines.sortedBy { it.top }
        val out = ArrayList<Line>()
        var below = sorted.last()
        out += below
        for (i in sorted.size - 2 downTo 0) {
            val l = sorted[i]
            val lineH = maxOf(1, maxOf(l.bottom - l.top, below.bottom - below.top))
            val gap = below.top - l.bottom
            if (gap > lineH * 0.9f) break          // arada bir satırdan fazla boşluk: başka blok
            out += l
            below = l
            if (out.size >= 3) break               // altyazı en fazla üç satırdır
        }
        return out.reversed()
    }
}

/** Yerleşik çeviri (ML Kit) cevap vermediğinde fırlatılır; dışarıya null olarak döner. */
class OfflineUnavailable : Exception()

/**
 * Uygulamanın çevrim dışı çevirisi. CaptureService şöyle kullanır:
 *   OfflineFix.translate(metin) { fast?.translate(it) }
 */
class OfflineFixEngine(
    private val glossary: SubtitleGlossary = SubtitleGlossary.default(SubtitleGlossary.GAME_ENTRIES),
    private val cacheSize: Int = 300
) {

    private val tr = Locale.forLanguageTag("tr-TR")
    private val sentenceSplit = Regex("(?<=[.!?…])\\s+")
    private val trailingPunct = Regex("[.!?…]+$")
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > cacheSize
    }

    // Yerleşik çeviri bazen küfürü çevirmeden bırakır; yerinde Türkçeleştir.
    private val leftovers = listOf(
        Regex("(?i)\\bmotherfucking\\b") to "siktiğimin",
        Regex("(?i)\\bmotherfucker\\b") to "orospu çocuğu",
        Regex("(?i)\\bfuck(?:ing|in'?)\\b") to "siktiğimin",
        Regex("(?i)\\bfuck\\b") to "siktir",
        Regex("(?i)\\bbullshit\\b") to "saçmalık",
        Regex("(?i)\\bshit\\b") to "bok",
        Regex("(?i)\\basshole\\b") to "pislik herif",
        Regex("(?i)\\bbastard\\b") to "piç",
        Regex("(?i)\\bgoddamn(?:ed)?\\b") to "lanet",
        Regex("(?i)\\bdamn\\b") to "lanet"
    )

    private var mlFn: suspend (String) -> String? = { null }

    /** "Sözlüğüm" (kullanıcının kendi satırları): hazır sözlüğün ÖNÜNDE gelir. */
    @Volatile private var user: SubtitleGlossary? = null

    fun clearCache() = synchronized(cache) { cache.clear() }

    fun setUserEntries(text: String) {
        user = if (text.isBlank()) null else SubtitleGlossary.parse(text)
        synchronized(cache) { cache.clear() }
    }

    private fun look(text: String): String? = user?.lookup(text) ?: glossary.lookup(text)
    private fun isName(text: String): Boolean = user?.isName(text) == true || glossary.isName(text)
    private fun startsWithName(text: String): Boolean = user?.startsWithName(text) == true || glossary.startsWithName(text)

    private val trChars = Regex("[çğışöüÇĞİŞÖÜ]")
    private val trWords = Regex("(?i)\\b(ve|bir|bu|için|daha|fazla|ile|değil|ama|çok|gibi|olan|nedeniyle|edinin|ekran|uygulama)\\b")

    /** Ekrandaki yazı zaten Türkçeyse (telefon uyarısı, Türkçe altyazı) çevrilmez. */
    fun isAlreadyTurkish(text: String): Boolean =
        trChars.findAll(text).count() >= 2 || trWords.findAll(text).count() >= 2

    private val videoMeta = Regex("(?i)\\b\\d+ (saniye|dakika|saat|gün|hafta|ay|yıl) önce\\b|\\b\\d+ (seconds?|minutes?|hours?|days?|weeks?|months?|years?) ago\\b|\\b\\d+([,.]\\d+)? ?(mn|b|bin|k|m) (görüntüleme|views?)\\b|görüntüleme|\\bsubscribe\\b|abone ol")
    private val copyright = Regex("(?i)(©|\\(c\\)|\\ball rights reserved\\b|\\b(19|20)\\d{2}\\b.*\\b(llc|inc|ltd|entertainment|studios?|games)\\b)")
    private val creditLine = Regex("^[\\p{Lu}(][\\p{L}'’.()]*( [\\p{Lu}'’\"][\\p{L}'’\".]*)* ?[-–] ?[\\p{Lu}'’\"][\\p{L}'’\".]*( [\\p{L}'’\".]+)*$")

    // Jeneriğin altyazıyla aynı satıra karışması: "Eric Morgan Stuart - CommissionerrS. Landry approached..."
    private val creditMerged = Regex("^\\p{Lu}\\p{Ll}+(?: (?:\\p{Lu}\\.|\\p{Lu}\\p{Ll}+)){1,3} ?[-–] ?\\p{Lu}\\p{Ll}+")

    /** Altyazı olmayan satır: Türkçe arayüz yazısı, X-Ray / oyuncu kartı, telif, "Ad Soyad - Rol" jeneriği. */
    fun isNoiseLine(line: String): Boolean {
        val t = line.trim()
        if (creditMerged.containsMatchIn(t)) return true
        // Kısa, TAMAMI BÜYÜK HARF, noktalamasız satır: uygulama/kanal/kutucuk adı ("SEND FILES", "LIMBO").
        // Altyazı büyük harfle yazılsa bile genelde noktalama taşır ("NO! GET DOWN!").
        run {
            val words = t.split(Regex("\\s+")).filter { w -> w.any { it.isLetter() } }
            val letters = t.filter { it.isLetter() }
            if (words.size in 1..4 && letters.length >= 3 && letters.all { it.isUpperCase() } &&
                t.none { it in ".!?,…'\"-" }) return true
        }
        if (isAlreadyTurkish(t)) return true
        if (t.contains("x-ray", ignoreCase = true)) return true
        if (videoMeta.containsMatchIn(t)) return true
        if (copyright.containsMatchIn(t)) return true
        if (creditLine.matches(t)) {
            // Her kelime büyük harfle başlıyorsa (isim listesi) jenerik say.
            val words = t.split(' ', '-', '–').filter { w -> w.any { it.isLetter() } }
            if (words.size >= 3 && words.count { w -> w.first { it.isLetter() }.isUpperCase() } >= words.size - 1) return true
        }
        return false
    }

    private val inlineTag = Regex("\\[[a-z][a-z ,'’-]*]")
    private val openSpeaker = Regex("^\\[(\\p{Lu}[\\p{Ll}'’]+)\\s+(?=\\p{Lu})(?![^\\]]*])")
    private val tagPrefix = Regex("^\\[([^\\]]{1,30})]\\s*")

    /**
     * Yapay zekâ açıkken: yalnızca kullanıcının kendi sözlüğü (Sözlüğüm) ve ses etiketleri.
     * Hazır sözlük yapay zekânın önüne geçmez (bağlamı bilmez, yanlış olabilir).
     */
    fun lookupUserOnly(text: String): String? {
        SoundTags.translate(text)?.let { return it }
        val u = user ?: return null
        val cleaned = OcrTextCleaner.clean(text)
        val punct = trailingPunct.find(cleaned)?.value ?: ""
        val core = cleaned.removeSuffix(punct).trim()
        if (core.isEmpty()) return null
        return u.lookup(core)?.let { it + punct }
    }

    private val languages = mapOf(
        "spanish" to "İspanyolca", "french" to "Fransızca", "german" to "Almanca", "italian" to "İtalyanca",
        "russian" to "Rusça", "japanese" to "Japonca", "chinese" to "Çince", "mandarin" to "Çince",
        "korean" to "Korece", "portuguese" to "Portekizce", "arabic" to "Arapça", "latin" to "Latince",
        "turkish" to "Türkçe", "hindi" to "Hintçe", "polish" to "Lehçe", "ukrainian" to "Ukraynaca"
    )

    /** "In Spanish" (altyazıda konuşmanın dilini belirten etiket) -> "İspanyolca"; değilse null. */
    fun languageLabel(name: String): String? {
        val m = Regex("(?i)^\\s*(?:in|speaking)\\s+(\\p{L}+)\\s*$").find(name) ?: return null
        return languages[m.groupValues[1].lowercase()]
    }

    /** Yapay zekâya gidecek metin: OCR hataları düzeltilmiş, argo/küfür OLDUĞU GİBİ. */
    fun cleanForAi(text: String): String = OcrTextCleaner.clean(text).ifBlank { text }

    /** Sözlükte tam karşılığı varsa döner (ML Kit'e hiç gitmez). */
    fun lookup(text: String): String? {
        SoundTags.translate(text)?.let { return it }
        val cleaned = OcrTextCleaner.clean(text)
        val punct = trailingPunct.find(cleaned)?.value ?: ""
        val core = cleaned.removeSuffix(punct).trim()
        if (core.isEmpty()) return null
        look(core)?.let { return it + punct }
        return Phrases.lookup(core)?.let { it + punct }
    }

    // İki konuşmacının tek satırda olduğu altyazı: "Why didn't you? -I'm no killer."
    private val dialogTurn = Regex("(?<=[.!?…\\]])\\s*[-–]\\s*(?=[\\[\\p{Lu}'\"])")

    /** ml: yerleşik çeviri; null dönerse (model yok vb.) sonuç da null olur. */
    suspend fun translate(text: String, ml: suspend (String) -> String?): String? {
        mlFn = ml
        SoundTags.translate(text)?.let { return it }
        // Her konuşmacının repliği AYRI çevrilir; birleşince yerleşik çeviri anlamı karıştırıyordu
        // ("Neden sen değildin - Hiçbir katil yok").
        val turns = text.split(dialogTurn).map { it.trim() }.filter { it.isNotEmpty() }
        if (turns.size > 1) {
            val out = ArrayList<String>()
            for (turnText in turns) out += (lookup(turnText) ?: translate(turnText, ml) ?: return null)
            return out.joinToString(" - ")
        }
        // Satır içindeki ses etiketleri: "[laughs] That's the ticket!" -> "[gülüyor] ..."
        val inner = inlineTag.findAll(text).toList()
        if (inner.isNotEmpty() && inlineTag.replace(text, "").any { it.isLetter() }) {
            val out = ArrayList<String>()
            var last = 0
            for (m in inner) {
                val before = text.substring(last, m.range.first).trim()
                if (before.any { it.isLetter() }) out += (translate(before, ml) ?: return null)
                out += SoundTags.translate(m.value) ?: m.value
                last = m.range.last + 1
            }
            val after = text.substring(last).trim()
            if (after.any { it.isLetter() }) out += (translate(after, ml) ?: return null)
            return out.joinToString(" ")
        }
        // "[Beckett Put 'em..." (kapanış parantezi okunamamış konuşmacı adı)
        openSpeaker.find(text)?.let { m ->
            val tr = translate(text.substring(m.range.last + 1), ml) ?: return null
            return "[" + m.groupValues[1] + "] " + tr
        }
        // "[Matches] Hey..." -> konuşmacı etiketi çevrilmez
        tagPrefix.find(text)?.let { m ->
            val rest = text.substring(m.range.last + 1)
            if (rest.any { it.isLetter() }) {
                val tr = translate(rest, ml) ?: return null
                return "[" + m.groupValues[1] + "] " + tr
            }
        }
        val cleaned = OcrTextCleaner.clean(text)
        if (cleaned.isBlank()) return null
        val sentences = cleaned.split(sentenceSplit).filter { it.isNotBlank() }
        return try {
            if (sentences.size == 1) return cached(sentences[0])
            // Hız: sözlükte olan cümleler anında; olmayan ARDIŞIK cümleler TEK çağrıyla çevrilir.
            val out = ArrayList<String>()
            val run = ArrayList<String>()
            suspend fun flush() {
                if (run.isEmpty()) return
                out += if (run.size == 1) cached(run[0]) else cachedRun(run.joinToString(" "))
                run.clear()
            }
            for (sn in sentences) {
                val hit = lookup(sn)
                if (hit != null) { flush(); out += hit } else run += sn
            }
            flush()
            out.joinToString(" ")
        } catch (e: OfflineUnavailable) {
            null
        }
    }

    private suspend fun cachedRun(text: String): String {
        synchronized(cache) { cache[text] }?.let { return it }
        val r = mlTranslate(text)
        if (r.isNotBlank()) synchronized(cache) { cache[text] = r }
        return r
    }

    private suspend fun base(text: String): String =
        mlFn(text)?.takeIf { it.isNotBlank() } ?: throw OfflineUnavailable()

    private suspend fun cached(sentence: String): String {
        synchronized(cache) { cache[sentence] }?.let { return it }
        val r = translateSentence(sentence)
        if (r.isNotBlank()) synchronized(cache) { cache[sentence] = r }
        return r
    }

    private suspend fun translateSentence(sentence: String): String {
        val punct = trailingPunct.find(sentence)?.value ?: ""
        val core = sentence.removeSuffix(punct).trim()
        if (core.isEmpty()) return sentence

        look(core)?.let { return it + punct }
        Phrases.lookup(core)?.let { return it + punct }

        val parts = core.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size > 1) {
            val resolved = parts.map { look(it) ?: Phrases.lookup(it) }
            val anyKnown = resolved.any { it != null } || isName(parts[0])
            if (anyKnown) return joinParts(parts, resolved, punct)
        }
        return mlTranslate(core + punct)
    }

    /** argo düzelt -> küfürü koru -> yerleşik çeviri -> küfürü Türkçe koy. */
    private suspend fun mlTranslate(text: String): String {
        val norm = SlangNormalizer.normalize(Slang.normalize(text))
        val sh = ProfanityShield.shield(norm)
        if (sh.slots.isEmpty()) return ProfanityShield.addTails(fix(base(sh.text)), sh.tails)
        val restored = ProfanityShield.restore(base(sh.text), sh.slots, tr)
        if (restored != null) return ProfanityShield.addTails(fix(restored), sh.tails)
        return ProfanityShield.addTails(fix(base(ProfanityShield.unshield(sh.text, sh.slots))), sh.tails)
    }

    private suspend fun joinParts(parts: List<String>, resolved: List<String?>, punct: String): String {
        val out = ArrayList<String>()
        var i = 0
        while (i < parts.size) {
            val known = resolved[i] ?: if (isName(parts[i])) parts[i] else null
            if (known != null) {
                val isGlossary = resolved[i] != null
                var text = if (i > 0 && isGlossary && !startsWithName(known)) lowerFirst(known) else known
                if (i == parts.lastIndex) text += punct
                out += text
                i++
            } else {
                // Bitişik bilinmeyen parçaları BİRLİKTE çevir (bağlam kopmasın).
                var j = i
                while (j < parts.size && resolved[j] == null && !isName(parts[j])) j++
                val run = parts.subList(i, j).joinToString(", ")
                val endsHere = j == parts.size
                val tr = mlTranslate(run + if (endsHere) punct else "")
                out += if (endsHere) tr else tr.trimEnd(',', '.', '!', '?', '…', ';', ' ')
                i = j
            }
        }
        return out.joinToString(", ")
    }

    private fun lowerFirst(s: String): String =
        if (s.isEmpty()) s else s.substring(0, 1).lowercase(tr) + s.substring(1)

    private fun fix(translated: String): String {
        var t = translated
        for ((re, rep) in leftovers) {
            t = re.replace(t) { m ->
                if (m.value.first().isUpperCase()) rep.substring(0, 1).uppercase(tr) + rep.substring(1) else rep
            }
        }
        return t
    }
}

/** Uygulama genelinde tek örnek. */
val OfflineFix = OfflineFixEngine()
