package com.example.altyazi

/**
 * Telefonun çevirisinden ÇIKAN Türkçeyi düzeltir.
 *
 * Cihaz üstü çeviri motoru hızlı ve sınırsız, ama iki şeyi düzenli olarak
 * yanlış yapıyor; ikisi de kullanıcının kaydında görüldü:
 *
 *  1. Soru eki: "Do I know that name?" -> "Bu ismi biliyorum mi?"
 *     Doğrusu "biliyor muyum". Ek fiilden sonra gelmeli, kişi eki de ekin
 *     üstüne binmeli.
 *
 *  2. Köşeli parantezli ses etiketleri: "[dramatic music playing]" ->
 *     "[Dramatik Müzik Oyna Ingl". Bunlar cümle değil, sahne notu; kelime
 *     kelime çevrilince saçmalıyor. Kendi tablomuzdan karşılıyoruz.
 */
object TurkishFix {

    /**
     * Ses/sahne etiketleri. OCR bunları sık bozduğu için tam eşleşme
     * aramıyoruz; parçada geçen anahtar kelimeye bakıyoruz.
     */
    private val SES_IPUCLARI: List<Pair<String, String>> = listOf(
        "footstep" to "ayak sesleri",
        "gunshot" to "silah sesi",
        "gunfire" to "silah sesi",
        "explos" to "patlama",
        "whisper" to "fısıldayarak",
        "scream" to "çığlık",
        "shout" to "bağırarak",
        "yell" to "bağırarak",
        "groan" to "inleyerek",
        "grunt" to "homurdanarak",
        "sigh" to "iç çekerek",
        "laugh" to "gülerek",
        "chuckl" to "kıkırdayarak",
        "sob" to "ağlayarak",
        "cry" to "ağlayarak",
        "strain" to "zorlanarak",
        "pant" to "nefes nefese",
        "breath" to "nefes sesi",
        "thunder" to "gök gürültüsü",
        "siren" to "siren sesi",
        "engine" to "motor sesi",
        "applau" to "alkış",
        "clap" to "alkış",
        "knock" to "kapı vuruluyor",
        "door" to "kapı sesi",
        "phone" to "telefon çalıyor",
        "ring" to "zil sesi",
        "beep" to "bip sesi",
        "static" to "parazit",
        "music" to "müzik çalıyor",
    )

    /**
     * Satır bir ses etiketiyse Türkçe karşılığını döndürür, değilse null.
     * Böyle satırlar çeviri motoruna hiç gitmez: hem doğru çıkar hem bedava.
     */
    fun sesIpucu(ingilizce: String): String? {
        val kirpik = ingilizce.trim()
        // Kapanış parantezi OCR'da sık kayboluyor, o yüzden sadece açılışa bakıyoruz.
        if (!kirpik.startsWith("[") && !kirpik.startsWith("(")) return null

        val sade = kirpik.lowercase().filter { it.isLetter() || it == ' ' }
        if (sade.isBlank()) return null

        if (sade.contains("dramatic") && sade.contains("music")) {
            return "[gerilim müziği]"
        }
        if (sade.contains("tense") && sade.contains("music")) {
            return "[gergin müzik]"
        }

        for ((anahtar, karsilik) in SES_IPUCLARI) {
            if (sade.contains(anahtar)) return "[$karsilik]"
        }
        return null
    }

    /**
     * "-yor" ekinden sonra gelen soru ekini yerine oturtur.
     * "biliyorum mi" -> "biliyor muyum", "geliyorsun mu" -> "geliyor musun"
     *
     * "-yor"dan sonra soru eki Türkçede daima "mu"dur; kişi eki de ekin
     * üstüne biner. Kural bilerek dar: yalnızca bu kalıba dokunuyor.
     */
    // DİKKAT: \w Java'da yalnızca İngiliz harflerini kapsar; "çalışıyorum"
    // gibi kelimelerde kural tutmazdı. \p{L} tüm harfleri kapsıyor.
    private val SORU_EKI = Regex(
        "(?<![\\p{L}])([\\p{L}]*?[ıiuü]yor)(um|sun|uz|sunuz)\\s+m[ıiuü](?![\\p{L}])",
        RegexOption.IGNORE_CASE
    )

    private fun kisiEki(ek: String): String = when (ek.lowercase()) {
        "um" -> "muyum"
        "sun" -> "musun"
        "uz" -> "muyuz"
        "sunuz" -> "musunuz"
        else -> "mu"
    }

    fun duzelt(turkce: String): String {
        var metin = SORU_EKI.replace(turkce) { eslesme ->
            val govde = eslesme.groupValues[1]
            govde + " " + kisiEki(eslesme.groupValues[2])
        }

        // Noktalama öncesi boşluk ve çoklu boşluk temizliği
        metin = metin.replace(Regex("\\s+([,.!?:;])"), "$1")
        metin = metin.replace(Regex("\\s+"), " ").trim()

        return metin
    }
}
