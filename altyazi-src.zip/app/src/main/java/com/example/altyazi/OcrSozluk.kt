package com.example.altyazi

import android.content.Context
import java.util.zip.GZIPInputStream

/**
 * SÖZLÜKLÜ OCR ONARIMI
 *
 * Bilgisayar sürümünde (pc/lingoplay_pc.py) uzun zamandır çalışan onarım
 * telefonda yoktu: telefon elle yazılmış kısa listelerle idare ediyordu.
 * Bu dosya aynı işi 124.207 kelimelik İngilizce sözlükle yapıyor.
 *
 * Kullanıcının kaydındaki hatalar ve sözlüğün verdiği karşılık:
 *   "Iwonder"   -> "I wonder"     (baştaki I kelimeye yapışmış)
 *   "labsolve"  -> "I absolve"
 *   "lvories"   -> "ivories"      (l harfi i okunmuş)
 *   "thal"      -> "that"
 *   "topickup"  -> "to pick up"
 *
 * Kural hep aynı ve temkinli: kelime SÖZLÜKTE VARSA hiç dokunulmaz, denenen
 * karşılık sözlükte YOKSA da dokunulmaz. Yani uydurma düzeltme yapamaz.
 */
object Sozluk {
    private const val VARLIK = "kelimeler.txt.gz"

    @Volatile private var kelimeler: Set<String>? = null
    @Volatile private var yukleniyor = false
    @Volatile var sonHata: String? = null
        private set

    val hazir: Boolean get() = kelimeler != null
    val adet: Int get() = kelimeler?.size ?: 0

    /** Hangi yoldan yüklendiği (kayda yazılıyor). */
    @Volatile var kaynak: String = "-"
        private set

    /**
     * Sözlüğü arka planda yükler. Birden çok kez çağrılabilir, bir kez yükler.
     *
     * İKİ YOLDAN birden deniyoruz. Kullanıcının 6 Kasım 21:42 kaydında varlık
     * kaynak zip'inde olmasına rağmen APK'da bulunamadı
     * ("FileNotFoundException: kelimeler.txt.gz"). Sebebi anlaşılamadığı için
     * aynı dosya res/raw içine de konuldu: biri paketlenmezse diğeri çalışır.
     * Hata hâlinde APK'daki varlıkların listesi de kayda yazılıyor.
     */
    fun yukle(context: Context) {
        if (kelimeler != null || yukleniyor) return
        yukleniyor = true
        val app = context.applicationContext
        val is_ = Runnable { yukleIsi(app) }
        Thread(is_, "sozluk-yukle").apply { priority = Thread.MIN_PRIORITY }.start()
    }

    /** Asıl yükleme. Ayrı fonksiyon: etiketli return'e gerek kalmasın. */
    private fun yukleIsi(app: Context) {
        try {
            val hatalar = ArrayList<String>(2)
            // 1) res/raw/kelimeler.gz
            //    Kullanıcının 6 Kasım 22:32 kaydında assets yolu APK'da bulunamadı,
            //    res/raw çalıştı ("SÖZLÜK HAZIR: 124207 kelime (res/raw)").
            //    O yüzden sıra tersine çevrildi ve assets kopyası kaldırıldı.
            val a = dene("res/raw") { app.resources.openRawResource(R.raw.kelimeler) }
            if (a != null) {
                kelimeler = a
                kaynak = "res/raw"
                sonHata = null
                return
            }
            hatalar.add(sonHata ?: "res/raw: bilinmeyen")
            // 2) assets/kelimeler.txt.gz (eski yol; artık varsayılan olarak yok)
            val b = dene("assets") { app.assets.open(VARLIK) }
            if (b != null) {
                kelimeler = b
                kaynak = "assets"
                sonHata = null
                return
            }
            hatalar.add(sonHata ?: "assets: bilinmeyen")
            // İkisi de olmadı: APK'da ne var, kayda yazalım.
            val varliklar = try {
                app.assets.list("")?.joinToString(", ")?.take(200) ?: "(okunamadı)"
            } catch (e: Throwable) {
                "(liste alınamadı: ${e.javaClass.simpleName})"
            }
            sonHata = hatalar.joinToString(" | ") + " | APK varlıkları: $varliklar"
        } finally {
            yukleniyor = false
        }
    }

    /** Bir akıştan kelime kümesi okur; olmazsa sonHata'yı yazıp null döner. */
    private fun dene(ad: String, akis: () -> java.io.InputStream): Set<String>? = try {
        val set = HashSet<String>(1 shl 18)   // 262144 kova: 124k kelime rahat sığar
        GZIPInputStream(akis()).bufferedReader().use { r ->
            r.forEachLine { satir ->
                val k = satir.trim()
                if (k.isNotEmpty()) set.add(k)
            }
        }
        if (set.size < 1000) {
            sonHata = "$ad: beklenenden az kelime (${set.size})"
            null
        } else {
            set
        }
    } catch (e: Throwable) {
        sonHata = "$ad: ${e.javaClass.simpleName}: ${e.message}"
        null
    }

    /** Kelime sözlükte mi? Sözlük henüz yüklenmediyse daima false. */
    fun icinde(kelime: String): Boolean {
        val s = kelimeler ?: return false
        return kelime.lowercase() in s
    }
}

object OcrOnar {

    /**
     * OCR'ın sık karıştırdığı harfler. Bilgisayar sürümündeki liste (l/I/1 -> t,
     * a -> o) artı telefon kaydından çıkan birkaç tanesi: "lvories" -> "ivories".
     * Her harfin birkaç adayı olabilir; hepsi sözlüğe sorulur.
     */
    private val KARISIK: Map<Char, CharArray> = mapOf(
        'l' to charArrayOf('t', 'i'),
        'I' to charArrayOf('t', 'l'),
        '1' to charArrayOf('t', 'l'),
        'a' to charArrayOf('o'),
        '0' to charArrayOf('o'),
        '5' to charArrayOf('s'),
    )

    /** Bölmede tek başına durabilen kısa kelimeler. */
    private val KISA_SIK = setOf(
        "to", "of", "in", "on", "is", "it", "at", "be", "we", "he", "me", "my",
        "no", "so", "up", "do", "go", "an", "as", "by", "or", "us", "if", "oh",
        "ok", "am", "hi", "yo",
    )

    /** "I" ile başlayan gerçek özel adlar: "Iran", "Ivy" bozulmasın. */
    private val I_ADLARI = setOf(
        "ian", "ivan", "iris", "isaac", "ida", "ike", "ina", "ira", "ines", "ivy",
        "igor", "ilsa", "ilya", "imani", "ingrid", "isla", "ismail", "ivo", "izzy",
        "iggy", "iran", "iraq", "italy", "india", "israel", "ireland", "idaho", "iowa",
    )

    private val IZINLI_BASLIK = Regex("^(?:Mc|Mac|De|Di|La|Le|Van|Von|iP|eB)")
    private val PARCA = Regex("^([^\\w']*)([\\w']+)([^\\w']*)$")

    // ------------------------------------------------------- harf adayları

    /**
     * Karışabilen harfleri tek tek (en çok 3 tanesini) değiştirip aday üretir.
     * "thal" -> "that" ('l' yerine 't'), "lvories" -> "ivories" ('l' yerine 'i').
     */
    fun adaylar(kelime: String): List<String> {
        val yerler = kelime.indices.filter { kelime[it] in KARISIK }
        if (yerler.isEmpty() || yerler.size > 6) return emptyList()
        val sonuc = ArrayList<String>(64)
        for (adet in 1..minOf(3, yerler.size)) {
            kombinasyon(yerler, adet, 0, ArrayList()) { secim ->
                uretVeEkle(kelime, secim, 0, sonuc)
            }
        }
        return sonuc
    }

    /** yerler listesinden [adet] tanesini seçen tüm kombinasyonlar. */
    private fun kombinasyon(
        yerler: List<Int>, adet: Int, bas: Int,
        birikim: MutableList<Int>, isle: (List<Int>) -> Unit,
    ) {
        if (birikim.size == adet) { isle(birikim); return }
        for (i in bas until yerler.size) {
            birikim.add(yerler[i])
            kombinasyon(yerler, adet, i + 1, birikim, isle)
            birikim.removeAt(birikim.size - 1)
        }
    }

    /** Seçilen yerlerin her aday harfi için bir kelime üretir. */
    private fun uretVeEkle(kelime: String, secim: List<Int>, i: Int, cikti: MutableList<String>) {
        if (cikti.size > 300) return
        if (i == secim.size) { cikti.add(kelime); return }
        val yer = secim[i]
        for (yeni in KARISIK[kelime[yer]] ?: return) {
            uretVeEkle(kelime.substring(0, yer) + yeni + kelime.substring(yer + 1), secim, i + 1, cikti)
        }
    }

    // --------------------------------------------------------- harf onarımı

    /**
     * Sözlükte olmayan kelimede karışık harfleri dener: "thal" -> "that".
     * Sonuç sözlükte değilse kelimeye DOKUNMAZ.
     * Cümle ortasında büyük harfle başlayan kelimeler isim sayılır, ellenmez.
     */
    fun harfleriDuzelt(metin: String): String {
        if (!Sozluk.hazir) return metin
        val parcalar = metin.split(" ")
        val cikti = ArrayList<String>(parcalar.size)
        var cumleBasi = true
        for (parca in parcalar) {
            val m = PARCA.find(parca)
            if (m == null) {
                cikti.add(parca)
                cumleBasi = parca.endsWith(".") || parca.endsWith("!") || parca.endsWith("?")
                continue
            }
            val (on, govde, son) = m.destructured
            var yeni = govde
            val kucuk = govde.lowercase()
            // Cümle ortasında Büyük harf = isim (ellenmez). "I" ile başlayanlar hariç: "Ieel", "Ihey"
            val isimGibi = govde.firstOrNull()?.isUpperCase() == true &&
                govde.drop(1).all { !it.isUpperCase() } && !cumleBasi && govde[0] != 'I'
            // 0 ve 1 gerçek rakam değil, OCR'ın o/l harfini yanlış okuması:
            // "g0od" -> "good", "1hey" -> "they". Bunlar düzeltmeye SOKULUR.
            // Kullanıcının kaydındaki "what g0od is money" bu yüzden düzelmiyordu.
            val rakamli = govde.any { it.isDigit() && it != '0' && it != '1' }
            if (govde.length >= 2 && !Sozluk.icinde(kucuk) && !isimGibi &&
                govde != govde.uppercase() && kucuk !in I_ADLARI && !rakamli
            ) {
                val denenecek = ArrayList<String>()
                // "Ieel" -> "feel": baştaki f harfi I okunmuş
                if (govde.startsWith("I") && govde.length > 2) denenecek.add("f" + govde.substring(1))
                denenecek.addAll(adaylar(govde))
                for (aday in denenecek) {
                    if (Sozluk.icinde(aday)) {
                        yeni = aday
                        if (govde[0] == 'I' || govde[0] == '1') {
                            if (cumleBasi) yeni = yeni.replaceFirstChar { it.uppercase() }
                        } else if (govde[0].isUpperCase()) {
                            yeni = yeni.replaceFirstChar { it.uppercase() }
                        }
                        break
                    }
                }
            }
            cikti.add(on + yeni + son)
            val tam = govde + son
            cumleBasi = tam.endsWith(".") || tam.endsWith("!") || tam.endsWith("?")
        }
        return cikti.joinToString(" ")
    }

    // --------------------------------------------------------- bitişik ayırma

    /**
     * Bitişik okunmuş küçük harfli kelimeyi sözlükle böler:
     * "topickup" -> "to pick up". En az parçalı bölme seçilir; bölünemezse null.
     */
    fun bol(kelime: String): List<String>? {
        if (!Sozluk.hazir) return null
        val n = kelime.length
        val bedeller = DoubleArray(n + 1) { Double.MAX_VALUE }
        val yol = arrayOfNulls<List<String>>(n + 1)
        bedeller[0] = 0.0
        yol[0] = emptyList()
        for (i in 1..n) {
            for (j in maxOf(0, i - 15) until i) {
                if (yol[j] == null) continue
                val w = kelime.substring(j, i)
                // Bedel null ise bu parça kabul edilmiyor. ("when" içinde continue
                // kullanmıyoruz: eski Kotlin sürümlerinde tuzak.)
                val bedel: Double? =
                    if (w.length == 1) {
                        if (w == "a" || w == "i") 1.3 else null
                    } else if (w.length == 2 && w !in KISA_SIK) {
                        null   // "mi", "th" gibi: yabancı kelimeyi saçma parçalara bölmesin
                    } else if (Sozluk.icinde(w)) {
                        1.0
                    } else {
                        null
                    }
                if (bedel == null) continue
                val toplam = bedeller[j] + bedel
                if (toplam < bedeller[i]) {
                    bedeller[i] = toplam
                    yol[i] = yol[j]!! + w
                }
            }
        }
        val parcalar = yol[n] ?: return null
        if (parcalar.size < 2) return null
        // "herm a no" gibi: tek harflik "a" yalnız başta ya da sonda olabilir
        if (parcalar.subList(1, maxOf(1, parcalar.size - 1)).any { it == "a" }) return null
        // Kısa kelime ("cabran" -> "cab ran" olmasın): kısa bağlaç parçası yoksa bölme
        if (n <= 6 && parcalar.none { it in KISA_SIK || it.length == 1 }) return null
        return parcalar.map { if (it == "i") "I" else it }
    }

    private val NOKTALAMA_BOSLUK = Regex("(?<=[A-Za-z]{2})([,;])(?=[A-Za-z])")
    private val CUMLE_BOSLUK = Regex("(?<=[A-Za-z][a-z])([.!?])(?=[A-Z][a-z])")
    private val KUCUK_BUYUK = Regex("(?<=[a-z])(?=[A-Z])")
    private val BOLUNEBILIR = Regex("([\"(¿¡-]*)([a-z]{5,})('(?:t|s|re|ll|m|ve|d))?([^a-z']*)")
    // Baştaki harf: I (doğrusu), l ya da L (OCR'ın I yerine okuduğu hâller).
    // Kayıttan: "Iwonder", "Imay", "labsolve", "(Lpity".
    private val BASTAKI_I = Regex("([\"(-]*)[IlL]([a-z]{3,})([^a-z]*)")

    /**
     * Sözlük hunspell'in KÖK listesi: türemiş biçimler içinde yok.
     * "remarkable", "reasonable", "understandable" sözlükte bulunmuyor; önlem
     * almazsak bölücü bunları "remark able" diye parçalıyor (kullanıcının
     * kaydındaki "You have remarkable Skills." satırında tam bu oldu).
     * Bilinen bir ek atılınca geriye sözlükteki bir kök kalıyorsa kelime gerçektir.
     */
    private val EKLER = listOf(
        "ability", "ibility", "ableness", "able", "ible", "ably", "ibly",
        "fulness", "ness", "ments", "ment", "lessly", "less", "fully", "ful",
        "ships", "ship", "hood", "ward", "wise", "like", "ings", "ing",
        "ers", "est", "ies", "ied", "ier", "ly", "ish", "ism", "ist", "ity",
        "tion", "sion", "ance", "ence", "ive", "ous", "al", "ed", "es", "er", "s",
    )

    /**
     * Sözlükte olmayan ama ÖN EKLİ gerçek kelimeler: "incredible", "unhelpful".
     * Bölücü bunları "in credible" diye ayırıyordu. Ön ekten sonra kalan parça
     * UZUN olmalı (5+ harf): yoksa "inthe" -> "in the" ayırması da engellenirdi.
     */
    private val ONEKLER = listOf(
        "un", "in", "im", "ir", "il", "dis", "re", "pre", "non", "mis",
        "over", "under", "sub", "anti", "inter", "trans", "semi", "super", "multi",
    )

    private fun onekliMi(w: String): Boolean {
        for (on in ONEKLER) {
            if (!w.startsWith(on)) continue
            val kalan = w.substring(on.length)
            if (kalan.length >= 5 && Sozluk.icinde(kalan)) return true
        }
        return false
    }

    /** Kelime, sözlükteki bir kökün türemiş hâli mi? */
    fun turevMi(w: String): Boolean {
        if (!Sozluk.hazir) return false
        if (onekliMi(w)) return true
        for (ek in EKLER) {
            if (!w.endsWith(ek)) continue
            val govde = w.dropLast(ek.length)
            if (govde.length < 3) continue
            if (Sozluk.icinde(govde)) return true
            if (Sozluk.icinde(govde + "e")) return true                       // movable -> move
            if (govde.length >= 2 && govde.last() == govde[govde.length - 2] &&
                Sozluk.icinde(govde.dropLast(1))) return true                 // running -> run
            if (govde.endsWith("i") && Sozluk.icinde(govde.dropLast(1) + "y")) return true  // happily -> happy
        }
        return false
    }

    /**
     * OCR'ın boşluk kaçırdığı yerleri açar:
     * "Yo,is" -> "Yo, is" · "Iwonder" -> "I wonder" · "topickup" -> "to pick up".
     */
    fun bitisikleriAyir(metin: String): String {
        var t = NOKTALAMA_BOSLUK.replace(metin, "$1 ")
        t = CUMLE_BOSLUK.replace(t, "$1 ")
        if (!Sozluk.hazir) return t
        // küçük->Büyük geçişi ("thispointI"); McDonald, iPhone gibi bilinenler hariç
        t = t.split(" ").joinToString(" ") { p ->
            if (IZINLI_BASLIK.containsMatchIn(p)) p else KUCUK_BUYUK.replace(p, " ")
        }
        return t.split(" ").joinToString(" ") { parca -> parcayiAyir(parca) }
    }

    private fun parcayiAyir(parca: String): String {
        // 1) Baştaki I kelimeye yapışmış ya da l okunmuş:
        //    "Iwonder" -> "I wonder", "Imay" -> "I may", "labsolve" -> "I absolve".
        //    Bölmeden ÖNCE deneniyor; yoksa "labsolve" sözlükte karşılığı olan
        //    "lab solve" diye bölünüyordu.
        val m2 = BASTAKI_I.matchEntire(parca)
        if (m2 != null) {
            val kalan = m2.groupValues[2]
            // Kalan TAM bir kelime olmalı ve bütünü sözlükte OLMAMALI:
            // "Ireland", "Iron", "lover", "land" böylece bozulmaz.
            // "Iran", "Ivy", "Italy" gibi gerçek adlar bölünmesin: BÜTÜN kelimeye bakılır.
            if (!Sozluk.icinde("i$kalan") && !Sozluk.icinde("l$kalan") &&
                Sozluk.icinde(kalan) && "i$kalan".lowercase() !in I_ADLARI
            ) {
                return m2.groupValues[1] + "I " + kalan + m2.groupValues[3]
            }
        }
        // 2) Bitişik yazılmış kelimeleri sözlükle böl.
        val m = BOLUNEBILIR.matchEntire(parca) ?: return parca
        val govde = m.groupValues[2]
        val ek = m.groupValues[3]
        if (Sozluk.icinde(govde + ek) || Sozluk.icinde(govde)) return parca
        if (turevMi(govde)) return parca                       // "remarkable" bölünmesin
        if (adaylar(govde).any { Sozluk.icinde(it) }) return parca  // harf karışmış: harfleriDuzelt halleder
        val bolunmus = bol(govde) ?: return parca
        return m.groupValues[1] + bolunmus.joinToString(" ") + ek + m.groupValues[4]
    }

    /**
     * Satırın ne kadarı gerçek İngilizce? Sözlük geldiği için artık ölçebiliyoruz.
     *
     * Kullanıcının kaydından, çevrilmemesi gereken satır:
     *   "Years go by, and a man's nerve justain'twhat it used to be...
     *    Now all LCàndo Refollo M hehindwomand he Carefu"
     * Yarısından fazlası sözlükte yoksa bu OCR çöpüdür; çevirmek yerine
     * temiz okumayı beklemek daha iyi.
     */
    fun cokBozuk(metin: String): Boolean {
        if (!Sozluk.hazir) return false
        var toplam = 0
        var bilinen = 0
        for (ham in metin.split(Regex("[^\\p{L}'’]+"))) {
            val w = ham.substringBefore('\'').substringBefore('’')
            if (w.length < 4) continue
            if (w.any { it.code > 127 }) continue      // Türkçe/aksanlı: İngilizce sayma
            toplam++
            if (Sozluk.icinde(w) || turevMi(w.lowercase())) bilinen++
        }
        // Az kelimeli satırlarda oran güvenilmez; en az 4 kelime arıyoruz.
        return toplam >= 4 && bilinen * 2 < toplam
    }

    private val THCY = Regex("\\b([Tt])hcy\\b")
    private val THC = Regex("\\b([Tt])hc\\b")
    private val BOSLUK = Regex("\\s+")

    /** Tüm onarım: ayırma -> harf düzeltme -> sık hatalar. Sözlük yoksa metne dokunmaz. */
    fun onar(ham: String): String {
        if (ham.isBlank()) return ham
        var t = BOSLUK.replace(ham, " ").trim()
        t = bitisikleriAyir(t)
        t = harfleriDuzelt(t)
        t = THCY.replace(t, "$1hey")
        t = THC.replace(t, "$1he")
        return BOSLUK.replace(t, " ").trim()
    }
}
