package com.example.altyazi

/**
 * YAPAY ZEKÂ DENETİMİ
 *
 * Kullanıcının 6 Kasım kaydı gösterdi ki yapay zekâ taslağı düzelttiği kadar
 * bozuyor da. Kayıttan, taslak DOĞRUYKEN yapay zekânın bozduğu satırlar:
 *
 *   "Tapınaktaki heykel"            -> "Tapu'daki Heykel"
 *   "Kanlı cehennem"                -> "Helikopter"
 *   "Hunter ve suikastçıları"       -> "Avcı ve cinayetleri"      (ismi çevirdi)
 *   "Tapınakçılara sattığınız ..."  -> "Satılan haritalar"        (yarısını attı)
 *   "Kim orada?"                    -> "Kim çıktı orada?"
 *
 * Üstelik her satırda yapay zekâ çalıştırmak 1,5-3,7 sn gecikme ve ekranda
 * yanıp sönme demek. Bu dosya iki iş yapıyor:
 *
 *   1. [yzGerekli]  Taslak sağlamsa yapay zekâyı HİÇ çağırma.
 *   2. [onayla]     Yapay zekâ cevabı taslaktan kötüyse reddet, taslak kalsın.
 *
 * İkisi de mekanik; "daha güzel mi" diye karar vermiyor, sadece ölçülebilir
 * bozulmaları yakalıyor.
 */
object AiGuard {

    /**
     * Çevrilmemesi gereken adlar. NameFix listesi Türkçe anlamı olan isimleri
     * kapsıyor; burası oyun/dizi evrenine ait, çeviride İngilizce kalması
     * gereken özel adlar. Küçük harfle tutuluyor.
     */
    private val ADLAR: Set<String> = setOf(
        // Assassin's Creed (kullanıcının kaydındaki oyun)
        "jackdaw", "kenway", "edward", "laurens", "prins", "havana", "tortuga",
        "nassau", "kingston", "breddah", "mentor", "abstergo", "paris", "madrid",
        // Bilerek YOK: "Ben", "Anne", "Jack", "Mary" gibi kısa adlar.
        // "anne" ve "ben" Türkçede gerçek kelime; ad listesine girerlerse
        // çeviri denetimi boş yere sonuç reddediyor.
    )

    /**
     * Türkçe karşılığı OLAN terimler: ya İngilizcesi ya Türkçesi cevapta bulunmalı.
     * "Templars" -> "Tapınakçılar" doğru çeviridir, reddedilmemeli; ama cevaptan
     * tamamen düşmesi ("Satılan haritalar") içerik kaybıdır, reddedilmeli.
     * Değerler GÖVDE: Türkçe ekler ("Tapınakçılara") eklenebilsin diye.
     */
    private val TERIMLER: Map<String, String> = mapOf(
        "templar" to "tapınakçı", "templars" to "tapınakçı",
        "assassin" to "suikastçı", "assassins" to "suikastçı",
        "observatory" to "gözlemev",
        "jamaica" to "jamaik", "london" to "londra", "lisbon" to "lizbon",
        "seville" to "sevilla", "boston" to "boston",
    )

    /** Bir kelime çevrilmemesi gereken ad mı? */
    fun adMi(kelime: String): Boolean {
        val k = kelime.trim().trim('.', ',', '!', '?', ':', ';', '"', '\'', '’', '(', ')')
            .lowercase()
        if (k.isEmpty()) return false
        if (k in ADLAR) return true
        // NameFix'in koruduğu adlar (Sage, Hope, Rose, Hunter...) da ad sayılır.
        return NameFix.korunanAdlar.any { it.equals(k, ignoreCase = true) }
    }

    private fun kelimeler(s: String): List<String> =
        s.split(Regex("[^\\p{L}\\p{N}'’]+")).filter { it.isNotBlank() }

    // ------------------------------------------------------------- 1) kapı

    /**
     * Yapay zekâ bu satır için gerçekten gerekli mi?
     *
     * Kayıttaki veriye göre yapay zekânın kazandığı yerler UZUN ve karmaşık
     * cümleler; kaybettiği yerler kısa, taslağın zaten doğru olduğu satırlar.
     * Kural buna göre:
     *
     *   - taslak yoksa / başarısızsa            -> gerekli
     *   - taslakta çevrilmemiş İngilizce kaldıysa -> gerekli ("Chattel'i yapacak")
     *   - kaynak uzunsa (9+ kelime)             -> gerekli
     *   - başka her durumda                     -> GEREKSİZ, taslak kalsın
     */
    fun yzGerekli(kaynak: String, taslak: String?): Boolean {
        if (taslak.isNullOrBlank()) return true
        if (taslak.trim().equals(kaynak.trim(), ignoreCase = true)) return true
        if (kalanIngilizce(kaynak, taslak) != null) return true
        return kelimeler(kaynak).size >= 9
    }

    /**
     * Taslakta çevrilmeden kalmış İngilizce kelime var mı?
     *
     * Sözlük gerekmiyor: kaynakta AYNEN geçen, 4+ harfli, ad olmayan bir kelime
     * çeviride de duruyorsa o kelime çevrilememiş demektir.
     */
    fun kalanIngilizce(kaynak: String, ceviri: String): String? {
        val kaynakKelimeler = kelimeler(kaynak).map { it.lowercase() }.toSet()
        for (ham in kelimeler(ceviri)) {
            // Türkçe ek kesme işaretiyle yapışıyor: "Chattel'i" -> gövde "Chattel".
            val k = ham.substringBefore('\'').substringBefore('’')
            if (k.length < 4) continue
            if (adMi(k)) continue
            if (k.lowercase() in TERIMLER) continue
            // Türkçe harf taşıyorsa Türkçe kelimedir.
            if (k.any { it in "çğıöşüÇĞİÖŞÜ" }) continue
            if (k.lowercase() in kaynakKelimeler) return k
        }
        return null
    }

    // --------------------------------------------------------- 2) denetim

    /** Reddedilme sebebi; null dönerse cevap kabul edilir. */
    fun redSebebi(kaynak: String, taslak: String?, yz: String): String? {
        val y = yz.trim()
        if (y.isBlank()) return "boş"

        // a) Hiç çevirmemiş: İngilizcenin aynısını geri vermiş.
        if (y.equals(kaynak.trim(), ignoreCase = true)) return "çevrilmemiş"

        // b) Kaynaktaki ad/terim cevapta yok: "Hunter" -> "Avcı", düşen "Templars".
        val yKucuk = y.lowercase()
        for (k in kelimeler(kaynak)) {
            if (k.length < 3) continue
            val kk = k.lowercase()
            val turkce = TERIMLER[kk]
            if (turkce != null) {
                // İngilizcesi de Türkçesi de yoksa terim düşmüş demektir.
                if (!yKucuk.contains(kk) && !yKucuk.contains(turkce)) return "terim düştü: $k"
                continue
            }
            if (!adMi(k)) continue
            if (!yKucuk.contains(kk)) return "ad düştü: $k"
        }

        // c) Sayılar düşmüş: "5 gemi" -> "gemiler".
        //
        // YALNIZCA iki basamaklı ve üstü, tek başına duran sayılar aranıyor.
        // Kullanıcının kaydında tek basamaklılar yüzünden DOĞRU çeviriler
        // reddedildi: OCR "I remember" yerine "1 remember", "good" yerine
        // "g0od" okumuştu; yapay zekâ bu çöpü haklı olarak atınca
        // "sayı düştü: 1" / "sayı düştü: 0" diye cevabı çöpe atıyorduk.
        val sayilar = Regex("(?<![\\p{L}\\d])\\d{2,}(?![\\p{L}\\d])").findAll(kaynak)
            .map { it.value }.toList()
        for (s in sayilar) if (!y.contains(s)) return "sayı düştü: $s"

        // d) Taslağa göre belirgin kısalma: cümlenin yarısı atılmış.
        //    "Tapınakçılara sattığınız haritalar onları doğrudan bize yönlendirdi"
        //    -> "Satılan haritalar onları doğrudan bize getirdi"
        if (taslak != null) {
            val ts = kelimeler(taslak).size
            val ys = kelimeler(y).size
            if (ts >= 5 && ys < ts * 0.6) return "içerik düştü ($ys/$ts kelime)"
        }

        return null
    }

    /**
     * Yapay zekâ cevabını onaylar. Kabul edilirse düzeltilmiş hâlini,
     * reddedilirse null döner (o zaman taslak ekranda kalır).
     */
    fun onayla(kaynak: String, taslak: String?, yz: String?): String? {
        if (yz.isNullOrBlank()) return null
        // Adları geri koy: yapay zekâ "Hunter"ı "Avcı" yaptıysa burada düzelir.
        val duzgun = NameFix.koru(kaynak, yz.trim())
        return if (redSebebi(kaynak, taslak, duzgun) == null) duzgun else null
    }
}
