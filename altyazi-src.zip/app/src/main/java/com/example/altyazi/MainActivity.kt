package com.example.altyazi

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.EditText
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val TURLER = listOf("Oyun", "Dizi", "Film", "Belgesel", "Video")

    /** Yazı boyutu çubuğunun başladığı değer; çubuk 0'dan saydığı için gerekli. */
    private val SUB_SIZE_MIN = 12

    private lateinit var prefs: Prefs

    private lateinit var etGame: EditText
    private lateinit var spType: Spinner
    private lateinit var etKey: EditText
    private lateinit var etGeminiKey: EditText
    private lateinit var rgProvider: RadioGroup
    private lateinit var etModel: EditText
    private lateinit var rgMode: RadioGroup
    private lateinit var cbSpeaker: CheckBox
    private lateinit var cbDiag: CheckBox
    private lateinit var cbMenu: CheckBox
    private lateinit var sbTop: SeekBar
    private lateinit var sbBottom: SeekBar
    private lateinit var sbSpeed: SeekBar
    private lateinit var tvRegion: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvError: TextView
    private lateinit var tvModels: TextView
    private lateinit var boxAdvanced: android.widget.LinearLayout
    private lateinit var tvAdvancedHeader: TextView
    private lateinit var btnToggle: Button
    private lateinit var tvCheck: TextView

    // Altyazı görünümü
    private lateinit var sbSubSize: SeekBar
    private lateinit var tvSubSize: TextView
    private lateinit var cgSubColor: ChipGroup
    private lateinit var cgSubBg: ChipGroup
    private lateinit var cgSubBgColor: ChipGroup
    private lateinit var tvPreview: TextView
    private lateinit var rgSubPos: RadioGroup
    private lateinit var cbOutline: CheckBox

    private lateinit var projectionLauncher: ActivityResultLauncher<Intent>

    /** Telefondaki yapay zekâ modeli kartı (indir / dosyadan seç). */
    private var modelSetup: ModelSetup? = null
    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) modelSetup?.copyFrom(uri)
    }

    /** Arayüz kurulduysa true. Kurulamadıysa güvenli ekrandayız. */
    private var uiReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
            uiReady = true
        } catch (e: Throwable) {
            CrashLog.note(this, "acilis ekrani", e)
            showSafeScreen()
        }
    }

    /** Arayüz kurulamazsa uygulama kapanmasın; hatayı ekranda göster. */
    private fun showSafeScreen() {
        val info = TextView(this).apply {
            setPadding(40, 60, 40, 40)
            textSize = 13f
            text = "Uygulama açılırken bir sorun çıktı.\n\n" +
                (CrashLog.read(this@MainActivity) ?: "Ayrıntı kaydedilemedi.") +
                "\n\nBu yazıyı kopyalayıp sohbete yapıştırın."
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(info) }
        setContentView(scroll)
    }

    private fun buildUi() {
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)

        etGame = findViewById(R.id.etGame)
        spType = findViewById(R.id.spType)
        spType.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, TURLER
        )
        spType.setSelection(TURLER.indexOf(prefs.contentType).coerceAtLeast(0))
        etKey = findViewById(R.id.etKey)
        etGeminiKey = findViewById(R.id.etGeminiKey)
        rgProvider = findViewById(R.id.rgProvider)
        etModel = findViewById(R.id.etModel)
        rgMode = findViewById(R.id.rgMode)
        cbSpeaker = findViewById(R.id.cbSpeaker)
        cbDiag = findViewById(R.id.cbDiag)
        cbMenu = findViewById(R.id.cbMenu)
        sbTop = findViewById(R.id.sbTop)
        sbBottom = findViewById(R.id.sbBottom)
        sbSpeed = findViewById(R.id.sbSpeed)
        tvRegion = findViewById(R.id.tvRegion)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvStatus = findViewById(R.id.tvStatus)
        try {
            val card = tvStatus.parent as android.widget.LinearLayout
            modelSetup = ModelSetup(this) { pickModel.launch(arrayOf("*/*")) }.also {
                it.attach(card, card.indexOfChild(tvStatus) + 1)
            }
        } catch (e: Throwable) {
            CrashLog.note(this, "model karti", e)
        }
        findViewById<TextView>(R.id.tvVersion).text =
            "sürüm " + (packageManager.getPackageInfo(packageName, 0).versionName ?: "?")

        etGame.setText(prefs.gameName)
        etKey.setText(prefs.apiKey)
        etGeminiKey.setText(prefs.geminiKey)
        findViewById<RadioButton>(
            if (prefs.provider == Prefs.PROVIDER_ANTHROPIC) R.id.rbAnthropic else R.id.rbGemini
        ).isChecked = true
        // Kutuda, seçili sağlayıcının modeli görünsün.
        etModel.setText(
            if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel else prefs.model
        )
        findViewById<RadioButton>(
            when (prefs.mode) {
                Prefs.MODE_AI -> R.id.rbAi
                Prefs.MODE_HYBRID -> R.id.rbHybrid
                else -> R.id.rbInstant
            }
        ).isChecked = true
        cbSpeaker.isChecked = prefs.showSpeaker
        cbDiag.isChecked = prefs.diagnostics
        cbMenu.isChecked = prefs.menuTranslate
        sbTop.progress = prefs.topPct
        sbBottom.progress = prefs.bottomPct
        sbSpeed.progress = (prefs.intervalMs - 100).coerceIn(0, 900)
        updateRegionLabel()
        updateSpeedLabel()

        val regionListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateRegionLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        sbTop.setOnSeekBarChangeListener(regionListener)
        sbBottom.setOnSeekBarChangeListener(regionListener)

        sbSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateSpeedLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // ------------------------------------------- altyazı görünümü
        sbSubSize = findViewById(R.id.sbSubSize)
        tvSubSize = findViewById(R.id.tvSubSize)
        cgSubColor = findViewById(R.id.cgSubColor)
        cgSubBg = findViewById(R.id.cgSubBg)
        cgSubBgColor = findViewById(R.id.cgSubBgColor)
        tvPreview = findViewById(R.id.tvPreview)
        rgSubPos = findViewById(R.id.rgSubPos)
        cbOutline = findViewById(R.id.cbOutline)

        sbSubSize.progress = (prefs.subtitleSize - SUB_SIZE_MIN).coerceIn(0, sbSubSize.max)
        updateSubSizeLabel()
        sbSubSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) =
                updateSubSizeLabel()

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Chip>(
            when (prefs.subtitleColor) {
                Prefs.COLOR_YELLOW -> R.id.chColYellow
                Prefs.COLOR_GREEN -> R.id.chColGreen
                Prefs.COLOR_CYAN -> R.id.chColCyan
                else -> R.id.chColWhite
            }
        ).isChecked = true

        findViewById<Chip>(
            when (prefs.subtitleBg) {
                Prefs.BG_SOLID -> R.id.chBgSolid
                Prefs.BG_NONE -> R.id.chBgNone
                else -> R.id.chBgSemi
            }
        ).isChecked = true

        findViewById<Chip>(
            when (prefs.subtitleBgColor) {
                Prefs.BGC_GRAY -> R.id.chBgcGray
                Prefs.BGC_NAVY -> R.id.chBgcNavy
                else -> R.id.chBgcBlack
            }
        ).isChecked = true

        // Ayar her değiştiğinde önizleme de değişsin.
        val onizlemeDinleyici = ChipGroup.OnCheckedStateChangeListener { _, _ ->
            onizlemeyiGuncelle()
        }
        cgSubColor.setOnCheckedStateChangeListener(onizlemeDinleyici)
        cgSubBg.setOnCheckedStateChangeListener(onizlemeDinleyici)
        cgSubBgColor.setOnCheckedStateChangeListener(onizlemeDinleyici)

        findViewById<RadioButton>(
            when (prefs.subtitlePos) {
                Prefs.POS_COVER -> R.id.rbPosCover
                Prefs.POS_BOTTOM -> R.id.rbPosBottom
                else -> R.id.rbPosAbove
            }
        ).isChecked = true

        cbOutline.isChecked = prefs.subtitleOutline
        cbOutline.setOnCheckedChangeListener { _, _ -> onizlemeyiGuncelle() }
        onizlemeyiGuncelle()

        projectionLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
                showRunning(true)
                moveTaskToBack(true)
            } else {
                tvStatus.text = "Ekran yakalama izni verilmedi."
            }
        }

        tvError = findViewById(R.id.tvError)
        tvModels = findViewById(R.id.tvModels)
        boxAdvanced = findViewById(R.id.boxAdvanced)
        tvAdvancedHeader = findViewById(R.id.tvAdvancedHeader)
        btnToggle = findViewById(R.id.btnToggle)
        tvCheck = findViewById(R.id.tvCheck)
        findViewById<Button>(R.id.btnCheck).setOnClickListener { runSetupCheck() }
        findViewById<Button>(R.id.btnRegion).setOnClickListener {
            startActivity(Intent(this, RegionActivity::class.java))
        }

        tvAdvancedHeader.setOnClickListener {
            val open = boxAdvanced.visibility == View.VISIBLE
            boxAdvanced.visibility = if (open) View.GONE else View.VISIBLE
            tvAdvancedHeader.text = if (open) "Gelişmiş ▸" else "Gelişmiş ▾"
        }

        findViewById<Button>(R.id.btnFindModels).setOnClickListener { findModels() }
        findViewById<Button>(R.id.btnCopyError).setOnClickListener { copyError() }
        findViewById<Button>(R.id.btnCopyLog).setOnClickListener { copyLog() }

        btnToggle.setOnClickListener {
            save()
            if (CaptureService.running) {
                startService(
                    Intent(this, CaptureService::class.java)
                        .setAction(CaptureService.ACTION_STOP)
                )
                showRunning(false)
            } else {
                start()
            }
        }

        showRunning(CaptureService.running)
    }

    /**
     * Kurulum kontrolü: üç şeyi sırayla dener ve sonucu yazar.
     * Amaç, sorunun oyun sırasında değil burada ortaya çıkması.
     */
    private fun runSetupCheck() {
        save()
        tvCheck.text = "Kontrol ediliyor…"
        val prefsLocal = prefs

        Thread {
            val report = StringBuilder()

            // 1) Ekran üstüne çizme izni
            report.append(
                if (Settings.canDrawOverlays(this)) "✓ Ekran üstüne çizme izni var\n"
                else "✗ Ekran üstüne çizme izni yok — BAŞLAT'a basınca isteyecek\n"
            )

            // 2) Telefon içi Türkçe model
            val fastEngine = FastTranslate()
            val fastOk = kotlinx.coroutines.runBlocking {
                fastEngine.prepare() && !fastEngine.translate("Hello there").isNullOrBlank()
            }
            report.append(
                if (fastOk) "✓ İnternetsiz Türkçe model hazır\n"
                else "✗ İnternetsiz model inmedi (" + (fastEngine.lastError ?: "sebep yok") + ")\n"
            )
            fastEngine.close()

            // 3) Yapay zekâ çevirisi
            if (prefsLocal.activeKey.isBlank()) {
                report.append("• API anahtarı girilmemiş — yapay zekâ modu çalışmaz\n")
            } else {
                val engine = AiTranslate(prefsLocal)
                var result = kotlinx.coroutines.runBlocking { engine.translate("He is waiting outside.") }
                if (result.isNullOrBlank()) {
                    // Model adı sorunluysa hesaptaki gerçek modeli seç ve tekrar dene.
                    val best = engine.pickBest(engine.fetchModels(prefsLocal.activeKey))
                    if (best != null) {
                        if (prefsLocal.provider == Prefs.PROVIDER_GEMINI) prefsLocal.geminiModel = best
                        else prefsLocal.model = best
                        result = kotlinx.coroutines.runBlocking { engine.translate("He is waiting outside.") }
                    }
                }
                report.append(
                    if (!result.isNullOrBlank()) "✓ Yapay zekâ çevirisi çalışıyor (" + (if (prefsLocal.provider == Prefs.PROVIDER_GEMINI) prefsLocal.geminiModel else prefsLocal.model) + ")\n"
                    else "✗ Yapay zekâ çevirisi başarısız: " + (engine.lastError ?: "bilinmeyen") + "\n"
                )
            }

            runOnUiThread {
                tvCheck.text = report.toString().trim()
                etModel.setText(if (prefsLocal.provider == Prefs.PROVIDER_GEMINI) prefsLocal.geminiModel else prefsLocal.model)
            }
        }.start()
    }

    /** Yanlışlıkla yapıştırılan metinlerin anahtar sanılmasını engeller. */
    private fun cleanKey(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        // Birden fazla kelime veya Türkçe karakter varsa bu bir anahtar değildir.
        if (t.contains(" ") || t.any { it.code < 33 || it.code > 126 }) return ""
        return t
    }

    private fun secModel(ad: String) {
        if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel = ad else prefs.model = ad
        etModel.setText(ad)
    }

    /** Bulunan modelleri listeler; istediğinizi seçebilirsiniz. */
    private fun modelListesiniGoster(models: List<String>) {
        if (models.isEmpty()) return
        val dizi = models.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Model seçin")
            .setItems(dizi) { _, hangi -> secModel(dizi[hangi]) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showRunning(running: Boolean) {
        btnToggle.text = if (running) "DURDUR" else "BAŞLAT"
        tvStatus.text = if (running) {
            "Çalışıyor · Chiaki'yi açıp oyuna girebilirsiniz"
        } else {
            "Durduruldu"
        }
    }

    override fun onResume() {
        super.onResume()
        if (!uiReady) return
        try {
            showRunning(CaptureService.running)
            modelSetup?.onResume()
            tvModels.text = AiTranslate.summary()
            showError()
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        super.onPause()
        if (!uiReady) return
        modelSetup?.onPause()
        try {
            save()
        } catch (_: Throwable) {
        }
    }

    /** Hesaptaki gerçek model adlarını bulur ve en hızlısını seçer. */
    private fun findModels() {
        save()
        val key = prefs.activeKey
        if (key.isBlank()) {
            tvModels.text = if (prefs.provider == Prefs.PROVIDER_GEMINI)
                "Google AI Studio anahtarı girilmemiş ya da hatalı. Kutuyu temizleyip " +
                    "AIza ile başlayan anahtarı yapıştırın."
            else "Anthropic API anahtarı girilmemiş ya da hatalı."
            return
        }
        tvModels.text = "Modeller aranıyor..."
        Thread {
            val engine = AiTranslate(prefs)
            val models = engine.fetchModels(key)
            val best = engine.pickBest(models)
            runOnUiThread {
                if (models.isEmpty()) {
                    tvModels.text = "Model listesi alınamadı: " + (engine.lastError ?: "bilinmeyen hata")
                    return@runOnUiThread
                }
                if (best != null) {
                    secModel(best)
                }
                modelListesiniGoster(models)
                tvModels.text = "Seçilen: " + (best ?: "-") +
                    "\n\nHesabınızdaki modeller:\n" + models.joinToString("\n")
            }
        }.start()
    }

    private fun showError() {
        val text = CrashLog.read(this)
        if (text.isNullOrBlank()) {
            tvError.text = "Kayıtlı hata yok."
        } else {
            tvError.text = text
        }
    }

    /** Çalışma kaydı: ekrandan ne okundu, ne çevrildi, hata var mı. */
    private fun copyLog() {
        val text = AiTranslate.summary() + "\n\n" + CaptureService.dumpLog()
        tvError.text = text
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Lingo kaydı", text))
        Toast.makeText(this, "Çalışma kaydı kopyalandı, sohbete yapıştırın.", Toast.LENGTH_LONG).show()
    }

    private fun copyError() {
        val text = CrashLog.read(this)
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Kayıtlı hata yok.", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Lingo hata", text))
        Toast.makeText(this, "Hata kopyalandı, sohbete yapıştırabilirsiniz.", Toast.LENGTH_LONG).show()
    }

    private fun updateRegionLabel() {
        tvRegion.text = "Altyazının bulunduğu bölge: ekranın %${sbTop.progress} – %${sbBottom.progress} arası"
    }

    private fun updateSubSizeLabel() {
        tvSubSize.text = "Yazı boyutu: ${sbSubSize.progress + SUB_SIZE_MIN}"
        onizlemeyiGuncelle()
    }

    /**
     * Önizleme kutusunu seçili ayarlara göre boyar.
     * Renkleri servisle aynı yerden (SubtitleStyle) okuyor; böylece burada
     * gördüğünüz şey oyunda göreceğinizin aynısı oluyor.
     */
    private fun onizlemeyiGuncelle() {
        if (!::tvPreview.isInitialized) return

        val renkSecim = when (cgSubColor.checkedChipId) {
            R.id.chColYellow -> Prefs.COLOR_YELLOW
            R.id.chColGreen -> Prefs.COLOR_GREEN
            R.id.chColCyan -> Prefs.COLOR_CYAN
            else -> Prefs.COLOR_WHITE
        }
        val arkaSecim = when (cgSubBg.checkedChipId) {
            R.id.chBgSolid -> Prefs.BG_SOLID
            R.id.chBgNone -> Prefs.BG_NONE
            else -> Prefs.BG_SEMI
        }
        val arkaRenkSecim = when (cgSubBgColor.checkedChipId) {
            R.id.chBgcGray -> Prefs.BGC_GRAY
            R.id.chBgcNavy -> Prefs.BGC_NAVY
            else -> Prefs.BGC_BLACK
        }

        val alfa = SubtitleStyle.arkaAlfa(arkaSecim)
        val arka = SubtitleStyle.arkaRenk(arkaRenkSecim)

        tvPreview.setTextSize(
            android.util.TypedValue.COMPLEX_UNIT_SP,
            (sbSubSize.progress + SUB_SIZE_MIN).toFloat()
        )
        tvPreview.setTextColor(SubtitleStyle.yaziRengi(renkSecim))

        if (cbOutline.isChecked || alfa == 0) {
            tvPreview.setShadowLayer(7f, 0f, 2f, android.graphics.Color.BLACK)
        } else {
            tvPreview.setShadowLayer(0f, 0f, 0f, android.graphics.Color.TRANSPARENT)
        }

        val yogunluk = resources.displayMetrics.density
        tvPreview.setPadding(
            (10 * yogunluk).toInt(), (5 * yogunluk).toInt(),
            (10 * yogunluk).toInt(), (5 * yogunluk).toInt()
        )
        tvPreview.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 12 * yogunluk
            setColor(
                android.graphics.Color.argb(
                    alfa,
                    android.graphics.Color.red(arka),
                    android.graphics.Color.green(arka),
                    android.graphics.Color.blue(arka),
                )
            )
        }
    }

    private fun updateSpeedLabel() {
        tvSpeed.text = "Her ${sbSpeed.progress + 100} ms'de bir tara (küçük = daha hızlı tepki, daha çok pil)"
    }

    private fun save() {
        prefs.gameName = etGame.text.toString()
        prefs.contentType = TURLER.getOrElse(spType.selectedItemPosition) { "Oyun" }
        prefs.apiKey = cleanKey(etKey.text.toString())
        prefs.geminiKey = cleanKey(etGeminiKey.text.toString())
        prefs.provider = if (rgProvider.checkedRadioButtonId == R.id.rbAnthropic)
            Prefs.PROVIDER_ANTHROPIC else Prefs.PROVIDER_GEMINI
        // Model kutusu hangi sağlayıcı seçiliyse ONUN alanına yazılmalı.
        // Önceden hep prefs.model'e (Anthropic alanı) yazıyordu; bu yüzden
        // Gemini seçiliyken model elle hiç değiştirilemiyordu ve MODELLERİ
        // BUL ile doğru ad bulunsa bile uygulamaya geçmiyordu.
        val secilenModel = etModel.text.toString().trim()
        if (secilenModel.isNotEmpty()) {
            if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel = secilenModel
            else prefs.model = secilenModel
        }
        AiTranslate.devreyiAc()

        // Altyazı görünümü
        prefs.subtitleSize = sbSubSize.progress + SUB_SIZE_MIN
        prefs.subtitleColor = when (cgSubColor.checkedChipId) {
            R.id.chColYellow -> Prefs.COLOR_YELLOW
            R.id.chColGreen -> Prefs.COLOR_GREEN
            R.id.chColCyan -> Prefs.COLOR_CYAN
            else -> Prefs.COLOR_WHITE
        }
        prefs.subtitleBg = when (cgSubBg.checkedChipId) {
            R.id.chBgSolid -> Prefs.BG_SOLID
            R.id.chBgNone -> Prefs.BG_NONE
            else -> Prefs.BG_SEMI
        }
        prefs.subtitleBgColor = when (cgSubBgColor.checkedChipId) {
            R.id.chBgcGray -> Prefs.BGC_GRAY
            R.id.chBgcNavy -> Prefs.BGC_NAVY
            else -> Prefs.BGC_BLACK
        }
        prefs.subtitlePos = when (rgSubPos.checkedRadioButtonId) {
            R.id.rbPosCover -> Prefs.POS_COVER
            R.id.rbPosBottom -> Prefs.POS_BOTTOM
            else -> Prefs.POS_ABOVE
        }
        prefs.subtitleOutline = cbOutline.isChecked
        prefs.mode = when (rgMode.checkedRadioButtonId) {
            R.id.rbAi -> Prefs.MODE_AI
            R.id.rbHybrid -> Prefs.MODE_HYBRID
            else -> Prefs.MODE_INSTANT
        }
        prefs.showSpeaker = cbSpeaker.isChecked
        prefs.diagnostics = cbDiag.isChecked
        prefs.menuTranslate = cbMenu.isChecked
        prefs.intervalMs = sbSpeed.progress + 100

        var top = sbTop.progress
        var bottom = sbBottom.progress
        if (bottom <= top) {
            bottom = (top + 10).coerceAtMost(100)
            sbBottom.progress = bottom
        }
        if (top >= bottom) {
            top = (bottom - 10).coerceAtLeast(0)
            sbTop.progress = top
        }
        prefs.topPct = top
        prefs.bottomPct = bottom
    }

    private fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            tvStatus.text = "Bildirim iznini verin, sonra tekrar BAŞLAT deyin."
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce 'diğer uygulamaların üzerinde göster' iznini verin.", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            tvStatus.text = "İzni verdikten sonra geri gelip tekrar BAŞLAT deyin."
            return
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
