package com.example.altyazi

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Telefonun İÇİNDE çalışan yapay zekâ çevirisi (Gemma 4 E2B, LiteRT-LM).
 * İnternet, anahtar, jeton yok. Model bir kez indirilir (~2,6 GB).
 *
 * Model uygulama açık kaldığı sürece BİR KEZ yüklenir ve bellekte kalır:
 * Durdur/Başlat yapınca 30 sn yeniden yükleme beklenmez, iki kopya da açılmaz.
 */
class LlmTranslate(context: Context) {

    private val ctx: Context = context.applicationContext

    val ready: Boolean get() = shared.ready
    val lastError: String? get() = shared.lastError
    val backendName: String get() = shared.backendName

    fun hasModel(): Boolean = hasModel(ctx)

    /** Modeli yükler (ilk seferde ~10-30 sn). Önce GPU, olmazsa CPU. Zaten yüklüyse hemen döner. */
    suspend fun prepare(): Boolean = withContext(Dispatchers.IO) {
        shared.lock.withLock {
            if (shared.ready) return@withLock true
            if (!hasModel()) {
                shared.lastError = "model dosyası yok"
                return@withLock false
            }
            val backends: List<Backend> = listOf(Backend.GPU(), Backend.CPU())
            for (b in backends) {
                val name = if (b is Backend.GPU) "GPU" else "CPU"
                try {
                    val e = Engine(
                        EngineConfig(
                            modelPath = modelFile(ctx).absolutePath,
                            backend = b,
                            cacheDir = ctx.cacheDir.path
                        )
                    )
                    e.initialize()
                    shared.engine = e
                    shared.backendName = name
                    shared.ready = true
                    shared.lastError = null
                    return@withLock true
                } catch (t: Throwable) {
                    shared.lastError = "$name: ${t.message ?: t.javaClass.simpleName}"
                }
            }
            false
        }
    }

    /**
     * Bir satırı çevirir. [stillWanted] sıra gelince tekrar sorulur; replik
     * çoktan geçtiyse boşuna çalışılmaz. [contentType] ve [title] ana ekrandaki
     * "Ne izliyorsunuz" alanlarıdır (ör. "Oyun", "Batman").
     */
    suspend fun translate(
        line: String,
        previous: List<String>,
        contentType: String,
        title: String,
        stillWanted: () -> Boolean
    ): String? = withContext(Dispatchers.IO) {
        shared.lock.withLock {
            shared.lastError = null
            val e = shared.engine ?: return@withLock null
            if (!stillWanted()) return@withLock null
            try {
                val conv = e.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(SYSTEM),
                        samplerConfig = SamplerConfig(topK = 1, topP = 1.0, temperature = 0.0)
                    )
                )
                val out = try {
                    conv.sendMessage(
                        buildPrompt(line, previous, contentType, title),
                        maxOutputToken = 160
                    ).toString()
                } finally {
                    try { conv.close() } catch (_: Throwable) {}
                }
                clean(out, line)
            } catch (t: Throwable) {
                shared.lastError = t.message ?: t.javaClass.simpleName
                null
            }
        }
    }

    /**
     * Servis durunca modeli KAPATMIYORUZ: bir sonraki Başlat'ta beklemesiz
     * kullanılsın. Android bellek isterse uygulamayı zaten kendisi kapatır.
     */
    fun close() {}

    private fun buildPrompt(line: String, previous: List<String>, contentType: String, title: String): String {
        val sb = StringBuilder()
        val kind = when (contentType.trim().lowercase()) {
            "oyun" -> "a video game"
            "dizi" -> "a TV series"
            "film" -> "a film"
            "belgesel" -> "a documentary"
            else -> "a video"
        }
        sb.append("Source: ").append(kind)
        if (title.isNotBlank()) sb.append(" titled \"").append(title.trim()).append('"')
        sb.append(".\n\n")
        if (previous.isNotEmpty()) {
            sb.append("Previous subtitle lines (context only, do NOT translate):\n")
            for (p in previous.takeLast(3)) sb.append("- ").append(p).append('\n')
            sb.append('\n')
        }
        sb.append("Translate this subtitle line:\n").append(line)
        return sb.toString()
    }

    /** Modelin cevabından sadece çeviriyi bırakır; saçma cevapsa null. */
    private fun clean(raw: String, source: String): String? {
        var t = raw.trim()
        t = t.removePrefix("```").removeSuffix("```").trim()
        t = t.replace(Regex("^(Türkçe|Turkish|Çeviri|Translation)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        t = t.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ")
        if (t.length >= 2 && t.first() == '"' && t.last() == '"' && !source.trim().startsWith("\"")) {
            t = t.substring(1, t.length - 1).trim()
        }
        if (t.isEmpty()) return null
        if (t.length > source.length * 3 + 40) return null   // açıklama yazmaya başlamış
        return t
    }

    /** Uygulama boyunca tek motor. */
    private class Shared {
        val lock = Mutex()
        @Volatile var engine: Engine? = null
        @Volatile var ready = false
        @Volatile var lastError: String? = null
        @Volatile var backendName = ""
    }

    companion object {
        private val shared = Shared()

        const val MODEL_FILE = "gemma-4-E2B-it.litertlm"
        const val MODEL_URL =
            "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/" +
                "7fa1d78473894f7e736a21d920c3aa80f950c0db/gemma-4-E2B-it.litertlm?download=true"
        const val MODEL_BYTES = 2_583_085_056L

        fun modelFile(context: Context): File =
            File(context.getExternalFilesDir(null) ?: context.filesDir, MODEL_FILE)

        fun hasModel(context: Context): Boolean =
            modelFile(context).let { it.exists() && it.length() >= MODEL_BYTES * 95 / 100 }

        private const val SYSTEM =
            "You are a professional subtitle translator for video games, TV series and films. " +
                "Translate the given English subtitle line into natural, spoken, everyday Turkish, " +
                "the way a Turkish dubbing studio would. " +
                "Rules: keep the meaning and tone, not the literal words; translate slang and idioms " +
                "by meaning; keep profanity and insults as strong Turkish equivalents (do not soften); " +
                "keep character names, nicknames, place names and brand names unchanged - a capitalized " +
                "word used as a name or nickname stays in English even if it is a normal English word " +
                "(for example 'Matches', 'Hope', 'Ghost'); keep text in square brackets as a short " +
                "Turkish sound description; keep the line short like a subtitle. " +
                "Output ONLY the Turkish translation, with no quotes, notes or explanations."
    }
}
