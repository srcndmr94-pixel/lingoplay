package com.example.altyazi

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.ExperimentalApi
import com.google.ai.edge.litertlm.ExperimentalFlags
import com.google.ai.edge.litertlm.ModelInfo
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/** İndirilebilir model: dosya adı, adres, boyut, ekranda görünen ad. */
class ModelSpec(val file: String, val url: String, val bytes: Long, val label: String)

/**
 * Telefonun İÇİNDE çalışan yapay zekâ çevirisi (Gemma 4 E2B, LiteRT-LM).
 * İnternet, anahtar, jeton yok. Model bir kez indirilir (~2,6 GB).
 *
 * Model uygulama açık kaldığı sürece BİR KEZ yüklenir ve bellekte kalır:
 * Durdur/Başlat yapınca 30 sn yeniden yükleme beklenmez, iki kopya da açılmaz.
 */
class LlmTranslate(context: Context) {

    private val ctx: Context = context.applicationContext

    val ready: Boolean get() = shared.ready
    val lastError: String? get() = shared.lastError
    val backendName: String get() = shared.backendName

    fun hasModel(): Boolean = hasModel(ctx)

    /** Modeli yükler (ilk seferde ~10-30 sn). Önce GPU, olmazsa CPU. Zaten yüklüyse hemen döner. */
    @OptIn(ExperimentalApi::class)
    @Suppress("DEPRECATION")
    suspend fun prepare(): Boolean = withContext(Dispatchers.IO) {
        shared.lock.withLock {
            val wanted = modelFile(ctx).absolutePath
            if (shared.ready && shared.loadedPath == wanted) return@withLock true
            // Daha iyi model sonradan indiyse eskisini kapatıp yenisini yükle.
            if (shared.engine != null) {
                try { shared.engine?.close() } catch (_: Throwable) {}
                shared.engine = null
                shared.ready = false
            }
            if (!hasModel()) {
                shared.lastError = "model dosyası yok"
                return@withLock false
            }
            // Hızlandırma (çoklu kelime tahmini, MTP): model dosyası destekliyorsa GPU'da açılır.
            val mtp = try {
                ModelInfo.from(wanted).use { (it as? ModelInfo.Llm)?.hasSpeculativeDecodingSupport() == true }
            } catch (_: Throwable) {
                false
            }
            // GPU+MTP, GPU, CPU sırasıyla denenir; ilk çalışan kullanılır.
            val attempts: List<Pair<Backend, Boolean>> =
                (if (mtp) listOf<Pair<Backend, Boolean>>(Backend.GPU() to true) else emptyList()) +
                    listOf(Backend.GPU() to false, Backend.CPU() to false)
            for ((b, fast) in attempts) {
                val name = (if (b is Backend.GPU) "GPU" else "CPU") + (if (fast) " · hızlı" else "")
                ExperimentalFlags.enableSpeculativeDecoding = fast
                try {
                    val e = Engine(
                        EngineConfig(
                            modelPath = wanted,
                            backend = b,
                            cacheDir = ctx.cacheDir.path
                        )
                    )
                    e.initialize()
                    shared.engine = e
                    shared.backendName = name + " · " + (if (modelFile(ctx).name == E4B.file) "E4B" else "E2B")
                    shared.ready = true
                    shared.loadedPath = wanted
                    shared.lastError = null
                    return@withLock true
                } catch (t: Throwable) {
                    shared.lastError = "$name: ${t.message ?: t.javaClass.simpleName}"
                } finally {
                    ExperimentalFlags.enableSpeculativeDecoding = false
                }
            }
            false
        }
    }

    /**
     * Bir satırı çevirir. [stillWanted] sıra gelince tekrar sorulur; replik
     * çoktan geçtiyse boşuna çalışılmaz. [contentType] ve [title] ana ekrandaki
     * "Ne izliyorsunuz" alanlarıdır (ör. "Oyun", "Batman").
     */
    suspend fun translate(
        line: String,
        previous: List<String>,
        contentType: String,
        title: String,
        stillWanted: () -> Boolean
    ): String? = withContext(Dispatchers.IO) {
        val asked = System.currentTimeMillis()
        shared.lock.withLock {
            shared.lastError = null
            lastWaitMs = System.currentTimeMillis() - asked
            val e = shared.engine ?: return@withLock null
            if (!stillWanted()) return@withLock null
            try {
                val conv = e.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(SYSTEM),
                        samplerConfig = SamplerConfig(topK = 1, topP = 1.0, temperature = 0.0)
                    )
                )
                shared.current = conv
                shared.currentLine = line
                val out = try {
                    conv.sendMessage(
                        buildPrompt(line, previous, contentType, title),
                        maxOutputToken = 160
                    ).toString()
                } finally {
                    shared.current = null
                    shared.currentLine = null
                    try { conv.close() } catch (_: Throwable) {}
                }
                if (!stillWanted()) return@withLock null   // yarıda kesildiyse yarım cevabı gösterme
                clean(out, line)
            } catch (t: Throwable) {
                // Altyazı değişince bilerek kestiğimiz çeviri hata sayılmaz.
                val msg = t.message ?: t.javaClass.simpleName
                if (!msg.contains("CANCELLED", ignoreCase = true)) shared.lastError = msg
                null
            }
        }
    }

    /** Son çeviride sırada beklenen süre (ms). */
    @Volatile var lastWaitMs = 0L
        private set

    /**
     * Şu an BAŞKA bir satır çevriliyorsa onu yarıda keser: yapay zekâ hep ekrandaki
     * satırla uğraşsın, eski satırların arkasında sıra beklemesin.
     */
    fun cancelOthers(line: String) {
        val cur = shared.currentLine ?: return
        if (cur == line) return
        try { shared.current?.cancelProcess() } catch (_: Throwable) {}
    }

    /**
     * Servis durunca modeli KAPATMIYORUZ: bir sonraki Başlat'ta beklemesiz
     * kullanılsın. Android bellek isterse uygulamayı zaten kendisi kapatır.
     */
    fun close() {}

    private fun buildPrompt(line: String, previous: List<String>, contentType: String, title: String): String {
        val sb = StringBuilder()
        val kind = when (contentType.trim().lowercase()) {
            "oyun" -> "a video game"
            "dizi" -> "a TV series"
            "film" -> "a film"
            "belgesel" -> "a documentary"
            else -> "a video"
        }
        sb.append("Source: ").append(kind)
        if (title.isNotBlank()) sb.append(" titled \"").append(title.trim()).append('"')
        sb.append(".\n\n")
        if (previous.isNotEmpty()) {
            sb.append("Previous subtitle lines (context only, do NOT translate):\n")
            for (p in previous.takeLast(3)) sb.append("- ").append(p).append('\n')
            sb.append("If the new line continues a sentence from the previous line, translate only the new part " +
                "so that both read naturally together.\n\n")
        }
        val hints = Slang.hintsFor(line)
        if (hints.isNotEmpty()) {
            sb.append("Slang meanings in this line (use these meanings):\n")
            for (h in hints) sb.append("- ").append(h).append('\n')
            sb.append('\n')
        }
        sb.append("Translate this subtitle line:\n").append(line)
        return sb.toString()
    }

    /** Modelin cevabından sadece çeviriyi bırakır; saçma cevapsa null. */
    private fun clean(raw: String, source: String): String? {
        var t = raw.trim()
        t = t.removePrefix("```").removeSuffix("```").trim()
        t = t.replace(Regex("^(Türkçe|Turkish|Çeviri|Translation)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        t = t.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ")
        if (t.length >= 2 && t.first() == '"' && t.last() == '"' && !source.trim().startsWith("\"")) {
            t = t.substring(1, t.length - 1).trim()
        }
        // Kaynakta köşeli parantez yoksa model kendiliğinden eklememeli: "[Bu kokuyor!]" -> "Bu kokuyor!"
        if (!source.contains('[') && t.startsWith("[") && t.endsWith("]")) t = t.substring(1, t.length - 1).trim()
        if (t.isEmpty()) return null
        if (t.length > source.length * 3 + 40) return null   // açıklama yazmaya başlamış
        return t
    }

    /** Uygulama boyunca tek motor. */
    private class Shared {
        val lock = Mutex()
        @Volatile var engine: Engine? = null
        @Volatile var ready = false
        @Volatile var lastError: String? = null
        @Volatile var backendName = ""
        @Volatile var loadedPath = ""
        @Volatile var current: Conversation? = null
        @Volatile var currentLine: String? = null
    }

    companion object {
        private val shared = Shared()

        /** Yükleme servisten BAĞIMSIZ: Durdur'a basılsa da yarıda kesilmez. */
        private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        @Volatile private var loadJob: Job? = null

        /** Ana ekranda gösterilen yükleme durumu. */
        @Volatile var loadState: String = ""
            private set

        fun isLoading(): Boolean = loadJob?.isActive == true

        fun isReady(context: Context): Boolean =
            shared.ready && shared.loadedPath == modelFile(context).absolutePath

        /** Model telefondaysa arka planda belleğe yükler (zaten yüklüyse/yükleniyorsa bir şey yapmaz). */
        fun preload(context: Context) {
            val c = context.applicationContext
            if (!hasModel(c) || isReady(c) || isLoading()) return
            loadJob = appScope.launch {
                loadState = "yükleniyor"
                val t0 = System.currentTimeMillis()
                val ok = try {
                    LlmTranslate(c).prepare()
                } catch (e: Throwable) {
                    shared.lastError = e.message ?: e.javaClass.simpleName
                    false
                }
                val sec = (System.currentTimeMillis() - t0) / 1000
                loadState = if (ok) "hazır (${shared.backendName}, $sec sn)" else "hata: ${shared.lastError}"
            }
        }


        /** Büyük model: argo ve bağlamı daha iyi anlar, ~2 kat yavaş. 12 GB+ bellek. */
        val E4B = ModelSpec(
            "gemma-4-E4B-it.litertlm",
            "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm/resolve/" +
                "28299f30ee4d43294517a4ac93abd6163412f07f/gemma-4-E4B-it.litertlm?download=true",
            3_659_530_240L, "Gelişmiş (E4B, 3,7 GB)"
        )

        /** Küçük model: hızlı ama argoyu daha az bilir. */
        val E2B = ModelSpec(
            "gemma-4-E2B-it.litertlm",
            "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/" +
                "7fa1d78473894f7e736a21d920c3aa80f950c0db/gemma-4-E2B-it.litertlm?download=true",
            2_583_085_056L, "Hızlı (E2B, 2,6 GB)"
        )

        val MODELS = listOf(E4B, E2B)

        private fun dir(context: Context): File = context.getExternalFilesDir(null) ?: context.filesDir

        fun fileOf(context: Context, m: ModelSpec): File = File(dir(context), m.file)

        fun isComplete(context: Context, m: ModelSpec): Boolean =
            fileOf(context, m).let { it.exists() && it.length() >= m.bytes * 95 / 100 }

        private fun prefs(context: Context) =
            context.applicationContext.getSharedPreferences("model_indirme", Context.MODE_PRIVATE)

        /** Kullanıcının seçtiği model ("E4B" ya da "E2B"); seçmediyse gelişmiş olan. */
        fun preferred(context: Context): ModelSpec =
            if (prefs(context).getString("tercih", "E4B") == "E2B") E2B else E4B

        fun setPreferred(context: Context, m: ModelSpec) {
            prefs(context).edit().putString("tercih", if (m === E2B) "E2B" else "E4B").apply()
        }

        /** Kullanılacak model: tercih edilen telefondaysa o, değilse telefondaki diğeri. */
        fun active(context: Context): ModelSpec? {
            val p = preferred(context)
            if (isComplete(context, p)) return p
            return MODELS.firstOrNull { isComplete(context, it) }
        }

        fun modelFile(context: Context): File = fileOf(context, active(context) ?: E2B)

        fun hasModel(context: Context): Boolean = MODELS.any { isComplete(context, it) }

        /** Seçilen dosyanın boyutuna göre hangi model olduğunu bulur. */
        fun guessModel(sizeBytes: Long): ModelSpec? =
            MODELS.firstOrNull { sizeBytes in (it.bytes * 95 / 100)..(it.bytes * 105 / 100) }

        private const val SYSTEM =
            "You are a professional subtitle translator for video games, TV series and films. " +
                "Translate the given English subtitle line into natural, spoken, everyday Turkish, " +
                "the way a Turkish dubbing studio would. " +
                "Rules: keep the meaning and tone, not the literal words; translate slang and idioms " +
                "by meaning; keep profanity and insults as strong Turkish equivalents (do not soften); " +
                "keep character names, nicknames, place names and brand names unchanged - a capitalized " +
                "word used as a name or nickname stays in English even if it is a normal English word " +
                "(for example 'Matches', 'Hope', 'Ghost'), but DO translate titles and ranks in front of names " +
                "(Commissioner -> Komiser, Detective -> Dedektif, Officer -> Memur, Sergeant -> Çavuş, Mr. -> Bay, " +
                "Mrs. -> Bayan, Doctor -> Doktor, Captain -> Kaptan/Yüzbaşı); keep text in square brackets as a short " +
                "Turkish sound description; keep the line short like a subtitle. " +
                "Output ONLY the Turkish translation, with no quotes, notes or explanations."
    }
}
