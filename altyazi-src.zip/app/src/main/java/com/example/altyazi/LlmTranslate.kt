package com.example.altyazi

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Telefonun İÇİNDE çalışan yapay zekâ çevirisi (Gemma 4 E2B, LiteRT-LM).
 * İnternet, anahtar, jeton yok. Model bir kez indirilir (~2,6 GB).
 * ML Kit'ten yavaştır (satır başına ~1-3 sn) ama cümleyi anlayarak çevirir;
 * bu yüzden önce ML Kit anında yazar, sonra bu sınıf düzgün çeviriyi üstüne yazar.
 */
class LlmTranslate(private val context: Context) {

    @Volatile var ready = false
        private set
    @Volatile var lastError: String? = null
        private set
    @Volatile var backendName = ""
        private set

    private var engine: Engine? = null
    private val lock = Mutex()

    val modelFile: File get() = modelFile(context)

    fun hasModel(): Boolean = hasModel(context)

    /** Modeli yükler (ilk seferde ~10 sn). Önce GPU, olmazsa CPU. */
    suspend fun prepare(): Boolean = withContext(Dispatchers.IO) {
        lock.withLock {
            if (ready) return@withLock true
            if (!hasModel()) {
                lastError = "model dosyası yok"
                return@withLock false
            }
            val backends: List<Backend> = listOf(Backend.GPU(), Backend.CPU())
            for (b in backends) {
                try {
                    val e = Engine(
                        EngineConfig(
                            modelPath = modelFile.absolutePath,
                            backend = b,
                            cacheDir = context.cacheDir.path
                        )
                    )
                    e.initialize()
                    engine = e
                    backendName = if (b is Backend.GPU) "GPU" else "CPU"
                    ready = true
                    lastError = null
                    return@withLock true
                } catch (t: Throwable) {
                    lastError = "${b.name}: ${t.message ?: t.javaClass.simpleName}"
                }
            }
            false
        }
    }

    /**
     * Bir satırı çevirir. [stillWanted] sıra gelince tekrar sorulur; replik
     * çoktan geçtiyse boşuna çalışılmaz.
     */
    suspend fun translate(
        line: String,
        previous: List<String>,
        stillWanted: () -> Boolean
    ): String? = withContext(Dispatchers.IO) {
        lock.withLock {
            lastError = null
            val e = engine ?: return@withLock null
            if (!stillWanted()) return@withLock null
            try {
                val conv = e.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(SYSTEM),
                        samplerConfig = SamplerConfig(topK = 1, topP = 1.0, temperature = 0.0)
                    )
                )
                val out = try {
                    conv.sendMessage(buildPrompt(line, previous), maxOutputToken = 160).toString()
                } finally {
                    try { conv.close() } catch (_: Throwable) {}
                }
                clean(out, line)
            } catch (t: Throwable) {
                lastError = t.message ?: t.javaClass.simpleName
                null
            }
        }
    }

    /** Çalışan bir çeviri varsa onun bitmesini bekleyip kapatır (yerel çökme olmasın). */
    fun close() {
        ready = false
        Thread {
            kotlinx.coroutines.runBlocking {
                lock.withLock {
                    try { engine?.close() } catch (_: Throwable) {}
                    engine = null
                }
            }
        }.start()
    }

    private fun buildPrompt(line: String, previous: List<String>): String {
        val sb = StringBuilder()
        if (previous.isNotEmpty()) {
            sb.append("Previous subtitle lines (context only, do NOT translate):\n")
            for (p in previous.takeLast(3)) sb.append("- ").append(p).append('\n')
            sb.append('\n')
        }
        sb.append("Translate this subtitle line:\n").append(line)
        return sb.toString()
    }

    /** Modelin cevabından sadece çeviriyi bırakır; saçma cevapsa null. */
    private fun clean(raw: String, source: String): String? {
        var t = raw.trim()
        t = t.removePrefix("```").removeSuffix("```").trim()
        t = t.replace(Regex("^(Türkçe|Turkish|Çeviri|Translation)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        t = t.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ")
        if (t.length >= 2 && t.first() == '"' && t.last() == '"' && !source.trim().startsWith("\"")) {
            t = t.substring(1, t.length - 1).trim()
        }
        if (t.isEmpty()) return null
        if (t.length > source.length * 3 + 40) return null   // açıklama yazmaya başlamış
        return t
    }

    companion object {
        const val MODEL_FILE = "gemma-4-E2B-it.litertlm"
        const val MODEL_URL =
            "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/" +
                "7fa1d78473894f7e736a21d920c3aa80f950c0db/gemma-4-E2B-it.litertlm?download=true"
        const val MODEL_BYTES = 2_583_085_056L

        fun modelFile(context: Context): File =
            File(context.getExternalFilesDir(null) ?: context.filesDir, MODEL_FILE)

        fun hasModel(context: Context): Boolean =
            modelFile(context).let { it.exists() && it.length() >= MODEL_BYTES * 95 / 100 }

        private const val SYSTEM =
            "You are a professional subtitle translator for video games, TV series and films. " +
                "Translate the given English subtitle line into natural, spoken, everyday Turkish, " +
                "the way a Turkish dubbing studio would. " +
                "Rules: keep the meaning and tone, not the literal words; translate slang and idioms " +
                "by meaning; keep profanity and insults as strong Turkish equivalents (do not soften); " +
                "keep character names, place names and brand names unchanged; keep text in square " +
                "brackets as a short Turkish sound description; keep the line short like a subtitle. " +
                "Output ONLY the Turkish translation, with no quotes, notes or explanations."
    }
}
