package com.example.altyazi

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Ana ekrandaki "Gelişmiş çevrim dışı çeviri" kartı.
 * - Gelişmiş modeli (E4B, 3,7 GB) indirir; inene kadar standart model (E2B) çalışır.
 * - Telefondaki .litertlm dosyasını kopyalar (boyutundan hangi model olduğunu anlar).
 * - Gelişmiş model inince eski küçük modeli silip yer açmayı önerir.
 */
class ModelSetup(
    private val activity: AppCompatActivity,
    private val pickFile: () -> Unit
) {
    private val ctx: Context = activity.applicationContext
    private val sp = ctx.getSharedPreferences("model_indirme", Context.MODE_PRIVATE)
    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var tvState: TextView
    private lateinit var btnDownload: Button
    private lateinit var btnPick: Button
    private lateinit var btnDeleteSmall: Button
    @Volatile private var copying: String? = null

    private val target = LlmTranslate.E4B   // indirilen model hep gelişmiş olan

    /** Kartı [parent] içine, [index] sırasına ekler. */
    fun attach(parent: LinearLayout, index: Int) {
        val pad = (12 * ctx.resources.displayMetrics.density).toInt()
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, pad, 0, pad)
        }
        box.addView(TextView(activity).apply {
            text = "Gelişmiş çevrim dışı çeviri (telefondaki yapay zekâ)"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(activity).apply {
            text = "Satır önce anında çevrilir, ardından telefondaki yapay zekâ anlamlı " +
                "çevirisini üstüne yazar. İnternet ve anahtar gerekmez. " +
                "Gelişmiş model argoyu ve bağlamı daha iyi anlar ama biraz daha yavaştır."
            textSize = 13f
        })
        tvState = TextView(activity).apply { textSize = 13f; setPadding(0, pad / 2, 0, pad / 2) }
        box.addView(tvState)
        btnDownload = Button(activity).apply {
            text = "GELİŞMİŞ MODELİ İNDİR (Wi-Fi, 3,7 GB)"
            setOnClickListener { startDownload() }
        }
        box.addView(btnDownload)
        btnPick = Button(activity).apply {
            text = "İNDİRİLMİŞ DOSYAYI SEÇ (.litertlm)"
            setOnClickListener { pickFile() }
        }
        box.addView(btnPick)
        btnDeleteSmall = Button(activity).apply {
            text = "ESKİ KÜÇÜK MODELİ SİL (2,6 GB boşalt)"
            setOnClickListener {
                LlmTranslate.fileOf(ctx, LlmTranslate.E2B).delete()
                refresh()
            }
        }
        box.addView(btnDeleteSmall)
        parent.addView(box, index.coerceIn(0, parent.childCount))
        refresh()
    }

    fun onResume() = refresh()

    fun onPause() = main.removeCallbacksAndMessages(null)

    private fun partFile(): File = File(LlmTranslate.fileOf(ctx, target).parentFile, target.file + ".part")

    private fun startDownload() {
        LlmTranslate.fileOf(ctx, target).parentFile?.mkdirs()
        partFile().delete()
        try {
            val req = DownloadManager.Request(Uri.parse(target.url))
                .setTitle("Lingo çeviri modeli")
                .setDescription("Gemma 4 E4B · 3,7 GB")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setAllowedOverMetered(false)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalFilesDir(ctx, null, target.file + ".part")
            sp.edit().putLong("id", dm.enqueue(req)).apply()
        } catch (e: Throwable) {
            tvState.text = "İndirme başlatılamadı: ${e.message}"
            return
        }
        refresh()
    }

    /** Dosya seçiciden gelen dosyayı uygulamanın klasörüne kopyalar. */
    fun copyFrom(uri: Uri) {
        if (copying != null) return
        copying = "başlıyor"
        refresh()
        scope.launch {
            val result: String? = withContext(Dispatchers.IO) {
                try {
                    val dir = LlmTranslate.fileOf(ctx, target).parentFile!!
                    dir.mkdirs()
                    val tmp = File(dir, "secilen.litertlm.copy")
                    ctx.contentResolver.openInputStream(uri)!!.use { input ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var total = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                total += n
                                copying = "${total / (1024 * 1024)} MB"
                            }
                        }
                    }
                    val m = LlmTranslate.guessModel(tmp.length())
                    if (m == null) {
                        tmp.delete()
                        null
                    } else {
                        val dest = LlmTranslate.fileOf(ctx, m)
                        dest.delete()
                        if (tmp.renameTo(dest)) m.label else null
                    }
                } catch (e: Throwable) {
                    CrashLog.note(ctx, "model kopyalama", e)
                    null
                }
            }
            copying = null
            tvState.text = if (result != null) "✓ $result hazır. BAŞLAT'a basın." else
                "✗ Dosya tanınmadı ya da eksik. gemma-4-E4B-it.litertlm veya gemma-4-E2B-it.litertlm seçin."
            refresh(keepText = true)
        }
    }

    private fun refresh(keepText: Boolean = false) {
        main.removeCallbacksAndMessages(null)
        if (!::tvState.isInitialized) return
        val finalFile = LlmTranslate.fileOf(ctx, target)
        val part = partFile()

        copying?.let {
            tvState.text = "Kopyalanıyor… $it"
            btnDownload.isEnabled = false; btnPick.isEnabled = false
            main.postDelayed({ refresh() }, 1000)
            return
        }

        val id = sp.getLong("id", -1L)
        if (id != -1L) {
            var status = -1
            var done = 0L
            var reason = 0
            try {
                dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) {
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    }
                }
            } catch (_: Throwable) {
            }
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    sp.edit().remove("id").apply()
                    if (part.exists() && part.length() >= target.bytes * 95 / 100) {
                        finalFile.delete(); part.renameTo(finalFile)
                    }
                }
                DownloadManager.STATUS_FAILED -> {
                    sp.edit().remove("id").apply()
                    part.delete()
                    tvState.text = "✗ İndirme başarısız (kod $reason). Wi-Fi'yi kontrol edip tekrar deneyin " +
                        "ya da dosyayı Chrome ile indirip 'DOSYAYI SEÇ' ile gösterin."
                    btnDownload.isEnabled = true; btnPick.isEnabled = true
                    btnDeleteSmall.visibility = android.view.View.GONE
                    return
                }
                DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PAUSED -> {
                    val pct = done * 100 / target.bytes
                    val mb = done / (1024 * 1024)
                    val totalMb = target.bytes / (1024 * 1024)
                    tvState.text = (if (status == DownloadManager.STATUS_PAUSED)
                        "Gelişmiş model indirme bekliyor (Wi-Fi bekleniyor) · %$pct ($mb MB)"
                    else "Gelişmiş model iniyor… %$pct ($mb MB / $totalMb MB)") +
                        (if (LlmTranslate.isComplete(ctx, LlmTranslate.E2B)) "\nBu sırada standart model çalışmaya devam eder." else "")
                    btnDownload.isEnabled = false; btnPick.isEnabled = false
                    btnDeleteSmall.visibility = android.view.View.GONE
                    main.postDelayed({ refresh() }, 1000)
                    return
                }
                else -> sp.edit().remove("id").apply()
            }
        }

        btnPick.isEnabled = true
        val hasBig = LlmTranslate.isComplete(ctx, LlmTranslate.E4B)
        val hasSmall = LlmTranslate.isComplete(ctx, LlmTranslate.E2B)
        btnDeleteSmall.visibility = if (hasBig && hasSmall) android.view.View.VISIBLE else android.view.View.GONE
        when {
            hasBig -> {
                tvState.text = "✓ Gelişmiş model (E4B) hazır. Çeviri başlarken otomatik kullanılır."
                btnDownload.isEnabled = false
                btnDownload.text = "GELİŞMİŞ MODEL YÜKLÜ"
            }
            hasSmall -> {
                if (!keepText) tvState.text = "✓ Standart model (E2B) hazır ve kullanılıyor.\n" +
                    "Argoyu daha iyi anlayan gelişmiş modeli indirebilirsiniz (3,7 GB, Wi-Fi)."
                btnDownload.isEnabled = true
                btnDownload.text = "GELİŞMİŞ MODELİ İNDİR (Wi-Fi, 3,7 GB)"
            }
            else -> {
                if (!keepText) tvState.text = "Model yok. İndirmek için Wi-Fi'ye bağlanın."
                btnDownload.isEnabled = true
                btnDownload.text = "GELİŞMİŞ MODELİ İNDİR (Wi-Fi, 3,7 GB)"
            }
        }
    }
}
