package com.example.altyazi

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Ana ekrandaki "Gelişmiş çevrim dışı çeviri" kartı:
 * modeli indirir (Wi-Fi, ~2,6 GB) ya da telefondaki dosyadan kopyalar.
 */
class ModelSetup(
    private val activity: AppCompatActivity,
    private val pickFile: () -> Unit
) {
    private val ctx: Context = activity.applicationContext
    private val sp = ctx.getSharedPreferences("model_indirme", Context.MODE_PRIVATE)
    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var tvState: TextView
    private lateinit var btnDownload: Button
    private lateinit var btnPick: Button
    @Volatile private var copying: String? = null

    /** Kartı [parent] içine, [index] sırasına ekler. */
    fun attach(parent: LinearLayout, index: Int) {
        val pad = (12 * ctx.resources.displayMetrics.density).toInt()
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, pad, 0, pad)
        }
        box.addView(TextView(activity).apply {
            text = "Gelişmiş çevrim dışı çeviri (telefondaki yapay zekâ)"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(activity).apply {
            text = "Satır önce anında çevrilir, 1-3 saniye sonra telefondaki yapay zekâ " +
                "anlamlı çevirisini üstüne yazar. İnternet ve anahtar gerekmez. " +
                "Model bir kez iner (2,6 GB)."
            textSize = 13f
        })
        tvState = TextView(activity).apply { textSize = 13f; setPadding(0, pad / 2, 0, pad / 2) }
        box.addView(tvState)
        btnDownload = Button(activity).apply {
            text = "MODELİ İNDİR (Wi-Fi, 2,6 GB)"
            setOnClickListener { startDownload() }
        }
        box.addView(btnDownload)
        btnPick = Button(activity).apply {
            text = "İNDİRİLMİŞ DOSYAYI SEÇ (.litertlm)"
            setOnClickListener { pickFile() }
        }
        box.addView(btnPick)
        parent.addView(box, index.coerceIn(0, parent.childCount))
        refresh()
    }

    fun onResume() = refresh()

    fun onPause() = main.removeCallbacksAndMessages(null)

    private fun startDownload() {
        val target = LlmTranslate.modelFile(ctx)
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, LlmTranslate.MODEL_FILE + ".part")
        part.delete()
        try {
            val req = DownloadManager.Request(Uri.parse(LlmTranslate.MODEL_URL))
                .setTitle("LingoPlay çeviri modeli")
                .setDescription("Gemma 4 E2B · 2,6 GB")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setAllowedOverMetered(false)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalFilesDir(ctx, null, LlmTranslate.MODEL_FILE + ".part")
            sp.edit().putLong("id", dm.enqueue(req)).apply()
        } catch (e: Throwable) {
            tvState.text = "İndirme başlatılamadı: ${e.message}"
            return
        }
        refresh()
    }

    /** Dosya seçiciden gelen dosyayı uygulamanın klasörüne kopyalar. */
    fun copyFrom(uri: Uri) {
        if (copying != null) return
        copying = "başlıyor"
        refresh()
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val target = LlmTranslate.modelFile(ctx)
                    target.parentFile?.mkdirs()
                    val tmp = File(target.parentFile, LlmTranslate.MODEL_FILE + ".copy")
                    ctx.contentResolver.openInputStream(uri)!!.use { input ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var total = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                total += n
                                copying = "%${total * 100 / LlmTranslate.MODEL_BYTES}"
                            }
                        }
                    }
                    if (tmp.length() < LlmTranslate.MODEL_BYTES * 95 / 100) {
                        tmp.delete()
                        false
                    } else {
                        target.delete()
                        tmp.renameTo(target)
                    }
                } catch (e: Throwable) {
                    CrashLog.note(ctx, "model kopyalama", e)
                    false
                }
            }
            copying = null
            tvState.text = if (ok) "✓ Model hazır. BAŞLAT'a basın." else
                "✗ Dosya kopyalanamadı ya da eksik. Doğru dosyayı (gemma-4-E2B-it.litertlm) seçin."
            refresh(keepText = !ok)
        }
    }

    private fun refresh(keepText: Boolean = false) {
        main.removeCallbacksAndMessages(null)
        if (!::tvState.isInitialized) return
        val target = LlmTranslate.modelFile(ctx)
        val part = File(target.parentFile, LlmTranslate.MODEL_FILE + ".part")

        copying?.let {
            tvState.text = "Kopyalanıyor… $it"
            btnDownload.isEnabled = false; btnPick.isEnabled = false
            main.postDelayed({ refresh() }, 1000)
            return
        }

        val id = sp.getLong("id", -1L)
        if (id != -1L) {
            var status = -1
            var done = 0L
            var reason = 0
            try {
                dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) {
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    }
                }
            } catch (_: Throwable) {
            }
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    sp.edit().remove("id").apply()
                    if (part.exists() && part.length() >= LlmTranslate.MODEL_BYTES * 95 / 100) {
                        target.delete(); part.renameTo(target)
                    }
                }
                DownloadManager.STATUS_FAILED -> {
                    sp.edit().remove("id").apply()
                    part.delete()
                    tvState.text = "✗ İndirme başarısız (kod $reason). Wi-Fi'yi kontrol edip tekrar deneyin " +
                        "ya da dosyayı Chrome ile indirip 'DOSYAYI SEÇ' ile gösterin."
                    btnDownload.isEnabled = true; btnPick.isEnabled = true
                    return
                }
                DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PAUSED -> {
                    val pct = done * 100 / LlmTranslate.MODEL_BYTES
                    val mb = done / (1024 * 1024)
                    tvState.text = if (status == DownloadManager.STATUS_PAUSED)
                        "İndirme bekliyor (Wi-Fi bekleniyor) · %$pct ($mb MB)"
                    else "İndiriliyor… %$pct ($mb MB / 2464 MB)"
                    btnDownload.isEnabled = false; btnPick.isEnabled = false
                    main.postDelayed({ refresh() }, 1000)
                    return
                }
                else -> sp.edit().remove("id").apply()
            }
        }

        btnPick.isEnabled = true
        if (LlmTranslate.hasModel(ctx)) {
            tvState.text = "✓ Model telefonda hazır (${target.length() / (1024 * 1024)} MB). " +
                "Çeviri başlarken otomatik kullanılır."
            btnDownload.isEnabled = false
            btnDownload.text = "MODEL YÜKLÜ"
        } else {
            if (!keepText) tvState.text = "Model yok. İndirmek için Wi-Fi'ye bağlanın."
            btnDownload.isEnabled = true
            btnDownload.text = "MODELİ İNDİR (Wi-Fi, 2,6 GB)"
        }
    }
}
