package com.example.altyazi

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.min

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.altyazi.START"
        const val ACTION_STOP = "com.example.altyazi.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "altyazi"
        private const val NOTIF_ID = 1001

        /** Ekran bu genişliğe kadar olduğu gibi yakalanır (altyazı net kalsın diye). */
        private const val TARGET_WIDTH = 1500
        /** TV kutuları (Xiaomi Box vb.) zayıf: daha küçük yakalama, video takılmasın. */
        private const val TARGET_WIDTH_TV = 1024
        /** TV'de taramalar arası en az bu kadar beklenir (ms). */
        private const val MIN_INTERVAL_TV = 300L
        /** Bu kadar süre yeni kare gelmezse ekrandaki çeviri kaldırılır (ms). */
        private const val STALE_MS = 4000L

        /** Menü taraması bu genişliğe küçültülerek yapılır; menü yazıları büyüktür. */
        private const val MENU_WIDTH = 1200

        /** Menü taraması kaç tarama turunda bir yapılsın. */
        private const val MENU_EVERY = 4

        private const val MAX_LABELS = 5

        /** Aynı anda en fazla kaç replik çevrilsin. */
        private const val MAX_PARALLEL = 3

        /** Menü taraması ekranın sadece bu kadar üst kısmında yapılır. */
        private const val MENU_ZONE = 0.5f

        /** Türkçeye özgü harfler: bu satır bizim kendi çevirimizdir, tekrar çevirme. */
        private const val TURKISH_ONLY = "ığşİĞŞ"

        /** Servis çalışıyor mu? Ana ekran tuşun yazısını buna göre belirler. */
        @Volatile
        var running = false

        /** Son işlemlerin kaydı; ana ekrandan kopyalanıp sorun teşhisinde kullanılır. */
        private val logLines = ArrayDeque<String>()

        @JvmStatic
        fun log(line: String) {
            synchronized(logLines) {
                logLines.addLast(line)
                while (logLines.size > 150) logLines.removeFirst()
            }
        }

        /** Bu oturumda çevrilen satırlar (en yenisi sonda): ana ekrandaki Geçmiş ve Son çevrilen. */
        private val history = ArrayDeque<Pair<String, String>>()

        fun history(): List<Pair<String, String>> = synchronized(history) { history.toList() }

        fun lastPair(): Pair<String, String>? = synchronized(history) { history.lastOrNull() }

        internal fun addHistory(source: String, value: String) {
            synchronized(history) {
                // Aynı repliğin düzeltilmiş hali eskisinin yerine geçer.
                if (history.lastOrNull()?.first == source) history.removeLast()
                history.addLast(source to value)
                while (history.size > 150) history.removeFirst()
            }
        }

        /** "Ne görüyor?" ekranı için son yakalanan görüntü (küçültülmüş). */
        @Volatile var lastPreview: Bitmap? = null

        fun dumpLog(): String = synchronized(logLines) {
            if (logLines.isEmpty()) "Kayıt yok. BAŞLAT'a basıp oyunda birkaç replik bekleyin."
            else logLines.joinToString("\n")
        }

        /**
         * Yalnızca Türkçede bulunan sık kelimeler. Satırda bunlardan biri
         * geçiyorsa metin zaten Türkçedir: çevirmeye kalkmak hem saçma bir
         * sonuç üretiyor hem sırayı işgal ediyordu ("6 Hareket Halinde",
         * "izlemeye devam edin" gibi arayüz yazıları kayda düşmüştü).
         */
        private val TURKCE_KELIMELER = setOf(
            "bir", "bu", "şu", "için", "ile", "çok", "daha", "var", "yok",
            "değil", "ama", "gibi", "kadar", "sonra", "önce", "şey", "evet",
            "hayır", "tamam", "devam", "edin", "halinde", "abone", "izlemeye",
            "ve", "veya", "ben", "sen", "biz", "siz", "onlar", "bizim",
            "senin", "benim", "nasıl", "neden", "nerede", "kim", "hangi",
            "oldu", "olur", "yapıyor", "geldi", "gitti", "dedi", "bilmiyorum",
        )

        /** Oyun arayüzü yazıları; altyazıyla karışmasınlar. */
        private val UI_WORDS = setOf(
            "TOUCHPAD", "OPTIONS", "SKIP", "CONTINUE", "LOADING", "AUTOSAVE",
            "OBJECTIVE", "NEW OBJECTIVE", "MISSION", "CHECKPOINT"
        )

        private val CONTROLLER_LABELS = setOf(
            "L1", "L2", "L3", "R1", "R2", "R3",
            "X", "O", "□", "△", "▲", "●", "■", "✕",
            "PS", "START", "SELECT", "TOUCH", "SKIP", "HOLD", "MAP", "MENU",
            "BACK", "NEXT", "OPTION", "PAUSE", "WAIT"
        )

        /**
         * Altyazı OLMAYAN, ama ekranda altyazı bölgesine düşebilen yazılar.
         * Bunlar çevrilirse hem jeton harcanır hem de gerçek replik sıra bekler.
         * Küçük harfe çevrilmiş metnin içinde aranır.
         */
        private val BLOCK_PHRASES = listOf(
            // Android'in ekran kaydı uyarısı (Prime, Netflix vb.)
            "güvenlik nedeniyle", "uygulama içerikleri", "gizlendi",
            "secure content", "content is hidden",
            // Oynatıcı arayüzü
            "dialogue boost", "x-ray", "xray", "ekran görüntüsü",
            "alt yazı", "alt yazi", "altyazılar", "subtitles",
            "audio and subtitles", "audio & subtitles",
            "skip intro", "skip recap", "next episode", "watch credits",
            "episodes", "bölümler", "ses artırma", "ayarlar ve",
        )

        /** Oyuncu kadrosu listesinde sık geçmeyen, cümleye özgü kelimeler. */
        private val SENTENCE_WORDS = setOf(
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "i", "you", "he", "she", "we", "they", "it", "me", "him", "her",
            "my", "your", "his", "our", "their", "this", "that", "these",
            "to", "of", "in", "on", "at", "for", "with", "from", "by",
            "and", "or", "but", "if", "so", "not", "no", "yes",
            "do", "does", "did", "don't", "can", "can't", "will", "won't",
            "have", "has", "had", "get", "got", "go", "come", "know", "think",
            "what", "why", "how", "when", "where", "who",
        )
    }

    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var readerThread: HandlerThread? = null
    private var readerHandler: Handler? = null

    private lateinit var prefs: Prefs
    private lateinit var overlay: Overlay
    private var fast: FastTranslate? = null
    private var llm: LlmTranslate? = null
    @Volatile private var llmLatest = ""
    private val recentLines = ArrayDeque<String>()
    private var ai: AiTranslate? = null
    private var store: TranslationStore? = null
    private var storeAi: TranslationStore? = null

    // var: DURDUR'da kapatılıyor; servis yok edilmeden hemen yeniden BAŞLAT denirse yenisi açılır.
    private var recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    @Volatile private var recognizerClosed = false

    private var captureWidth = 0
    private var captureHeight = 0
    private var displayCreated = false

    private var screenWidth = 0
    private var screenHeight = 0

    /** Her karede yeni görüntü ayırmak telefonu yoruyor; aynı tamponu kullanıyoruz. */
    private var frameBitmap: Bitmap? = null

    /** Altyazı şeridinin önceki karedeki parmak izi; değişmeyen kare okunmaz. */
    private var bandImza: IntArray? = null
    private var imzaPiksel: IntArray? = null

    // --- altyazı durumu ---
    @Volatile private var shownSource = ""
    private var candidate = ""
    private var candidateSeen = 0
    @Volatile private var translatingFor = ""

    /** Aynı anda sürmekte olan çeviriler. Yeni replik eskisini iptal etmez. */
    private val inFlight = java.util.Collections.synchronizedSet(HashSet<String>())
    private val startedAt = java.util.concurrent.ConcurrentHashMap<String, Long>()
    @Volatile private var lastOcrRaw = ""
    private var emptyFrames = 0
    private var everShown = false
    private var noTextWarned = false
    /** Android TV'nin kendisinde mi çalışıyoruz (GameLingo TV)? */
    private val isTv: Boolean by lazy { TvMode.isTvDevice(this) }

    private var lastPreviewMs = 0L

    /** Yakalanan ekranın küçük kopyası; okunan altyazı bölgesi turkuaz çerçeveyle işaretli. */
    private fun onizlemeKaydet(full: Bitmap, left: Int, top: Int, right: Int, bottom: Int) {
        try {
            if (full.isRecycled || full.width <= 0) return
            val w = 640
            val h = (full.height * w / full.width).coerceAtLeast(1)
            val k = w.toFloat() / full.width
            val prev = Bitmap.createScaledBitmap(full, w, h, true).copy(Bitmap.Config.ARGB_8888, true)
            val c = android.graphics.Canvas(prev)
            val p = android.graphics.Paint().apply {
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = 3f
                color = android.graphics.Color.rgb(46, 230, 214)
            }
            c.drawRect(left * k, top * k, right * k, bottom * k, p)
            lastPreview = prev
        } catch (_: Throwable) {
        }
    }

    private var subtitleAnchorPx = 0
    private var subtitleBottomPx = -1

    // "İngilizcenin altında" konumu için: okunan altyazının ekrandaki alt kenarı ve
    // şerit (kesit) koordinatlarını ekrana çevirmek için gerekenler.
    @Volatile private var textBottomScreenPx = -1
    @Volatile private var textBottomAt = 0L
    @Volatile private var shownBoxTopPx = -1
    private var ocrBandTop = 0
    private var ocrBandScale = 1f
    private var ocrScreenPerCap = 1f
    private var ownTextFrames = 0

    // --- menü/görev durumu ---
    private val menuCache = java.util.Collections.synchronizedMap(LinkedHashMap<String, String>())
    private var lastMenuKey = ""
    private var menuJob: Job? = null

    /** Şu an ekrana bizim yazdığımız metinler; tekrar okunup çevrilmesinler. */
    // Birden fazla iş parçacığı (OCR döngüsü, yapay zekâ, taslak) aynı anda okuyup yazıyor:
    // eş zamanlı küme; döngü sırasında değişse de ConcurrentModificationException olmaz.
    private val displayed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        overlay = Overlay(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Sistem servisi kendiliğinden yeniden başlatmışsa (intent yok) ekran
        // yakalama izni artık geçersizdir. Döngüye girmemek için hemen duruyoruz.
        if (intent == null || intent.action == null) {
            log("Servis izinsiz yeniden başlatıldı, durduruluyor")
            stopEverything()
            return START_NOT_STICKY
        }

        when (intent.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }

            ACTION_START -> {
                startForegroundSafely()
                // Ayarlar değişmiş olabilir: yapay zekâ devresini yeniden aç.
                AiTranslate.devreyiAc()

                val code = intent.getIntExtra(EXTRA_CODE, 0)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
                if (data == null) {
                    stopEverything()
                    return START_NOT_STICKY
                }

                if (projection == null) {
                    // Daha önce durdurulmuşsa iş alanı kapalıdır, yenisini açıyoruz.
                    if (!scope.isActive) {
                        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
                    }
                    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val mp = try {
                        mpm.getMediaProjection(code, data)
                    } catch (e: Throwable) {
                        CrashLog.note(this, "ekran izni", e)
                        null
                    }
                    if (mp == null) {
                        stopEverything()
                        return START_NOT_STICKY
                    }
                    mp.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() {
                            stopEverything()
                        }
                    }, Handler(mainLooper))
                    projection = mp

                    overlay.show()
                    TvMode.autoUpdate(this, prefs)
                    overlay.setStil(gorunumStili())
                    running = true
                    startPipeline()
                }
            }

            else -> {
                stopEverything()
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- kurulum

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Lingo", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else
            @Suppress("DEPRECATION") Notification.Builder(this)

        return builder
            .setContentTitle("Lingo çalışıyor")
            .setContentText("Ekrandaki yazılar Türkçeye çevriliyor")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null as android.graphics.drawable.Icon?,
                    "Durdur",
                    stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }

    private fun startForegroundSafely() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            @Suppress("DEPRECATION")
            val d = wm.defaultDisplay
            @Suppress("DEPRECATION")
            val p = android.graphics.Point().also { d.getRealSize(it) }
            p.x to p.y
        }
    }

    /**
     * Android, bir ekran yakalama izni için sanal ekranı YALNIZCA BİR KEZ
     * kurmaya izin veriyor. Telefon döndüğünde yeniden kurmuyoruz, var olanı
     * yeniden boyutlandırıyoruz.
     */
    private fun configureDisplay(): Boolean {
        val (sw, sh) = screenSize()
        if (sw <= 0 || sh <= 0) return false
        screenWidth = sw
        screenHeight = sh

        val scale = min(1f, (if (isTv) TARGET_WIDTH_TV else TARGET_WIDTH).toFloat() / max(sw, 1))
        val w = max(2, (sw * scale).toInt() / 2 * 2)
        val h = max(2, (sh * scale).toInt() / 2 * 2)

        if (displayCreated && w == captureWidth && h == captureHeight) return true

        if (readerThread == null) {
            // TV'de görüntü okuyucu düşük öncelikte: video oynatmanın önüne geçmesin.
            val thread = HandlerThread(
                "altyazi-reader",
                if (isTv) android.os.Process.THREAD_PRIORITY_BACKGROUND else android.os.Process.THREAD_PRIORITY_DEFAULT
            ).also { it.start() }
            readerThread = thread
            readerHandler = Handler(thread.looper)
        }

        val reader = try {
            ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        } catch (e: Throwable) {
            CrashLog.note(this, "goruntu okuyucu", e)
            return false
        }

        return try {
            if (!displayCreated) {
                val vd = projection?.createVirtualDisplay(
                    "altyazi",
                    w, h,
                    resources.displayMetrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.surface,
                    null,
                    readerHandler
                )
                if (vd == null) {
                    reader.close()
                    return false
                }
                virtualDisplay = vd
                displayCreated = true
            } else {
                val vd = virtualDisplay
                if (vd == null) {
                    reader.close()
                    return false
                }
                // Sıra önemli: önce yüzeyi ayır, sonra boyutla, sonra yeni yüzeyi bağla.
                // Doğrudan resize+setSurface yapınca bazı cihazlarda (Pixel, Android 16)
                // ekran dönünce hiç yeni kare gelmiyordu: "ilk başlatmada çevirmiyor".
                vd.setSurface(null)
                vd.resize(w, h, resources.displayMetrics.densityDpi)
                vd.setSurface(reader.surface)
            }

            val old = imageReader
            imageReader = reader
            try {
                old?.close()
            } catch (_: Throwable) {
            }

            captureWidth = w
            captureHeight = h
            true
        } catch (e: Throwable) {
            CrashLog.note(this, "ekran kurulumu", e)
            try {
                reader.close()
            } catch (_: Throwable) {
            }
            false
        }
    }

    private fun releaseDisplay() {
        try {
            virtualDisplay?.release()
        } catch (_: Throwable) {
        }
        virtualDisplay = null
        try {
            imageReader?.close()
        } catch (_: Throwable) {
        }
        imageReader = null
        try {
            readerThread?.quitSafely()
        } catch (_: Throwable) {
        }
        readerThread = null
        readerHandler = null
        // Tamponu serbest bırakmıyoruz; tarama işi hâlâ okuyor olabilir.
        frameBitmap = null
        bandImza = null
        displayCreated = false
        captureWidth = 0
        captureHeight = 0
    }

    // ----------------------------------------------------------------- akış

    /** Çeviri döngüsü bir kez çalışsın (çift başlatma kilidi). */
    private val pipelineOn = java.util.concurrent.atomic.AtomicBoolean(false)

    // Ekran döndükten sonra kare gelip gelmediğini izlemek için
    @Volatile private var lastFrameMs = 0L
    @Volatile private var staleWarned = false
    @Volatile private var rotatedAtMs = 0L
    @Volatile private var framesSinceRotate = 0
    @Volatile private var reattachTries = 0

    /** Sanal ekranın yüzeyini ayırıp yeniden bağlar; bazı cihazlarda dönmeden sonra kareleri geri getirir. */
    private fun reattachSurface(): Boolean = try {
        val vd = virtualDisplay
        val r = imageReader
        if (vd == null || r == null) false
        else {
            vd.setSurface(null)
            vd.resize(captureWidth, captureHeight, resources.displayMetrics.densityDpi)
            vd.setSurface(r.surface)
            true
        }
    } catch (e: Throwable) {
        CrashLog.note(this, "yuzey yeniden baglama", e)
        false
    }

    // Tanı sayaçları (başlangıçta okunmama sorununu kayıtta görmek için)
    @Volatile private var diagFrames = 0
    @Volatile private var diagNoFrame = 0
    @Volatile private var diagText = 0
    @Volatile private var diagOwn = 0

    private fun startPipeline() {
        UserDict.apply(this)   // "Sözlüğüm" satırları çeviride geçerli olsun
        if (recognizerClosed) {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizerClosed = false
        }
        diagFrames = 0; diagNoFrame = 0; diagText = 0; diagOwn = 0
        rotatedAtMs = 0L; framesSinceRotate = 0; reattachTries = 0
        lastFrameMs = 0L; staleWarned = false
        everShown = false
        if (!pipelineOn.compareAndSet(false, true)) {
            log("Çeviri zaten çalışıyor, ikinci başlatma yok sayıldı")
            return
        }
        val f = FastTranslate()
        fast = f
        ai = AiTranslate(prefs)
        store = TranslationStore(this)
        storeAi = TranslationStore(this, TranslationStore.AI)

        if (LlmTranslate.hasModel(this)) {
            val l = LlmTranslate(this)
            llm = l
            LlmTranslate.preload(this)
            scope.launch {
                if (!LlmTranslate.isReady(this@CaptureService)) {
                    log("Telefon yapay zekâsı belleğe yükleniyor… (büyük modelde ilk seferde 1-2 dk)")
                }
                while (isActive && LlmTranslate.isLoading()) delay(500)
                log(if (l.ready) "TELEFON YAPAY ZEKÂSI HAZIR (${l.backendName}) · ${LlmTranslate.loadState}"
                    else "TELEFON YAPAY ZEKÂSI YÜKLENEMEDİ: ${l.lastError}")
            }
        } else {
            log("Telefon yapay zekâsı modeli yok (ana ekrandan indirilebilir)")
        }

        scope.launch {
            try {
                f.prepare()
                f.translate("Hello.")  // ısındır: ilk replik de hızlı gelsin
            } catch (e: Throwable) {
                CrashLog.note(this@CaptureService, "ceviri modeli", e)
            }
        }

        scope.launch {
            if (!configureDisplay()) {
                stopEverything()
                return@launch
            }

            log("SÜRÜM 9.29 · mod: ${if (prefs.mode == Prefs.MODE_INSTANT) "çevrim dışı" else "internet (API)"} · ${if (prefs.accuracyFirst) "taslak + yapay zekâ düzeltmesi" else "hız öncelikli"} · küfür korunuyor${if (prefs.tvMode) " · TV modu" else ""}${if (isTv && prefs.bridgeOn) " · çeviri telefondan (${prefs.bridgeHost})" else ""}")
            overlay.setSubtitle("GameLingo çalışıyor…", dp(80))
            delay(2000)
            if (shownSource.isEmpty()) overlay.setSubtitle(null, 0)

            // ÖNEMLİ: kurulumda KULLANILAN boyutla başla. Eskiden 2 sn sonra yeniden okunuyordu:
            // BAŞLAT'tan sonra uygulama arka plana geçip oyun yatay açılınca yakalama dikey
            // boyutta kalıyor, fark hiç fark edilmiyordu. Yatay görüntü dikey çerçeveye küçülüp
            // sığdırıldığı için altyazı bölgesinde yazı yoktu: "ilk başlatmada çevirmiyor".
            var lastScreen = screenWidth to screenHeight
            var cycle = 0L
            val startedMs = android.os.SystemClock.elapsedRealtime()
            var nextDiagMs = startedMs + 5000
            var nextTvCheckMs = 0L
            var lastTv = prefs.tvMode
            log("Ekran ${screenWidth}x${screenHeight} · yakalama ${captureWidth}x${captureHeight}${if (isTv) " · TV: hafif tarama (300 ms)" else ""}")

            while (isActive) {
                // TV'de sık tarama videoyu takıltıyor: en az 300 ms ara.
                val interval = prefs.intervalMs.toLong().coerceIn(if (isTv) MIN_INTERVAL_TV else 80L, 1000L)
                delay(interval)

                try {
                    val now = screenSize()
                    if (now != lastScreen) {
                        lastScreen = now
                        val ok = configureDisplay()
                        log("Ekran döndü: ${now.first}x${now.second} · yakalama ${captureWidth}x${captureHeight}${if (ok) "" else " · KURULAMADI"}")
                        rotatedAtMs = android.os.SystemClock.elapsedRealtime()
                        framesSinceRotate = 0
                        reattachTries = 0
                        bandImza = null
                        overlay.clearLabels()
                        lastMenuKey = ""
                        delay(250)
                        continue
                    }

                    // Tanı: başlangıçta hiç altyazı okunmadıysa nedenini kayda yaz (ilk 60 sn).
                    val nowMs = android.os.SystemClock.elapsedRealtime()
                    // TV modu: kablo takılıp çıkarıldıysa ya da ana ekrandan değiştirildiyse kutuyu yeniden ayarla.
                    if (nowMs >= nextTvCheckMs) {
                        nextTvCheckMs = nowMs + 2000
                        TvMode.autoUpdate(this@CaptureService, prefs)
                        if (prefs.tvMode != lastTv) {
                            lastTv = prefs.tvMode
                            overlay.setStil(gorunumStili())
                            log(if (lastTv) "TV MODU AÇIK · yazı büyük" else "TV modu kapalı · telefon boyutu")
                        }
                    }
                    // İlk 3 dakika her 15 sn'de bir: takılma olursa kayıtta sebebi görünsün.
                    if (nowMs >= nextDiagMs && nowMs - startedMs <= 180_000) {
                        nextDiagMs = nowMs + 15_000
                        log("TANI: kare $diagFrames (boş $diagNoFrame) · okunan yazı $diagText · sadece kendi yazımız $diagOwn · son OCR: \"${lastOcrRaw.take(40)}\"")
                    }
                    val full = grabFull()
                    if (full == null) {
                        diagNoFrame++
                        // Uzun süre yeni görüntü gelmiyorsa (izlenen uygulama videoyu kayda kapalı
                        // katmanda oynatıyor) eski çeviri ekranda takılı kalmasın.
                        if (shownSource.isNotEmpty() && lastFrameMs > 0 && nowMs - lastFrameMs > STALE_MS) {
                            shownSource = ""
                            candidate = ""
                            candidateSeen = 0
                            translatingFor = ""
                            showSubtitle(null)
                            if (!staleWarned) {
                                staleWarned = true
                                log("GÖRÜNTÜ GELMİYOR: ${STALE_MS / 1000} sn'dir yeni kare yok, eski çeviri kaldırıldı. İzlenen uygulama videoyu kayda kapatıyor olabilir.")
                            }
                        }
                        // Ekran döndükten sonra kare gelmiyorsa yüzeyi yeniden bağla (en fazla 3 kez).
                        if (rotatedAtMs > 0 && framesSinceRotate == 0 &&
                            nowMs - rotatedAtMs > 1500L * (reattachTries + 1)) {
                            if (reattachTries < 3) {
                                reattachTries++
                                val ok = reattachSurface()
                                log("Döndükten sonra görüntü gelmedi, yeniden bağlanıyor ($reattachTries/3)${if (ok) "" else " · başarısız"}")
                            } else if (reattachTries == 3) {
                                reattachTries++
                                log("UYARI: ekran döndükten sonra görüntü gelmiyor. DURDUR → BAŞLAT deneyin.")
                            }
                        }
                        continue
                    }
                    framesSinceRotate++
                    lastFrameMs = nowMs
                    diagFrames++
                    processSubtitle(full)

                    // Menü çevirisi tüm ekranı okur, ağırdır: TV'de kapalı.
                    if (!isTv && prefs.menuTranslate && cycle % MENU_EVERY == 0L && menuJob?.isActive != true) {
                        val copy = try {
                            if (full.isRecycled) null
                            else full.copy(Bitmap.Config.ARGB_8888, false)
                        } catch (_: Throwable) {
                            null
                        }
                        if (copy != null) menuJob = scope.launch {
                            try {
                                processMenu(copy)
                            } catch (e: Throwable) {
                                CrashLog.note(this@CaptureService, "menu taramasi", e)
                            } finally {
                                copy.recycle()
                            }
                        }
                    }

                    cycle++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    CrashLog.note(this@CaptureService, "tarama dongusu", e)
                    delay(400)
                }
            }
        }
    }

    /** Ekranın son karesini olduğu gibi alır. */
    private fun grabFull(): Bitmap? {
        val reader = imageReader ?: return null
        val image = try {
            reader.acquireLatestImage()
        } catch (_: Throwable) {
            null
        } ?: return null

        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val paddedWidth = image.width + (rowStride - pixelStride * image.width) / pixelStride

            var bmp = frameBitmap
            if (bmp == null || bmp.isRecycled ||
                bmp.width != paddedWidth || bmp.height != image.height
            ) {
                // Eskisini serbest bırakmıyoruz: başka bir iş onu okuyor olabilir.
                // Çöp toplayıcı kendisi temizler.
                bmp = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
                frameBitmap = bmp
                bandImza = null
            }
            bmp.copyPixelsFromBuffer(buffer)
            bmp
        } catch (_: Throwable) {
            null
        } finally {
            try {
                image.close()
            } catch (_: Throwable) {
            }
        }
    }

    // --------------------------------------------------------------- altyazı

    private suspend fun processSubtitle(full: Bitmap) {
        // Ekran yeniden kurulurken tampon serbest bırakılmış olabilir.
        if (full.isRecycled) return

        val topPct = prefs.topPct.coerceIn(0, 98)
        val bottomPct = prefs.bottomPct.coerceIn(topPct + 1, 100)

        val top = (full.height * topPct / 100).coerceIn(0, full.height - 2)
        val bottom = (full.height * bottomPct / 100).coerceIn(top + 2, full.height)
        val usable = if (captureWidth in 1..full.width) captureWidth else full.width
        val left = (usable * prefs.leftPct / 100).coerceIn(0, usable - 4)
        val right = (usable * prefs.rightPct / 100).coerceIn(left + 4, usable)

        // Kutunun ekrandaki yeri, ayardaki konum tercihine göre.
        val seritUstu = screenHeight * topPct / 100
        subtitleAnchorPx = when (prefs.subtitlePos) {
            // Şeridin üstünü kapat: İngilizce yazının üzerine otursun.
            Prefs.POS_COVER -> seritUstu - dp(6)
            // Ekranın en altı.
            Prefs.POS_BOTTOM -> screenHeight - dp(110)
            // İngilizcenin altında: yazı okununca gerçek yeri gösterirken hesaplanır; bu yedek.
            Prefs.POS_BELOW -> screenHeight * prefs.bottomPct.coerceIn(1, 100) / 100 - dp(4)
            // Varsayılan: şeridin hemen üstünde, kendi yazımızı okumayalım diye.
            else -> seritUstu - dp(58)
        }
        // Varsayılan konumda kutunun ALT kenarı şeridin üstünde durur: TV'de yazı büyük
        // olunca kutu aşağı taşıp İngilizce altyazıyı kapatıyor, okuma duruyordu.
        subtitleBottomPx = if (prefs.subtitlePos == Prefs.POS_ABOVE) seritUstu - dp(6) else -1

        var band = try {
            Bitmap.createBitmap(full, left, top, right - left, bottom - top)
        } catch (e: Throwable) {
            // Tampon bu arada serbest bırakıldıysa bu kareyi atlıyoruz.
            return
        }
        // Kucuk seritleri buyutmek OCR dogrulugunu artiriyor ama tarama
        // suresini de ikiye katliyor. Esigi dusurduk: yalnizca gercekten
        // kucuk seritler buyutuluyor, normal boyuttakiler oldugu gibi gidiyor.
        if (band.height < 110) {
            val scaled = Bitmap.createScaledBitmap(band, band.width * 2, band.height * 2, true)
            if (scaled != band) band.recycle()
            band = scaled
        }

        // "Ne görüyor?" önizlemesi: 2 sn'de bir küçük bir kopya, okunan bölge çerçeveli.
        val simdiMs = android.os.SystemClock.elapsedRealtime()
        if (simdiMs - lastPreviewMs > 2000) {
            lastPreviewMs = simdiMs
            onizlemeKaydet(full, left, top, right, bottom)
        }

        // GameLingo'nun kendi ekranı açıkken (ayar yaparken) kendi yazılarımızı çevirmeyelim.
        if (MainActivity.visible) {
            band.recycle()
            return
        }

        // Şerit önceki kareyle neredeyse aynıysa OCR'a hiç girmiyoruz.
        // Altyazı ekranda dururken boşuna işlem yapmak telefonu yoruyor ve
        // oyun akışını bozuyor.
        if (bandDegismedi(band)) {
            band.recycle()
            // Şerit değişmedi ama bekleyen bir replik varsa onu ONAYLA.
            // (Siyah arka planlı sahnelerde şerit hiç değişmez; eskiden replik hiç çevrilmiyordu.)
            if (candidateSeen == 1 && lastOcrRaw.isNotEmpty()) handleText(lastOcrRaw)
            return
        }

        ocrBandTop = top
        ocrBandScale = if (band.height >= (bottom - top) * 2 - 1) 2f else 1f
        ocrScreenPerCap = if (full.height > 0) screenHeight.toFloat() / full.height else 1f
        val text = runOcr(band, filterEdges = true)
        band.recycle()
        if (text.isNotBlank()) diagText++
        lastOcrRaw = text
        handleText(text)
    }

    /**
     * Tek kural: bir replik için ekrana BİR KEZ yazılır ve replik değişene
     * kadar hiç değiştirilmez.
     */
    private fun handleText(raw: String) {
        val text = clean(raw)

        if (text.isEmpty()) {
            emptyFrames++
            if (prefs.diagnostics && !noTextWarned && !everShown && emptyFrames >= 60) {
                noTextWarned = true
                log("UYARI: ekranda hiç yazı okunamadı")
                if (prefs.diagnostics) {
                    showSubtitle("⚠ Ekranda yazı okunamıyor. Altyazı bölgesini kontrol edin.")
                }
                return
            }
            if (emptyFrames >= 6 && shownSource.isNotEmpty()) {
                shownSource = ""
                candidate = ""
                candidateSeen = 0
                translatingFor = ""
                showSubtitle(null)
            }
            return
        }
        emptyFrames = 0

        // Oyuncu kadrosu, oynatıcı menüsü, güvenlik uyarısı… Bunlar çevrilirse
        // hem jeton gider hem de üç çeviri kanalını doldurup gerçek repliği
        // sıraya sokar; altyazı geriden gelmesinin başlıca sebebi buydu.
        // Kendi çevirimizi yeniden okuyup çevirmeyelim; yoksa metin her turda
        // büyüyerek geri gelir ve çeviri kanallarını boşa doldurur.
        if (isOurOwnText(text) && prefs.subtitlePos != Prefs.POS_COVER) {
            // Bölgede yalnızca KENDİ Türkçe yazımız görünüyor: İngilizce altyazı bitmiş
            // (ya da görüntü engelli). Boş kare gibi say ki eski çeviri ekranda takılı kalmasın.
            ownTextFrames++
            diagOwn++
            candidate = ""
            candidateSeen = 0
            if (ownTextFrames >= 8 && shownSource.isNotEmpty()) {
                ownTextFrames = 0
                shownSource = ""
                translatingFor = ""
                showSubtitle(null)
            }
            return
        }
        ownTextFrames = 0
        if (isOurOwnText(text) || altyaziDegil(text)) {
            candidate = ""
            candidateSeen = 0
            return
        }

        if (similar(text, shownSource)) {
            candidate = ""
            candidateSeen = 0
            return
        }

        if (similar(text, candidate)) {
            candidateSeen++
        } else {
            candidate = text
            candidateSeen = 1
        }

        // Kaç kez okununca çevrilsin?
        //
        // İki kez okuma kuralı, yarım okunmuş metni sunucuya göndermemek
        // içindi. Ama çevrimdışı çeviri telefonun içinde ve bedava: orada
        // beklemenin tek sonucu altyazının bir tarama süresi geç gelmesi.
        // 150 ms'lik aralıkta bu, her replikte en az 300 ms kayıp demekti.
        //
        // Cümle tamamlanmış görünüyorsa (noktalamayla bitiyor ya da yeterince
        // uzunsa) çevrimdışı modda ilk okumada çeviriyoruz.
        val tamamGorunuyor = text.length >= 12 ||
            text.trimEnd().lastOrNull() in listOf('.', '!', '?', '…')
        val gerekenOkuma =
            if (prefs.mode == Prefs.MODE_INSTANT && tamamGorunuyor) 1 else 2

        if (candidateSeen < gerekenOkuma) return
        if (similar(text, translatingFor)) return

        val source = text

        if (inFlight.contains(source)) return
        // ÖNEMLİ: translatingFor'u kapasite kontrolünden SONRA yazıyoruz.
        // Önce yazılırsa, sıra doluyken elenen replik bir daha hiç denenmez;
        // metin değişene kadar o altyazı ekrana gelmez. ("bazen gelmiyor")
        if (inFlight.size >= MAX_PARALLEL) return

        translatingFor = source
        inFlight.add(source)
        log("OKUNAN: $text")
        startedAt[source] = android.os.SystemClock.elapsedRealtime()
        scope.launch {
            try {
                runTranslation(source)
            } finally {
                inFlight.remove(source)
                startedAt.remove(source)
            }
        }
    }

    private fun showSubtitle(value: String?, refined: Boolean = false, draft: Boolean = false) {
        if (value == null) {
            displayed.remove(normalize(shownSource))
        } else {
            displayed.add(normalize(value))
        }
        var ust = subtitleAnchorPx
        if (prefs.subtitlePos == Prefs.POS_BELOW) {
            // İngilizce altyazının hemen altına; yazının yeri yakın zamanda okunmadıysa yedek konum.
            val taze = android.os.SystemClock.elapsedRealtime() - textBottomAt < 10_000
            if (taze && textBottomScreenPx > 0) ust = textBottomScreenPx + dp(6)
            shownBoxTopPx = if (value == null) -1 else ust
        }
        overlay.setSubtitle(value, ust, refined, draft, subtitleBottomPx)
    }

    /** Yapay zekâ çevirisi kendi hafızasına, hızlı çeviri ayrı hafızaya yazılır. */
    private fun saveToMemory(source: String, value: String, tag: String) {
        if (tag.contains("YZ")) storeAi?.put(source, value) else store?.put(source, value)
    }

    private fun publish(source: String, value: String?, remember: Boolean = true, tag: String = "") {
        if (value.isNullOrBlank()) return
        if (translatingFor != source) {
            // Replik değişmiş; ekrana yazmıyoruz ama hafızaya alıyoruz.
            // Aynı cümle tekrar geçtiğinde anında çıkacak.
            if (remember && !value.startsWith("⚠")) saveToMemory(source, value, tag)
            log("GEÇ KALDI (hafızaya alındı): ${value.take(50)}")
            return
        }
        val ms = startedAt.remove(source)?.let { android.os.SystemClock.elapsedRealtime() - it }
        log(if (ms != null) "YAZILAN$tag ($ms ms): $value" else "YAZILAN$tag: $value")
        shownSource = source
        everShown = true
        if (remember && !value.startsWith("⚠")) saveToMemory(source, value, tag)
        if (!value.startsWith("⚠")) addHistory(source, value)
        showSubtitle(value, refined = tag.contains("YZ"), draft = tag.contains("taslak"))
    }

    /**
     * DOĞRULUK ÖNCELİKLİ (taslak + düzeltme):
     *  - Hızlı çeviri hemen GRİ (taslak) olarak çıkar, hafızaya yazılmaz.
     *  - Yapay zekâ yarıda KESİLMEZ; bitince turkuaz noktalı doğru çeviri taslağın yerine geçer.
     *    Replik geçmişse ekrana yazmaz ama hafızaya alır: sonraki izlemede anında doğrusu çıkar.
     *  - Birikme olmasın: sırası geldiğinde artık en yeni replik değilse atlanır.
     */
    private fun accurateOnDevice(l: LlmTranslate, source: String) {
        llmLatest = source
        val forAi = aiInput(source)
        val previous = synchronized(recentLines) { recentLines.toList() }
        synchronized(recentLines) {
            recentLines.addLast(source)
            while (recentLines.size > 3) recentLines.removeFirst()
        }
        scope.launch {
            val quick = fastTranslateKeepingName(source)
            // Yapay zekâ bu arada bitirdiyse taslağı gösterme.
            // Hızlı çeviri başarısızsa (boş ya da İngilizcesiyle aynı) bozuk taslak gösterme; yapay zekâyı bekle.
            val failed = quick.isNullOrBlank() || quick.trim().equals(source.trim(), ignoreCase = true)
            if (failed) log("TASLAK GÖSTERİLMEDİ (hızlı çeviri başarısız): $source")
            if (!failed && translatingFor == source && shownSource != source) {
                publish(source, quick!!, remember = false, tag = " · taslak")
            }
        }
        scope.launch {
            val t0 = android.os.SystemClock.elapsedRealtime()
            val better = l.translate(forAi, previous, prefs.contentType, prefs.gameName, discardIfStale = false) {
                llmLatest == source
            }
            val ms = android.os.SystemClock.elapsedRealtime() - t0
            if (better.isNullOrBlank()) {
                l.lastError?.let { log("YAPAY ZEKÂ (telefon) hata: $it") }
                return@launch
            }
            startedAt.remove(source)
            publish(source, aiPrefix(source) + better, remember = true, tag = " · YZ $ms ms (sıra ${l.lastWaitMs} ms)")
        }
    }

    // ---------------------------------------------- TV: çeviriyi telefona yaptır

    private val bridgeBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var bridgeNext: Pair<String, List<String>>? = null
    private val bridgeSeq = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var bridgeLastWarnMs = 0L

    /**
     * Önce gri taslak (TV'nin kendi hızlı çevirisi), sonra telefondaki yapay zekânın doğru
     * çevirisi. Telefon meşgulken gelen ara replikler atlanır, hep en yenisi gönderilir.
     */
    private fun bridgeTranslate(source: String) {
        llmLatest = source
        val previous = synchronized(recentLines) { recentLines.toList() }
        synchronized(recentLines) {
            recentLines.addLast(source)
            while (recentLines.size > 3) recentLines.removeFirst()
        }
        scope.launch {
            val quick = fastTranslateKeepingName(source)
            val failed = quick.isNullOrBlank() || quick.trim().equals(source.trim(), ignoreCase = true)
            if (!failed && translatingFor == source && shownSource != source) {
                publish(source, quick!!, remember = false, tag = " · taslak")
            }
        }
        if (!bridgeBusy.compareAndSet(false, true)) {
            bridgeNext = source to previous   // telefon meşgul: bitince EN YENİSİ gidecek
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                var job: Pair<String, List<String>>? = source to previous
                while (job != null) {
                    val (src, prev) = job
                    val seq = bridgeSeq.incrementAndGet()
                    val t0 = android.os.SystemClock.elapsedRealtime()
                    val r = PhoneBridge.translate(
                        prefs.bridgeHost, prefs.bridgePin, seq, aiInput(src), prev,
                        prefs.contentType, prefs.gameName
                    )
                    val ms = android.os.SystemClock.elapsedRealtime() - t0
                    when (r) {
                        is PhoneBridge.Result.Ok -> {
                            startedAt.remove(src)
                            publish(src, aiPrefix(src) + r.text, remember = true, tag = " · YZ telefon $ms ms")
                        }
                        is PhoneBridge.Result.Skip -> {}
                        is PhoneBridge.Result.Err -> {
                            val now = android.os.SystemClock.elapsedRealtime()
                            if (now - bridgeLastWarnMs > 30_000) {
                                bridgeLastWarnMs = now
                                log("TELEFON ÇEVİRİSİ YOK (${r.reason}) · bu sırada TV'nin hızlı çevirisi kullanılıyor")
                            }
                        }
                    }
                    job = bridgeNext
                    bridgeNext = null
                }
            } finally {
                bridgeBusy.set(false)
            }
        }
    }

    /** Yapay zekâya gidecek metin: konuşmacı adı korunur, OCR hataları düzeltilir, küfür olduğu gibi kalır. */
    private fun aiInput(source: String): String {
        val (name, body) = splitSpeaker(source)
        val fixed = OfflineFix.cleanForAi(body)
        if (fixed != body) log("YZ'YE GİDEN (OCR düzeltildi): $fixed")
        // "In Spanish: ..." dil etiketi yapay zekâya gitmez; çevirinin başına "[İspanyolca]" konur.
        if (name != null && OfflineFix.languageLabel(name) != null) return fixed
        return if (name == null) fixed else "$name: $fixed"
    }

    /** "In Spanish: Shit!" -> "[İspanyolca] " (yapay zekâ çevirisinin başına eklenir). */
    private fun aiPrefix(source: String): String {
        val (name, _) = splitSpeaker(source)
        return name?.let { OfflineFix.languageLabel(it) }?.let { "[$it] " } ?: ""
    }

    /** Telefondaki yapay zekâ ile düzgün çeviri; gelince ekrandakinin üstüne yazar. */
    private fun refineOnDevice(l: LlmTranslate, source: String) {
        llmLatest = source
        val forAi = aiInput(source)
        l.cancelOthers(forAi)   // eski satırın çevirisi sürüyorsa kes, sıra bu satırda
        val previous = synchronized(recentLines) { recentLines.toList() }
        synchronized(recentLines) {
            recentLines.addLast(source)
            while (recentLines.size > 3) recentLines.removeFirst()
        }
        scope.launch {
            val t0 = android.os.SystemClock.elapsedRealtime()
            // Sırada beklerken replik geçtiyse (ve daha yenisi geldiyse) boşuna çalışma.
            // Sadece hâlâ ekrandaki (ya da en son gelen) satır için çalış.
            val better = l.translate(forAi, previous, prefs.contentType, prefs.gameName) {
                llmLatest == source && translatingFor == source
            }
            val ms = android.os.SystemClock.elapsedRealtime() - t0
            if (better.isNullOrBlank()) {
                l.lastError?.let { log("YAPAY ZEKÂ (telefon) hata: $it") }
                return@launch
            }
            startedAt.remove(source)
            publish(source, aiPrefix(source) + better, remember = true, tag = " · YZ $ms ms (sıra ${l.lastWaitMs} ms)")
        }
    }

    private suspend fun runTranslation(source: String) {
        val mode = prefs.mode
        val engine = ai

        // TV, çeviriyi telefondaki yapay zekâya yaptırıyorsa yapay zekâ "hazır" sayılır:
        // hazır sözlük ve kaba çeviri hafızası telefonun doğru çevirisinin önüne geçmesin.
        val bridge = isTv && prefs.bridgeOn && prefs.bridgeHost.isNotBlank() && prefs.bridgePin.isNotBlank()
        val llmReady = mode == Prefs.MODE_INSTANT && (llm?.ready == true || bridge)

        // 1) Sözlük. Yapay zekâ hazırsa SADECE Sözlüğüm + ses etiketleri; hazır sözlük
        //    yapay zekânın önüne geçmez (bağlamı bilmez, sabit karşılığı yanlış olabilir).
        val (nameIn, bodyIn) = splitSpeaker(source)
        val dictHit = if (llmReady) OfflineFix.lookupUserOnly(bodyIn) else OfflineFix.lookup(bodyIn)
        dictHit?.let { fixed ->
            publish(source, if (nameIn == null) fixed else "$nameIn: $fixed", remember = false)
            return
        }

        // 2) Hafıza. Yapay zekâ hazırsa yalnızca YAPAY ZEKÂ hafızası; eski kaba çeviriler kullanılmaz.
        val remembered = if (llmReady) storeAi?.get(source) else (storeAi?.get(source) ?: store?.get(source))
        remembered?.let {
            publish(source, it, remember = false, tag = if (llmReady) " · YZ hafıza" else "")
            return
        }

        if (mode == Prefs.MODE_INSTANT) {
            if (bridge) {
                bridgeTranslate(source)
                return
            }
            val l = llm
            val llmOn = l != null && l.ready
            if (l != null && llmOn && prefs.accuracyFirst) {
                accurateOnDevice(l, source)
                return
            }
            val quick = fastTranslateKeepingName(source)
            if (!quick.isNullOrBlank()) {
                // Model hazırsa kaba çeviri hafızaya YAZILMAZ; hafızaya düzgün olan girer.
                publish(source, quick, remember = !llmOn)
                if (l != null && llmOn) refineOnDevice(l, source)
                return
            }
            if (l != null && llmOn) {
                refineOnDevice(l, source)
                return
            }
            // Sessiz kalmıyoruz: sebebini hem ekrana hem kayda yazıyoruz.
            val reason = fast?.lastError
            log("TELEFON ÇEVİRİSİ YOK: ${reason ?: "model hazır değil"}")
            if (prefs.diagnostics) {
                publish(source, "⚠ Türkçe model hazır değil · ${reason ?: "indirilmedi"}")
            }
            return
        }

        if (mode == Prefs.MODE_HYBRID) {
            val quick = fastTranslateKeepingName(source)
            if (!quick.isNullOrBlank()) publish(source, quick)
        }

        if (prefs.activeKey.isBlank() || engine == null) {
            log("API anahtarı yok, telefon çevirisine düşülüyor")
            val quick = fastTranslateKeepingName(source)
            if (!quick.isNullOrBlank()) publish(source, quick)
            else if (prefs.diagnostics) publish(source, "⚠ API anahtarı girilmemiş")
            return
        }

        val better = engine.translate(source)
        if (!better.isNullOrBlank()) {
            engine.remember(source, better)
            publish(source, better)
            return
        }

        // Yapay zekâ modunda sessizce kaba çeviriye düşmüyoruz; yanlış çeviri
        // göstermektense sebebini yazmak daha dürüst.
        // Oyun sırasında teknik hata göstermiyoruz: sessizce telefon çevirisine
        // düşüyoruz. Sebep yine kayda yazılıyor, ayarlardan görülebiliyor.
        val err = engine.lastError
        log("YAPAY ZEKÂ BAŞARISIZ: ${err ?: "boş yanıt"}")

        if (mode != Prefs.MODE_HYBRID) {
            val quick = fastTranslateKeepingName(source)
            if (!quick.isNullOrBlank()) {
                publish(source, quick)
                return
            }
        }
        if (prefs.diagnostics) publish(source, "⚠ ${err ?: "çeviri boş döndü"}")
    }

    // ----------------------------------------------------- menü / görev yazısı

    /**
     * Menü, görev ve tuş yazıları: her biri kendi yerinde, telefonun içindeki
     * çeviriyle anında çevrilir. Aynı yazı ikinci kez çevrilmez, hafızada tutulur.
     */
    private suspend fun processMenu(full: Bitmap) {
        val scale = min(1f, MENU_WIDTH.toFloat() / max(full.width, 1))
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                full,
                max(2, (full.width * scale).toInt()),
                max(2, (full.height * scale).toInt()),
                true
            )
        } else {
            full
        }

        val found = ArrayList<Triple<String, Int, Int>>()
        val subtitleTop = prefs.topPct.coerceIn(0, 98) / 100f

        try {
            val lines = ocrLines(small)
            for (line in lines) {
                val box = line.second ?: continue
                val raw = line.first.trim()
                if (raw.length < 3) continue
                if (isControllerLabel(raw)) continue
                if (raw.count { it.isLetter() } < 3) continue

                val relY = box.top.toFloat() / small.height
                if (relY >= min(subtitleTop, MENU_ZONE)) continue   // altyazı bölgesi ayrı işleniyor
                if (isOurOwnText(raw)) continue                      // kendi çevirimizi çevirmeyelim
                if (displayed.contains(normalize(raw))) continue  // kendi yazdığımız çeviri

                val screenX = (box.left.toFloat() / small.width * screenWidth).toInt()
                val screenY = (box.bottom.toFloat() / small.height * screenHeight).toInt()
                found.add(Triple(raw, screenX, screenY))
                if (found.size >= MAX_LABELS) break
            }
        } finally {
            if (small != full) small.recycle()
        }

        val key = found.joinToString("|") { it.first }
        if (key == lastMenuKey) return
        lastMenuKey = key

        if (found.isEmpty()) {
            displayed.clear()
            shownSource.takeIf { it.isNotEmpty() }?.let { displayed.add(normalize(it)) }
            overlay.clearLabels()
            return
        }

        val labels = ArrayList<Overlay.Label>()
        for ((text, x, y) in found) {
            val translated = translateMenuText(text) ?: continue
            labels.add(Overlay.Label(translated, x, y))
            displayed.add(normalize(translated))
        }
        overlay.setLabels(labels)
    }

    private suspend fun translateMenuText(text: String): String? {
        menuCache[text]?.let { return it }
        val (name, body) = splitSpeaker(text)
        val translated = fast?.translate(body) ?: return null
        if (translated.isBlank()) return null
        val result = if (name == null) translated else "$name: $translated"
        if (menuCache.size > 300) {
            val oldest = synchronized(menuCache) { menuCache.keys.firstOrNull() }
            if (oldest != null) menuCache.remove(oldest)
        }
        menuCache[text] = result
        return result
    }

    // --------------------------------------------------------------------- OCR

    private suspend fun ocrLines(bitmap: Bitmap): List<Pair<String, android.graphics.Rect?>> =
        suspendCancellableCoroutine { cont ->
            try {
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val out = ArrayList<Pair<String, android.graphics.Rect?>>()
                        for (block in result.textBlocks) {
                            for (line in block.lines) {
                                val t = line.text.trim()
                                if (t.isNotEmpty()) out.add(t to line.boundingBox)
                            }
                        }
                        if (cont.isActive) cont.resume(out)
                    }
                    .addOnFailureListener {
                        if (cont.isActive) cont.resume(emptyList())
                    }
            } catch (_: Throwable) {
                if (cont.isActive) cont.resume(emptyList())
            }
        }

    private suspend fun runOcr(bitmap: Bitmap, filterEdges: Boolean): String {
        val lines = ocrLines(bitmap)
        val width = bitmap.width.toFloat()
        val kept = ArrayList<SubtitleBlocks.Line>()
        // Şerit koordinatı -> ekran pikseli (yalnızca ana şerit okumasında anlamlı).
        fun ekranY(y: Int): Int = ((ocrBandTop + y / ocrBandScale) * ocrScreenPerCap).toInt()
        val altta = filterEdges && prefs.subtitlePos == Prefs.POS_BELOW

        for ((text, box) in lines) {
            // "Altında" konumunda kutumuz şeridin içine düşebilir: kutunun olduğu yerdeki yazıyı okuma.
            if (altta && box != null && shownBoxTopPx >= 0 && ekranY(box.top) >= shownBoxTopPx - dp(2)) continue
            if (isControllerLabel(text)) continue
            if (isOurOwnText(text)) continue
            if (OfflineFix.isNoiseLine(text)) continue  // Türkçe arayüz, jenerik, X-Ray, telif yazısı
            if (filterEdges && box != null) {
                val centerX = (box.left + box.right) / 2f / width
                val lineWidth = box.width() / width
                // Altyazı daima ortalıdır. Ortadan belirgin kaymış satırlar
                // görev yazısı, tuş etiketi veya kenar arayüzüdür.
                if (kotlin.math.abs(centerX - 0.5f) > 0.30f) continue
                if (lineWidth < 0.18f && kotlin.math.abs(centerX - 0.5f) > 0.20f) continue
            }
            val top = box?.top ?: 0
            kept.add(SubtitleBlocks.Line(top, box?.bottom ?: (top + 1), text))
        }

        val blok = SubtitleBlocks.bottomBlock(kept)
        if (altta && blok.isNotEmpty()) {
            textBottomScreenPx = ekranY(blok.maxOf { it.bottom })
            textBottomAt = android.os.SystemClock.elapsedRealtime()
        }
        return blok.joinToString(" ") { it.text }
    }

    /**
     * Şeritte birden fazla yazı bloğu olabilir: gerçek replik ve onun
     * üstündeki X-Ray oyuncu listesi gibi. Hepsini birleştirmek cümleleri
     * iç içe geçiriyordu ("There are an awful lot Hamish Linklater - Bruce
     * Wayne of unanswered questions").
     *
     * Altyazı satırları birbirine yakın durur, diğer bloklar arada belirgin
     * boşluk bırakır. Bu yüzden aşağıdan yukarı yürüyüp ilk büyük boşlukta
     * duruyoruz: geriye yalnızca en alttaki blok kalıyor.
     */
    private fun enAlttakiKume(
        satirlar: List<Pair<Int, String>>,
        seritYuksekligi: Int,
    ): List<Pair<Int, String>> {
        if (satirlar.size <= 1) return satirlar

        // İki satır arası bu kadar açılırsa ayrı blok sayılır.
        val boslukEsigi = (seritYuksekligi * 0.14f).toInt().coerceAtLeast(12)

        val sonuc = ArrayList<Pair<Int, String>>()
        var oncekiUst = satirlar.last().first
        for (i in satirlar.indices.reversed()) {
            val satir = satirlar[i]
            if (sonuc.isNotEmpty() && oncekiUst - satir.first > boslukEsigi) break
            sonuc.add(satir)
            oncekiUst = satir.first
            // Altyazı en fazla üç satırdır; fazlası başka bir şeydir.
            if (sonuc.size >= 3) break
        }
        return sonuc.reversed()
    }

    // ------------------------------------------------------------- yardımcılar

    /**
     * Şeridin kaba bir parmak izini çıkarıp öncekiyle karşılaştırır.
     * Altyazı ekranda dururken aynı kareyi tekrar tekrar okumak telefonu
     * yoruyor ve oyun akışını bozuyordu; değişmeyen kare artık atlanıyor.
     */
    private fun bandDegismedi(band: Bitmap): Boolean {
        if (band.isRecycled || band.width < 4 || band.height < 4) return false

        val sutun = 24
        val satir = 8
        val toplam = sutun * satir

        var piksel = imzaPiksel
        if (piksel == null || piksel.size != toplam) {
            piksel = IntArray(toplam)
            imzaPiksel = piksel
        }

        var i = 0
        for (y in 0 until satir) {
            val py = (band.height - 1) * y / (satir - 1)
            for (x in 0 until sutun) {
                val px = (band.width - 1) * x / (sutun - 1)
                val renk = band.getPixel(px, py)
                piksel[i++] =
                    ((renk shr 16 and 0xFF) + (renk shr 8 and 0xFF) + (renk and 0xFF)) / 3
            }
        }

        val onceki = bandImza
        if (onceki == null || onceki.size != toplam) {
            bandImza = piksel.copyOf()
            return false
        }

        var enBuyukFark = 0
        for (j in 0 until toplam) {
            val fark = kotlin.math.abs(piksel[j] - onceki[j])
            if (fark > enBuyukFark) enBuyukFark = fark
        }

        return if (enBuyukFark < 10) {
            true
        } else {
            System.arraycopy(piksel, 0, onceki, 0, toplam)
            false
        }
    }

    /** Satır zaten Türkçe mi? Öyleyse çevirmenin anlamı yok. */
    private fun zatenTurkce(text: String): Boolean {
        if (text.any { it in TURKISH_ONLY }) return true
        for (k in text.lowercase().split(Regex("[^\\p{L}]+"))) {
            if (k.length >= 2 && k in TURKCE_KELIMELER) return true
        }
        return false
    }

    /** Ekranda bizim yazdığımız Türkçe metin mi? Öyleyse tekrar çevrilmemeli. */
    private fun isOurOwnText(text: String): Boolean {
        if (zatenTurkce(text)) return true
        val simdi = normalize(text)
        if (simdi.isEmpty()) return false
        if (displayed.contains(simdi)) return true
        // Kendi yazımız yeniden okunup eskisinin üstüne eklenince metin her
        // turda büyüyerek geri geliyor: "bcventr" -> "bcventrlbcventr" -> ...
        // Tam eşleşme bunu yakalayamaz; parça eşleşmesi döngüyü kırar.
        for (eski in displayed) {
            if (eski.length >= 6 && (simdi.contains(eski) || eski.contains(simdi))) {
                return true
            }
        }
        return false
    }

    /** Ayarlardaki görünüm tercihlerini çizim katmanının anlayacağı hâle getirir. */
    /** Ayarlardaki görünüm tercihlerini çizim katmanının anlayacağı hâle getirir. */
    private fun gorunumStili(): Overlay.Stil {
        val alfa = SubtitleStyle.arkaAlfa(prefs.subtitleBg)
        val tv = prefs.tvMode
        return Overlay.Stil(
            // TV: 2-3 metreden okunsun diye ~1,5 kat büyük (en az 26).
            boyutSp = if (tv) maxOf(prefs.subtitleSize * 1.5f, 26f) else prefs.subtitleSize.toFloat(),
            yaziRengi = SubtitleStyle.yaziRengi(prefs.subtitleColor),
            // TV: parlak sahnelerde kaybolmasın diye arka plan koyu.
            // İngilizceyi örten konumda kutu tamamen koyu olsun; yoksa arkadaki yazı içinden görünüyor.
            arkaAlfa = when {
                prefs.subtitlePos == Prefs.POS_COVER && prefs.subtitleBg != Prefs.BG_NONE -> 255
                tv -> maxOf(alfa, 215)
                else -> alfa
            },
            arkaRenk = SubtitleStyle.arkaRenk(prefs.subtitleBgColor),
            // Arka plan yokken kenarlık okunurluk için şart.
            kenarlik = tv || prefs.subtitleOutline || alfa == 0,
            kenarPayYuzde = if (tv) 6 else 0,
        )
    }

    /**
     * Bu satır altyazı değil de ekrandaki başka bir yazı mı?
     *
     * İki şeyi yakalar:
     *  1. Bilinen arayüz/uyarı yazıları (güvenlik uyarısı, "Dialogue Boost"…).
     *  2. Oyuncu kadrosu listesi. Bunlar baş harfleri büyük, peş peşe dizilmiş
     *     özel adlardan oluşur ve içinde cümle kuran kelime geçmez.
     */
    private fun altyaziDegil(text: String): Boolean {
        val kucuk = text.lowercase()
        for (kalip in BLOCK_PHRASES) {
            if (kucuk.contains(kalip)) return true
        }

        val kelimeler = text.split(Regex("\\s+")).filter { it.isNotBlank() }

        // Dil göstergesi ("EN • TR") ve benzeri rozetler altyazı değil.
        val sikisik = kucuk.filter { !it.isWhitespace() }
        if (sikisik.contains("en•tr") || sikisik.contains("tr•en")) return true

        // Telefonun kendi arayüzü: indirme bildirimi, dosya adı, boyut.
        // ("altyazi-apk.zip ZIP 51 MB" gibi satırlar kayda düşmüştü.)
        if (Regex("\\.(zip|apk|rar|pdf|mp4|png|jpg)\\b").containsMatchIn(kucuk)) return true
        if (Regex("\\d+[.,]?\\d*\\s?(mb|kb|gb)\\b").containsMatchIn(kucuk)) return true

        // Anahtar, karma ya da adres parçası: harf ve rakam karışık, uzun.
        // Diyalogda böyle bir kelime geçmez.
        for (k in text.split(Regex("\\s+"))) {
            if (k.length < 16) continue
            if (k.any { it.isDigit() } && k.any { it.isLetter() }) return true
        }

        // Parçalanmış okuma: "f h b C V EN• TR" gibi, çoğu tek-iki harflik
        // kırıntıdan oluşan satırlar. Gerçek bir replik böyle görünmez.
        if (kelimeler.size >= 3) {
            val kirinti = kelimeler.count { it.length <= 2 }
            if (kirinti * 2 >= kelimeler.size) return true
        }

        if (kelimeler.size < 5) return false

        // Cümle kuran bir kelime varsa bu bir repliktir, kadro listesi değil.
        for (k in kelimeler) {
            val sade = k.lowercase().trim('.', ',', '!', '?', ':', ';', '"', '\'')
            if (sade in SENTENCE_WORDS) return false
        }

        // Cümle noktalaması bolsa yine repliktir.
        if (text.count { it == '.' || it == '!' || it == '?' } >= 2) return false

        // Baş harfi büyük, gerisi küçük: "Hamish", "Linklater", "Bonilla"...
        val ozelAd = kelimeler.count { k ->
            k.length > 1 && k[0].isUpperCase() &&
                k.drop(1).all { it.isLowerCase() || it == '.' || it == '-' }
        }
        return ozelAd >= 5
    }

    private fun isControllerLabel(text: String): Boolean {
        val t = text.trim().trim('.', ',', ':', ';')
        if (t.uppercase() in UI_WORDS) return true
        if (t.length > 6) return false
        if (t.uppercase() in CONTROLLER_LABELS) return true
        if (t.all { it.isDigit() || it == 'm' || it == 'M' || it == ' ' }) return true
        return false
    }

    /**
     * "JAMES: Merhaba" gibi konuşan adını ayırır. Ad çeviriye hiç girmez,
     * böylece Hope, Faith, Rose gibi isimler yanlışlıkla çevrilmez.
     */
    private fun splitSpeaker(text: String): Pair<String?, String> {
        val idx = text.indexOf(':')
        if (idx !in 1..24) return null to text
        val name = text.substring(0, idx).trim()
        val rest = text.substring(idx + 1).trim()
        if (rest.length < 2) return null to text
        if (name.any { !it.isLetter() && it != ' ' && it != '.' && it != '\'' && it != '-' }) {
            return null to text
        }
        return name to rest
    }

    private suspend fun fastTranslateKeepingName(source: String): String? {
        val (name, body) = splitSpeaker(source)
        // Sözlük + OCR düzeltme + argo/küfür kuralları + telefon çevirisi (OfflineFix.kt)
        val f = fast ?: return null
        val translated = OfflineFix.translate(body) { f.translate(it) } ?: return null
        if (translated.isBlank()) return null

        // Motorun çıktısındaki bilinen Türkçe hatalarını düzelt.
        val duzgun = TurkishFix.duzelt(translated)
        if (name != null) OfflineFix.languageLabel(name)?.let { return "[$it] $duzgun" }
        return if (name == null) duzgun else "$name: $duzgun"
    }

    private fun clean(raw: String): String {
        // OCR onarımı kaynakta: taslak, yapay zekâ, hafıza ve kayıt aynı düzeltilmiş metni görür.
        val collapsed = SoundTags.repair(OcrTextCleaner.clean(TextFix.clean(raw)))
        if (collapsed.length < 3) return ""
        val letters = collapsed.count { it.isLetter() }
        if (letters < 3) return ""
        if (letters.toFloat() / collapsed.length < 0.45f) return ""
        return collapsed
    }

    private fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun similar(a: String, b: String): Boolean {
        if (a.isEmpty() || b.isEmpty()) return a == b
        val na = normalize(a)
        val nb = normalize(b)
        if (na == nb) return true
        if (na.isEmpty() || nb.isEmpty()) return false
        val longer = if (na.length >= nb.length) na else nb
        val shorter = if (na.length >= nb.length) nb else na
        if (shorter.length.toFloat() / longer.length < 0.8f) return false
        return levenshtein(shorter, longer).toFloat() / longer.length <= 0.12f
    }

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // --------------------------------------------------------------- kapanış

    private fun stopEverything() {
        running = false
        pipelineOn.set(false)
        try {
            scope.cancel()
        } catch (_: Throwable) {
        }
        releaseDisplay()
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        fast?.close()
        fast = null
        llm?.close()
        llm = null
        ai = null
        store = null
        overlay.clearLabels()
        overlay.setSubtitle(null, 0)
        overlay.hide()
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
        recognizerClosed = true
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releaseDisplay()
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        overlay.hide()
        super.onDestroy()
    }
}
