plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.altyazi"
    compileSdk = 35

    defaultConfig {
        // Paket kimliği yeni: eski LingoPlay telefonda kalsın, Lingo onun
        // yanına ayrı bir uygulama olarak kurulsun. Namespace değişmiyor,
        // çünkü tüm kaynak dosyalar o ad altında duruyor.
        applicationId = "com.example.altyazi"  // telefondaki LingoPlay'in üstüne kurulsun
        minSdk = 31
        targetSdk = 34
        versionCode = 29
        versionName = "8.2"
    }

    // Sabit imza: her derleme aynı anahtarla imzalanır, güncelleme eskisinin üstüne kurulur.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }


    buildFeatures {
        viewBinding = false
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        jniLibs { pickFirsts.add("**/liblitertlm_jni.so") }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.mlkit:translate:17.0.2")

    // Telefonda çalışan yapay zekâ (Gemma) — internetsiz çeviri.
    // Kotlin 2.4 ile derlenmiş; bu yüzden projede Kotlin 2.3 (bir sonraki sürümü okuyabilir).
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.1")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
