package com.example.altyazi

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.EditText
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.LinearLayout
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val TURLER = listOf("Oyun", "Dizi", "Film", "Belgesel", "Video")

    /** Yazı boyutu çubuğunun başladığı değer; çubuk 0'dan saydığı için gerekli. */
    private val SUB_SIZE_MIN = 12
    /** Ses kaydırıcılarının alt sınırı, yüzde (SeekBar 0 = %50). */
    private val SES_MIN = 50
    /** requestPermissions istek kodu: mikrofon (ses algılama). */
    private val MIKROFON_IZNI = 13
    /** İki deneme repliği arasındaki bekleme (ms). */
    private val SES_DENEME_ARASI = 2600L

    private lateinit var prefs: Prefs

    private lateinit var etGame: EditText
    private lateinit var spType: Spinner
    private lateinit var etKey: EditText
    private lateinit var etGeminiKey: EditText
    private lateinit var rgProvider: RadioGroup
    private lateinit var etModel: EditText
    private lateinit var rgMode: RadioGroup
    private lateinit var cbSpeaker: CheckBox
    private lateinit var rgBicim: RadioGroup
    private lateinit var cbAccuracy: CheckBox
    private lateinit var cbDiag: CheckBox
    private lateinit var sbMinShow: SeekBar
    private lateinit var cbDogruyuBekle: CheckBox
    private lateinit var cbYalnizDogru: CheckBox
    private lateinit var cbYigin: CheckBox
    private lateinit var cbAlwaysAi: CheckBox
    private lateinit var cbFirefox: CheckBox
    private lateinit var cbGoogle: CheckBox
    private lateinit var cbOpus: CheckBox
    private lateinit var cbDeepL: CheckBox
    private lateinit var etDeepLKey: EditText

    /** Offline Translator kurulu mu, ayar ekranında yazar. */
    private fun firefoxDurumYaz() {
        val kurulu = FirefoxCeviri.kurulu(this)
        findViewById<TextView>(R.id.tvFirefoxDurum).text =
            if (kurulu) "Offline Translator kurulu. Uygulamada İngilizce ve Türkçe dil paketlerini indirdiğinizden emin olun."
            else "Offline Translator kurulu değil. Aşağıdaki düğmeyle F-Droid'den ücretsiz indirin, açıp İngilizce ve Türkçe dil paketlerini indirin."
        findViewById<Button>(R.id.btnFirefoxIndir).visibility = if (kurulu) View.GONE else View.VISIBLE
    }
    private lateinit var cbMenu: CheckBox
    private lateinit var cbMenuAlan: CheckBox
    private lateinit var btnMenuAlan: Button
    private lateinit var tvMenuAlan: TextView
    private lateinit var sbTop: SeekBar
    private lateinit var sbBottom: SeekBar
    private lateinit var sbSpeed: SeekBar
    private lateinit var tvRegion: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvError: TextView
    private lateinit var tvModels: TextView
    private lateinit var boxAdvanced: android.widget.LinearLayout
    private lateinit var tvAdvancedHeader: TextView
    private lateinit var btnToggle: Button
    private lateinit var tvCheck: TextView

    // Altyazı görünümü
    private lateinit var sbSubSize: SeekBar
    private lateinit var tvSubSize: TextView
    private lateinit var cgSubColor: ChipGroup
    private lateinit var cgSubBg: ChipGroup
    private lateinit var cgSubBgColor: ChipGroup
    private lateinit var tvPreview: TextView
    private lateinit var rgSubPos: RadioGroup
    private lateinit var cbOutline: CheckBox
    private lateinit var cbSesli: CheckBox
    private lateinit var boxSesli: View
    private lateinit var sbSesHiz: SeekBar
    private lateinit var sbSesTon: SeekBar
    private lateinit var tvSesHiz: TextView
    private lateinit var tvSesTon: TextView
    private lateinit var tvSesDurum: TextView
    private lateinit var btnSesDene: Button

    /** Yalnız "Sesi dene" için; ekran kapanınca kapatılır. */
    private var sesDeneme: SesliOku? = null

    // ------------------------------------------------- 10.54 duygu ve menü
    private lateinit var cbDuygu: CheckBox
    private lateinit var boxDuygu: LinearLayout
    private lateinit var rgDuyguNot: RadioGroup
    private lateinit var cbDuyguUnlem: CheckBox
    private lateinit var cbDuyguCumle: CheckBox
    private lateinit var cbDuyguTr: CheckBox
    private lateinit var sbDuyguSiddet: SeekBar
    private lateinit var tvDuyguSiddet: TextView
    private lateinit var tvDuyguDurum: TextView

    // ------------------------------------------- 10.55 ses akışı ve kaydı
    private lateinit var rgSesAkis: RadioGroup
    private lateinit var cbSesKaydi: CheckBox
    private lateinit var tvSesAkisOzet: TextView

    // ------------------------------------------- 10.58 doğallık ve alanlar
    private lateinit var tvDogalDurum: TextView
    private lateinit var cbSesAdsizAtla: CheckBox
    private lateinit var cbSesTekrarSuz: CheckBox
    private lateinit var boxSesCinsiyet: LinearLayout
    private lateinit var tvSesCinsiyetOzet: TextView
    private lateinit var cbYanSol: CheckBox
    private lateinit var cbYanSag: CheckBox
    private lateinit var cbMenuModu: CheckBox
    private lateinit var tvOzelDurum: TextView
    private lateinit var boxOzel: LinearLayout

    /**
     * Tablodan çizilen yazı/sayı kutuları.
     *
     * NEDEN LİSTE: bu kutular odağı kaybedince kaydediyor; kullanıcı
     * yazdıktan sonra odağı bırakmadan ekrandan çıkarsa değer uçardı.
     * Liste sayesinde kaydetme sırasında hepsi bir kez daha yazılıyor.
     */
    private val ozelYaziKutulari = ArrayList<Pair<OzelAyar.Satir, EditText>>()

    /** Ayar menüsünde açık olan bölüm; -1 ise liste görünüyor. */
    private var acikBolum = -1

    /**
     * Menü satırının gösterdiği kart kimlikleri. Boş dizi: kendi kartı
     * olmayan bölüm (Cihaz ve bağlantı ana ekranda duruyor, oraya kaydırır).
     */
    private val ayarKartIdleri: List<IntArray> = listOf(
        intArrayOf(R.id.secRegion),
        intArrayOf(R.id.secLook),
        intArrayOf(R.id.secContent, R.id.secAi),
        intArrayOf(R.id.secSes),
        intArrayOf(R.id.secDuygu),
        intArrayOf(),
        intArrayOf(R.id.secOzel),
        intArrayOf(R.id.secAdvanced),
    )

    private val ayarBasliklari = listOf(
        "Ekran alanı", "Yazı ve görünüm", "Dil ve çeviri", "Sesli okuma",
        "Duygu ve ünlemler", "Cihaz ve bağlantı", "Özel ayarlar", "Gelişmiş",
    )

    private val ayarSatirIdleri = intArrayOf(
        R.id.ayarSatir1, R.id.ayarSatir2, R.id.ayarSatir3, R.id.ayarSatir4,
        R.id.ayarSatir5, R.id.ayarSatir6, R.id.ayarSatir7, R.id.ayarSatir8,
    )

    private val ayarOzetIdleri = intArrayOf(
        R.id.ayarOzet1, R.id.ayarOzet2, R.id.ayarOzet3, R.id.ayarOzet4,
        R.id.ayarOzet5, R.id.ayarOzet6, R.id.ayarOzet7, R.id.ayarOzet8,
    )

    /** Tabloyu seçtirir; içe aktarma bunun sonucunda yapılır. */
    private val ozelTabloSec =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) ozelTabloyuAktar(uri)
        }
    private lateinit var cbSesCinsiyet: CheckBox
    private lateinit var cbSesKarakter: CheckBox
    private lateinit var cbSesInternet: CheckBox
    private lateinit var cbSesDogalGenAi: CheckBox
    private lateinit var cbSesCanliAlgila: CheckBox
    private lateinit var btnSesTara: Button
    private lateinit var boxSesSecim: View
    private lateinit var spSesErkek: Spinner
    private lateinit var spSesKadin: Spinner
    private lateinit var btnSesErkekDene: Button
    private lateinit var btnSesKadinDene: Button
    private lateinit var spSesVarsayilan: Spinner
    private lateinit var btnSesVarsayilanDene: Button

    /** Taranan Türkçe sesler; spinner sırası bununla aynı (0 = "en iyi ses"). */
    private var bulunanSesler: List<SesliOku.SesBilgi> = emptyList()

    /** Ölçüm sonuçları; spinner satırlarında gösterilir. */
    private var sesOlcumleri: List<SesliOku.SesOlcumu> = emptyList()

    /**
     * Spinner'lar kurulurken gelen ilk seçim olayı yok sayılır.
     *
     * ANDROID TUZAĞI: adapter atanıp setSelection çağrıldığında Spinner
     * yerleşimden sonra onItemSelected'ı kendiliğinden tetikler. Dinleyici o
     * sırada bağlıysa, kayıtlı ses seçimi "En iyi ses" (0. sıra) ile
     * ezilebiliyordu.
     */
    private var sesSpinnerKuruluyor = false

    private lateinit var projectionLauncher: ActivityResultLauncher<Intent>

    /** Telefondaki yapay zekâ modeli kartı (indir / dosyadan seç). */
    private var modelSetup: ModelSetup? = null
    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) modelSetup?.copyFrom(uri)
    }
    private val pickOpusPack = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            findViewById<TextView>(R.id.tvOpusStatus).text = "OPUS-MT modeli içe aktarılıyor..."
            Thread {
                val error = OpusModelPack.import(applicationContext, uri)
                runOnUiThread {
                    findViewById<TextView>(R.id.tvOpusStatus).text = if (error == null)
                        "OPUS-MT paketi yüklendi. 11 replik karşılaştırmasında hızını ölçün."
                    else "OPUS-MT yüklenemedi: $error"
                    if (error == null) findViewById<CheckBox>(R.id.cbOpus).isChecked = true
                }
            }.start()
        }
    }

    /** Arayüz kurulduysa true. Kurulamadıysa güvenli ekrandayız. */
    private var uiReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
            uiReady = true
        } catch (e: Throwable) {
            CrashLog.note(this, "acilis ekrani", e)
            showSafeScreen()
        }
        // Animasyonlu giriş: yalnızca uygulama ilk açılırken (ekran dönünce tekrar oynamasın).
        if (savedInstanceState == null) {
            try { GirisAnimasyonu.goster(this) } catch (_: Throwable) {}
        }
    }

    /** Arayüz kurulamazsa uygulama kapanmasın; hatayı ekranda göster. */
    private fun showSafeScreen() {
        val info = TextView(this).apply {
            setPadding(40, 60, 40, 40)
            textSize = 13f
            text = "Uygulama açılırken bir sorun çıktı.\n\n" +
                (CrashLog.read(this@MainActivity) ?: "Ayrıntı kaydedilemedi.") +
                "\n\nBu yazıyı kopyalayıp sohbete yapıştırın."
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(info) }
        setContentView(scroll)
    }

    private fun buildUi() {
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)

        etGame = findViewById(R.id.etGame)
        spType = findViewById(R.id.spType)
        spType.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, TURLER
        )
        spType.setSelection(TURLER.indexOf(prefs.contentType).coerceAtLeast(0))
        etKey = findViewById(R.id.etKey)
        etGeminiKey = findViewById(R.id.etGeminiKey)
        rgProvider = findViewById(R.id.rgProvider)
        etModel = findViewById(R.id.etModel)
        rgMode = findViewById(R.id.rgMode)
        cbSpeaker = findViewById(R.id.cbSpeaker)
        cbFirefox = findViewById(R.id.cbFirefox)
        cbGoogle = findViewById(R.id.cbGoogle)
        cbOpus = findViewById(R.id.cbOpus)
        cbDeepL = findViewById(R.id.cbDeepL)
        etDeepLKey = findViewById(R.id.etDeepLKey)
        etDeepLKey.setText(DeepLCredentials.read(this))
        findViewById<Button>(R.id.btnModelCleanup).setOnClickListener { confirmModelCleanup() }
        findViewById<TextView>(R.id.tvOpusStatus).text = OpusModelPack.status(this)
        findViewById<Button>(R.id.btnOpusImport).setOnClickListener {
            pickOpusPack.launch(arrayOf("application/zip", "application/octet-stream"))
        }
        firefoxDurumYaz()
        findViewById<Button>(R.id.btnFirefoxIndir).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(FirefoxCeviri.INDIRME)))
            } catch (_: Throwable) {
                Toast.makeText(this, FirefoxCeviri.INDIRME, Toast.LENGTH_LONG).show()
            }
        }
        rgBicim = findViewById(R.id.rgBicim)
        cbAccuracy = findViewById(R.id.cbAccuracy)
        cbDiag = findViewById(R.id.cbDiag)
        sbMinShow = findViewById(R.id.sbMinShow)
        sbMinShow.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = minShowEtiketi()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { prefs.minShowSec = sbMinShow.progress }
        })
        cbDogruyuBekle = findViewById(R.id.cbDogruyuBekle)
        cbYalnizDogru = findViewById(R.id.cbYalnizDogru)
        cbYigin = findViewById(R.id.cbYigin)
        cbAlwaysAi = findViewById(R.id.cbAlwaysAi)
        cbMenu = findViewById(R.id.cbMenu)
        sbTop = findViewById(R.id.sbTop)
        sbBottom = findViewById(R.id.sbBottom)
        sbSpeed = findViewById(R.id.sbSpeed)
        tvRegion = findViewById(R.id.tvRegion)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvStatus = findViewById(R.id.tvStatus)
        val tvCihaz = TvMode.isTvDevice(this)
        try {
            val box = findViewById<LinearLayout>(R.id.boxModel)
            // TV'de yapay zekâ yok (bellek yetmez): 3,6 GB model indirme kartı gösterilmez.
            if (tvCihaz) box.visibility = View.GONE
            else modelSetup = ModelSetup(this) { pickModel.launch(arrayOf("*/*")) }.also { it.attach(box, 0) }
        } catch (e: Throwable) {
            CrashLog.note(this, "model karti", e)
        }
        if (tvCihaz) {
            try { findViewById<View>(R.id.cbAccuracy)?.visibility = View.GONE } catch (_: Throwable) {}
        }
        try {
            baglaGezinti()
        } catch (e: Throwable) {
            CrashLog.note(this, "gezinti", e)
        }
        try {
            duyguKur()
        } catch (e: Throwable) {
            CrashLog.note(this, "duygu ayarlari", e)
        }
        try {
            sesAkisiKur()
        } catch (e: Throwable) {
            CrashLog.note(this, "ses akisi", e)
        }
        try {
            dogallikKur()
        } catch (e: Throwable) {
            CrashLog.note(this, "dogallik", e)
        }
        try {
            yanAlanlariKur()
        } catch (e: Throwable) {
            CrashLog.note(this, "yan alanlar", e)
        }
        try {
            tvDuzeni()
        } catch (e: Throwable) {
            CrashLog.note(this, "tv duzeni", e)
        }
        try {
            ozelKur()
        } catch (e: Throwable) {
            CrashLog.note(this, "ozel ayarlar", e)
        }
        try {
            ayarMenusuKur()
        } catch (e: Throwable) {
            CrashLog.note(this, "ayar menusu", e)
        }
        findViewById<TextView>(R.id.tvVersion).text =
            "sürüm " + (packageManager.getPackageInfo(packageName, 0).versionName ?: "?")

        etGame.setText(prefs.gameName)
        etKey.setText(prefs.apiKey)
        etGeminiKey.setText(prefs.geminiKey)
        findViewById<RadioButton>(
            if (prefs.provider == Prefs.PROVIDER_ANTHROPIC) R.id.rbAnthropic else R.id.rbGemini
        ).isChecked = true
        // Kutuda, seçili sağlayıcının modeli görünsün.
        etModel.setText(
            if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel else prefs.model
        )
        // 9.91: eski kutu bileşimleri temizlenir, ekranda tek seçim görünür.
        prefs.bicimiOnar()
        findViewById<RadioButton>(
            when (prefs.ceviriBicimi) {
                Prefs.BICIM_HIZLI -> R.id.rbBicimHizli
                Prefs.BICIM_DOGRU -> R.id.rbBicimDogru
                else -> R.id.rbBicimDengeli
            }
        ).isChecked = true
        findViewById<RadioButton>(
            when (prefs.mode) {
                Prefs.MODE_AI -> R.id.rbAi
                Prefs.MODE_HYBRID -> R.id.rbHybrid
                else -> R.id.rbInstant
            }
        ).isChecked = true
        cbSpeaker.isChecked = prefs.showSpeaker
        cbFirefox.isChecked = prefs.firefoxMotoru
        cbGoogle.isChecked = prefs.googleCeviri
        cbOpus.isChecked = prefs.opusMtEnabled
        cbDeepL.isChecked = prefs.deepLEnabled
        cbAccuracy.isChecked = prefs.accuracyFirst
        cbDiag.isChecked = prefs.diagnostics
        sbMinShow.progress = prefs.minShowSec
        minShowEtiketi()
        cbDogruyuBekle.isChecked = prefs.dogruyuBekle
        cbYalnizDogru.isChecked = prefs.yalnizDogru
        cbYigin.isChecked = prefs.yigin
        cbAlwaysAi.isChecked = prefs.alwaysAi
        cbMenu.isChecked = prefs.menuTranslate
        cbMenuAlan = findViewById(R.id.cbMenuAlan)
        btnMenuAlan = findViewById(R.id.btnMenuAlan)
        tvMenuAlan = findViewById(R.id.tvMenuAlan)
        cbMenuAlan.isChecked = prefs.menuAlanAcik
        cbMenuAlan.setOnCheckedChangeListener { _, acik ->
            prefs.menuAlanAcik = acik
            menuAlanOzeti()
        }
        btnMenuAlan.setOnClickListener {
            startActivity(
                Intent(this, RegionActivity::class.java)
                    .putExtra(RegionActivity.EK_MENU_ALANI, true)
            )
        }
        menuAlanOzeti()
        sbTop.progress = prefs.topPct
        sbBottom.progress = prefs.bottomPct
        sbSpeed.progress = (prefs.intervalMs - 100).coerceIn(0, 900)
        updateRegionLabel()
        updateSpeedLabel()

        val regionListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateRegionLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        sbTop.setOnSeekBarChangeListener(regionListener)
        sbBottom.setOnSeekBarChangeListener(regionListener)
        // Tek dokunuşla en sık durum: altyazı ekranın en altında (YouTube, çoğu oyun).
        findViewById<Button>(R.id.btnRegionBottom)?.setOnClickListener {
            sbTop.progress = 72
            sbBottom.progress = 95
            updateRegionLabel()
            save()
            Toast.makeText(this, "Altyazı bölgesi: ekranın %72 – %95 arası", Toast.LENGTH_SHORT).show()
        }
        // 9.93: hızlı konumlar — üst bölge ve tam ekran
        findViewById<Button>(R.id.btnRegionTop)?.setOnClickListener {
            sbTop.progress = 4
            sbBottom.progress = 28
            updateRegionLabel()
            save()
            Toast.makeText(this, "Altyazı bölgesi: ekranın üstü (%4 – %28)", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnRegionFull)?.setOnClickListener {
            sbTop.progress = 0
            sbBottom.progress = 100
            updateRegionLabel()
            save()
            Toast.makeText(this, "Altyazı bölgesi: tam ekran (daha yavaş okur)", Toast.LENGTH_SHORT).show()
        }

        sbSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = updateSpeedLabel()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // ------------------------------------------- altyazı görünümü
        sbSubSize = findViewById(R.id.sbSubSize)
        tvSubSize = findViewById(R.id.tvSubSize)
        cgSubColor = findViewById(R.id.cgSubColor)
        cgSubBg = findViewById(R.id.cgSubBg)
        cgSubBgColor = findViewById(R.id.cgSubBgColor)
        tvPreview = findViewById(R.id.tvPreview)
        rgSubPos = findViewById(R.id.rgSubPos)
        cbOutline = findViewById(R.id.cbOutline)

        sbSubSize.progress = (prefs.subtitleSize - SUB_SIZE_MIN).coerceIn(0, sbSubSize.max)
        updateSubSizeLabel()
        sbSubSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) =
                updateSubSizeLabel()

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Chip>(
            when (prefs.subtitleColor) {
                Prefs.COLOR_YELLOW -> R.id.chColYellow
                Prefs.COLOR_GREEN -> R.id.chColGreen
                Prefs.COLOR_CYAN -> R.id.chColCyan
                else -> R.id.chColWhite
            }
        ).isChecked = true

        findViewById<Chip>(
            when (prefs.subtitleBg) {
                Prefs.BG_SOLID -> R.id.chBgSolid
                Prefs.BG_NONE -> R.id.chBgNone
                else -> R.id.chBgSemi
            }
        ).isChecked = true

        findViewById<Chip>(
            when (prefs.subtitleBgColor) {
                Prefs.BGC_GRAY -> R.id.chBgcGray
                Prefs.BGC_NAVY -> R.id.chBgcNavy
                else -> R.id.chBgcBlack
            }
        ).isChecked = true

        // Ayar her değiştiğinde önizleme de değişsin.
        val onizlemeDinleyici = ChipGroup.OnCheckedStateChangeListener { _, _ ->
            onizlemeyiGuncelle()
        }
        cgSubColor.setOnCheckedStateChangeListener(onizlemeDinleyici)
        cgSubBg.setOnCheckedStateChangeListener(onizlemeDinleyici)
        cgSubBgColor.setOnCheckedStateChangeListener(onizlemeDinleyici)

        findViewById<RadioButton>(
            when (prefs.subtitlePos) {
                Prefs.POS_COVER -> R.id.rbPosCover
                Prefs.POS_BELOW -> R.id.rbPosBelow
                Prefs.POS_BOTTOM -> R.id.rbPosBottom
                else -> R.id.rbPosAbove
            }
        ).isChecked = true

        cbOutline.isChecked = prefs.subtitleOutline
        cbOutline.setOnCheckedChangeListener { _, _ -> onizlemeyiGuncelle() }
        onizlemeyiGuncelle()

        // ------------------------------------------- sesli okuma (10.43)
        cbSesli = findViewById(R.id.cbSesli)
        boxSesli = findViewById(R.id.boxSesli)
        sbSesHiz = findViewById(R.id.sbSesHiz)
        sbSesTon = findViewById(R.id.sbSesTon)
        tvSesHiz = findViewById(R.id.tvSesHiz)
        tvSesTon = findViewById(R.id.tvSesTon)
        tvSesDurum = findViewById(R.id.tvSesDurum)
        btnSesDene = findViewById(R.id.btnSesDene)

        cbSesli.isChecked = prefs.sesliOku
        boxSesli.visibility = if (prefs.sesliOku) View.VISIBLE else View.GONE
        sbSesHiz.progress = (prefs.sesHiz - SES_MIN).coerceIn(0, sbSesHiz.max)
        sbSesTon.progress = (prefs.sesTon - SES_MIN).coerceIn(0, sbSesTon.max)
        sesEtiketleri()

        cbSesli.setOnCheckedChangeListener { _, acik ->
            boxSesli.visibility = if (acik) View.VISIBLE else View.GONE
            prefs.sesliOku = acik
            if (!acik) {
                sesDeneme?.kapat()
                sesDeneme = null
                tvSesDurum.text = ""
            }
            if (CaptureService.running) {
                tvSesDurum.text = "Değişikliğin geçerli olması için çeviriyi durdurup yeniden başlatın."
            }
        }

        val sesListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = sesEtiketleri()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                prefs.sesHiz = sbSesHiz.progress + SES_MIN
                prefs.sesTon = sbSesTon.progress + SES_MIN
                sesDeneme?.hiz = prefs.sesHiz / 100f
                sesDeneme?.ton = prefs.sesTon / 100f
            }
        }
        sbSesHiz.setOnSeekBarChangeListener(sesListener)
        sbSesTon.setOnSeekBarChangeListener(sesListener)

        btnSesDene.setOnClickListener { sesiDene() }

        cbSesCinsiyet = findViewById(R.id.cbSesCinsiyet)
        btnSesTara = findViewById(R.id.btnSesTara)
        boxSesSecim = findViewById(R.id.boxSesSecim)
        spSesErkek = findViewById(R.id.spSesErkek)
        spSesKadin = findViewById(R.id.spSesKadin)
        btnSesErkekDene = findViewById(R.id.btnSesErkekDene)
        btnSesKadinDene = findViewById(R.id.btnSesKadinDene)

        cbSesCinsiyet.isChecked = prefs.sesCinsiyet
        // 10.60: durum satırı artık bu iki anahtara bakıyor, değişince yenilensin.
        cbSesCinsiyet.setOnCheckedChangeListener { _, acik ->
            prefs.sesCinsiyet = acik
            sesEtiketleri()
            ayarOzetleriYaz()
        }
        cbSesKarakter = findViewById(R.id.cbSesKarakter)
        cbSesKarakter.isChecked = prefs.sesKarakter
        cbSesKarakter.setOnCheckedChangeListener { _, acik ->
            prefs.sesKarakter = acik
            sesEtiketleri()
            ayarOzetleriYaz()
        }
        cbSesDogalGenAi = findViewById(R.id.cbSesDogalGenAi)
        cbSesDogalGenAi.isChecked = prefs.sesDogalGenAi
        cbSesDogalGenAi.setOnCheckedChangeListener { _, acik ->
            prefs.sesDogalGenAi = acik
            // Deneme motoru yeniden kurulsun ki değişiklik "Sesi dene"de duyulsun.
            sesDeneme?.kapat()
            sesDeneme = null
            dogalDurumYaz()
            tvSesDurum.text = "Doğal ses ayarı değişti. Denemek için \"Sesi dene\"ye basın; " +
                "çeviri çalışıyorsa durdurup yeniden başlatın."
        }

        cbSesCanliAlgila = findViewById(R.id.cbSesCanliAlgila)
        cbSesCanliAlgila.isChecked = prefs.sesCanliAlgila
        cbSesCanliAlgila.setOnCheckedChangeListener { _, acik ->
            prefs.sesCanliAlgila = acik
            tvSesDurum.text = if (acik)
                "Ses algılama açıldı. BAŞLAT'a bastığınızda mikrofon izni istenecek."
            else "Ses algılama kapatıldı."
        }

        cbSesInternet = findViewById(R.id.cbSesInternet)
        cbSesInternet.isChecked = prefs.sesInternet
        cbSesInternet.setOnCheckedChangeListener { _, acik ->
            prefs.sesInternet = acik
            sesDeneme?.let { sesAyarlariniUygula(it) }
            if (sesOlcumleri.isNotEmpty()) sesleriAta(sesOlcumleri)
        }
        btnSesTara.setOnClickListener { sesleriTara() }
        btnSesErkekDene.setOnClickListener { sesCinsiyetDene(true) }
        btnSesKadinDene.setOnClickListener { sesCinsiyetDene(false) }
        spSesVarsayilan = findViewById(R.id.spSesVarsayilan)
        btnSesVarsayilanDene = findViewById(R.id.btnSesVarsayilanDene)
        btnSesVarsayilanDene.setOnClickListener {
            sesMotoru { s ->
                s.sus()
                // Adsız replik: varsayılan ses yolundan geçsin.
                s.oku("Bu, konuşan adı olmayan bir altyazı repliği.")
            }
        }

        projectionLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
                showRunning(true)
                moveTaskToBack(true)
            } else {
                tvStatus.text = "Ekran yakalama izni verilmedi."
            }
        }

        tvError = findViewById(R.id.tvError)
        tvModels = findViewById(R.id.tvModels)
        boxAdvanced = findViewById(R.id.boxAdvanced)
        tvAdvancedHeader = findViewById(R.id.tvAdvancedHeader)
        btnToggle = findViewById(R.id.btnToggle)
        tvCheck = findViewById(R.id.tvCheck)
        findViewById<Button>(R.id.btnCheck).setOnClickListener { runSetupCheck() }
        findViewById<Button>(R.id.btnRegion).setOnClickListener {
            startActivity(Intent(this, RegionActivity::class.java))
        }

        tvAdvancedHeader.setOnClickListener {
            val open = boxAdvanced.visibility == View.VISIBLE
            boxAdvanced.visibility = if (open) View.GONE else View.VISIBLE
            tvAdvancedHeader.text = if (open) "Gelişmiş ▸" else "Gelişmiş ▾"
        }

        findViewById<Button>(R.id.btnFindModels).setOnClickListener { findModels() }
        findViewById<Button>(R.id.btnCopyError).setOnClickListener { copyError() }
        findViewById<Button>(R.id.btnClearError)?.setOnClickListener {
            CrashLog.clear(this)
            tvError.text = "Kayıtlı hata yok."
            Toast.makeText(this, "Son hata silindi.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnCopyLog).setOnClickListener { copyLog() }
        findViewById<Button>(R.id.btnClearLog)?.setOnClickListener {
            CaptureService.clearLog()
            tvError.text = ""
            Toast.makeText(
                this,
                "Kayıt temizlendi. Şimdi oyuna dönüp tek bir sahne oynayın, sonra kaydı kopyalayın.",
                Toast.LENGTH_LONG,
            ).show()
        }
        findViewById<Button>(R.id.btnPreview)?.setOnClickListener { onizlemeGoster() }

        tvSecimiBagla()

        btnToggle.setOnClickListener {
            save()
            if (CaptureService.running) {
                startService(
                    Intent(this, CaptureService::class.java)
                        .setAction(CaptureService.ACTION_STOP)
                )
                showRunning(false)
            } else {
                if (EngineBenchmark1035.running) {
                    Toast.makeText(this, "Model testi sürüyor. Önce testi bitirin veya iptal edin.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                start()
            }
        }

        showRunning(CaptureService.running)
    }

    /**
     * Kurulum kontrolü: üç şeyi sırayla dener ve sonucu yazar.
     * Amaç, sorunun oyun sırasında değil burada ortaya çıkması.
     */
    private fun runSetupCheck() {
        save()
        tvCheck.text = "Kontrol ediliyor…"
        val prefsLocal = prefs

        Thread {
            val report = StringBuilder()

            // 1) Ekran üstüne çizme izni
            report.append(
                if (Settings.canDrawOverlays(this)) "✓ Ekran üstüne çizme izni var\n"
                else "✗ Ekran üstüne çizme izni yok — BAŞLAT'a basınca isteyecek\n"
            )

            // 2) Telefon içi Türkçe model
            val fastEngine = FastTranslate()
            val fastOk = kotlinx.coroutines.runBlocking {
                fastEngine.prepare() && !fastEngine.translate("Hello there").isNullOrBlank()
            }
            report.append(
                if (fastOk) "✓ İnternetsiz Türkçe model hazır\n"
                else "✗ İnternetsiz model inmedi (" + (fastEngine.lastError ?: "sebep yok") + ")\n"
            )
            fastEngine.close()

            // 3) Yapay zekâ çevirisi
            if (prefsLocal.activeKey.isBlank()) {
                report.append("• API anahtarı girilmemiş — yapay zekâ modu çalışmaz\n")
            } else {
                val engine = AiTranslate(prefsLocal)
                var result = kotlinx.coroutines.runBlocking { engine.translate("He is waiting outside.") }
                if (result.isNullOrBlank()) {
                    // Model adı sorunluysa hesaptaki gerçek modeli seç ve tekrar dene.
                    val best = engine.pickBest(engine.fetchModels(prefsLocal.activeKey))
                    if (best != null) {
                        if (prefsLocal.provider == Prefs.PROVIDER_GEMINI) prefsLocal.geminiModel = best
                        else prefsLocal.model = best
                        result = kotlinx.coroutines.runBlocking { engine.translate("He is waiting outside.") }
                    }
                }
                report.append(
                    if (!result.isNullOrBlank()) "✓ Yapay zekâ çevirisi çalışıyor (" + (if (prefsLocal.provider == Prefs.PROVIDER_GEMINI) prefsLocal.geminiModel else prefsLocal.model) + ")\n"
                    else "✗ Yapay zekâ çevirisi başarısız: " + (engine.lastError ?: "bilinmeyen") + "\n"
                )
            }

            runOnUiThread {
                tvCheck.text = report.toString().trim()
                etModel.setText(if (prefsLocal.provider == Prefs.PROVIDER_GEMINI) prefsLocal.geminiModel else prefsLocal.model)
            }
        }.start()
    }

    /** Yanlışlıkla yapıştırılan metinlerin anahtar sanılmasını engeller. */
    private fun cleanKey(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return ""
        // Birden fazla kelime veya Türkçe karakter varsa bu bir anahtar değildir.
        if (t.contains(" ") || t.any { it.code < 33 || it.code > 126 }) return ""
        return t
    }

    private fun secModel(ad: String) {
        if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel = ad else prefs.model = ad
        etModel.setText(ad)
    }

    /** Bulunan modelleri listeler; istediğinizi seçebilirsiniz. */
    private fun modelListesiniGoster(models: List<String>) {
        if (models.isEmpty()) return
        val dizi = models.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Model seçin")
            .setItems(dizi) { _, hangi -> secModel(dizi[hangi]) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showRunning(running: Boolean) {
        btnToggle.text = if (running) "DURDUR" else "ÇEVİRİYİ BAŞLAT"
        tvStatus.text = if (running) {
            "Çalışıyor · Chiaki'yi açıp oyuna girebilirsiniz"
        } else {
            "Durduruldu"
        }
    }

    override fun onResume() {
        super.onResume()
        // Alan seçme ekranından dönülmüş olabilir: özet ve kutu tazelensin.
        if (::cbMenuAlan.isInitialized) {
            cbMenuAlan.isChecked = prefs.menuAlanAcik
            menuAlanOzeti()
        }
        try { firefoxDurumYaz() } catch (_: Throwable) {}
        // Bölge seçme ekranından dönülmüş olabilir: menü özetleri tazelensin.
        try { ayarOzetleriYaz() } catch (_: Throwable) {}
        try { sesAkisOzetiYaz() } catch (_: Throwable) {}
        try { dogalDurumYaz() } catch (_: Throwable) {}
        try { if (::boxSesCinsiyet.isInitialized) sesCinsiyetleriniCiz() } catch (_: Throwable) {}
        try { if (::cbYanSol.isInitialized) yanAlanOzetleri() } catch (_: Throwable) {}
        visible = true
        if (!uiReady) return
        try {
            TvMode.autoUpdate(this, prefs)
            tvSecimiGoster()
        } catch (_: Throwable) {
        }
        // Çeviri alanı ekranında (RegionActivity) kaydedilen yeni bölgeyi çubuklara da yansıt;
        // yoksa buradan çıkarken eski çubuk değerleri yeni alanın üstüne yazılıyordu.
        try {
            sbTop.progress = prefs.topPct
            sbBottom.progress = prefs.bottomPct
            updateRegionLabel()
        } catch (_: Throwable) {
        }
        try {
            showRunning(CaptureService.running)
            modelSetup?.onResume()
            durumuGuncelle()
            tvModels.text = AiTranslate.summary()
            showError()
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        modelSetup?.onDestroy()
        sesDeneme?.kapat()
        sesDeneme = null
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
        visible = false
        if (!uiReady) return
        modelSetup?.onPause()
        ui.removeCallbacksAndMessages(null)
        try {
            save()
        } catch (_: Throwable) {
        }
    }

    /** Hesaptaki gerçek model adlarını bulur ve en hızlısını seçer. */
    private fun findModels() {
        save()
        val key = prefs.activeKey
        if (key.isBlank()) {
            tvModels.text = if (prefs.provider == Prefs.PROVIDER_GEMINI)
                "Google AI Studio anahtarı girilmemiş ya da hatalı. Kutuyu temizleyip " +
                    "AIza ile başlayan anahtarı yapıştırın."
            else "Anthropic API anahtarı girilmemiş ya da hatalı."
            return
        }
        tvModels.text = "Modeller aranıyor..."
        Thread {
            val engine = AiTranslate(prefs)
            val models = engine.fetchModels(key)
            val best = engine.pickBest(models)
            runOnUiThread {
                if (models.isEmpty()) {
                    tvModels.text = "Model listesi alınamadı: " + (engine.lastError ?: "bilinmeyen hata")
                    return@runOnUiThread
                }
                if (best != null) {
                    secModel(best)
                }
                modelListesiniGoster(models)
                tvModels.text = "Seçilen: " + (best ?: "-") +
                    "\n\nHesabınızdaki modeller:\n" + models.joinToString("\n")
            }
        }.start()
    }

    private fun showError() {
        val text = CrashLog.read(this)
        if (text.isNullOrBlank()) {
            tvError.text = "Kayıtlı hata yok."
        } else {
            tvError.text = text
        }
    }

    /** Çalışma kaydı: ekrandan ne okundu, ne çevrildi, hata var mı. */
    private fun copyLog() {
        val text = AiTranslate.summary() + "\n\n" + CaptureService.dumpLog()
        tvError.text = text
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Lingo kaydı", text))
        Toast.makeText(this, "Çalışma kaydı kopyalandı, sohbete yapıştırın.", Toast.LENGTH_LONG).show()
    }

    private fun copyError() {
        val text = CrashLog.read(this)
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Kayıtlı hata yok.", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Lingo hata", text))
        Toast.makeText(this, "Hata kopyalandı, sohbete yapıştırabilirsiniz.", Toast.LENGTH_LONG).show()
    }

    /** "Çeviri ekranda en az: N sn" etiketini günceller. */
    private fun minShowEtiketi() {
        val sn = sbMinShow.progress.coerceIn(1, 10)
        findViewById<TextView>(R.id.tvMinShow)?.text =
            "Çeviri ekranda en az: $sn sn · uzun satırlar kendiliğinden daha uzun durur"
    }

    private fun updateRegionLabel() {
        tvRegion.text = "Altyazının bulunduğu bölge: ekranın %${sbTop.progress} – %${sbBottom.progress} arası"
        // Her çubuğun yanında da yüzdesi görünsün (TV'de kumandayla ayarlarken kolay olsun).
        findViewById<TextView>(R.id.tvTopPct)?.text = "Üst sınır: %${sbTop.progress}"
        findViewById<TextView>(R.id.tvBottomPct)?.text = "Alt sınır: %${sbBottom.progress}"
    }

    private fun updateSubSizeLabel() {
        tvSubSize.text = "Yazı boyutu: ${sbSubSize.progress + SUB_SIZE_MIN}"
        onizlemeyiGuncelle()
    }

    // ------------------------------------------------ sesli okuma (10.43)

    /** Seçili yan yazı alanını kullanıcıya yüzde olarak gösterir. */
    private fun menuAlanOzeti() {
        if (!::tvMenuAlan.isInitialized) return
        tvMenuAlan.text = if (prefs.menuAlanAcik)
            "Seçili alan — yatay %${prefs.menuLeftPct}–%${prefs.menuRightPct}, " +
                "dikey %${prefs.menuTopPct}–%${prefs.menuBottomPct}"
        else "Alan seçilmedi; ekranın üst yarısına bakılıyor."
    }

    private fun sesEtiketleri() {
        if (!::tvSesHiz.isInitialized) return
        tvSesHiz.text = "Konuşma hızı · %${sbSesHiz.progress + SES_MIN}"
        tvSesTon.text = "Ses tonu · %${sbSesTon.progress + SES_MIN}" +
            when {
                sbSesTon.progress + SES_MIN < 90 -> " (kalın)"
                sbSesTon.progress + SES_MIN > 110 -> " (ince)"
                else -> ""
            }
    }

    /**
     * Motoru hazırlayıp sonucu [sonra]'ya verir. Motor zaten açıksa anında.
     * "Sesi dene", "sesleri tara" ve cinsiyet denemeleri bunu kullanır.
     */
    private fun sesMotoru(sonra: (SesliOku) -> Unit) {
        val mevcut = sesDeneme
        if (mevcut != null && mevcut.hazirMi()) {
            sesAyarlariniUygula(mevcut)
            sonra(mevcut)
            return
        }
        if (mevcut != null) return   // açılış sürüyor, ikinci motor kurma
        tvSesDurum.text = "Konuşma motoru açılıyor…"
        val yeni = SesliOku(this)
        sesDeneme = yeni
        sesAyarlariniUygula(yeni)
        yeni.baslat { ok, mesaj ->
            tvSesDurum.text = mesaj
            if (ok) sonra(yeni)
        }
    }

    /** Ekrandaki ayarları deneme motoruna yazar. */
    private fun sesAyarlariniUygula(s: SesliOku) {
        prefs.sesHiz = sbSesHiz.progress + SES_MIN
        prefs.sesTon = sbSesTon.progress + SES_MIN
        s.hiz = prefs.sesHiz / 100f
        s.ton = prefs.sesTon / 100f
        s.adiAtla = prefs.showSpeaker
        s.cinsiyetAyrimi = cbSesCinsiyet.isChecked
        s.karakterAyrimi = cbSesKarakter.isChecked
        s.erkekSesAdi = prefs.sesErkekAdi
        s.kadinSesAdi = prefs.sesKadinAdi
        s.internetSesi = cbSesInternet.isChecked
        s.havuz = SesHavuzu.oku(prefs.sesHavuzu)
        s.varsayilanSesAdi = prefs.sesVarsayilanAdi
        s.dogalSesAcik = cbSesDogalGenAi.isChecked
        // Duygu kontrolleri henüz bağlanmamış olabilir (kuruluş sırası):
        // o durumda kayıtlı ayarlar kullanılır.
        s.akisModu = prefs.sesAkisModu
        if (::cbDuygu.isInitialized) {
            duyguAyarlariniUygula(s)
        } else {
            s.duyguAcik = prefs.duyguAcik
            s.duyguNotModu = prefs.duyguNotModu
            s.duyguUnlem = prefs.duyguUnlem
            s.duyguCumle = prefs.duyguCumle
            s.duyguTr = prefs.duyguTr
            s.duyguSiddet = prefs.duyguSiddet / 100f
        }
    }

    /**
     * Telefondaki Türkçe sesleri listeler ve iki seçim kutusunu doldurur.
     *
     * NEDEN ELLE SEÇİM: Android'in `Voice` sınıfı cinsiyet bildirmiyor.
     * Hangi sesin erkek hangisinin kadın olduğunu ancak dinleyerek
     * anlayabiliyoruz, o yüzden seçimi kullanıcı yapıyor.
     */
    /**
     * HAVUZ BOŞSA KENDİLİĞİNDEN TARA (10.58)
     *
     * 19 Kasım kaydında 20 repliğin hepsi aynı sesle okundu, çünkü
     * taranan havuz boştu ve seçecek ikinci ses yoktu: erkek karakter
     * de kadın sesiyle çıkıyordu. Kullanıcının bir düğmeye basmasına
     * bağlı kalmamalı; kurulumda havuz silinince sessizce bozuluyor.
     */
    private fun havuzBossaTara() {
        if (otomatikTaramaYapildi) return
        if (prefs.sesHavuzu.isNotBlank()) return
        if (!prefs.sesliOku) return
        otomatikTaramaYapildi = true
        ui.postDelayed({
            try {
                if (prefs.sesHavuzu.isBlank()) sesleriTara()
            } catch (e: Throwable) {
                CrashLog.note(this, "otomatik ses taramasi", e)
            }
        }, 1200L)
    }

    private var otomatikTaramaYapildi = false

    private fun sesleriTara() {
        tvSesDurum.text = "Sesler taranıyor, her ses ölçülüyor…"
        sesMotoru { s ->
            bulunanSesler = s.bulunanSesler()
            if (bulunanSesler.isEmpty()) {
                boxSesSecim.visibility = View.GONE
                tvSesDurum.text = "Konuşma motoru ayrı ses listesi vermiyor. " +
                    "Erkek/kadın ayrımı perdeyle yapılacak: erkek kalın, kadın ince."
                return@sesMotoru
            }
            // Her sesi sessizce dosyaya okutup perdesini ölçer; hoparlörden
            // ses çıkmaz. Birkaç saniye sürebilir.
            s.seslerIncele(
                onIlerleme = { kacinci, toplam ->
                    tvSesDurum.text = "Sesler ölçülüyor… ($kacinci/$toplam)"
                },
            ) { olcumler ->
                sesOlcumleri = olcumler
                // Havuz kaydedilir: çeviri servisi yeniden ölçmesin.
                prefs.sesHavuzu = SesHavuzu.yaz(
                    olcumler.map {
                        SesHavuzu.Kayit(it.ses.ad, it.hz, it.cinsiyet, it.ses.agGerekir)
                    }
                )
                sesleriAta(olcumler)
            }
        }
    }

    /**
     * Ölçüm sonuçlarına göre erkek ve kadın sesini KENDİLİĞİNDEN atar.
     *
     * Önce açıkça erkek/kadın çıkanlara bakılır. Hiçbiri sınıflanamadıysa
     * ama en az iki ses ölçülebildiyse en kalın olan erkek, en ince olan
     * kadın sayılır: ayrım yapmak, hiç yapmamaktan iyidir.
     */
    private fun sesleriAta(olcumler: List<SesliOku.SesOlcumu>) {
        val olculen = olcumler.filter { it.olculdu }
        val erkekler = olculen.filter { it.cinsiyet == SesPerdeOlcer.ERKEK }
        val kadinlar = olculen.filter { it.cinsiyet == SesPerdeOlcer.KADIN }

        var erkekAd = erkekler.minByOrNull { it.hz }?.ses?.ad ?: ""
        var kadinAd = kadinlar.maxByOrNull { it.hz }?.ses?.ad ?: ""

        if ((erkekAd.isEmpty() || kadinAd.isEmpty()) && olculen.size >= 2) {
            val enKalin = olculen.minByOrNull { it.hz }
            val enInce = olculen.maxByOrNull { it.hz }
            if (enKalin != null && enInce != null && enKalin.ses.ad != enInce.ses.ad) {
                if (erkekAd.isEmpty()) erkekAd = enKalin.ses.ad
                if (kadinAd.isEmpty()) kadinAd = enInce.ses.ad
            }
        }
        // Aynı ses ikisine birden atanmasın: o durumda ayrım perdeyle yapılır.
        if (erkekAd.isNotEmpty() && erkekAd == kadinAd) kadinAd = ""

        prefs.sesErkekAdi = erkekAd
        prefs.sesKadinAdi = kadinAd
        // VARSAYILAN SES: konuşan adı olmayan altyazılarda her replik bununla
        // okunur. Seçilmemişse erkek sesine kurulur — önceki sürümde listenin
        // ilk sesine düşüyordu ve 19 sesin 15'i ince olduğu için her şey
        // kadın sesiyle okunuyordu.
        if (prefs.sesVarsayilanAdi.isBlank() ||
            olcumler.none { it.ses.ad == prefs.sesVarsayilanAdi }
        ) {
            prefs.sesVarsayilanAdi = when {
                erkekAd.isNotEmpty() -> erkekAd
                kadinAd.isNotEmpty() -> kadinAd
                else -> olcumler.firstOrNull { it.olculdu }?.ses?.ad ?: ""
            }
        }

        sesSpinnerKuruluyor = true
        val satirlar = ArrayList<String>()
        satirlar.add("En iyi ses (kendiliğinden)")
        for (o in olcumler) satirlar.add("${o.ses.etiket} · ${o.aciklama}")
        spSesErkek.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, satirlar
        )
        spSesKadin.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, satirlar
        )
        spSesVarsayilan.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, satirlar
        )
        spSesErkek.setSelection(sesSirasi(erkekAd))
        spSesKadin.setSelection(sesSirasi(kadinAd))
        spSesVarsayilan.setSelection(sesSirasi(prefs.sesVarsayilanAdi))
        spSesErkek.onItemSelectedListener = sesSecildi(true)
        spSesKadin.onItemSelectedListener = sesSecildi(false)
        spSesVarsayilan.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (sesSpinnerKuruluyor) return
                prefs.sesVarsayilanAdi =
                    if (pos <= 0) "" else bulunanSesler.getOrNull(pos - 1)?.ad ?: ""
                sesDeneme?.let { sesAyarlariniUygula(it) }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        boxSesSecim.visibility = View.VISIBLE
        // Yerleşimden sonra gelen ilk seçim olayları geçsin, sonra dinlemeye
        // başla: kayıtlı seçimler ezilmesin.
        ui.post { sesSpinnerKuruluyor = false }
        sesDeneme?.let { sesAyarlariniUygula(it) }

        // Kaç karakterin ayrı sesle konuşabileceğini söyle: asıl merak
        // edilen bu. Havuzda iki ses varsa iki erkek ayrı duyulur.
        val mevcutAdlar = bulunanSesler.map { it.ad }.toSet()
        val kayitlar = olcumler.map {
            SesHavuzu.Kayit(it.ses.ad, it.hz, it.cinsiyet, it.ses.agGerekir)
        }
        val internet = cbSesInternet.isChecked
        val erkekHavuz = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.ERKEK, mevcutAdlar, internet)
        val kadinHavuz = SesHavuzu.havuz(kayitlar, SesPerdeOlcer.KADIN, mevcutAdlar, internet)

        // 10.60 — DURUM SATIRI AYARLARA BAKAR.
        //
        // Eskiden bu satır yalnız havuza bakıyor ve iki anahtar KAPALIYKEN
        // bile "her karaktere ayrı bir gerçek ses verilecek" diyordu. Doğru
        // değildi: ses seçimi "Erkek ve kadın seslerini ayır" ile "Her
        // karaktere ayrı ton ver" anahtarlarına bağlı.
        val cinsiyetAcik = cbSesCinsiyet.isChecked
        val karakterAcik = cbSesKarakter.isChecked
        val olculenOzet = "${bulunanSesler.size} ses ölçüldü: ${erkekHavuz.size} erkek, " +
            "${kadinHavuz.size} kadın sesi. "

        val durumu = SesSecimi.durum(
            cinsiyetAcik, karakterAcik, erkekHavuz.size, kadinHavuz.size, olculen.size,
        )
        tvSesDurum.text = when (durumu) {
            SesSecimi.D_TEK_SES ->
                olculenOzet + "Ama \"Erkek ve kadın seslerini ayır\" ve \"Her karaktere " +
                    "ayrı ton ver\" kapalı: her replik aşağıda seçtiğiniz tek sesle okunur. " +
                    "Karakterlerin ayrışmasını istiyorsanız ikisinden birini açın."
            SesSecimi.D_CINSIYETSIZ ->
                olculenOzet + "\"Erkek ve kadın seslerini ayır\" kapalı olduğu için " +
                    "cinsiyete bakılmaz: her karakter farklı bir sesle okunur ama erkek " +
                    "bir karaktere kadın sesi düşebilir. Cinsiyet ayrımını açın."
            SesSecimi.D_TONSUZ ->
                olculenOzet + "Erkek ve kadın ayrı seslerle okunur. \"Her karaktere ayrı " +
                    "ton ver\" kapalı olduğu için aynı cinsiyetten iki karakter aynı sesle çıkar."
            SesSecimi.D_TAM ->
                olculenOzet + "Her karaktere ayrı bir gerçek ses verilecek; " +
                    "perdeyle oynanmayacak."
            SesSecimi.D_BIRER_SES ->
                "${bulunanSesler.size} ses ölçüldü: birer erkek ve kadın sesi bulundu. " +
                    "Aynı cinsiyetten karakterler ton farkıyla ayrılacak."
            SesSecimi.D_OLCULEMEDI ->
                "${bulunanSesler.size} ses bulundu ama perdeleri ölçülemedi. " +
                    "Aşağıdan dinleyerek kendiniz seçebilirsiniz."
            else ->
                "${bulunanSesler.size} ses ölçüldü ama ayrı bir erkek ve kadın sesi " +
                    "seçilemedi. Ayrım perdeyle yapılacak: erkek kalın, kadın ince."
        }
    }

    /** Kayıtlı ses adının spinner sırası; bulunamazsa 0 ("en iyi ses"). */
    private fun sesSirasi(ad: String): Int {
        if (ad.isBlank()) return 0
        val i = bulunanSesler.indexOfFirst { it.ad == ad }
        return if (i < 0) 0 else i + 1
    }

    private fun sesSecildi(erkek: Boolean) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
            if (sesSpinnerKuruluyor) return
            val ad = if (pos <= 0) "" else bulunanSesler.getOrNull(pos - 1)?.ad ?: ""
            if (erkek) prefs.sesErkekAdi = ad else prefs.sesKadinAdi = ad
            sesDeneme?.let { sesAyarlariniUygula(it) }
        }

        override fun onNothingSelected(p: AdapterView<*>?) {}
    }

    /**
     * Seçilen erkek ya da kadın sesini dinletir.
     * Örnek repliğin başına bilinen bir ad konuyor; ses seçimi oyundaki
     * yolun birebir aynısından geçsin diye (KonusanCinsiyeti -> ses).
     */
    private fun sesCinsiyetDene(erkek: Boolean) {
        sesMotoru { s ->
            s.sus()
            // İKİ FARKLI karakter okunur: karakter ayrımı açıkken aradaki
            // ton farkı burada duyulsun, oyunda sürpriz olmasın.
            if (erkek) {
                s.oku("James: Arabaya bin, hemen gidiyoruz.", "James")
                sesGecikmeli { s.oku("Arthur: Sakin ol, bir planım var.", "Arthur") }
            } else {
                s.oku("Lucia: Buradan çıkmamız lazım, beni dinle.", "Lucia")
                sesGecikmeli { s.oku("Martha: Kapıyı açık bıraktım.", "Martha") }
            }
        }
    }

    /**
     * İlk replik bitsin diye kısa bir bekleme. QUEUE_FLUSH kullandığımız
     * için arka arkaya iki okuma yapılsa ikincisi birinciyi keserdi.
     */
    private fun sesGecikmeli(islem: () -> Unit) {
        ui.postDelayed({ if (!isFinishing && !isDestroyed) islem() }, SES_DENEME_ARASI)
    }

    /**
     * Örnek bir repliği okuyup sesin kulağa nasıl geldiğini dinletir.
     * Motor burada bir kez kurulur; ekran kapanınca kapatılır.
     */
    private fun sesiDene() {
        sesMotoru { s ->
            s.sus()
            s.oku("Lan buraya gel, şu kapıyı açmamız lazım.")
        }
    }

    /**
     * Önizleme kutusunu seçili ayarlara göre boyar.
     * Renkleri servisle aynı yerden (SubtitleStyle) okuyor; böylece burada
     * gördüğünüz şey oyunda göreceğinizin aynısı oluyor.
     */
    private fun onizlemeyiGuncelle() {
        if (!::tvPreview.isInitialized) return

        val renkSecim = when (cgSubColor.checkedChipId) {
            R.id.chColYellow -> Prefs.COLOR_YELLOW
            R.id.chColGreen -> Prefs.COLOR_GREEN
            R.id.chColCyan -> Prefs.COLOR_CYAN
            else -> Prefs.COLOR_WHITE
        }
        val arkaSecim = when (cgSubBg.checkedChipId) {
            R.id.chBgSolid -> Prefs.BG_SOLID
            R.id.chBgNone -> Prefs.BG_NONE
            else -> Prefs.BG_SEMI
        }
        val arkaRenkSecim = when (cgSubBgColor.checkedChipId) {
            R.id.chBgcGray -> Prefs.BGC_GRAY
            R.id.chBgcNavy -> Prefs.BGC_NAVY
            else -> Prefs.BGC_BLACK
        }

        val alfa = SubtitleStyle.arkaAlfa(arkaSecim)
        val arka = SubtitleStyle.arkaRenk(arkaRenkSecim)

        tvPreview.setTextSize(
            android.util.TypedValue.COMPLEX_UNIT_SP,
            (sbSubSize.progress + SUB_SIZE_MIN).toFloat()
        )
        tvPreview.setTextColor(SubtitleStyle.yaziRengi(renkSecim))

        if (cbOutline.isChecked || alfa == 0) {
            tvPreview.setShadowLayer(7f, 0f, 2f, android.graphics.Color.BLACK)
        } else {
            tvPreview.setShadowLayer(0f, 0f, 0f, android.graphics.Color.TRANSPARENT)
        }

        val yogunluk = resources.displayMetrics.density
        tvPreview.setPadding(
            (10 * yogunluk).toInt(), (5 * yogunluk).toInt(),
            (10 * yogunluk).toInt(), (5 * yogunluk).toInt()
        )
        tvPreview.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 12 * yogunluk
            setColor(
                android.graphics.Color.argb(
                    alfa,
                    android.graphics.Color.red(arka),
                    android.graphics.Color.green(arka),
                    android.graphics.Color.blue(arka),
                )
            )
        }
    }

    private fun updateSpeedLabel() {
        tvSpeed.text = "Her ${sbSpeed.progress + 100} ms'de bir tara (küçük = daha hızlı tepki, daha çok pil)"
    }

    /** Delete one downloaded model only after explicit confirmation and with no active engines. */
    private fun confirmModelCleanup() {
        if (CaptureService.running || EngineBenchmark1035.running || LlmTranslate.isLoading() || OpusModelPack.isImporting) {
            Toast.makeText(this, "Önce canlı çeviriyi ve model testini durdurun.", Toast.LENGTH_LONG).show()
            return
        }
        val models = mutableListOf<Pair<String, () -> Boolean>>()
        if (OpusModelPack.directory(this).exists()) {
            models.add("OPUS-MT EN-TR (ONNX)" to {
                val deleted = OpusModelPack.deleteInstalled(this)
                if (deleted) { prefs.opusMtEnabled = false; cbOpus.isChecked = false }
                deleted
            })
        }
        for (spec in listOf(LlmTranslate.E2B, LlmTranslate.E4B)) {
            val file = LlmTranslate.fileOf(this, spec)
            if (file.exists()) models.add("${spec.label} (${file.length() / (1024 * 1024)} MB)" to {
                file.delete()
            })
        }
        if (models.isEmpty()) {
            Toast.makeText(this, "Temizlenecek yüklü model yok.", Toast.LENGTH_SHORT).show()
            return
        }
        val names = models.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Hangi modeli kaldırmak istiyorsun?")
            .setItems(names) { _, chosen ->
                AlertDialog.Builder(this)
                    .setTitle("Modeli kalıcı olarak sil")
                    .setMessage("${names[chosen]} silinecek. Yeniden kullanmak için model dosyasını tekrar yüklemen gerekir. Çeviri hafızası korunur.")
                    .setNegativeButton("İPTAL", null)
                    .setPositiveButton("MODELİ SİL") { _, _ ->
                        if (CaptureService.running || EngineBenchmark1035.running || LlmTranslate.isLoading() || OpusModelPack.isImporting) {
                            Toast.makeText(this, "Çeviri/test çalışıyor; model silinmedi.", Toast.LENGTH_LONG).show()
                        } else {
                            val ok = models[chosen].second.invoke()
                            findViewById<TextView>(R.id.tvOpusStatus).text = OpusModelPack.status(this)
                            modelSetup?.onResume()
                            Toast.makeText(this, if (ok) "Seçilen model silindi" else "Model silinemedi", Toast.LENGTH_LONG).show()
                        }
                    }.show()
            }.setNegativeButton("KAPAT", null).show()
    }

    private fun save() {
        prefs.gameName = etGame.text.toString()
        prefs.contentType = TURLER.getOrElse(spType.selectedItemPosition) { "Oyun" }
        prefs.apiKey = cleanKey(etKey.text.toString())
        prefs.geminiKey = cleanKey(etGeminiKey.text.toString())
        prefs.provider = if (rgProvider.checkedRadioButtonId == R.id.rbAnthropic)
            Prefs.PROVIDER_ANTHROPIC else Prefs.PROVIDER_GEMINI
        // Model kutusu hangi sağlayıcı seçiliyse ONUN alanına yazılmalı.
        // Önceden hep prefs.model'e (Anthropic alanı) yazıyordu; bu yüzden
        // Gemini seçiliyken model elle hiç değiştirilemiyordu ve MODELLERİ
        // BUL ile doğru ad bulunsa bile uygulamaya geçmiyordu.
        val secilenModel = etModel.text.toString().trim()
        if (secilenModel.isNotEmpty()) {
            if (prefs.provider == Prefs.PROVIDER_GEMINI) prefs.geminiModel = secilenModel
            else prefs.model = secilenModel
        }
        AiTranslate.devreyiAc()

        // Altyazı görünümü
        prefs.subtitleSize = sbSubSize.progress + SUB_SIZE_MIN
        prefs.subtitleColor = when (cgSubColor.checkedChipId) {
            R.id.chColYellow -> Prefs.COLOR_YELLOW
            R.id.chColGreen -> Prefs.COLOR_GREEN
            R.id.chColCyan -> Prefs.COLOR_CYAN
            else -> Prefs.COLOR_WHITE
        }
        prefs.subtitleBg = when (cgSubBg.checkedChipId) {
            R.id.chBgSolid -> Prefs.BG_SOLID
            R.id.chBgNone -> Prefs.BG_NONE
            else -> Prefs.BG_SEMI
        }
        prefs.subtitleBgColor = when (cgSubBgColor.checkedChipId) {
            R.id.chBgcGray -> Prefs.BGC_GRAY
            R.id.chBgcNavy -> Prefs.BGC_NAVY
            else -> Prefs.BGC_BLACK
        }
        prefs.subtitlePos = when (rgSubPos.checkedRadioButtonId) {
            R.id.rbPosCover -> Prefs.POS_COVER
            R.id.rbPosBelow -> Prefs.POS_BELOW
            R.id.rbPosBottom -> Prefs.POS_BOTTOM
            else -> Prefs.POS_ABOVE
        }
        prefs.subtitleOutline = cbOutline.isChecked
        prefs.sesliOku = cbSesli.isChecked
        prefs.sesHiz = sbSesHiz.progress + SES_MIN
        prefs.sesTon = sbSesTon.progress + SES_MIN
        prefs.sesCinsiyet = cbSesCinsiyet.isChecked
        prefs.sesKarakter = cbSesKarakter.isChecked
        prefs.sesInternet = cbSesInternet.isChecked
        prefs.sesDogalGenAi = cbSesDogalGenAi.isChecked
        prefs.sesCanliAlgila = cbSesCanliAlgila.isChecked
        // 10.54 duygu ayarları: değiştikçe de yazılıyor, burada son durum
        // bir kez daha sabitleniyor (kaydırak bırakılmadan çıkılabilir).
        if (::boxOzel.isInitialized) ozelYazilariKaydet()
        if (::cbDuygu.isInitialized) {
            prefs.duyguAcik = cbDuygu.isChecked
            prefs.duyguUnlem = cbDuyguUnlem.isChecked
            prefs.duyguCumle = cbDuyguCumle.isChecked
            prefs.duyguTr = cbDuyguTr.isChecked
            prefs.duyguSiddet = sbDuyguSiddet.progress
        }
        prefs.mode = when (rgMode.checkedRadioButtonId) {
            R.id.rbAi -> Prefs.MODE_AI
            R.id.rbHybrid -> Prefs.MODE_HYBRID
            else -> Prefs.MODE_INSTANT
        }
        prefs.showSpeaker = cbSpeaker.isChecked
        prefs.firefoxMotoru = cbFirefox.isChecked
        prefs.googleCeviri = cbGoogle.isChecked
        prefs.opusMtEnabled = cbOpus.isChecked && OpusModelPack.isInstalled(this)
        // Never store the API key in a plain preference or ZIP. Refuse activation if encryption fails.
        val deeplKey = etDeepLKey.text.toString().trim()
        if (deeplKey != DeepLCredentials.read(this) && !DeepLCredentials.save(this, deeplKey)) {
            cbDeepL.isChecked = false
            Toast.makeText(this, "DeepL anahtarı güvenli kaydedilemedi; DeepL kapatıldı", Toast.LENGTH_LONG).show()
        }
        prefs.deepLEnabled = cbDeepL.isChecked && DeepLCredentials.read(this).isNotBlank()
        // 9.91: gizli beş kutunun değerini ÇEVİRİ BİÇİMİ belirler. Kutular
        // ekranda yok; aşağıdaki satırlar onları eskisi gibi kaydeder.
        val bicim = when (rgBicim.checkedRadioButtonId) {
            R.id.rbBicimHizli -> Prefs.BICIM_HIZLI
            R.id.rbBicimDogru -> Prefs.BICIM_DOGRU
            else -> Prefs.BICIM_DENGELI
        }
        prefs.ceviriBicimi = bicim
        cbAccuracy.isChecked = true
        cbDogruyuBekle.isChecked = false
        cbYalnizDogru.isChecked = bicim == Prefs.BICIM_DOGRU
        cbYigin.isChecked = false
        cbAlwaysAi.isChecked = false
        prefs.accuracyFirst = cbAccuracy.isChecked
        prefs.diagnostics = cbDiag.isChecked
        prefs.minShowSec = sbMinShow.progress
        prefs.dogruyuBekle = cbDogruyuBekle.isChecked
        prefs.yalnizDogru = cbYalnizDogru.isChecked
        prefs.yigin = cbYigin.isChecked
        prefs.alwaysAi = cbAlwaysAi.isChecked
        prefs.menuTranslate = cbMenu.isChecked
        prefs.menuAlanAcik = cbMenuAlan.isChecked
        prefs.intervalMs = sbSpeed.progress + 100

        var top = sbTop.progress
        var bottom = sbBottom.progress
        if (bottom <= top) {
            bottom = (top + 10).coerceAtMost(100)
            sbBottom.progress = bottom
        }
        if (top >= bottom) {
            top = (bottom - 10).coerceAtLeast(0)
            sbTop.progress = top
        }
        prefs.topPct = top
        prefs.bottomPct = bottom
    }

    /**
     * Mikrofon izni sonucu. İzin verilmezse ses algılama kapatılır ve
     * altyazı çevirisi normal şekilde kullanılmaya devam eder.
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIKROFON_IZNI &&
            grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.sesCanliAlgila = false
            if (::cbSesCanliAlgila.isInitialized) cbSesCanliAlgila.isChecked = false
            tvStatus.text = "Ses izni verilmedi; ses algılama kapatıldı. " +
                "Altyazıyı normal başlatabilirsiniz."
        }
    }

    private fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            tvStatus.text = "Bildirim iznini verin, sonra tekrar BAŞLAT deyin."
            return
        }

        // Ses algılama açıksa mikrofon izni şart; yoksa özellik sessizce
        // çalışmaz ve kullanıcı neden olmadığını anlamaz.
        if (prefs.sesliOku && prefs.sesCanliAlgila &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIKROFON_IZNI)
            tvStatus.text = "Oyun sesinden algılama için mikrofon iznini verin, " +
                "sonra tekrar BAŞLAT deyin."
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce 'diğer uygulamaların üzerinde göster' iznini verin.", Toast.LENGTH_LONG).show()
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                tvStatus.text = "İzni verdikten sonra geri gelip tekrar BAŞLAT deyin."
            } catch (e: Throwable) {
                // Çoğu Android TV'de bu ayar ekranı yok: izni telefondan komutla açma yolunu göster.
                tvStatus.text = "Bu cihazda izin ekranı yok. TV kılavuzu'ndaki 'İlk kurulum' adımlarını uygula."
                tvKilavuzu()
            }
            return
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        } catch (e: Throwable) {
            CrashLog.note(this, "ekran kaydi izni", e)
            tvStatus.text = "Ekran kaydı bu cihazda yok; üretici bu özelliği kapatmış."
        }
    }

    // ------------------------------------------------ GameLingo: gezinti ve pencereler

    private val ui = Handler(Looper.getMainLooper())

    private fun dpx(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** Kısayol kutuları ve alt menü. */
    private fun baglaGezinti() {
        val scroll = findViewById<ScrollView>(R.id.scroll)
        fun git(id: Int) {
            val v = findViewById<View>(id) ?: return
            scroll.post { scroll.smoothScrollTo(0, (v.top - dpx(8)).coerceAtLeast(0)) }
        }
        // 10.54: kısayol kutuları artık ilgili ayar BÖLÜMÜNÜ açıyor; kartlar
        // liste görünümünde gizli olduğu için yalnız kaydırmak yetmiyordu.
        findViewById<View>(R.id.tileRegion).setOnClickListener {
            ayarBolumuAc(0)
        }
        findViewById<View>(R.id.tileAi).setOnClickListener {
            ayarBolumuAc(2)
        }
        findViewById<View>(R.id.tileLook).setOnClickListener {
            ayarBolumuAc(1)
        }
        findViewById<View>(R.id.tileDict).setOnClickListener { sozlukPenceresi(null, null) }
        findViewById<View>(R.id.navHome).setOnClickListener { scroll.post { scroll.smoothScrollTo(0, 0) } }
        findViewById<View>(R.id.navSettings).setOnClickListener {
            ayarListesineDon()
            git(R.id.secSettings)
        }
        findViewById<View>(R.id.navHistory).setOnClickListener { gecmisPenceresi() }
        findViewById<View>(R.id.navHelp).setOnClickListener { yardimPenceresi() }
        UserDict.apply(this)
    }


    // ======================================================================
    //  10.54  DUYGU VE ÜNLEMLER
    // ======================================================================

    private var duyguDeneSira = 0

    /** Duygu bölümündeki kontrolleri bağlar. */
    private fun duyguKur() {
        cbDuygu = findViewById(R.id.cbDuygu)
        boxDuygu = findViewById(R.id.boxDuygu)
        rgDuyguNot = findViewById(R.id.rgDuyguNot)
        cbDuyguUnlem = findViewById(R.id.cbDuyguUnlem)
        cbDuyguCumle = findViewById(R.id.cbDuyguCumle)
        cbDuyguTr = findViewById(R.id.cbDuyguTr)
        sbDuyguSiddet = findViewById(R.id.sbDuyguSiddet)
        tvDuyguSiddet = findViewById(R.id.tvDuyguSiddet)
        tvDuyguDurum = findViewById(R.id.tvDuyguDurum)

        cbDuygu.isChecked = prefs.duyguAcik
        boxDuygu.visibility = if (prefs.duyguAcik) View.VISIBLE else View.GONE
        cbDuygu.setOnCheckedChangeListener { _, acik ->
            prefs.duyguAcik = acik
            boxDuygu.visibility = if (acik) View.VISIBLE else View.GONE
            ayarOzetleriYaz()
        }

        findViewById<RadioButton>(
            when (prefs.duyguNotModu) {
                DuyguSesi.NOT_KISIK -> R.id.rbDuyguKisik
                DuyguSesi.NOT_CANLANDIR -> R.id.rbDuyguCanli
                else -> R.id.rbDuyguAtla
            }
        ).isChecked = true
        rgDuyguNot.setOnCheckedChangeListener { _, id ->
            prefs.duyguNotModu = when (id) {
                R.id.rbDuyguKisik -> DuyguSesi.NOT_KISIK
                R.id.rbDuyguCanli -> DuyguSesi.NOT_CANLANDIR
                else -> DuyguSesi.NOT_ATLA
            }
            ayarOzetleriYaz()
        }

        cbDuyguUnlem.isChecked = prefs.duyguUnlem
        cbDuyguUnlem.setOnCheckedChangeListener { _, v -> prefs.duyguUnlem = v }
        cbDuyguCumle.isChecked = prefs.duyguCumle
        cbDuyguCumle.setOnCheckedChangeListener { _, v -> prefs.duyguCumle = v }
        cbDuyguTr.isChecked = prefs.duyguTr
        cbDuyguTr.setOnCheckedChangeListener { _, v -> prefs.duyguTr = v }

        sbDuyguSiddet.progress = prefs.duyguSiddet
        duyguSiddetYaz(prefs.duyguSiddet)
        sbDuyguSiddet.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, deger: Int, kullanici: Boolean) {
                duyguSiddetYaz(deger)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}

            override fun onStopTrackingTouch(sb: SeekBar?) {
                prefs.duyguSiddet = sbDuyguSiddet.progress
                ayarOzetleriYaz()
            }
        })

        findViewById<TextView>(R.id.tvDuyguOrnek).text = DUYGU_ORNEKLERI
        findViewById<View>(R.id.btnDuyguDene).setOnClickListener { duyguyuDene() }
    }

    private fun duyguSiddetYaz(deger: Int) {
        tvDuyguSiddet.text = "Duygu şiddeti · %$deger" + when {
            deger <= 20 -> " (çok hafif)"
            deger >= 85 -> " (çok belirgin)"
            else -> ""
        }
    }

    /**
     * Sırayla farklı duygu örnekleri okutur.
     *
     * NEDEN SIRAYLA: SesliOku aynı yazıyı iki kez okumaz (tekrar filtresi).
     * Tek örnek olsa ikinci basışta hiçbir şey duyulmazdı.
     */
    private fun duyguyuDene() {
        prefs.duyguSiddet = sbDuyguSiddet.progress
        val ornek = DUYGU_DENEME[duyguDeneSira % DUYGU_DENEME.size]
        duyguDeneSira++
        val sonuc = DuyguSesi.hazirla(
            ornek,
            duyguAcik = cbDuygu.isChecked,
            notModu = prefs.duyguNotModu,
            unlemAcik = cbDuyguUnlem.isChecked,
            cumleAcik = cbDuyguCumle.isChecked,
            trAcik = cbDuyguTr.isChecked,
            siddet = sbDuyguSiddet.progress / 100f,
        )
        if (!sonuc.okunur) {
            tvDuyguDurum.text = "«$ornek» okunmadı · sahne notu atlanıyor"
            Toast.makeText(
                this,
                "«$ornek» okunmaz: sahne notu atlanıyor. Duymak için " +
                    "«Kısık sesle oku» ya da «Ünlem gibi canlandır» seçin.",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        // Durum yazısı DUYGU kartına yazılır: sesli okuma kartı o sırada
        // gizli olduğu için tvSesDurum'a yazmak kullanıcıya hiç görünmezdi.
        tvDuyguDurum.text = "«$ornek» → «${sonuc.metin}» · ${sonuc.duygu.ad} · " +
            "perde ${"%.2f".format(sonuc.perde)} · hız ${"%.2f".format(sonuc.hiz)}"
        sesMotoru { s ->
            duyguAyarlariniUygula(s)
            s.oku(ornek)
        }
    }

    /** Ekrandaki duygu ayarlarını bir motora yazar. */
    private fun duyguAyarlariniUygula(s: SesliOku) {
        s.duyguAcik = cbDuygu.isChecked
        s.duyguNotModu = prefs.duyguNotModu
        s.duyguUnlem = cbDuyguUnlem.isChecked
        s.duyguCumle = cbDuyguCumle.isChecked
        s.duyguTr = cbDuyguTr.isChecked
        s.duyguSiddet = sbDuyguSiddet.progress / 100f
    }

    // ======================================================================
    //  10.55  SES AKIŞI VE ÇALIŞMA KAYDI
    // ======================================================================

    private fun sesAkisiKur() {
        rgSesAkis = findViewById(R.id.rgSesAkis)
        cbSesKaydi = findViewById(R.id.cbSesKaydi)
        tvSesAkisOzet = findViewById(R.id.tvSesAkisOzet)

        findViewById<RadioButton>(
            when (prefs.sesAkisModu) {
                SesAkisi.KES -> R.id.rbAkisKes
                SesAkisi.BITIR_ATLA -> R.id.rbAkisBitir
                else -> R.id.rbAkisHizlan
            }
        ).isChecked = true
        rgSesAkis.setOnCheckedChangeListener { _, id ->
            prefs.sesAkisModu = when (id) {
                R.id.rbAkisKes -> SesAkisi.KES
                R.id.rbAkisBitir -> SesAkisi.BITIR_ATLA
                else -> SesAkisi.HIZLAN
            }
            // Çalışan servisin motoru da hemen öğrensin; yeniden
            // başlatmak gerekmesin.
            sesDeneme?.akisModu = prefs.sesAkisModu
            sesAkisOzetiYaz()
        }

        cbSesKaydi.isChecked = prefs.sesKaydi
        cbSesKaydi.setOnCheckedChangeListener { _, acik ->
            prefs.sesKaydi = acik
            SesAkisi.kayitAcik = acik
            if (acik) SesAkisi.temizle()
            sesAkisOzetiYaz()
        }

        findViewById<View>(R.id.btnSesKaydiKopyala).setOnClickListener { sesKaydiniKopyala() }
        findViewById<View>(R.id.btnSesKaydiTemizle).setOnClickListener {
            SesAkisi.temizle()
            sesAkisOzetiYaz()
            Toast.makeText(this, "Ses kaydı temizlendi.", Toast.LENGTH_SHORT).show()
        }
        sesAkisOzetiYaz()
    }

    private fun sesAkisOzetiYaz() {
        if (!::tvSesAkisOzet.isInitialized) return
        val satir = SesAkisi.satirSayisi()
        tvSesAkisOzet.text = if (!prefs.sesKaydi) {
            "Kayıt kapalı. " + CaptureService.sesAkisOzeti()
        } else {
            "Kayıt açık · $satir satır. " + CaptureService.sesAkisOzeti()
        }
    }

    /**
     * Ses kaydını panoya verir. Özet satırı en SONA eklenir: kayıt
     * uzun olduğu için sohbete yapıştırıldığında önce özet okunsun diye
     * başa da bir kopya konuyor.
     */
    private fun sesKaydiniKopyala() {
        val satirlar = SesAkisi.tumu()
        val ozet = CaptureService.sesAkisOzeti()
        if (satirlar.isEmpty()) {
            Toast.makeText(
                this,
                if (prefs.sesKaydi) "Kayıt boş. Sesli okumayı açıp bir sahne oynatın."
                else "Önce «Ses çalışma kaydı»nı açın.",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        val metin = StringBuilder()
        metin.append(ozet).append('\n')
        metin.append("mod=").append(
            when (prefs.sesAkisModu) {
                SesAkisi.KES -> "kes"
                SesAkisi.BITIR_ATLA -> "cümleyi bitir, atla"
                else -> "hızlanarak yetiş"
            }
        )
        metin.append(" · hız %").append(prefs.sesHiz)
        metin.append(" · ton %").append(prefs.sesTon)
        metin.append(" · doğal ses ").append(if (prefs.sesDogalGenAi) "açık" else "kapalı")
        metin.append(" · duygu ").append(if (prefs.duyguAcik) "açık %" + prefs.duyguSiddet else "kapalı")
        metin.append('\n').append("----\n")
        for (l in satirlar) metin.append(l).append('\n')
        metin.append("----\n").append(ozet).append('\n')
        panoyaYaz(metin.toString())
        Toast.makeText(this, "${satirlar.size} satır kopyalandı.", Toast.LENGTH_SHORT).show()
    }

    // ======================================================================
    //  10.58  DOĞALLIK, SES CİNSİYETİ VE ALANLAR
    // ======================================================================

    private fun dogallikKur() {
        tvDogalDurum = findViewById(R.id.tvDogalDurum)
        cbSesAdsizAtla = findViewById(R.id.cbSesAdsizAtla)
        cbSesTekrarSuz = findViewById(R.id.cbSesTekrarSuz)
        boxSesCinsiyet = findViewById(R.id.boxSesCinsiyet)
        tvSesCinsiyetOzet = findViewById(R.id.tvSesCinsiyetOzet)

        cbSesAdsizAtla.isChecked = prefs.sesAdsizAtla
        cbSesAdsizAtla.setOnCheckedChangeListener { _, v ->
            prefs.sesAdsizAtla = v
            sesDeneme?.adsizAtla = v
        }
        cbSesTekrarSuz.isChecked = prefs.sesTekrarSuz
        cbSesTekrarSuz.setOnCheckedChangeListener { _, v ->
            prefs.sesTekrarSuz = v
            sesDeneme?.tekrarSuz = v
        }

        findViewById<View>(R.id.btnSesDogalAyar).setOnClickListener { enDogalAyarlar() }
        dogalDurumYaz()
        sesCinsiyetleriniCiz()
        havuzBossaTara()
    }

    /**
     * Çarpanlar üst üste binince ses sentetik duyuluyor. Bu düğme
     * tabanı sıfıra çeker: hız ve ton %100, duygu şiddeti %45.
     * Yetişme hızlanmasının üst sınırı kodda zaten 1,25'e indirildi.
     */
    private fun enDogalAyarlar() {
        prefs.sesHiz = 100
        prefs.sesTon = 100
        prefs.duyguSiddet = 45
        sbSesHiz.progress = 100 - SES_MIN
        sbSesTon.progress = 100 - SES_MIN
        if (::sbDuyguSiddet.isInitialized) {
            sbDuyguSiddet.progress = 45
            duyguSiddetYaz(45)
        }
        sesDeneme?.let { sesAyarlariniUygula(it) }
        sesEtiketleri()
        ayarOzetleriYaz()
        Toast.makeText(this, "Hız %100 · ton %100 · duygu %45 yapıldı.", Toast.LENGTH_SHORT).show()
    }

    /** Doğal ses motorunun neden çalışmadığı günlüğe gömülü kalmasın. */
    private fun dogalDurumYaz() {
        if (!::tvDogalDurum.isInitialized) return
        val durum = CaptureService.sesDogalDurumu()
        tvDogalDurum.text = if (!prefs.sesDogalGenAi) {
            "Doğal ses kapalı. Açılırsa cihazda destekleniyorsa kullanılır."
        } else {
            // 10.60 — HANGİSİ OKUYOR? Doğal motor hazırsa O okur; aşağıda
            // seçilen erkek/kadın sesleri, cinsiyet ve karakter ayrımı o
            // replikte devreye girmez. Hazır değilse Android sesine düşer
            // ve seçimler geçerli olur. İkisi aynı anda açık olabildiği
            // için hangisinin kazandığını yazmak gerekiyor.
            "Doğal ses motoru: $durum\n\nDoğal ses çalıştığında aşağıdaki ses " +
                "seçimleri, cinsiyet ve karakter ayrımı devreye girmez; doğal motorun " +
                "tek sesi okur. Çalışmadığında Android sesine düşülür ve seçimleriniz geçerli olur."
        }
    }

    /**
     * Taranan seslerin cinsiyetini kullanıcı işaretler.
     *
     * NEDEN: perde ölçümü güvenilir değil. 19 Kasım kaydında erkek
     * karakterler kadın sesiyle okundu; ölçüm 19 sesten 15'ini kadın
     * saymıştı. Ölçüm öneriyor, kullanıcı karar veriyor.
     */
    private fun sesCinsiyetleriniCiz() {
        boxSesCinsiyet.removeAllViews()
        val kayitlar = SesHavuzu.oku(prefs.sesHavuzu)
        val elle = SesHavuzu.elleOku(prefs.sesCinsiyetElle).toMutableMap()
        tvSesCinsiyetOzet.text = SesHavuzu.elleOzet(kayitlar, elle)
        if (kayitlar.isEmpty()) return
        for (kayit in kayitlar) {
            boxSesCinsiyet.addView(sesCinsiyetSatiri(kayit, elle))
        }
    }

    private fun sesCinsiyetSatiri(
        kayit: SesHavuzu.Kayit,
        elle: MutableMap<String, Int>,
    ): View {
        val satir = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = ozelLp(10)
        }
        val etiket = TextView(this).apply {
            text = kisaSesAdi(kayit.ad) + "  " + kayit.hz.toInt() + " Hz"
            textSize = 12.5f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        satir.addView(etiket)
        val secili = elle[kayit.ad] ?: kayit.cinsiyet
        val erkek = cinsiyetDugmesi("Erkek", secili == SesPerdeOlcer.ERKEK)
        val kadin = cinsiyetDugmesi("Kadın", secili == SesPerdeOlcer.KADIN)
        val dene = TextView(this).apply {
            text = "Dinle"
            textSize = 12.5f
            setPadding(dpx(10), dpx(6), dpx(4), dpx(6))
            setTextColor(resources.getColor(R.color.lingo_primary, null))
            isClickable = true
            isFocusable = true
            setBackgroundResource(R.drawable.tv_odak)
            setOnClickListener { sesiDinle(kayit.ad) }
        }
        erkek.setOnClickListener {
            elle[kayit.ad] = SesPerdeOlcer.ERKEK
            prefs.sesCinsiyetElle = SesHavuzu.elleYaz(elle)
            sesDeneme?.cinsiyetElle = elle.toMap()
            sesCinsiyetleriniCiz()
        }
        kadin.setOnClickListener {
            elle[kayit.ad] = SesPerdeOlcer.KADIN
            prefs.sesCinsiyetElle = SesHavuzu.elleYaz(elle)
            sesDeneme?.cinsiyetElle = elle.toMap()
            sesCinsiyetleriniCiz()
        }
        satir.addView(erkek)
        satir.addView(kadin)
        satir.addView(dene)
        return satir
    }

    private fun cinsiyetDugmesi(yazi: String, secili: Boolean): TextView =
        TextView(this).apply {
            text = yazi
            textSize = 12.5f
            setPadding(dpx(10), dpx(6), dpx(10), dpx(6))
            setTextColor(
                if (secili) resources.getColor(R.color.lingo_on_primary, null)
                else resources.getColor(R.color.lingo_on_surface_variant, null)
            )
            setBackgroundResource(if (secili) R.drawable.bg_seg_on else R.drawable.tv_odak)
            isClickable = true
            isFocusable = true
        }

    /** "tr-tr-x-tmc-network" -> "tmc · ağ" */
    private fun kisaSesAdi(ad: String): String {
        val p = ad.split('-')
        val kod = p.getOrNull(3) ?: ad
        val yer = if (ad.endsWith("network")) "ağ" else "cihaz"
        return "$kod · $yer"
    }

    private fun sesiDinle(ad: String) {
        sesMotoru { s -> s.sesiDinle(ad, SES_DENEME_METNI) }
    }

    private fun yanAlanlariKur() {
        cbYanSol = findViewById(R.id.cbYanSol)
        cbYanSag = findViewById(R.id.cbYanSag)
        cbMenuModu = findViewById(R.id.cbMenuModu)

        cbYanSol.isChecked = prefs.yanSolAcik
        cbYanSol.setOnCheckedChangeListener { _, v ->
            prefs.yanSolAcik = v
            yanAlanOzetleri()
            ayarOzetleriYaz()
        }
        cbYanSag.isChecked = prefs.yanSagAcik
        cbYanSag.setOnCheckedChangeListener { _, v ->
            prefs.yanSagAcik = v
            yanAlanOzetleri()
            ayarOzetleriYaz()
        }
        cbMenuModu.isChecked = prefs.menuModu
        cbMenuModu.setOnCheckedChangeListener { _, v ->
            prefs.menuModu = v
            ayarOzetleriYaz()
        }
        findViewById<View>(R.id.btnYanSol).setOnClickListener { alanSec(RegionActivity.ALAN_SOL) }
        findViewById<View>(R.id.btnYanSag).setOnClickListener { alanSec(RegionActivity.ALAN_SAG) }
        yanAlanOzetleri()
    }

    private fun alanSec(alan: String) {
        try {
            startActivity(
                Intent(this, RegionActivity::class.java)
                    .putExtra(RegionActivity.EK_ALAN, alan)
            )
        } catch (t: Throwable) {
            Toast.makeText(this, "Alan seçme ekranı açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * TV DÜZENİ (10.58)
     *
     * Televizyonların çoğu görüntünün kenarlarından kırpıyor; kenara
     * dayanan düğmeler ve yazılar görünmüyor. TV'de çalışırken ana
     * kaydırma alanına kenar boşluğu veriliyor.
     *
     * Ayrıca kumandayla açılışta ilk odak ayar listesine veriliyor,
     * yoksa odak hiçbir yerde olmuyor ve ilk tuşa basınca ekran
     * beklenmedik bir yere atlıyor.
     */
    private fun tvDuzeni() {
        if (!TvMode.isTvDevice(this)) return
        val kok = findViewById<View>(R.id.scroll) ?: return
        val dm = resources.displayMetrics
        val bosluk = TvYerlesim.overscanPx(dm.widthPixels, dm.heightPixels)
        kok.setPadding(bosluk, bosluk, bosluk, bosluk)
        kok.post {
            try {
                findViewById<View>(R.id.ayarSatir1)?.requestFocus()
            } catch (_: Throwable) {
            }
        }
    }

    private fun yanAlanOzetleri() {
        findViewById<TextView>(R.id.tvYanSol)?.text = "Sol: " + YanAlan.ozet(
            YanAlan.Kutu(prefs.yanSolAcik, prefs.yanSolLeft, prefs.yanSolTop, prefs.yanSolRight, prefs.yanSolBottom)
        )
        findViewById<TextView>(R.id.tvYanSag)?.text = "Sağ: " + YanAlan.ozet(
            YanAlan.Kutu(prefs.yanSagAcik, prefs.yanSagLeft, prefs.yanSagTop, prefs.yanSagRight, prefs.yanSagBottom)
        )
    }

    // ======================================================================
    //  10.54  ÖZEL AYARLAR (tablodan)
    // ======================================================================

    private fun ozelKur() {
        tvOzelDurum = findViewById(R.id.tvOzelDurum)
        boxOzel = findViewById(R.id.boxOzel)
        findViewById<View>(R.id.btnOzelAktar).setOnClickListener {
            try {
                ozelTabloSec.launch(arrayOf("*/*"))
            } catch (t: Throwable) {
                Toast.makeText(this, "Dosya seçici açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnOzelSablon).setOnClickListener {
            panoyaYaz(OzelAyar.sablon())
            Toast.makeText(this, "Örnek tablo panoya kopyalandı.", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.btnOzelSil).setOnClickListener {
            prefs.ozelTablo = ""
            ozelCiz()
            ayarOzetleriYaz()
            Toast.makeText(this, "Tablo silindi.", Toast.LENGTH_SHORT).show()
        }
        ozelCiz()
    }

    private fun panoyaYaz(metin: String) {
        try {
            val pano = getSystemService(Context.CLIPBOARD_SERVICE)
                as android.content.ClipboardManager
            pano.setPrimaryClip(android.content.ClipData.newPlainText("GameLingo", metin))
        } catch (_: Throwable) {
        }
    }

    /** Seçilen dosyayı okur, çözer ve saklar. */
    private fun ozelTabloyuAktar(uri: Uri) {
        val ham = try {
            contentResolver.openInputStream(uri)?.use { akis ->
                akis.readBytes().toString(Charsets.UTF_8)
            }
        } catch (t: Throwable) {
            CrashLog.note(this, "ozel tablo okuma", t)
            null
        }
        if (ham.isNullOrBlank()) {
            Toast.makeText(this, "Dosya okunamadı ya da boş.", Toast.LENGTH_LONG).show()
            return
        }
        val satirlar = OzelAyar.coz(ham)
        if (satirlar.isEmpty()) {
            Toast.makeText(
                this,
                "Tabloda ayar bulunamadı. Sütunlar: Ad ; Tür ; Varsayılan ; Bölüm",
                Toast.LENGTH_LONG,
            ).show()
            return
        }
        prefs.ozelTablo = ham
        ozelCiz()
        ayarOzetleriYaz()
        Toast.makeText(this, "${satirlar.size} özel ayar aktarıldı.", Toast.LENGTH_SHORT).show()
    }

    private fun ozelLp(ustBosluk: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dpx(ustBosluk) }

    /** Tabloyu gerçek kontrollere çevirir. */
    private fun ozelCiz() {
        boxOzel.removeAllViews()
        ozelYaziKutulari.clear()
        val satirlar = OzelAyar.coz(prefs.ozelTablo)
        tvOzelDurum.text = OzelAyar.ozet(satirlar)
        findViewById<View>(R.id.btnOzelSil).visibility =
            if (satirlar.isEmpty()) View.GONE else View.VISIBLE
        if (satirlar.isEmpty()) return
        for ((bolum, grup) in OzelAyar.bolumler(satirlar)) {
            boxOzel.addView(TextView(this).apply {
                text = bolum
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                layoutParams = ozelLp(16)
            })
            for (sat in grup) ozelKontrol(sat)
        }
    }

    /** Bir tablo satırı için uygun kontrolü kutuya ekler. */
    private fun ozelKontrol(sat: OzelAyar.Satir) {
        when (sat.tur) {
            OzelAyar.T_ANAHTAR -> boxOzel.addView(CheckBox(this).apply {
                text = sat.ad
                isChecked = prefs.ozelDeger(sat.anahtar, if (sat.varsayilanAcik) "1" else "0") == "1"
                layoutParams = ozelLp(4)
                setOnCheckedChangeListener { _, v ->
                    prefs.ozelDegerYaz(sat.anahtar, if (v) "1" else "0")
                }
            })

            OzelAyar.T_KAYDIRAK -> {
                val etiket = TextView(this).apply { textSize = 13f; layoutParams = ozelLp(10) }
                val baslangic = prefs.ozelDeger(sat.anahtar, sat.varsayilanSayi.toString())
                    .toIntOrNull()?.coerceIn(0, 100) ?: 0
                etiket.text = sat.ad + " · %" + baslangic
                boxOzel.addView(etiket)
                boxOzel.addView(SeekBar(this).apply {
                    max = 100
                    progress = baslangic
                    layoutParams = ozelLp(0)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(sb: SeekBar?, deger: Int, kul: Boolean) {
                            etiket.text = sat.ad + " · %" + deger
                        }

                        override fun onStartTrackingTouch(sb: SeekBar?) {}

                        override fun onStopTrackingTouch(sb: SeekBar?) {
                            prefs.ozelDegerYaz(sat.anahtar, (sb?.progress ?: 0).toString())
                        }
                    })
                })
            }

            OzelAyar.T_SAYI, OzelAyar.T_YAZI -> {
                boxOzel.addView(TextView(this).apply {
                    text = sat.ad
                    textSize = 13f
                    layoutParams = ozelLp(10)
                })
                val kutu = EditText(this).apply {
                    setText(prefs.ozelDeger(sat.anahtar, sat.varsayilan))
                    if (sat.tur == OzelAyar.T_SAYI) {
                        inputType = android.text.InputType.TYPE_CLASS_NUMBER
                    }
                    layoutParams = ozelLp(0)
                    setOnFocusChangeListener { v, odak ->
                        if (!odak) prefs.ozelDegerYaz(sat.anahtar, (v as EditText).text.toString())
                    }
                }
                ozelYaziKutulari += sat to kutu
                boxOzel.addView(kutu)
            }

            else -> {
                val secenekler = if (sat.secenekler.isEmpty()) listOf(sat.varsayilan)
                else sat.secenekler
                boxOzel.addView(TextView(this).apply {
                    text = sat.ad
                    textSize = 13f
                    layoutParams = ozelLp(10)
                })
                boxOzel.addView(Spinner(this).apply {
                    adapter = ArrayAdapter(
                        this@MainActivity,
                        android.R.layout.simple_spinner_dropdown_item,
                        secenekler,
                    )
                    val kayitli = prefs.ozelDeger(sat.anahtar, sat.varsayilan)
                    setSelection(secenekler.indexOf(kayitli).coerceAtLeast(0))
                    layoutParams = ozelLp(0)
                    // Kuruluş sırasında tetiklenen ilk seçimi yazmıyoruz:
                    // kayıtlı değerin üstüne ilk seçeneği yazardı.
                    var kuruluyor = true
                    onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            ebeveyn: AdapterView<*>?,
                            gorunum: View?,
                            sira: Int,
                            kimlik: Long,
                        ) {
                            if (kuruluyor) {
                                kuruluyor = false
                                return
                            }
                            prefs.ozelDegerYaz(sat.anahtar, secenekler.getOrElse(sira) { "" })
                        }

                        override fun onNothingSelected(ebeveyn: AdapterView<*>?) {}
                    }
                })
            }
        }
    }

    /** Tablodan çizilen yazı kutularını kaydeder. */
    private fun ozelYazilariKaydet() {
        for ((sat, kutu) in ozelYaziKutulari) {
            prefs.ozelDegerYaz(sat.anahtar, kutu.text.toString())
        }
    }

    // ======================================================================
    //  10.54  AYAR MENÜSÜ
    // ======================================================================

    /**
     * Ayarları bölümlere ayırır.
     *
     * TASARIM NOTU: Hiçbir kontrol taşınmadı, hiçbir findViewById
     * değişmedi. Kartlar yerinde duruyor; menü yalnız GÖRÜNÜRLÜĞÜ
     * değiştiriyor. Böylece ses, bölge ve çeviri kodu hiç etkilenmiyor.
     */
    private fun ayarMenusuKur() {
        for ((sira, id) in ayarSatirIdleri.withIndex()) {
            findViewById<View>(id)?.setOnClickListener { ayarBolumuAc(sira) }
        }
        findViewById<View>(R.id.btnAyarGeri)?.setOnClickListener { ayarListesineDon() }
        ayarListesineDon()
        onBackPressedDispatcher.addCallback(
            this,
            object : androidx.activity.OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (acikBolum >= 0) {
                        ayarListesineDon()
                        return
                    }
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            },
        )
    }

    private fun ayarBolumuAc(sira: Int) {
        if (sira < 0 || sira >= ayarKartIdleri.size) return
        val scroll = findViewById<ScrollView>(R.id.scroll)
        // Cihaz ve bağlantı: kendi kartı yok, ana ekrandaki mod kutusuna götürür.
        if (ayarKartIdleri[sira].isEmpty()) {
            val hedef = findViewById<View>(R.id.segMode) ?: return
            scroll?.post { scroll.smoothScrollTo(0, (hedef.top - dpx(8)).coerceAtLeast(0)) }
            return
        }
        acikBolum = sira
        prefs.ayarBolumu = sira
        findViewById<View>(R.id.ayarMenu)?.visibility = View.GONE
        findViewById<View>(R.id.ayarBaslikCubugu)?.visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvAyarBaslik)?.text = ayarBasliklari[sira]
        for ((n, idler) in ayarKartIdleri.withIndex()) {
            val gorunur = n == sira
            for (id in idler) {
                findViewById<View>(id)?.visibility = if (gorunur) View.VISIBLE else View.GONE
            }
        }
        val cubuk = findViewById<View>(R.id.ayarBaslikCubugu)
        if (scroll != null && cubuk != null) {
            scroll.post { scroll.smoothScrollTo(0, (cubuk.top - dpx(8)).coerceAtLeast(0)) }
        }
    }

    private fun ayarListesineDon() {
        if (::boxOzel.isInitialized) ozelYazilariKaydet()
        acikBolum = -1
        prefs.ayarBolumu = -1
        findViewById<View>(R.id.ayarMenu)?.visibility = View.VISIBLE
        findViewById<View>(R.id.ayarBaslikCubugu)?.visibility = View.GONE
        for (idler in ayarKartIdleri) {
            for (id in idler) findViewById<View>(id)?.visibility = View.GONE
        }
        ayarOzetleriYaz()
    }

    /** Menü satırlarının altındaki özetler: girmeden ne durumda olduğu görünsün. */
    private fun ayarOzetleriYaz() {
        if (!::prefs.isInitialized) return
        val ozetler = try {
            listOf(
                "Altyazı %${prefs.topPct}–%${prefs.bottomPct}" +
                    (if (prefs.menuModu) " · MENÜ MODU açık"
                    else if (!prefs.menuTranslate) " · yan yazı kapalı"
                    else " · yan yazı: " + yanAlanAdlari()),
                "Boyut ${prefs.subtitleSize} · ${konumAdi(prefs.subtitlePos)}" +
                    (if (prefs.subtitleOutline) " · kenarlıklı" else ""),
                motorlarOzeti(),
                if (prefs.sesliOku) {
                    "Açık" + (if (prefs.sesDogalGenAi) " · doğal ses" else "") +
                        (if (prefs.sesKarakter) " · karakter ayrımı" else "")
                } else "Kapalı",
                if (prefs.duyguAcik) {
                    notModuAdi(prefs.duyguNotModu) + " · şiddet %${prefs.duyguSiddet}"
                } else "Kapalı",
                (if (prefs.tvMode) "TV modu" else "Telefon modu") +
                    (if (prefs.bridgeOn) " · köprü açık" else " · köprü kapalı"),
                OzelAyar.ozet(OzelAyar.coz(prefs.ozelTablo)),
                motorAdi(prefs.mode) +
                    (if (prefs.diagnostics) " · teşhis açık" else " · teşhis kapalı"),
            )
        } catch (_: Throwable) {
            return
        }
        for ((sira, id) in ayarOzetIdleri.withIndex()) {
            findViewById<TextView>(id)?.text = ozetler.getOrElse(sira) { "" }
        }
    }

    /** Açık olan yan alanların kısa adı. */
    private fun yanAlanAdlari(): String {
        val acik = ArrayList<String>(3)
        if (prefs.yanSolAcik) acik += "sol"
        if (prefs.yanSagAcik) acik += "sağ"
        if (prefs.menuAlanAcik) acik += "özel"
        return if (acik.isEmpty()) "üst bölge" else acik.joinToString(" + ")
    }

    private fun konumAdi(deger: Int): String = when (deger) {
        1 -> "altyazıyı kapatır"
        2 -> "altyazının altında"
        3 -> "ekranın en altı"
        else -> "altyazının üstünde"
    }

    private fun notModuAdi(deger: Int): String = when (deger) {
        DuyguSesi.NOT_KISIK -> "sahne notu kısık"
        DuyguSesi.NOT_CANLANDIR -> "sahne notu canlandırılıyor"
        else -> "sahne notu atlanıyor"
    }

    private fun motorlarOzeti(): String {
        val acik = ArrayList<String>(4)
        if (prefs.googleCeviri) acik += "Google"
        if (prefs.deepLEnabled) acik += "DeepL"
        if (prefs.opusMtEnabled) acik += "OPUS"
        if (prefs.firefoxMotoru) acik += "Firefox"
        val liste = if (acik.isEmpty()) "motor seçilmedi" else acik.joinToString(" + ")
        return liste + " · " + bicimAdi(prefs.ceviriBicimi)
    }

    private fun bicimAdi(deger: Int): String = when (deger) {
        0 -> "hızlı"
        2 -> "doğru"
        else -> "dengeli"
    }

    private fun motorAdi(deger: Int): String = when (deger) {
        Prefs.MODE_AI -> "Yapay zekâ"
        Prefs.MODE_HYBRID -> "Hibrit"
        else -> "Anında"
    }

    /** Durum satırındaki göstergeler ve "Son çevrilen" kutusu; ekran açıkken saniyede bir yenilenir. */
    private fun durumuGuncelle() {
        ui.removeCallbacksAndMessages(null)
        try {
            val ok = ContextCompat.getColor(this, R.color.lingo_ok)
            val warn = ContextCompat.getColor(this, R.color.lingo_warn)
            val bad = ContextCompat.getColor(this, R.color.lingo_bad)
            val sb = SpannableStringBuilder()
            fun nokta(renk: Int, yazi: String) {
                val st = sb.length
                sb.append("●")
                sb.setSpan(ForegroundColorSpan(renk), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.append(" ").append(yazi).append("    ")
            }
            nokta(if (CaptureService.running) ok else warn, if (CaptureService.running) "Okuma açık" else "Okuma kapalı")
            nokta(ok, "Çeviri hazır")
            when {
                LlmTranslate.isReady(this) -> nokta(ok, "Yapay zekâ hazır")
                LlmTranslate.isLoading() -> nokta(warn, "Yapay zekâ yükleniyor")
                LlmTranslate.hasModel(this) -> nokta(warn, "Yapay zekâ bekliyor")
                else -> nokta(bad, "Yapay zekâ modeli yok")
            }
            findViewById<TextView>(R.id.tvIndicators).text = sb

            CaptureService.lastPair()?.let { (en, tr) ->
                findViewById<TextView>(R.id.tvLastSrc).text = en
                findViewById<TextView>(R.id.tvLastTr).text = tr
            }
            // 9.93 — canlı süreler: GERÇEK ölçüm, örnek veri değil.
            val ocrMs = CaptureService.sonOcrMs
            val ceviriMs = CaptureService.sonCeviriMs
            if (ocrMs > 0L) findViewById<TextView>(R.id.tvStatOcr).text = "$ocrMs ms"
            if (ceviriMs > 0L) findViewById<TextView>(R.id.tvStatCeviri).text = "$ceviriMs ms"
            if (ocrMs > 0L && ceviriMs > 0L) {
                findViewById<TextView>(R.id.tvStatGecikme).text = "${ocrMs + ceviriMs} ms"
            }
            kopruGoster()
        } catch (_: Throwable) {
        }
        ui.postDelayed({ durumuGuncelle() }, 1000)
    }

    /** "Sözlüğüm": kendi düzeltmelerini yazdığın pencere. İngilizce/Türkçe verilirse o satırı ekler. */
    private fun sozlukPenceresi(en: String?, tr: String?) {
        if (en != null && tr != null) {
            val pad = dpx(20)
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, dpx(8), pad, 0) }
            val etEn = EditText(this).apply { setText(en); hint = "İngilizce" }
            val etTr = EditText(this).apply { setText(tr); hint = "Doğru Türkçesi" }
            box.addView(etEn); box.addView(etTr)
            AlertDialog.Builder(this)
                .setTitle("Sözlüğe ekle")
                .setMessage("Türkçeyi düzeltip kaydet. Bu satır bir daha hep böyle çevrilir.")
                .setView(box)
                .setPositiveButton("Kaydet") { _, _ ->
                    val e = etEn.text.toString().trim()
                    val t = etTr.text.toString().trim()
                    if (e.isNotEmpty() && t.isNotEmpty()) {
                        UserDict.add(this, e, t)
                        Toast.makeText(this, "Sözlüğe eklendi", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Vazgeç", null)
                .show()
            return
        }
        val et = EditText(this).apply {
            val mevcut = UserDict.load(this@MainActivity)
            setText(if (mevcut.isBlank()) UserDict.ORNEK else mevcut)
            minLines = 8
            gravity = android.view.Gravity.TOP
            textSize = 14f
        }
        val wrap = LinearLayout(this).apply {
            setPadding(dpx(20), dpx(8), dpx(20), 0)
            addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setTitle("Sözlüğüm")
            .setMessage("Her satıra bir düzeltme: ingilizce = türkçe\nÇevrilmemesi gereken isimler: @İsim")
            .setView(wrap)
            .setPositiveButton("Kaydet") { _, _ ->
                UserDict.save(this, et.text.toString())
                Toast.makeText(this, "Sözlük kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    /** Bu oturumda çevrilen satırlar; birine dokununca sözlüğe eklenebilir. */
    private fun gecmisPenceresi() {
        val list = CaptureService.history().asReversed()
        if (list.isEmpty()) {
            Toast.makeText(this, "Henüz çeviri yok. Çeviriyi başlatıp oyuna geçin.", Toast.LENGTH_LONG).show()
            return
        }
        val items = list.map { (en, tr) -> "$en\n→ $tr" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Çeviri geçmişi · yanlış olana dokun")
            .setItems(items) { _, i -> sozlukPenceresi(list[i].first, list[i].second) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    // ------------------------------------------------ Telefon / TV seçimi

    private fun tvSecimiBagla() {
        try {
            findViewById<View>(R.id.btnModePhone).setOnClickListener {
                TvMode.setManual(this, prefs, false); tvSecimiGoster()
            }
            findViewById<View>(R.id.btnModeTv).setOnClickListener {
                TvMode.setManual(this, prefs, true); tvSecimiGoster()
                if (!TvMode.externalDisplayConnected(this)) {
                    Toast.makeText(this, "TV modu açık. Telefonu kabloyla TV'ye bağlayınca altyazı büyük görünecek.", Toast.LENGTH_LONG).show()
                }
            }
            findViewById<View>(R.id.btnTvGuide).setOnClickListener { tvKilavuzu() }
            kopruBagla()
            if (TvMode.isTvDevice(this)) {
                // TV'nin kendisinde seçim yok: her zaman TV görünümü.
                findViewById<View>(R.id.segMode)?.visibility = View.GONE
                kumandaOdagi(window.decorView)
            }
            TvMode.autoUpdate(this, prefs)
            tvSecimiGoster()
        } catch (e: Throwable) {
            CrashLog.note(this, "tv secimi", e)
        }
    }

    // ------------------------------------------------ Telefon ↔ TV köprüsü

    private fun kopruBagla() {
        val tv = TvMode.isTvDevice(this)
        val btnBridge = findViewById<View>(R.id.btnTvBridge)
        val tvBridge = findViewById<View>(R.id.tvBridgeState)
        val btnLink = findViewById<View>(R.id.btnPhoneLink)
        if (tv) {
            // TV: köprüyü SAĞLAYAN telefon tarafı gizli, telefonla eşleşme düğmesi görünür.
            btnBridge?.visibility = View.GONE
            tvBridge?.visibility = View.GONE
            btnLink?.visibility = View.VISIBLE
            btnLink?.setOnClickListener { eslesmePenceresi() }
        } else {
            btnLink?.visibility = View.GONE
            btnBridge?.setOnClickListener {
                if (PhoneBridgeService.running) {
                    startService(Intent(this, PhoneBridgeService::class.java).setAction(PhoneBridgeService.ACTION_STOP))
                } else {
                    if (!LlmTranslate.hasModel(this)) {
                        Toast.makeText(this, "Önce yapay zekâ modelini indir; çeviriyi o yapacak.", Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    ContextCompat.startForegroundService(this,
                        Intent(this, PhoneBridgeService::class.java).setAction(PhoneBridgeService.ACTION_START))
                    AlertDialog.Builder(this)
                        .setTitle("TV ve bilgisayara çeviri sağlanıyor")
                        .setMessage("GameLingo TV'de \"Telefonun yapay zekâsını kullan\"a, bilgisayarda GameLingo PC → Çeviri → Ayarlar'a gir ve şu kodu yaz:\n\n" +
                            "      ${PhoneBridgeService.pinFor(this)}\n\n" +
                            "Telefon ile TV/bilgisayar aynı ağda olmalı. Telefonu şarja takıp kenara bırakabilirsin; ekran kapalıyken de çalışır.")
                        .setPositiveButton("Tamam", null)
                        .show()
                }
                ui.postDelayed({ kopruGoster() }, 600)
            }
        }
        kopruGoster()
    }

    private fun kopruGoster() {
        try {
            if (TvMode.isTvDevice(this)) {
                findViewById<Button>(R.id.btnPhoneLink)?.text =
                    if (prefs.bridgeOn && prefs.bridgeHost.isNotBlank()) "Telefonun yapay zekâsı: açık · ${prefs.bridgeHost}"
                    else "Telefonun yapay zekâsını kullan (doğru çeviri)"
            } else {
                findViewById<Button>(R.id.btnTvBridge)?.text =
                    if (PhoneBridgeService.running) "Çeviri sağlamayı durdur" else "TV ve bilgisayara çeviri sağla"
                findViewById<TextView>(R.id.tvBridgeState)?.text = "Çeviri köprüsü: " + PhoneBridgeService.statusText()
            }
        } catch (_: Throwable) {
        }
    }

    /** TV: telefonla eşleşme penceresi (kod + istenirse adres). */
    private fun eslesmePenceresi() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val info = TextView(this).apply {
            text = "Telefondaki GameLingo'da \"TV ve bilgisayara çeviri sağla\" düğmesine bas. Ekranda çıkan 4 haneli kodu buraya yaz. " +
                "Telefon ile TV/bilgisayar aynı ağda olmalı."
        }
        val code = android.widget.EditText(this).apply {
            hint = "Kod (ör. 4821)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.bridgePin)
        }
        val host = android.widget.EditText(this).apply {
            hint = "Telefonun adresi (boş bırak: kendisi bulur)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.bridgeHost)
        }
        box.addView(info); box.addView(code); box.addView(host)
        AlertDialog.Builder(this)
            .setTitle("Telefonun yapay zekâsını kullan")
            .setView(box)
            .setPositiveButton("Eşleş") { _, _ -> eslestir(code.text.toString().trim(), host.text.toString().trim()) }
            .setNeutralButton("Kullanma") { _, _ ->
                prefs.bridgeOn = false
                kopruGoster()
                Toast.makeText(this, "TV kendi hızlı çevirisini kullanacak.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun eslestir(pin: String, manualHost: String) {
        if (pin.length != 4 || pin.any { !it.isDigit() }) {
            Toast.makeText(this, "Kod 4 haneli olmalı.", Toast.LENGTH_LONG).show()
            return
        }
        tvStatus.text = "Telefon aranıyor…"
        Thread {
            val host = manualHost.ifBlank { PhoneBridge.discover(pin) ?: PhoneBridge.discover(pin) ?: "" }
            val sonuc = if (host.isBlank()) null else PhoneBridge.ping(host, pin)
            runOnUiThread {
                when {
                    host.isBlank() -> {
                        tvStatus.text = "Telefon bulunamadı."
                        AlertDialog.Builder(this)
                            .setTitle("Telefon bulunamadı")
                            .setMessage("Telefonda \"TV ve bilgisayara çeviri sağla\" açık mı ve ikisi aynı Wi-Fi'da mı? " +
                                "Olmazsa telefondaki TV köprüsü satırında yazan adresi (ör. 192.168.1.23) eşleşme penceresindeki adres kutusuna yaz.")
                            .setPositiveButton("Tamam", null).show()
                    }
                    sonuc == null -> {
                        tvStatus.text = "Telefona ulaşılamadı ($host)."
                        Toast.makeText(this, "Telefona ulaşılamadı: kod doğru mu, telefonda köprü açık mı?", Toast.LENGTH_LONG).show()
                    }
                    else -> {
                        prefs.bridgePin = pin
                        prefs.bridgeHost = host
                        prefs.bridgeOn = true
                        tvStatus.text = if (sonuc) "Telefona bağlandı · yapay zekâ hazır" else "Telefona bağlandı · yapay zekâ yükleniyor"
                        Toast.makeText(this, "Eşleşti: $host. Çeviriler artık telefondaki yapay zekâdan gelecek.", Toast.LENGTH_LONG).show()
                        kopruGoster()
                    }
                }
            }
        }.start()
    }

    private fun tvSecimiGoster() {
        val tv = prefs.tvMode
        val phone = findViewById<TextView>(R.id.btnModePhone) ?: return
        val tvBtn = findViewById<TextView>(R.id.btnModeTv) ?: return
        val on = ContextCompat.getColor(this, R.color.lingo_on_surface)
        val off = ContextCompat.getColor(this, R.color.lingo_on_surface_variant)
        val accent = ContextCompat.getColor(this, R.color.lingo_primary)
        phone.setBackgroundResource(if (tv) R.drawable.bg_seg_off else R.drawable.bg_seg_on)
        tvBtn.setBackgroundResource(if (tv) R.drawable.bg_seg_on else R.drawable.bg_seg_off)
        phone.setTextColor(if (tv) off else on)
        tvBtn.setTextColor(if (tv) on else off)
        phone.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(if (tv) off else accent)
        tvBtn.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(if (tv) accent else off)
        val bagli = TvMode.externalDisplayConnected(this)
        findViewById<TextView>(R.id.tvTvState)?.text = if (TvMode.isTvDevice(this)) "Android TV · çevrim dışı hızlı çeviri" else when {
            tv && bagli -> "TV bağlı · yazı büyük, kutu geniş"
            tv -> "TV modu · kablo bağlanınca büyük görünür"
            bagli -> "TV bağlı ama Telefon seçili · normal boyut"
            else -> "Telefon · normal boyut"
        }
    }

    /**
     * Kumanda (D-pad) ile gezinme: tıklanabilen her öğe odaklanabilsin ve
     * odaktayken belirgin olsun (hafif büyür, turkuaz çerçeve).
     */
    private fun kumandaOdagi(v: View?) {
        if (v == null) return
        if (v.isClickable || v is android.widget.CompoundButton || v is android.widget.SeekBar || v is android.widget.EditText) {
            v.isFocusable = true
            val onceki = v.onFocusChangeListener
            v.setOnFocusChangeListener { view, odak ->
                onceki?.onFocusChange(view, odak)
                view.animate().scaleX(if (odak) 1.04f else 1f).scaleY(if (odak) 1.04f else 1f).setDuration(120).start()
                view.foreground = if (odak) android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 14f * resources.displayMetrics.density
                    setStroke((2 * resources.displayMetrics.density).toInt(), ContextCompat.getColor(this@MainActivity, R.color.lingo_primary))
                } else null
            }
        }
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) kumandaOdagi(v.getChildAt(i))
    }

    /** "Ne görüyor?": uygulamanın yakaladığı son görüntü; altyazı bölgesi çerçeveli. */
    private fun onizlemeGoster() {
        val bmp = CaptureService.lastPreview
        if (bmp == null || bmp.isRecycled) {
            AlertDialog.Builder(this)
                .setTitle("Ne görüyor?")
                .setMessage("Henüz görüntü yok. Önce Çeviriyi başlat'a bas, izleyeceğin videoyu birkaç saniye aç, sonra buraya dön.")
                .setPositiveButton("Tamam", null)
                .show()
            return
        }
        val iv = android.widget.ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            setPadding(16, 16, 16, 16)
        }
        AlertDialog.Builder(this)
            .setTitle("Ne görüyor? (son yakalanan görüntü)")
            .setView(iv)
            .setMessage("Turkuaz çerçeve okunan altyazı bölgesi. Videonun yerinde siyah görünüyorsa izlediğin uygulama ekran kaydını engelliyor; altyazı çerçevenin dışındaysa Altyazı bölgesi'ni ayarla.")
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun tvKilavuzu() {
        if (TvMode.isTvDevice(this)) {
            AlertDialog.Builder(this)
                .setTitle(TvMode.TV_GUIDE_TITLE)
                .setMessage(TvMode.tvGuide(packageName))
                .setPositiveButton("Tamam", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(TvMode.GUIDE_TITLE)
            .setMessage(TvMode.GUIDE)
            .setPositiveButton("Tamam", null)
            .show()
    }

    /**
     * 10.59 — UYGULAMA İÇİ KULLANIM KILAVUZU.
     *
     * Eskiden burada dört satırlık bir "Nasıl kullanılır" penceresi vardı;
     * 88 denetimin ne yaptığını anlatmaya yetmiyordu. Artık Kilavuz.TELEFON
     * bölümleri listelenir, bölüm seçilince metni açılır. Metin uzun olduğu
     * için AlertDialog kendi kendine kaydırılabilir olur.
     */
    private fun yardimPenceresi() {
        val bolumler = Kilavuz.TELEFON
        AlertDialog.Builder(this)
            .setTitle(Kilavuz.BASLIK)
            .setItems(Kilavuz.basliklar(bolumler).toTypedArray()) { _, sira ->
                kilavuzBolumu(sira)
            }
            .setPositiveButton("Kapat", null)
            .setNeutralButton("Tümünü kopyala") { _, _ ->
                panoyaYaz(Kilavuz.tumMetin(bolumler))
            }
            .setNegativeButton("TV kılavuzu") { _, _ -> tvKilavuzu() }
            .show()
    }

    /** Kılavuzun tek bir bölümü: metin + "Bölümler"e dön + "Sonraki". */
    private fun kilavuzBolumu(sira: Int) {
        val bolumler = Kilavuz.TELEFON
        val bolum = bolumler.getOrNull(sira) ?: return
        val pencere = AlertDialog.Builder(this)
            .setTitle(bolum.baslik)
            .setMessage(bolum.metin)
            .setPositiveButton("Kapat", null)
            .setNeutralButton("‹ Bölümler") { _, _ -> yardimPenceresi() }
        if (sira + 1 < bolumler.size) {
            pencere.setNegativeButton("Sonraki ›") { _, _ -> kilavuzBolumu(sira + 1) }
        }
        pencere.show()
    }

    companion object {

        /** Ses cinsiyeti listesinde "Dinle" ile okunan örnek. */
        private const val SES_DENEME_METNI = "Merhaba, ben bu sesim. Beni duyuyor musun?"

        /** Duygu bölümünde gösterilen ünlem örnekleri. */
        private const val DUYGU_ORNEKLERI =
            "hmm → hımm (düşünme) · ahaha → ha ha ha (gülme) · " +
                "ahhhh → ahh (acı, yavaş) · hık → hıh hıh (ağlama) · oh (şaşırma)"

        /** «Duyguyu dene» sırayla bunları okutur. */
        private val DUYGU_DENEME = listOf(
            "Hmm, bir saniye.",
            "Ahaha!",
            "Ahhhhhh!",
            "KOŞ! ARKANDA!",
            "Gidiyorum...",
            "[gülüyor]",
        )
        /** GameLingo'nun ana ekranı açık mı (açıkken çeviri durur, kendi yazılarımızı okumayalım). */
        @Volatile var visible = false
    }
}
