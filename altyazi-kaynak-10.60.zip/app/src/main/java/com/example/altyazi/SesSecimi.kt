package com.example.altyazi

/**
 * SES SEÇİM KURALI — 10.60
 *
 * Hangi repliğin hangi sesle okunacağına karar veren iki kuralı
 * SesliOku'dan ayırıp buraya aldım; Android'e bağlı olmadığı için
 * testten geçirilebiliyorlar (bkz. SesSecimTest.kt).
 *
 * NEDEN AYRILDI: 19 Kasım ekran görüntülerinde "Erkek ve kadın seslerini
 * ayır" ve "Her karaktere ayrı ton ver" kapalıyken bile, konuşan adı olan
 * replikler havuzun ilk sesiyle okunuyordu. Kullanıcının seçtiği üç ses
 * (erkek, kadın, "konuşan adı yoksa") yok sayılıyordu ve havuz cinsiyete
 * bakmadan kurulduğu için erkek karakter kadın sesiyle çıkabiliyordu.
 * Kural koda gömülü olduğu sürece bu sessizce geri gelebilir; artık test
 * ediliyor.
 */
object SesSecimi {

    /**
     * Havuzdan karaktere özel GERÇEK ses seçilsin mi?
     *
     * Yalnız karakter ayrımı AÇIKKEN ve havuzda en az iki ses varken.
     * Kapalıyken kullanıcının seçtiği ses geçerlidir; havuzdan ses
     * seçmek onun seçimini ezmek olur.
     */
    fun havuzdanSecilsin(karakterAyrimi: Boolean, havuzBoyu: Int): Boolean =
        karakterAyrimi && havuzBoyu >= 2

    /**
     * Bu cinsiyet için kullanıcının seçtiği ses adı.
     *
     * Cinsiyet BİLİNMİYOR ise "Konuşan adı yoksa" kutusundaki seçim
     * kullanılır. Eskiden burası boş dönüyor ve motorun listedeki ilk
     * sesine düşülüyordu — cinsiyet ayrımı kapalıyken cinsiyet her zaman
     * BİLİNMİYOR olduğu için bu, seçilen sesin hiç çalmaması demekti.
     */
    fun istenenSesAdi(
        cinsiyet: Int,
        erkekAdi: String,
        kadinAdi: String,
        varsayilanAdi: String,
    ): String = when (cinsiyet) {
        KonusanCinsiyeti.ERKEK -> erkekAdi
        KonusanCinsiyeti.KADIN -> kadinAdi
        else -> varsayilanAdi
    }

    /**
     * Ayar ekranındaki durum satırının hangi durumu anlatacağı.
     * Durum metinleri MainActivity'de; burada yalnız hangi durumda
     * olunduğu kararı var, çünkü asıl kolay bozulan yer bu.
     */
    const val D_TEK_SES = 0        // iki anahtar da kapalı
    const val D_CINSIYETSIZ = 1    // karakter ayrımı var, cinsiyet yok
    const val D_TONSUZ = 2         // cinsiyet var, karakter ayrımı yok
    const val D_TAM = 3            // ikisi de açık, havuz yeterli
    const val D_BIRER_SES = 4      // ikisi de açık, cinsiyet başına tek ses
    const val D_OLCULEMEDI = 5     // perdeler ölçülemedi
    const val D_AYRILAMADI = 6     // ayrı erkek/kadın sesi seçilemedi

    fun durum(
        cinsiyetAcik: Boolean,
        karakterAcik: Boolean,
        erkekHavuzu: Int,
        kadinHavuzu: Int,
        olculenSayisi: Int,
    ): Int = when {
        !cinsiyetAcik && !karakterAcik -> D_TEK_SES
        !cinsiyetAcik -> D_CINSIYETSIZ
        !karakterAcik -> D_TONSUZ
        erkekHavuzu >= 2 || kadinHavuzu >= 2 -> D_TAM
        erkekHavuzu > 0 && kadinHavuzu > 0 -> D_BIRER_SES
        olculenSayisi == 0 -> D_OLCULEMEDI
        else -> D_AYRILAMADI
    }
}
