# -*- coding: utf-8 -*-
import io, re, sys

KAYNAK = "/home/claude/src_zip/app/src/main/java/com/example/altyazi/MainActivity.kt"
s = io.open(KAYNAK, encoding="utf-8").read()
satirlar = s.split("\n")

def fonksiyon(ad):
    """4 girintili 'private fun ad(' ... eslesen kapanis suslusuna kadar."""
    bas = None
    for i, l in enumerate(satirlar):
        if re.match(r"^    (private |)fun " + re.escape(ad) + r"\s*\(", l):
            bas = i
            break
    if bas is None:
        raise SystemExit("bulunamadi: " + ad)
    # dogrudan ifade govdesi (= ... ) olabilir
    # imza satirlarini topla: ilk '{' ya da '=' gorunene kadar
    i = bas
    derinlik = 0
    acildi = False
    while i < len(satirlar):
        l = satirlar[i]
        derinlik += l.count("{") - l.count("}")
        if "{" in l:
            acildi = True
        if acildi and derinlik <= 0:
            return "\n".join(satirlar[bas:i + 1])
        if not acildi and ("=" in l) and l.rstrip().endswith(("}", ")")) is False and derinlik == 0:
            # ifade govdesi: devam eden 'when {' olabilir -> acildi yakalar
            pass
        if not acildi and derinlik == 0 and i > bas and satirlar[i].strip() == "":
            return "\n".join(satirlar[bas:i])
        i += 1
    raise SystemExit("kapanis bulunamadi: " + ad)

ADLAR = [
    "duyguKur", "duyguSiddetYaz", "duyguyuDene", "duyguAyarlariniUygula",
    "ozelKur", "panoyaYaz", "ozelTabloyuAktar", "ozelLp", "ozelCiz", "ozelKontrol",
    "ayarMenusuKur", "ayarBolumuAc", "ayarListesineDon", "ayarOzetleriYaz",
    "konumAdi", "notModuAdi", "motorlarOzeti", "bicimAdi", "motorAdi",
    "sesAyarlariniUygula", "baglaGezinti", "ozelYazilariKaydet",
    "sesAkisiKur", "sesAkisOzetiYaz", "sesKaydiniKopyala",
    "dogallikKur", "enDogalAyarlar", "dogalDurumYaz", "sesCinsiyetleriniCiz",
    "sesCinsiyetSatiri", "cinsiyetDugmesi", "kisaSesAdi", "sesiDinle",
    "yanAlanlariKur", "alanSec", "yanAlanOzetleri", "havuzBossaTara", "yanAlanAdlari",
    "tvDuzeni",
    "yardimPenceresi", "kilavuzBolumu",
]

govdeler = [fonksiyon(a) for a in ADLAR]
birlesik = "\n\n".join(govdeler)

# kullanilan R.id adlarini topla
idler = None  # BASLIK tanimlandiktan sonra hesaplanir

BASLIK = '''package com.example.altyazi

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog

/**
 * SALT DERLEME DENETIMI: MainActivity'nin 10.54'te eklenen duygu, ozel
 * ayar ve ayar menusu fonksiyonlari -- GERCEK GOVDELERIYLE.
 */
class MainActivityDuyguDenetim : Activity() {

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var tvSesDurum: TextView
    private lateinit var cbDuygu: CheckBox
    private lateinit var boxDuygu: LinearLayout
    private lateinit var rgDuyguNot: RadioGroup
    private lateinit var cbDuyguUnlem: CheckBox
    private lateinit var cbDuyguCumle: CheckBox
    private lateinit var cbDuyguTr: CheckBox
    private lateinit var sbDuyguSiddet: SeekBar
    private lateinit var tvDuyguSiddet: TextView
    private lateinit var tvDuyguDurum: TextView
    private lateinit var rgSesAkis: RadioGroup
    private lateinit var cbSesKaydi: CheckBox
    private lateinit var tvSesAkisOzet: TextView
    private lateinit var tvDogalDurum: TextView
    private lateinit var cbSesAdsizAtla: CheckBox
    private lateinit var cbSesTekrarSuz: CheckBox
    private lateinit var boxSesCinsiyet: LinearLayout
    private lateinit var tvSesCinsiyetOzet: TextView
    private lateinit var cbYanSol: CheckBox
    private lateinit var cbYanSag: CheckBox
    private lateinit var cbMenuModu: CheckBox
    private var otomatikTaramaYapildi = false
    private lateinit var tvOzelDurum: TextView
    private lateinit var boxOzel: LinearLayout
    private val ozelYaziKutulari = ArrayList<Pair<OzelAyar.Satir, EditText>>()

    private var acikBolum = -1
    private var sesDeneme: SesliOku? = null
    private var duyguDeneSira = 0

    private val ayarKartIdleri: List<IntArray> = listOf(
        intArrayOf(R.id.secRegion),
        intArrayOf(R.id.secLook),
        intArrayOf(R.id.secContent, R.id.secAi),
        intArrayOf(R.id.secSes),
        intArrayOf(R.id.secDuygu),
        intArrayOf(),
        intArrayOf(R.id.secOzel),
        intArrayOf(R.id.secAdvanced),
    )

    private val ayarBasliklari = listOf(
        "Ekran alani", "Yazi ve gorunum", "Dil ve ceviri", "Sesli okuma",
        "Duygu ve unlemler", "Cihaz ve baglanti", "Ozel ayarlar", "Gelismis",
    )

    private val ayarSatirIdleri = intArrayOf(
        R.id.ayarSatir1, R.id.ayarSatir2, R.id.ayarSatir3, R.id.ayarSatir4,
        R.id.ayarSatir5, R.id.ayarSatir6, R.id.ayarSatir7, R.id.ayarSatir8,
    )

    private val ayarOzetIdleri = intArrayOf(
        R.id.ayarOzet1, R.id.ayarOzet2, R.id.ayarOzet3, R.id.ayarOzet4,
        R.id.ayarOzet5, R.id.ayarOzet6, R.id.ayarOzet7, R.id.ayarOzet8,
    )

    private val ozelTabloSec =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) ozelTabloyuAktar(uri)
        }

    private val SES_MIN = 50

    private lateinit var sbSesHiz: SeekBar
    private lateinit var sbSesTon: SeekBar
    private lateinit var cbSesCinsiyet: CheckBox
    private lateinit var cbSesKarakter: CheckBox
    private lateinit var cbSesInternet: CheckBox
    private lateinit var cbSesDogalGenAi: CheckBox

    private fun dpx(v: Int): Int = v * 3

    private fun sozlukPenceresi(a: String?, b: String?) {}

    private fun gecmisPenceresi() {}

    private fun tvKilavuzu() {}

    private fun sesEtiketleri() {}

    private fun sesleriTara() {}

    private fun onizlemeyiGuncelle() {}

    /** Gercek MainActivity'de ses motorunu acan yardimci; burada taklit. */
    private fun sesMotoru(sonra: (SesliOku) -> Unit) {
        sonra(SesliOku(this))
    }

'''

SON = '''
    companion object {
        private const val DUYGU_ORNEKLERI = "hmm -> himm"
        private val DUYGU_DENEME = listOf("Hmm, bir saniye.", "Ahaha!")
        private const val SES_DENEME_METNI = "Merhaba."
    }
}
'''

io.open("/home/claude/derleme/MainActivityDuyguDenetim.kt", "w", encoding="utf-8").write(
    BASLIK + birlesik.replace("this@MainActivity", "this@MainActivityDuyguDenetim") + "\n" + SON
)

idler = sorted(set(re.findall(r"R\.id\.(\w+)", BASLIK + birlesik)))
R = ["package com.example.altyazi;", "public final class R {", "    public static final class id {"]
for n, ad in enumerate(idler):
    R.append("        public static final int %s = %d;" % (ad, 1000 + n))
R += ["    }", "    public static final class layout {",
      "        public static final int activity_main = 1;", "    }",
      "    public static final class color {",
      "        public static final int lingo_ok = 1, lingo_warn = 2, lingo_bad = 3,",
      "            lingo_primary = 4, lingo_on_primary = 5, lingo_on_surface_variant = 6;", "    }",
      "    public static final class drawable {",
      "        public static final int tv_odak = 1, bg_seg_on = 2, bg_seg_off = 3;", "    }", "}"]
import os
os.makedirs("/home/claude/derleme/jtaklit/com/example/altyazi", exist_ok=True)
io.open("/home/claude/derleme/jtaklit/com/example/altyazi/R.java", "w", encoding="utf-8").write("\n".join(R) + "\n")
print("cikarildi; %d fonksiyon, %d id" % (len(ADLAR), len(idler)))
print("idler:", " ".join(idler))
