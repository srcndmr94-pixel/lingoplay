package com.example.altyazi

private var gecti = 0
private var kaldi = 0

private fun kontrol(ad: String, kosul: Boolean, ek: String = "") {
    if (kosul) { gecti++ } else { kaldi++; println("  BASARISIZ: $ad ${if (ek.isNotEmpty()) "-> $ek" else ""}") }
}

fun main(args: Array<String>) {
    val arayuzMetni = if (args.isNotEmpty()) java.io.File(args[0]).readText() else ""

    println("== Kilavuz testleri ==")

    // 1. Yapi
    kontrol("bolum sayisi 11", Kilavuz.TELEFON.size == 11, "${Kilavuz.TELEFON.size}")
    for (b in Kilavuz.TELEFON) {
        kontrol("baslik bos degil", b.baslik.isNotBlank())
        kontrol("metin yeterince uzun: ${b.baslik}", b.metin.length > 200, "${b.metin.length}")
        kontrol("ilkSatir dolu: ${b.baslik}", b.ilkSatir.isNotBlank())
        kontrol("metin basligi tekrar etmiyor: ${b.baslik}", !b.metin.startsWith(b.baslik))
    }
    kontrol("basliklar tekil", Kilavuz.basliklar().toSet().size == Kilavuz.TELEFON.size)
    kontrol("basliklar sirali 1..11", Kilavuz.basliklar().mapIndexed { i, s -> s.startsWith("${i + 1} ") }.all { it })

    // 2. tumMetin
    val tum = Kilavuz.tumMetin()
    kontrol("tumMetin tum basliklari icerir", Kilavuz.basliklar().all { tum.contains(it) })
    kontrol("tumMetin tum govdeleri icerir", Kilavuz.TELEFON.all { tum.contains(it.metin) })

    // 3. Arama
    kontrol("arama: 'ses robotik'", Kilavuz.ara("ses robotik").isNotEmpty())
    kontrol("arama: 'altyazi cikmiyor' sorun giderme bulur",
        Kilavuz.ara("altyazı çıkmıyor").any { Kilavuz.TELEFON[it].baslik.contains("Sorun giderme") })
    kontrol("arama: 'netflix' TV bolumunu bulur",
        Kilavuz.ara("netflix").any { Kilavuz.TELEFON[it].baslik.contains("TV") })
    kontrol("arama: 'NETFLIX' buyuk harf de bulur", Kilavuz.ara("NETFLIX").isNotEmpty())
    kontrol("arama: 'LINGO' buyuk harf (Turkce I tuzagi)", Kilavuz.ara("LINGO").isNotEmpty())
    kontrol("arama: bos soru bos sonuc", Kilavuz.ara("   ").isEmpty())
    kontrol("arama: kisa sozcuk sayilmaz", Kilavuz.ara("bu ve").isEmpty())
    kontrol("arama: olmayan sozcuk bos sonuc", Kilavuz.ara("zürafa kuantum").isEmpty())
    kontrol("arama: en cok eslesen basta", Kilavuz.ara("duygu ünlem şiddeti").firstOrNull()
        ?.let { Kilavuz.TELEFON[it].baslik.contains("Duygu") } == true)

    // 4. EN ONEMLI: kilavuzdaki her dugme adi arayuzde gercekten var mi?
    if (arayuzMetni.isEmpty()) {
        println("  (arayuz dosyasi verilmedi, ad denetimi atlandi)")
    } else {
        val adlar = listOf(
            "ÇEVİRİYİ BAŞLAT", "Durduruldu", "Kurulumu kontrol et", "Ne izliyorsunuz",
            "Altyazı bölgesi", "HIZLI KONUM", "Alt bölge", "Üst bölge", "Tam ekran",
            "Üst sınır", "Alt sınır", "Alanı ekranda seç",
            "Menü, görev ve tuş yazılarını da çevir", "Sol alanı kullan", "Sağ alanı kullan",
            "Menü modu · tüm ekranı tara",
            "Önce doğru çeviriyi bekle", "Yazıya koyu kenarlık ekle",
            "Çeviriyi sesli oku", "Erkek ve kadın seslerini ayır",
            "Sesleri tara ve kendiliğinden ata", "Ses cinsiyetleri",
            "En doğal ayarlara dön", "Konuşan adı olmayan satırları okuma",
            "Aynı satırı bir kez oku", "Doğal Türkçe ses (cihaz içi)",
            "Ses çalışma kaydı", "Ses kaydını kopyala",
            "Duygu şiddeti", "Duyguyu dene",
            "Çalışma kaydını kopyala", "Son hatayı kopyala",
            "TV ve bilgisayara çeviri sağla", "Telefonun yapay zekâsını kullan",
            "Örnek tablo şablonunu panoya kopyala",
        )
        for (ad in adlar) {
            val kilavuzda = tum.contains(ad)
            val arayuzde = arayuzMetni.contains(ad)
            kontrol("arayuzde var: \"$ad\"", arayuzde)
            if (arayuzde) kontrol("kilavuzda anilmis: \"$ad\"", kilavuzda)
        }
        // Ters yon: kilavuzda tirnakli gecen bir ad arayuzde yoksa, uydurma
        // dugme adidir. Dugme olmayan alintilar (Android'in kendi penceresi,
        // ceviri ornekleri) asagida tek tek sayilmistir; listede olmayan yeni
        // bir uydurma ad testi dusurur.
        val dugmeDisiAlintilar = setOf(
            "Ekran kaydı başlatılsın mı?", "Şimdi başlat",           // Android'in kendi penceresi
            "Fire!", "Ateş!", "Ocağa ver!", "Settings", "Ayarlar",    // ceviri ornekleri
            "Işığı söndür, çabuk!",                                   // ornek altyazi satiri
            "DP Alt Mode / video çıkışı", "altyazı bölgesi", "Durduruldu",
            "Yok", "Hızlı", "TV", "kopyala", "temizle",
        )
        val tirnakli = Regex("\"([^\"\\n]{3,60})\"").findAll(tum).map { it.groupValues[1] }.toList()
        var kacak = 0
        for (t in tirnakli) {
            if (t in dugmeDisiAlintilar) continue
            // Cumle noktalamasi tasiyan alinti dugme adi degil, duz metindir.
            if (t.contains(",") || t.contains("→")) continue
            if (!arayuzMetni.contains(t)) { kacak++; println("  UYARI: kilavuzda \"$t\" var, arayuzde yok") }
        }
        kontrol("kilavuzda uydurma dugme adi yok ($kacak)", kacak == 0)
    }

    println("\nGecti: $gecti   Kaldi: $kaldi")
    if (kaldi > 0) kotlin.system.exitProcess(1)
}
