import com.example.altyazi.SesSecimi
import com.example.altyazi.KonusanCinsiyeti

private var g = 0
private var k = 0
private fun ko(ad: String, kosul: Boolean, ek: String = "") {
    if (kosul) g++ else { k++; println("  BASARISIZ: $ad ${if (ek.isNotEmpty()) "-> $ek" else ""}") }
}

fun main() {
    println("== havuzdanSecilsin ==")
    // 19 Kasim ekran goruntusundeki durum: karakter ayrimi KAPALI, havuzda 19 ses.
    ko("karakter ayrimi kapali + 19 ses -> havuzdan SECILMEZ",
        !SesSecimi.havuzdanSecilsin(false, 19))
    ko("karakter ayrimi kapali + 2 ses -> secilmez", !SesSecimi.havuzdanSecilsin(false, 2))
    ko("karakter ayrimi kapali + 0 ses -> secilmez", !SesSecimi.havuzdanSecilsin(false, 0))
    ko("karakter ayrimi acik + 19 ses -> secilir", SesSecimi.havuzdanSecilsin(true, 19))
    ko("karakter ayrimi acik + 2 ses -> secilir", SesSecimi.havuzdanSecilsin(true, 2))
    ko("karakter ayrimi acik + 1 ses -> secilmez (ton yoluna duser)",
        !SesSecimi.havuzdanSecilsin(true, 1))
    ko("karakter ayrimi acik + 0 ses -> secilmez", !SesSecimi.havuzdanSecilsin(true, 0))

    println("== istenenSesAdi ==")
    val E = "tr-tr-x-tmc-network"
    val K = "tr-tr-x-cfs-network"
    val V = "tr-tr-x-tmc-network"
    ko("erkek -> erkek sesi",
        SesSecimi.istenenSesAdi(KonusanCinsiyeti.ERKEK, E, K, V) == E)
    ko("kadin -> kadin sesi",
        SesSecimi.istenenSesAdi(KonusanCinsiyeti.KADIN, E, K, V) == K)
    // ASIL HATA: cinsiyet bilinmiyorken eskiden "" donuyordu.
    ko("bilinmiyor -> kullanicinin 'konusan adi yoksa' secimi",
        SesSecimi.istenenSesAdi(KonusanCinsiyeti.BILINMIYOR, E, K, V) == V)
    ko("bilinmiyor -> bos donmez",
        SesSecimi.istenenSesAdi(KonusanCinsiyeti.BILINMIYOR, E, K, V).isNotEmpty())
    ko("varsayilan da bossa bos doner (motorun ilk sesine duser)",
        SesSecimi.istenenSesAdi(KonusanCinsiyeti.BILINMIYOR, E, K, "").isEmpty())
    ko("erkek secilmemisse bos doner",
        SesSecimi.istenenSesAdi(KonusanCinsiyeti.ERKEK, "", K, V).isEmpty())

    println("== durum satiri ==")
    // Ekran goruntusundeki tam durum: ikisi de kapali, 4 erkek 15 kadin.
    ko("ikisi de kapali -> TEK SES",
        SesSecimi.durum(false, false, 4, 15, 19) == SesSecimi.D_TEK_SES)
    ko("ikisi de kapaliyken 'her karaktere ayri ses' DENMEZ",
        SesSecimi.durum(false, false, 4, 15, 19) != SesSecimi.D_TAM)
    ko("cinsiyet kapali + karakter acik -> CINSIYETSIZ",
        SesSecimi.durum(false, true, 4, 15, 19) == SesSecimi.D_CINSIYETSIZ)
    ko("cinsiyet acik + karakter kapali -> TONSUZ",
        SesSecimi.durum(true, false, 4, 15, 19) == SesSecimi.D_TONSUZ)
    ko("ikisi acik + bol havuz -> TAM",
        SesSecimi.durum(true, true, 4, 15, 19) == SesSecimi.D_TAM)
    ko("ikisi acik + birer ses -> BIRER_SES",
        SesSecimi.durum(true, true, 1, 1, 2) == SesSecimi.D_BIRER_SES)
    ko("ikisi acik + hic olcum -> OLCULEMEDI",
        SesSecimi.durum(true, true, 0, 0, 0) == SesSecimi.D_OLCULEMEDI)
    ko("ikisi acik + olcum var ama ayrilamadi -> AYRILAMADI",
        SesSecimi.durum(true, true, 0, 1, 5) == SesSecimi.D_AYRILAMADI)
    ko("ikisi acik + yalniz erkek bulundu -> AYRILAMADI",
        SesSecimi.durum(true, true, 3, 0, 5) == SesSecimi.D_TAM)

    // Anahtarlar kapaliyken havuz ne olursa olsun TAM denmez.
    var hata = 0
    for (e in 0..5) for (kd in 0..20) {
        if (SesSecimi.durum(false, false, e, kd, e + kd) == SesSecimi.D_TAM) hata++
        if (SesSecimi.durum(false, true, e, kd, e + kd) == SesSecimi.D_TAM) hata++
        if (SesSecimi.durum(true, false, e, kd, e + kd) == SesSecimi.D_TAM) hata++
    }
    ko("anahtarlardan biri kapaliyken hicbir havuzda TAM denmez ($hata)", hata == 0)

    println("\nGECTI: $g   KALDI: $k")
    if (k > 0) kotlin.system.exitProcess(1)
}
