package com.example.altyazi

/**
 * OCR kaynaklı, yüksek güvenli metin düzeltmeleri ve ilk kare güven denetimi.
 * Dil modeli değildir; cümleyi yeniden yazmaz, özel isimleri tahmin etmez.
 * GameTranslator'ın kararlı okuma yaklaşımının Android'e uyarlanmış küçük kısmı.
 */
object SubtitlePreparation {
    private val repairs = listOf(
        // Örnekleri gerçek test loglarından alındı; dar bağlam dışına uygulanmaz.
        Regex("(?i)\\bmost hand some\\b") to "most handsome",
        Regex("(?i)\\bmnonths\\b") to "months",
        Regex("(?i)\\bmomn\\b") to "mom",
        Regex("(?i)\\btw\\s+O-week\\b") to "two-week",
        Regex("(?i)\\bwara million\\b") to "war a million",
        Regex("(?i)\\bthere'sa\\b") to "there's a",
        Regex("(?i)\\bain['’]?t\\b") to "ain't",
        // Yalnız ayırt edici bağlamda OCR harf/boşluk kayıpları.
        Regex("(?i)\\bwhat,\\s*didl\\s+leave\\b") to "What, did I leave",
        Regex("(?i)^wet,\\s+that sounds like a challenge\\b") to "Well, that sounds like a challenge",
        Regex("(?i)\\b(suit)\\s+Al(?=])") to "suit AI"
    )

    fun repair(text: String): String {
        var current = text
        for ((pattern, replacement) in repairs) {
            current = pattern.replace(current) { match ->
                if (match.value.firstOrNull()?.isUpperCase() == true) {
                    replacement.replaceFirstChar { it.uppercase() }
                } else replacement
            }
        }
        return current
    }

    private val safeShortWords = setOf(
        "a", "i", "o", "an", "am", "as", "at", "be", "by", "do", "go", "ha",
        "he", "hi", "if", "in", "is", "it", "me", "mr", "ms", "my", "no",
        "of", "oh", "ok", "on", "or", "so", "to", "tv", "uh", "um", "up",
        "us", "we", "ya", "ye", "ai", "dr", "st", "id", "vs"
    )
    private val words = Regex("[\\p{L}]+(?:['’][\\p{L}]+)?")
    private val suspiciousChars = Regex("[|#@%]|[\\p{L}]\\d[\\p{L}]|\\d[\\p{L}]\\d")

    /** Şüpheli OCR: ilk karede acele etmeyip ikinci, aynı okumayı bekle. */
    fun confidentFirstRead(text: String): Boolean {
        if (text.isBlank()) return false
        // Sahne/ses etiketlerini gereksiz yere yavaşlatma.
        if (text.trim().matches(Regex("^\\[[^]\\n]+]$"))) return true
        if (suspiciousChars.containsMatchIn(text)) return false
        val tokens = words.findAll(text).map { it.value }.toList()
        if (tokens.isEmpty()) return false
        return tokens.none { word ->
            word.length <= 2 && word.lowercase() !in safeShortWords
        }
    }
}

/**
 * Yalnız Google yolunda güvenli anlamsal normalleştirme.
 * Cümle sonundaki ", too" çoğu zaman "ben de" anlamındadır;
 * "too much/too late" hiçbir zaman değiştirilmez.
 */
object GoogleSourcePreparation {
    private val finalToo = Regex("(?i),\\s*too([.!?…]*)$")

    fun prepare(text: String): String = finalToo.replace(text) { match ->
        " as well" + match.groupValues[1]
    }
}
