# GameLingo 10.23 — altyazı alanı görsel ayarı

10.22 üzerine görsel seçici eklendi: önizleme, Üst/Alt/Sol/Sağ, yüzde kaydırıcısı, sürüklenebilir çerçeve, Varsayılana Dön, Kaydet/Vazgeç.

**Bu bir kaynak ZIP dosyasıdır, APK değildir.** Android SDK/Gradle bulunmadığı için bu ortamda APK derlenemedi veya telefonda test edilmedi. Daha önceki APK'yi silmeyin. GitHub Actions üzerinden derleme gerekir.

Ayrıntılar: `GUNCELLEME-NOTU-10.23.md`.
