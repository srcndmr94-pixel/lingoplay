from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=r/'app/src/main/java/com/example/altyazi'
read=lambda f:(s/f).read_text()
service=read('CaptureService.kt'); gate=read('TranslationQualityGate.kt')
checks={
    '10.42.5 version and monotonic code': 'versionCode = 187' in (r/'app/build.gradle.kts').read_text() and 'versionName = "10.42.5-apk299-log-fix"' in (r/'app/build.gradle.kts').read_text(),
    'package identity preserved': 'applicationId = "com.example.altyazi"' in (r/'app/build.gradle.kts').read_text(),
    'APK299 source-only verified OCR repairs wired': 'GameplayLogRepair299.repairOcr(current)' in read('SubtitlePreparation.kt'),
    'APK299 corrupted game text delayed': 'GameplayLogRepair299.waitForCleanReading(text)' in service,
    'APK299 false speaker blocked': 'GameplayLogRepair299.plausibleSpeakerName(ad)' in service,
    'APK299 game terms in render': 'GameplayLogRepair299.repairTranslation(' in service,
    'Gameplay labels protected from decorative filter': '!GameplayLogRepair299.isGameplayInstruction(collapsed2)' in service,
    'DeepL remains opt-in and key-gated': 'prefs.deepLEnabled && deeplKey.isNotBlank()' in service,
    'DeepL quality gate integrated': 'val accepted = normalized?.takeIf' in service and 'TranslationQualityGate.check(text, it) == null' in service,
    'Profanity repair only after detected loss': 'TranslationQualityGate.Problem.LOST_PROFANITY' in service and 'ProfanityShield.addTails(raw, tails)' in service,
    'OPUS fallback preserved': 'opusAttempt(text)' in service,
    'Google fallback now validated': 'GoogleCeviri.cevir(text)?.takeIf { googleResult ->' in service,
    'Missing detail is retried': 'issue == TranslationQualityGate.Problem.MISSING_DETAIL' in service,
    'Names still shielded before engines': 'NameShield.shield(GoogleSourcePreparation.prepare(text))' in read('OfflineFix.kt'),
    'Character label OCR repair': 'damagedWilliamLabel.replace' in read('SubtitlePreparation.kt'),
    'Both quality checks wired': 'LiveSubtitleQuality10425.defect(s, t)' in gate,
    'DeepL raw benchmark path intact': 'DeepLCeviri.translate(case.source' in read('EngineBenchmark1035.kt'),
    'Model removal functionality retained': 'MODEL' in read('ModelSetup.kt').upper() and 'opus' in read('ModelSetup.kt').lower(),
    'Current engine displayed in diagnostics': 'motor:$chain' in service,
}
for name, ok in checks.items():
    if not ok: raise AssertionError(name)
print(f'{len(checks)}/{len(checks)} 10.42.5 integration assertions passed')
