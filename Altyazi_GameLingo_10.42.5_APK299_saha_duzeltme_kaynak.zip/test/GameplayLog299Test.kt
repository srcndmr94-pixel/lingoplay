package com.example.altyazi

fun main() {
    var passes = 0
    fun checkCase(label: String, value: Boolean) {
        check(value) { "FAILED: $label" }
        passes++
    }
    val repair = GameplayLogRepair299::repairOcr
    checkCase("time OCR", repair("Ata time this dangerous... they went out?") ==
        "At a time this dangerous... they went out?")
    checkCase("not 'Ata' proper name", repair("Ata went to the lake.") == "Ata went to the lake.")
    checkCase("fallen souls in Blight", repair("The souls of our fatten now retun to the Blight!") ==
        "The souls of our fallen now return to the Blight!")
    checkCase("real fatten untouched", repair("They fatten the cattle.") == "They fatten the cattle.")
    checkCase("real return untouched", repair("We will retun tomorrow") == "We will retun tomorrow")
    checkCase("Sha Chi", repair("Sha Chi unleased... It sends the Perfect Transcension fighters") ==
        "Sha-Chi unleashed... It sends the Perfect Transcension fighters")
    checkCase("Std combo", repair("Standand Combo") == "Standard Combo")
    checkCase("normal standard", repair("Standard Combo") == "Standard Combo")
    checkCase("unleashed after", repair("Can be unieasned otter any swing during a Standand Combo") ==
        "Can be unleashed after any swing during a Standard Combo")
    checkCase("unrelated otter", repair("An otter swam by.") == "An otter swam by.")
    checkCase("temper verb", repair("There to tem per this sword's soul.") ==
        "There to temper this sword's soul.")
    checkCase("broken IH", repair("IH can't explain it...") == "I can't explain it...")
    checkCase("letter abbreviation IH unmodified", repair("The IH engine is ready.") == "The IH engine is ready.")
    checkCase("joined I'mused", repair("I'mused to the wind.") == "I'm used to the wind.")
    checkCase("drop unusable char tail", GameplayLogRepair299.waitForCleanReading(
        "Press after dodging or while sprinting to charge thg"))
    checkCase("drop chopped ability", GameplayLogRepair299.waitForCleanReading(
        "Can be unleashed after any swing during a Standard"))
    checkCase("drop terrible OCR", GameplayLogRepair299.waitForCleanReading(
        "Can be unieasned otter any swing, Witti enogi Sla CHi, Jtfarkwith"))
    checkCase("keep clean menu sentence", !GameplayLogRepair299.waitForCleanReading(
        "These attacks convert HP into Recoverable HP and deal damage"))
    checkCase("protected gameplay sentence", GameplayLogRepair299.isGameplayInstruction(
        "These attacks convert HP into Recoverable HP and deal damage"))
    checkCase("skip controller text", !GameplayLogRepair299.isGameplayInstruction("O Move @ Zoom"))
    checkCase("keep valid speaker", GameplayLogRepair299.plausibleSpeakerName("Daoist Bi Di"))
    checkCase("keep valid other speaker", GameplayLogRepair299.plausibleSpeakerName("Archer Captain"))
    checkCase("reject OCR fake speaker", !GameplayLogRepair299.plausibleSpeakerName("WU Xra H"))
    checkCase("reject giant prefix", !GameplayLogRepair299.plausibleSpeakerName("Some Long Speaker Title With Five Words"))
    checkCase("repair Bronze Essence", GameplayLogRepair299.repairTranslation(
        "Bronze Essence there to temper this sword's soul", "Bronze ve Essence'ü bulabilirsin") ==
        "Bronze Essence'i bulabilirsin")
    checkCase("never change unrelated Bronze", GameplayLogRepair299.repairTranslation(
        "A bronze sword", "Bronze ve Essence'ü bulabilirsin") == "Bronze ve Essence'ü bulabilirsin")
    checkCase("repair Sha Chi", GameplayLogRepair299.repairTranslation(
        "Sha Chi unleashed", "Sha ve Chi'ü serbest bırak") == "Sha-Chi'yi serbest bırak")
    checkCase("repair named title", GameplayLogRepair299.repairTranslation(
        "Perfect Transcension fighters", "Perfect ve Transcension savaşçıları") == "Perfect Transcension savaşçıları")
    checkCase("soul temper menu", GameplayLogRepair299.verifiedUiLabel("Soul Temper Leave") == "Ruh Tavlama · Ayrıl")
    checkCase("soul temper with cost", GameplayLogRepair299.verifiedUiLabel("8 Soul Temper") == "8 Ruh Tavlama")
    checkCase("no menu override other sentence", GameplayLogRepair299.verifiedUiLabel("We must temper the soul") == null)
    checkCase("do not touch profanity", GameplayLogRepair299.repairTranslation("Yo, what the fuck?", "Bu ne lan?") == "Bu ne lan?")
    // Verify that the actual shipped OCR stage invokes these repairs.
    checkCase("production OCR repair", SubtitlePreparation.repair("Ata time this dangerous...") == "At a time this dangerous...")
    checkCase("production confidence guard", !SubtitlePreparation.confidentFirstRead(
        "Press after dodging or while sprinting to charge thg"))
    println("PASS $passes APK-299 log regressions")
}
