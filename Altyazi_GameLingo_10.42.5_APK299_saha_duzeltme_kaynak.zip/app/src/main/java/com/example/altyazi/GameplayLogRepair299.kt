package com.example.altyazi

/**
 * 10.42.5 / APK-299 saha kaydına dayalı dar kapsamlı OCR ve çıktı düzeltmeleri.
 * Buradaki kurallar motor seçmez, yeni altyazı üretmez ve bilinmeyen
 * eksik kelimeleri tahmin etmez. Sadece iki tarafta da açık kanıt bulunan
 * teknik terim/parçalanma sorunlarına dokunur.
 */
object GameplayLogRepair299 {
    private val ocrFixes = listOf(
        // Her kural yalnız kayıtla doğrulanan cümle parçasında çalışır.
        Regex("(?i)^Ata time(?=\\s+this\\s+dangerous\\b)") to "At a time",
        Regex("(?i)\\bsouls\\s+of\\s+our\\s+fatten\\b") to "souls of our fallen",
        Regex("(?i)\\bretun(?=\\s+to\\s+the\\s+Blight\\b)") to "return",
        Regex("(?i)\\bSha[ -]Chi\\s+unleased\\b") to "Sha-Chi unleashed",
        Regex("(?i)\\bunieasned\\s+otter(?=\\s+any\\s+swing\\b)") to "unleashed after",
        Regex("(?i)\\bStandand(?=\\s+Combo\\b|\\s*$)") to "Standard",
        Regex("(?i)\\btem\\s+per(?=\\s+this\\s+sword['’]s\\s+soul\\b)") to "temper",
        Regex("(?i)\\bIH(?=\\s+can['’]t\\s+explain\\s+it\\b)") to "I",
        Regex("(?i)^I['’]mused(?=\\s+to\\s+the\\s+wind\\b)") to "I'm used"
    )

    fun repairOcr(text: String): String {
        var fixed = text
        for ((pattern, replacement) in ocrFixes) fixed = pattern.replace(fixed, replacement)
        return fixed
    }

    /** Bir sonraki OCR karesini bekle; bozuk metni çevirip hafızaya yazma. */
    fun waitForCleanReading(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        // Bunlar gerçek saha logunda kopmuş veya ağır biçimde bozulmuştu.
        if (Regex("(?i)\\b(?:witti\\s+enogi|jtfarkwith|hdtd\\s+bieak|ineroa|inrrea)\\b")
                .containsMatchIn(t)) return true
        if (Regex("(?i)\\bcharge\\s+thg\\s*$").containsMatchIn(t)) return true
        if (Regex("(?i)\\bcan be unleashed after any swing during a Standard\\s*$")
                .containsMatchIn(t)) return true
        // Gerçek yetenek metni, ancak OCR'nin yarım bıraktığı son kelimeyi uyduramayız.
        if (Regex("(?i)\\b(?:deal|restore)\\s+ineroa\\s*$").containsMatchIn(t)) return true
        return false
    }

    /** Süsleme süzgeci teknik oyun açıklamalarını çöp sanmamalı. */
    fun isGameplayInstruction(text: String): Boolean =
        Regex("(?i)^\\s*(?:These attacks convert HP|Press after dodging|Reduces damage taken|Can be unleashed after|Switching to this weapon|The Order maintains a tavern)\\b")
            .containsMatchIn(text)

    /** Hatalı OCR'den sahte konuşmacı öğrenilmesini azaltır. */
    fun plausibleSpeakerName(name: String): Boolean {
        val words = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 4 || name.length > 32) return false
        // "WU Xra H" gibi tek harfli OCR kırıntılarını ada dönüştürme.
        return words.all { w ->
            val cleaned = w.trimEnd('.')
            cleaned.length >= 2 && cleaned.first().isUpperCase() &&
                cleaned.all { it.isLetter() || it == '\'' || it == '’' }
        }
    }

    /** Tekrar eden oyun menüsü etiketleri. Sadece tam eşleşmeye uygulanır. */
    fun verifiedUiLabel(source: String): String? = when (source.trim()) {
        "Soul Temper Leave" -> "Ruh Tavlama · Ayrıl"
        "8 Soul Temper" -> "8 Ruh Tavlama"
        else -> null
    }

    /** Kaynak iki kelimelik oyun terimiyse modelin ürettiği yapay 've' bağını düzelt. */
    fun repairTranslation(source: String, translated: String): String {
        var out = translated
        if (Regex("(?i)\\bBronze Essence\\b").containsMatchIn(source)) {
            out = out.replace(Regex("(?iu)\\bBronze\\s+ve\\s+Essence(?:['’](?:ü|u|i|yi|yü))?"), "Bronze Essence'i")
        }
        if (Regex("(?i)\\bSha[ -]Chi\\b").containsMatchIn(source)) {
            out = out.replace(Regex("(?iu)\\bSha\\s+ve\\s+Chi(?:['’](?:ü|u|i|yi|yü))?"), "Sha-Chi'yi")
        }
        if (Regex("(?i)\\bPerfect Transcension\\b").containsMatchIn(source)) {
            out = out.replace(Regex("(?iu)\\bPerfect\\s+ve\\s+Transcension\\b"), "Perfect Transcension")
        }
        return out
    }
}
