package com.example.altyazi

/**
 * Conservative lexical disambiguation of unmistakable literal MT errors.
 * Not a translation model: only edits a problematic Turkish fragment when
 * both the English source and the literal output independently match.
 * Never alters the English OCR text or a model's already-natural result.
 */
object DialogueDisambiguation1038 {
    private val tagQuestion = Regex("""(?i)(?:[.!?]\s+|,\s*)right\?\s*$""")
    private val literalRight = Regex("""(?iu)\bsağ\s*\?$""")
    private val untranslatedNerd = Regex("""(?iu)\b(?:poindexter|pointexter)(?:['’]sın)?\b""")
    private val birdsBees = Regex("""(?iu)kuşlar\s+ve\s+arılar""")
    private val sororityLiteral = Regex("""(?iu)kardeşlik\s+kızı""")

    fun repair(source: String, translated: String): String {
        if (source.isBlank() || translated.isBlank()) return translated
        var result = translated
        if (tagQuestion.containsMatchIn(source)) {
            result = result.replace(literalRight, "değil mi?")
            result = result.replace(Regex("""(?iu)\.\s+değil mi\?$"""), ", değil mi?")
        }
        if (Regex("""(?i)\bpoindexter\b""").containsMatchIn(source)) {
            // A proper name is never replaced unless the source literally
            // identifies the slang noun poindexter.
            result = result.replace(untranslatedNerd) { m ->
                if (m.value.endsWith("sın", ignoreCase = true)) "ineksin" else "inek"
            }
        }
        if (Regex("""(?i)\bbirds\s+and\s+the\s+bees\b""").containsMatchIn(source)) {
            result = result.replace(birdsBees, "cinsellik")
        }
        if (Regex("""(?i)\bsorority\s+girl\b""").containsMatchIn(source)) {
            result = result.replace(sororityLiteral, "öğrenci topluluğundaki kız")
        }
        return result
    }
}
